"""Tests for xml_parser helpers and TallyClient request/response handling."""

import os
import unittest
import xml.etree.ElementTree as ET
from decimal import Decimal

from tally_connector.tally_client import (
    TallyClient,
    TallyError,
    build_daybook_request,
    build_voucher_collection_request,
    split_date_range,
)
from tally_connector.xml_parser import (
    TallyParseError,
    decode_tally_bytes,
    element_to_value,
    extract_masters,
    extract_tally_errors,
    extract_vouchers,
    parse_amount,
    parse_credit_period,
    parse_quantity,
    parse_rate,
    parse_tally_date,
    parse_xml,
    round2,
    sanitize_xml,
    text_of,
    value_to_element,
)

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


def read_fixture(name):
    with open(os.path.join(FIXTURES, name), "rb") as fh:
        return fh.read()


class SanitizeAndDecodeTests(unittest.TestCase):
    def test_removes_invalid_char_refs_and_raw_controls(self):
        cleaned = sanitize_xml("<A>x&#4;y\x04z&#9;&#x1F;</A>")
        self.assertEqual(cleaned, "<A>xyz&#9;</A>")

    def test_escapes_bare_ampersands_and_unknown_entities(self):
        root = parse_xml("<A>Delhi Foam & Fabric &nbsp;</A>")
        self.assertEqual(root.text, "Delhi Foam & Fabric &nbsp;")

    def test_primary_parent_prefix(self):
        root = parse_xml("<GROUP><PARENT>&#4; Primary</PARENT></GROUP>")
        self.assertEqual(text_of(root, "PARENT"), "Primary")

    def test_utf16_with_bom(self):
        data = '<?xml version="1.0" encoding="UTF-16"?><ENVELOPE><A>₹ 5</A></ENVELOPE>'.encode("utf-16")
        root = parse_xml(data)
        self.assertEqual(text_of(root, "A"), "₹ 5")

    def test_utf16_le_without_bom(self):
        data = "<ENVELOPE><A>Kirti Nagar</A></ENVELOPE>".encode("utf-16-le")
        self.assertEqual(decode_tally_bytes(data), "<ENVELOPE><A>Kirti Nagar</A></ENVELOPE>")
        self.assertEqual(text_of(parse_xml(data), "A"), "Kirti Nagar")

    def test_utf8_bom(self):
        data = b"\xef\xbb\xbf<A>ok</A>"
        self.assertEqual(parse_xml(data).text, "ok")

    def test_undeclared_namespace_prefix(self):
        root = parse_xml('<VOUCHER><UDF:SALESMAN.LIST DESC="`Salesman`"><UDF:SALESMAN>Ravi</UDF:SALESMAN>'
                         '</UDF:SALESMAN.LIST></VOUCHER>')
        self.assertEqual(root[0].tag, "UDF_SALESMAN.LIST")
        self.assertEqual(root[0][0].text, "Ravi")

    def test_non_xml_raises(self):
        with self.assertRaises(TallyParseError):
            parse_xml(b"Unknown Request, cannot be processed")
        with self.assertRaises(TallyParseError):
            parse_xml(b"")

    def test_multiple_roots_are_wrapped(self):
        root = parse_xml("<VOUCHER><DATE>20260901</DATE></VOUCHER><VOUCHER><DATE>20260902</DATE></VOUCHER>")
        self.assertEqual(len(extract_vouchers(root)), 2)


class ValueHelperTests(unittest.TestCase):
    def test_amounts(self):
        self.assertEqual(parse_amount("1,18,000.00"), Decimal("118000.00"))
        self.assertEqual(parse_amount("-118000.00"), Decimal("-118000.00"))
        self.assertEqual(parse_amount("5,000.00 Dr"), Decimal("-5000.00"))
        self.assertEqual(parse_amount("5000 Cr"), Decimal("5000"))
        self.assertEqual(parse_amount("(250.50)"), Decimal("-250.50"))
        self.assertEqual(parse_amount("₹ 1,000"), Decimal("1000"))
        self.assertEqual(parse_amount("USD 100 @ 83.00/USD = 8300.00"), Decimal("8300.00"))
        self.assertEqual(parse_amount(""), Decimal("0"))
        self.assertEqual(parse_amount(None), Decimal("0"))
        with self.assertRaises(ValueError):
            parse_amount("abc")

    def test_round2(self):
        self.assertEqual(round2(Decimal("2.345")), Decimal("2.35"))
        self.assertEqual(round2(Decimal("-2.345")), Decimal("-2.35"))

    def test_dates(self):
        self.assertEqual(parse_tally_date("20260901"), "2026-09-01")
        self.assertEqual(parse_tally_date("2026-09-01"), "2026-09-01")
        self.assertEqual(parse_tally_date("01-09-2026"), "2026-09-01")
        self.assertEqual(parse_tally_date("1-Sep-2026"), "2026-09-01")
        self.assertEqual(parse_tally_date("1-Sep-26"), "2026-09-01")
        self.assertEqual(parse_tally_date("20261301"), "")
        self.assertEqual(parse_tally_date(""), "")

    def test_quantities_and_rates(self):
        self.assertEqual(parse_quantity(" 2 Nos"), (Decimal("2"), "Nos"))
        self.assertEqual(parse_quantity("2.000 Pairs"), (Decimal("2.000"), "Pairs"))
        self.assertEqual(parse_quantity("2 Nos = 24 Pcs"), (Decimal("2"), "Nos"))
        self.assertEqual(parse_quantity(""), (Decimal("0"), ""))
        self.assertEqual(parse_rate("50000.00/Nos"), (Decimal("50000.00"), "Nos"))
        self.assertEqual(parse_rate("₹ 1,250.50/Pairs"), (Decimal("1250.50"), "Pairs"))

    def test_credit_period(self):
        el = ET.fromstring('<BILLCREDITPERIOD JD="46295" P="30 Days">30 Days</BILLCREDITPERIOD>')
        self.assertEqual(parse_credit_period(el), (30, ""))
        self.assertEqual(parse_credit_period("45"), (45, ""))
        self.assertEqual(parse_credit_period("15-Oct-2026", "2026-09-15"), (30, "2026-10-15"))
        self.assertEqual(parse_credit_period(""), (None, ""))

    def test_dict_roundtrip(self):
        el = ET.fromstring('<VOUCHER VCHTYPE="Receipt"><DATE>20260915</DATE>'
                           '<L><N>a</N></L><L><N>b</N></L></VOUCHER>')
        value = element_to_value(el)
        self.assertEqual(value["@VCHTYPE"], "Receipt")
        self.assertEqual(value["L"], [{"N": "a"}, {"N": "b"}])
        back = value_to_element("VOUCHER", value)
        self.assertEqual(back.get("VCHTYPE"), "Receipt")
        self.assertEqual([text_of(c, "N") for c in back if c.tag == "L"], ["a", "b"])


class FixtureParsingTests(unittest.TestCase):
    def test_daybook_vouchers_found_anywhere(self):
        root = parse_xml(read_fixture("daybook_sample.xml"))
        vouchers = extract_vouchers(root)
        self.assertEqual(len(vouchers), 5)
        self.assertEqual([text_of(v, "VOUCHERNUMBER") for v in vouchers],
                         ["AC/S/0001", "AC/R/0031", "AC/P/0012", "AC/J/0007", "AC/J/0008"])
        self.assertEqual(extract_tally_errors(root), [])

    def test_masters_fixture(self):
        masters = extract_masters(parse_xml(read_fixture("masters_sample.xml")))
        self.assertEqual(len(masters["groups"]), 6)
        self.assertEqual(len(masters["ledgers"]), 10)
        self.assertEqual(len(masters["voucher_types"]), 7)
        self.assertEqual(len(masters["stock_items"]), 1)
        self.assertEqual(len(masters["cost_centres"]), 2)

    def test_collection_wrapper_vouchers(self):
        xml = ("<ENVELOPE><BODY><DATA><COLLECTION><VOUCHER><DATE>20260901</DATE></VOUCHER>"
               "</COLLECTION></DATA></BODY></ENVELOPE>")
        self.assertEqual(len(extract_vouchers(parse_xml(xml))), 1)

    def test_line_error_detected(self):
        xml = ("<ENVELOPE><HEADER><VERSION>1</VERSION><STATUS>0</STATUS></HEADER><BODY><DATA>"
               "<LINEERROR>Could not set 'SVCurrentCompany' to 'Demo Company'</LINEERROR>"
               "</DATA></BODY></ENVELOPE>")
        errors = extract_tally_errors(parse_xml(xml))
        self.assertEqual(len(errors), 1)
        self.assertIn("SVCurrentCompany", errors[0])


class _FakeResponse:
    def __init__(self, body):
        self._body = body

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _FakeOpener:
    def __init__(self, bodies=None, error=None):
        self.bodies = list(bodies or [])
        self.error = error
        self.requests = []

    def open(self, request, timeout=None):
        self.requests.append(request)
        if self.error is not None:
            raise self.error
        return _FakeResponse(self.bodies.pop(0))


class TallyClientTests(unittest.TestCase):
    def test_voucher_request_is_valid_xml_with_escaped_company_and_filters(self):
        xml = build_voucher_collection_request("A & B Furniture", "2026-04-01", "2026-09-30",
                                               min_alter_id=1234, voucher_type="Sales GST")
        self.assertIn("<SVCURRENTCOMPANY>A &amp; B Furniture</SVCURRENTCOMPANY>", xml)
        self.assertIn("<SVFROMDATE>20260401</SVFROMDATE>", xml)
        self.assertIn("<SVTODATE>20260930</SVTODATE>", xml)
        self.assertIn("$AlterID &gt; 1234", xml)
        self.assertIn('$VoucherTypeName = "Sales GST"', xml)
        root = ET.fromstring(xml)
        self.assertEqual(root.find("HEADER/TYPE").text, "Collection")
        self.assertEqual(root.find("BODY/DESC/TDL/TDLMESSAGE/COLLECTION/TYPE").text, "Voucher")

    def test_daybook_request(self):
        root = ET.fromstring(build_daybook_request("Demo Company", "2026-09-01", "2026-09-30"))
        self.assertEqual(root.find("HEADER/ID").text, "Day Book")
        self.assertEqual(root.find("BODY/DESC/STATICVARIABLES/EXPLODEFLAG").text, "Yes")

    def test_split_date_range(self):
        from datetime import date
        chunks = split_date_range(date(2026, 4, 1), date(2026, 5, 15), 31)
        self.assertEqual(chunks, [(date(2026, 4, 1), date(2026, 5, 1)), (date(2026, 5, 2), date(2026, 5, 15))])

    def test_company_not_open_error(self):
        body = (b"<ENVELOPE><HEADER><STATUS>0</STATUS></HEADER><BODY><DATA><LINEERROR>"
                b"Could not set 'SVCurrentCompany' to 'Demo Company'</LINEERROR></DATA></BODY></ENVELOPE>")
        client = TallyClient("http://localhost:9000", "Demo Company", opener=_FakeOpener([body]))
        with self.assertRaises(TallyError) as ctx:
            client.fetch_masters()
        self.assertIn("not open in Tally", str(ctx.exception))

    def test_connection_unavailable_after_retries(self):
        opener = _FakeOpener(error=ConnectionRefusedError("refused"))
        client = TallyClient("http://localhost:9000", "Demo Company", retries=2, opener=opener,
                             sleep=lambda s: None)
        with self.assertRaises(TallyError) as ctx:
            client.ping()
        self.assertIn("Tally connection unavailable", str(ctx.exception))
        self.assertEqual(len(opener.requests), 3)

    def test_fetch_vouchers_filters_client_side(self):
        body = read_fixture("daybook_sample.xml")
        client = TallyClient("http://localhost:9000", "Demo Company", export_mode="daybook",
                             chunk_days=400, opener=_FakeOpener([body]))
        vouchers = client.fetch_vouchers("2026-09-01", "2026-09-30", min_alter_id=5005)
        self.assertEqual([text_of(v, "VOUCHERNUMBER") for v in vouchers], ["AC/R/0031", "AC/J/0007", "AC/J/0008"])

    def test_ping_lists_companies(self):
        body = (b'<ENVELOPE><BODY><DATA><COLLECTION><COMPANY NAME="Demo Company"><NAME>Demo Company'
                b'</NAME></COMPANY></COLLECTION></DATA></BODY></ENVELOPE>')
        client = TallyClient("http://localhost:9000", "acctdash furniture", opener=_FakeOpener([body]))
        info = client.ping()
        self.assertTrue(info["company_open"])
        self.assertEqual(info["companies"], ["Demo Company"])


if __name__ == "__main__":
    unittest.main()
