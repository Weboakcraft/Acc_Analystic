# Tally integration

```
Tally (XML server :9000)
  ↓  inline-TDL collection export (vouchers filtered by $AlterID; masters)
Python connector  (backend/python/tally_connector)
  ↓  xml_parser     - sanitise control chars, UTF-8/UTF-16, find VOUCHER elements anywhere (Collection or Day Book)
  ↓  normalizer     - normalize_tally_voucher(): signs, ledger lines, bills, items, GST, unique_key
  ↓  validators     - Σdebit = Σcredit, ≥2 lines, valid date/type → invalid ones reported, never sent
  ↓  api_client     - batches of 100, retries with backoff, API key
Apps Script  Tally.gs
  ↓  dedupe by unique_key, revision on higher AlterID, auto-ledger for unknowns (flagged), registers, raw XML
Google Sheets → Engine → web app
```

## Tally facts the normalizer handles
- **Sign convention:** in ledger entries a *negative* `AMOUNT` is a **debit** and a positive one a credit. `ISDEEMEDPOSITIVE=Yes` also means debit. The amount sign wins, and a disagreement is logged as a warning.
- **Invoice-mode vouchers:** the sales/purchase ledger amount sits inside `ALLINVENTORYENTRIES.LIST → ACCOUNTINGALLOCATIONS.LIST`, not in `ALLLEDGERENTRIES.LIST`. Both are collected, without double counting.
- **Bill-wise details:** `BILLALLOCATIONS.LIST` gives `NAME`, `BILLTYPE` (New Ref / Agst Ref / Advance / On Account), `AMOUNT` and `BILLCREDITPERIOD` ("30 Days"). Due date = bill date + credit days.
- **Status:** `ISCANCELLED` → CANCELLED, `ISOPTIONAL` → OPTIONAL. Both are excluded from the books by default.
- **Custom voucher types** (e.g. "Sales GST") resolve to a base type through the VoucherType master's `PARENT` chain.
- **GST heads** come from ledger masters (`GSTDUTYHEAD`: Central Tax → CGST, State/UT Tax → SGST, Integrated Tax → IGST, Cess), with a name-pattern fallback.
- **Opening balances:** negative = Dr.

## Normalized record (flat form, `to_flat_transactions`)
Transaction ID · Voucher ID (unique_key) · Voucher Number · Voucher Type · Voucher Date · Company · Ledger · Party · Debit · Credit · Amount · Reference · Due Date · GST · Taxable Amount · Narration · Source (TALLY) · Sync Timestamp.

## Sync modes
| Mode | CLI | Use |
|---|---|---|
| Incremental | `sync --mode incremental` | Default and automatic. Pulls vouchers with AlterID above the server watermark (max stored `tally_alter_id`) |
| Full | `sync --mode full` | Complete re-read from `from_date`; also marks vouchers deleted in Tally as DELETED_IN_TALLY |
| Date range | `sync --mode date --from --to` | Re-read a period (also reconciles deletions within it) |
| Voucher | `sync --mode voucher --voucher-type --voucher-number` | One type or voucher |
| Ledger | `sync --mode ledger --ledger` | Vouchers touching one ledger |
| Masters | `sync --mode masters` | Groups, ledgers, voucher types, stock items, cost centres |
| Watch | `watch` | Automatic incremental sync every interval, plus web "Sync now" requests |

## Duplicate prevention
- Key: `GUID:<guid>`. When Tally omits the GUID, `KEY:<company|voucher type|voucher number|date>` (lower-case).
- Same key and same or lower AlterID → skipped (counted in `records_skipped`).
- Higher AlterID → new revision; old lines are kept for history.
- Every run is logged in `TALLY_SYNC_LOG` (start/end, fetched/added/updated/skipped/failed, status, error, connector host). Failures are logged in `TALLY_ERRORS` and raise alerts.

## Caveat
The XML request formats follow Tally's documented XML interface, but they have **not yet been run against a live Tally** from this build. Run `test-connection` and a `MASTERS` sync first. If vouchers come back incomplete, set `export_mode = daybook` in `config.ini` to use the Day Book export instead.
