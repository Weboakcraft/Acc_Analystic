# Accounts Dashboard - Tally-integrated accounting & financial management

A web accounting platform that sits on top of **Tally**. It merges Tally vouchers and **offline sales** into one set of double-entry books, then turns them into receivables, payables, ageing, GST, trial balance, P&L, balance sheet, cash flow, MIS, analytics and automated alerts.

- **Frontend:** HTML/CSS/JavaScript + Chart.js, deployed on GitHub Pages (`frontend/`)
- **API & business logic:** Google Apps Script (`backend/apps-script/`)
- **Database:** Google Sheets, 42 tables (`database/schema.json`), replaceable by PostgreSQL/MySQL
- **Tally connector:** Python, on-premise (`backend/python/`)
- **Accounting engine:** one pure JS file shared by backend and browser (`shared/accounting-engine.js`)
- **Java:** reserved for the scale-out API/gateway (`backend/java/README.md`)

## Try it in 1 minute (demo mode)
With `API_URL` empty in `frontend/js/config.js`, the app runs on generated demo books with no backend.
```bash
powershell -ExecutionPolicy Bypass -File tools\serve.ps1
```
Open http://localhost:8080, pick a role, and explore. To reset demo data, use the user menu â†’ Reset demo data.

## Deploy for real
Follow [documentation/DEPLOYMENT.md](documentation/DEPLOYMENT.md): Sheet â†’ Apps Script (menu â†’ *Initialize database*) â†’ first admin â†’ GitHub Pages â†’ Tally connector.

## Repository
```
accounting-system/
â”œâ”€ frontend/                 GitHub Pages site (single-page app)
â”‚  â”œâ”€ index.html
â”‚  â”œâ”€ css/app.css            design tokens, light/dark, print layouts
â”‚  â””â”€ js/
â”‚     â”œâ”€ config.js           API_URL (the only file to edit)
â”‚     â”œâ”€ api.js              Remote adapter (Apps Script) + Demo adapter
â”‚     â”œâ”€ engine.js           generated copy of shared/accounting-engine.js
â”‚     â”œâ”€ ui.js               tables, charts, modals, exports (Excel/CSV/Print-PDF)
â”‚     â”œâ”€ app.js              login, role-based navigation, router, global search
â”‚     â””â”€ pages-*.js          26 screens
â”œâ”€ backend/
â”‚  â”œâ”€ apps-script/           Code, Routes, Auth, Db, Setup, Services, Tally, Automation, Schema*, Engine*
â”‚  â”œâ”€ python/                Tally connector (fetch Â· parse Â· normalize Â· validate Â· sync Â· watch) + tests
â”‚  â””â”€ java/                  architecture note for the scale-out service
â”œâ”€ shared/accounting-engine.js   double-entry engine (single source)
â”œâ”€ database/
â”‚  â”œâ”€ schema.json            single source for all 42 tables (headers, types, dropdowns, sample rows)
â”‚  â””â”€ csv/                   generated header + sample-row templates
â”œâ”€ tests/                    engine test suite (browser or Node)
â”œâ”€ tools/                    build.py / build.ps1 (generate Schema.gs, Engine copies, CSVs, DATABASE.md), serve.ps1
â””â”€ documentation/            ARCHITECTURE, DATABASE, API, TALLY_INTEGRATION, DEPLOYMENT, TESTING
```
`*` = generated. After editing `database/schema.json` or `shared/accounting-engine.js`, run `python tools/build.py` (or `tools\build.ps1`).

## Documentation
| Doc | Contents |
|---|---|
| [ARCHITECTURE](documentation/ARCHITECTURE.md) | System architecture, modules, data model, accounting rules and every configurable ambiguity, security, performance, roadmap |
| [DATABASE](documentation/DATABASE.md) | Every sheet, column, type, dropdown and sample value (generated) |
| [API](documentation/API.md) | All endpoints, params, permissions, roles |
| [TALLY_INTEGRATION](documentation/TALLY_INTEGRATION.md) | Connector pipeline, Tally XML rules, sync modes, duplicate prevention |
| [DEPLOYMENT](documentation/DEPLOYMENT.md) | Sheets, Apps Script, GitHub Pages, Tally setup, roles, security, backup, troubleshooting |
| [TESTING](documentation/TESTING.md) | Automated suites and UAT cases for every module |

## Status
Built: phases 1-7 plus the deployment guide.
Verified in this build: the engine test suite (25/25), all 26 screens loading in demo mode, and an end-to-end offline sale with the books still balancing.
The Apps Script backend passed a 30-check smoke test against mocked Google services.
Not yet run: the backend on a real Google Sheet, and the Python connector against a live Tally (no Python on the build machine). Do these first, per DEPLOYMENT.md and TESTING.md.

GST figures are indicative summaries derived from the books, not tax advice.
