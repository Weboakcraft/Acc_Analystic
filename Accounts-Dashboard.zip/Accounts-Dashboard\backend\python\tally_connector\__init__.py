"""Accounts Dashboard - on-premise Tally connector.

Pulls vouchers and masters from Tally Prime / Tally ERP 9 over its XML HTTP
server, validates and normalizes them, and pushes them to the Accounts Dashboard
Google Apps Script web app.
"""

__version__ = "1.0.0"

__all__ = ["__version__"]
