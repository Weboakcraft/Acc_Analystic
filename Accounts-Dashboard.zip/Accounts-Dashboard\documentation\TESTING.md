# Testing

## Automated suites

| Suite | Run | Covers |
|---|---|---|
| Accounting engine (25 tests) | Open `tests/engine-tests.html` in a browser (serve the repo: `tools\serve.ps1 -Root . -Port 8081`, then http://localhost:8081/tests/engine-tests.html), or `node -e "global.Engine=require('./shared/accounting-engine.js');require('./tests/engine.spec.js').run()"` | Sales, receipts, payment status, FIFO allocation, ageing, vendor ledgers, trial balance, unbalanced detection, opening differences, revisions/cancellations, P&L, balance sheet, retained earnings, cash flow, GST, offline sales, ledger statement, duplicate numbers, FY periods |
| Apps Script backend smoke test (30 checks) | `tests/backend-smoke.html` via the same server | The real `.gs` files run against in-memory mocks of SpreadsheetApp/Properties/Cache/Lock/Utilities: idempotent `initializeDatabase`, login and lockout, token checks, offline sale posting, duplicate/invalid invoices, connector auth, Tally sync (add, duplicate skip, alteration → revision, unbalanced rejection, unknown ledger, deletion reconcile, log counters), all 36 read endpoints, expense approval, formula-injection guard, settings, audit, alert scan and snapshots |
| Tally connector | `cd backend\python` then `python -m unittest discover -s tests -v` | XML parsing and sanitising, sign conventions, invoice-mode ledger collection, bills and due dates, items, GST summary, unique keys, unbalanced rejection, batching, reconcile keys, pending requests |

Last runs: engine suite **25/25 passed**, backend smoke test **30/30 passed**. The mock doesn't cover real Google quotas, triggers, e-mail delivery or formatting, so do one pass on a real Sheet as well. The Python suite has **not been run yet** (Python was not available on the build machine).

## UAT test cases

Run these in demo mode first, then against a copy of the real Sheet. "Books tie" means: Trial Balance shows *Balanced*, and Balance Sheet shows *Balanced*.

### Sales
| # | Steps | Expected |
|---|---|---|
| S1 | Sales → Register → This month | Every Tally and offline invoice listed. Total = sum of rows. Tally/Offline split KPIs add up to the total |
| S2 | Open an invoice | Voucher drawer: party Dr = sales Cr + GST Cr, footer shows "Balanced" |
| S3 | Sales → Reports → group by customer / product / salesperson / GST / state / source | Totals equal the register total for the same period |
| S4 | Filter status = Overdue | Only invoices past due with outstanding > 0 |

### Offline sales
| # | Steps | Expected |
|---|---|---|
| O1 | Enter a Delhi customer, 3 chairs × ₹12,000, 5% discount, 18%, UPI ₹20,000 | CGST + SGST 9% each; round-off to the rupee; posted as Sales + Receipt; outstanding = total − 20,000 |
| O2 | Same with an Uttar Pradesh customer | IGST 18%, no CGST/SGST |
| O3 | A new customer name | Customer ledger auto-created under Sundry Debtors and shown in Customers |
| O4 | Post the same invoice number again | "Offline invoice … already exists" |
| O5 | GSTIN `ABC`, qty 0, GST 7% | Rejected with all three errors listed; nothing posted |
| O6 | Payment mode Credit with a paid amount | Rejected |
| O7 | Dashboard after O1 | Today's sales bills +1, offline amount includes the invoice, receipts +20,000 |

### Purchases / payables
| # | Steps | Expected |
|---|---|---|
| P1 | Purchases register | Vendor bills with GST input split, paid and outstanding |
| P2 | Payables → pay a bill (Pay button) | Payment voucher Dr vendor / Cr bank against that bill; bill outstanding falls |
| P3 | MSME vendor bill older than 38 days | "MSME payment limit" alert (45-day rule) |
| P4 | Vendors page | Opening + purchases − debit notes − payments ± adjustments = closing for every vendor |

### Payments / receipts
| # | Steps | Expected |
|---|---|---|
| R1 | New receipt, against bill left blank | Posted On Account; with FIFO, the oldest open bill of that customer reduces |
| R2 | Receipt with TDS ₹1,000 | Dr Bank (amount), Dr TDS Receivable (1,000), Cr customer (amount + 1,000) |
| R3 | Payment to a ledger that doesn't exist | "Ledger … does not exist" |

### Ledger
| # | Steps | Expected |
|---|---|---|
| L1 | Ledgers → a bank ledger → statement for the current FY | Opening + debits − credits = closing; the running balance on the last row = closing |
| L2 | Export Excel / CSV / Print | File or print view matches the screen; CSV opens in Excel with ₹ values as numbers |
| L3 | Income ledger statement from mid-FY | Opening = movement since FY start (income ledgers reset every FY) |

### Receivables & ageing
| # | Steps | Expected |
|---|---|---|
| A1 | Receivables total vs the sum of debtor ledger closing balances (Ledgers, group Sundry Debtors) | Equal |
| A2 | Bucket totals | Sum of buckets + Advance = total |
| A3 | Settings → AGEING_BASIS = BILL_DATE | Buckets recalculated from bill date |
| A4 | Settings → BILL_ALLOCATION_FALLBACK = NONE | Unallocated receipts appear as "On Account (advance)" rows |

### GST
| # | Steps | Expected |
|---|---|---|
| G1 | GST → This month | Output = Σ GST on sales vouchers; input = Σ GST on purchases/expenses |
| G2 | Post a credit note in Tally and sync | Output tax falls by the credit-note tax |
| G3 | GST payment voucher (Dr Output CGST / Cr Bank) | Shown as "GST paid / set-off", **not** as input credit |
| G4 | HSN tab | Taxable value per HSN = item-level taxable values |

### Profit & Loss / Balance Sheet / Cash Flow
| # | Steps | Expected |
|---|---|---|
| F1 | P&L current FY | Gross profit = revenue + direct income − (opening stock + purchases + direct expenses − closing stock); net profit = PBT − tax |
| F2 | Balance sheet as of today | Balanced; "Profit for the period" = P&L net profit for the FY to date |
| F3 | Balance sheet as of a date in the previous FY | Balanced; that year's profit becomes retained earnings in the next FY |
| F4 | Cash flow for any period | Opening + net = closing (green check); a contra between bank and cash does not appear as inflow/outflow |
| F5 | Trial balance | Balanced; any unbalanced voucher is listed; an opening mismatch shows "Difference in opening balances" |

### Tally synchronisation
| # | Steps | Expected |
|---|---|---|
| T1 | `sync --mode masters` | Groups, ledgers, voucher types, stock items, cost centres upserted; customer/vendor profiles created for every debtor/creditor |
| T2 | `sync --mode full` | All vouchers in range added; TALLY_SYNC_LOG row SUCCESS with counts; raw XML in TALLY_RAW_DATA |
| T3 | Alter a voucher amount in Tally, then `sync` (incremental) | Same voucher_id, revision 2; reports use the new amount; audit shows UPDATE with the old and new AlterID |
| T4 | Delete a voucher in Tally, then `sync --mode full` | Voucher marked DELETED_IN_TALLY; it drops out of reports |
| T5 | Stop Tally and run sync | Run FAILED, "Tally connection unavailable" alert raised |
| T6 | Web app → Tally Integration → Sync now | Row REQUESTED → the connector picks it up within `poll_seconds` → SUCCESS |
| T7 | Unbalanced journal in Tally | Rejected into TALLY_ERRORS (UNBALANCED); other vouchers in the batch still import |

### Duplicate detection
| # | Steps | Expected |
|---|---|---|
| D1 | Run the same full sync twice | Second run: added 0, skipped = number fetched |
| D2 | Retry a batch (kill the connector mid-run and rerun) | No duplicate vouchers (unique_key) |
| D3 | Two Tally vouchers of the same type and number in one FY | "Duplicate voucher number" alert |

### Security & roles
| # | Steps | Expected |
|---|---|---|
| X1 | Sign in as Data Entry | Navigation shows only Offline Sales and Expenses; calling `getProfitLoss` returns FORBIDDEN |
| X2 | Accountant approves their own expense | Refused (maker-checker) |
| X3 | Five wrong passwords | Account LOCKED; LOGIN_FAILED entries in the audit log |
| X4 | Customer name `<img src=x onerror=alert(1)>` | Displayed as text, not executed |
| X5 | Narration `=HYPERLINK(...)` | Stored as literal text in the Sheet |
