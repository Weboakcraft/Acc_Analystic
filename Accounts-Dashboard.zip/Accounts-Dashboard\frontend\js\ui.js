/**
 * UI toolkit: formatting, safe HTML, icons, KPI cards, data tables, charts, modals, toasts, exports.
 * All data is inserted through esc() - never raw - so API/Tally content cannot inject markup.
 */
var UI = (function () {
  'use strict';
  var U = Engine.util;

  // ---------- formatting ----------
  var inrFmt = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });
  var inr2Fmt = new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var fmt = {
    inr: function (n) { if (n === null || n === undefined || n === '') return '-'; n = Number(n); return (n < 0 ? '-' : '') + '₹' + inrFmt.format(Math.abs(Math.round(n))); },
    inr2: function (n) { if (n === null || n === undefined || n === '') return '-'; n = Number(n); return (n < 0 ? '-' : '') + inr2Fmt.format(Math.abs(n)); },
    compact: function (n) {
      if (n === null || n === undefined) return '-';
      var a = Math.abs(n), s = n < 0 ? '-' : '';
      if (a >= 1e7) return s + '₹' + (a / 1e7).toFixed(2) + ' Cr';
      if (a >= 1e5) return s + '₹' + (a / 1e5).toFixed(2) + ' L';
      if (a >= 1e3) return s + '₹' + (a / 1e3).toFixed(1) + 'K';
      return s + '₹' + Math.round(a);
    },
    num: function (n, d) { if (n === null || n === undefined || n === '') return '-'; return Number(n).toLocaleString('en-IN', { maximumFractionDigits: d === undefined ? 2 : d }); },
    pct: function (n) { return n === null || n === undefined ? '-' : Number(n).toFixed(1) + '%'; },
    date: function (d) { d = U.D(d); if (!d) return '-'; return d.slice(8, 10) + ' ' + MONTHS[+d.slice(5, 7) - 1] + ' ' + d.slice(0, 4); },
    month: function (m) { m = String(m); return MONTHS[+m.slice(5, 7) - 1] + ' ' + m.slice(2, 4); },
    drcr: function (n) { if (!n) return '0'; return inr2Fmt.format(Math.abs(n)) + (n < 0 ? ' Cr' : ' Dr'); },
    dt: function (s) { return s ? String(s).replace('T', ' ').slice(0, 16) : '-'; }
  };

  function esc(s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function el(html) { var t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }

  // ---------- icons (inline, stroke) ----------
  var ICONS = {
    dashboard: 'M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z', mis: 'M4 19V9M10 19V5M16 19v-7M22 19H2',
    bell: 'M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0', sales: 'M3 3h18v4H3zM5 7v14h14V7M9 11h6',
    offline: 'M4 4h16v12H4zM8 20h8M12 16v4M8 9h8', purchase: 'M6 6h15l-1.5 9h-12zM6 6L5 3H2M9 20a1 1 0 100-2 1 1 0 000 2zM18 20a1 1 0 100-2 1 1 0 000 2z',
    receipt: 'M12 19V5M5 12l7 7 7-7', payment: 'M12 5v14M5 12l7-7 7 7', expense: 'M4 4h16v16H4zM4 9h16M9 4v16',
    users: 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75',
    truck: 'M1 3h15v13H1zM16 8h4l3 3v5h-7M5.5 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM18.5 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',
    in: 'M21 12H3M10 5l-7 7 7 7', out: 'M3 12h18M14 5l7 7-7 7', book: 'M4 19.5A2.5 2.5 0 016.5 17H20V2H6.5A2.5 2.5 0 004 4.5zM4 19.5A2.5 2.5 0 006.5 22H20v-5',
    bank: 'M3 21h18M5 21V10M19 21V10M9 21V10M15 21V10M2 10l10-7 10 7z', scale: 'M12 3v18M5 7h14M5 7l-3 7a4 4 0 006 0zM19 7l-3 7a4 4 0 006 0z',
    pl: 'M3 17l6-6 4 4 8-8M14 7h7v7', bs: 'M3 3h18v18H3zM12 3v18M3 12h18', flow: 'M3 12h4l3-8 4 16 3-8h4', tax: 'M19 5L5 19M6.5 9a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM17.5 20a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',
    box: 'M21 16V8l-9-5-9 5v8l9 5 9-5zM3.3 7L12 12l8.7-5M12 22V12', chart: 'M3 3v18h18M7 14l4-4 3 3 5-6', heart: 'M22 12h-4l-3 9L9 3l-3 9H2',
    sync: 'M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0114.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0020.5 15', audit: 'M9 11l3 3L22 4M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11',
    settings: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z',
    search: 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.35-4.35', plus: 'M12 5v14M5 12h14', download: 'M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3',
    print: 'M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2M6 14h12v8H6z', x: 'M18 6L6 18M6 6l12 12',
    check: 'M20 6L9 17l-5-5', alert: 'M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0zM12 9v4M12 17h.01', info: 'M12 22a10 10 0 100-20 10 10 0 000 20zM12 16v-4M12 8h.01',
    moon: 'M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z', menu: 'M3 12h18M3 6h18M3 18h18', clock: 'M12 22a10 10 0 100-20 10 10 0 000 20zM12 6v6l4 2', external: 'M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3'
  };
  function icon(name) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + (ICONS[name] || ICONS.info) + '"/></svg>'; }

  // ---------- small components ----------
  function kpi(label, value, foot, tone, title) {
    return '<div class="kpi ' + (tone || '') + '"' + (title ? ' title="' + esc(title) + '"' : '') + '><div class="label">' + esc(label) + '</div><div class="value">' + esc(value) + '</div>' + (foot ? '<div class="foot">' + esc(foot) + '</div>' : '') + '</div>';
  }
  var STATUS_TONE = { Paid: 'good', Matched: 'good', Approved: 'good', SUCCESS: 'good', ACTIVE: 'good', Current: 'info', 'Not Due': 'info', 'Partially Paid': 'warn', 'Partially Matched': 'warn', Pending: 'warn', PARTIAL: 'warn', REQUESTED: 'info', RUNNING: 'info', Outstanding: 'warn', Advance: 'info', Overdue: 'bad', Unmatched: 'bad', Rejected: 'bad', FAILED: 'bad', CANCELLED: 'bad', Cancelled: 'bad', ERROR: 'bad', WARNING: 'warn', CRITICAL: 'bad', good: 'good', warn: 'warn', bad: 'bad' };
  var STATUS_ICON = { good: 'check', bad: 'alert', warn: 'clock', info: 'info' };
  function badge(text, tone) { tone = tone || STATUS_TONE[text] || ''; return '<span class="badge ' + tone + '">' + (tone ? icon(STATUS_ICON[tone] || 'info') : '') + esc(text) + '</span>'; }
  function signed(n) { return '<span class="' + (n < 0 ? 'neg' : '') + '">' + fmt.inr(n) + '</span>'; }
  function loading() { return '<div class="loading"><span class="spinner"></span></div>'; }
  function empty(msg) { return '<div class="empty">' + esc(msg || 'No records for the selected filters.') + '</div>'; }
  function errorBox(e) { return '<div class="card"><div class="empty"><b>' + esc(e.message || 'Something went wrong.') + '</b>' + (e.details && e.details.length ? '<ul style="text-align:left;display:inline-block">' + e.details.map(function (d) { return '<li>' + esc(d) + '</li>'; }).join('') + '</ul>' : '') + '</div></div>'; }
  function card(title, body, opts) {
    opts = opts || {};
    return '<div class="card ' + (opts.cls || '') + '"' + (opts.id ? ' id="' + opts.id + '"' : '') + '>' + (title ? '<div class="card-head"><div><h3>' + esc(title) + '</h3>' + (opts.sub ? '<div class="sub">' + esc(opts.sub) + '</div>' : '') + '</div>' + (opts.actions || '') + '</div>' : '') + '<div class="' + (opts.flush ? '' : 'card-body') + '">' + body + '</div></div>';
  }

  // ---------- toasts ----------
  function toast(msg, tone) {
    var box = $('#toasts') || document.body.appendChild(el('<div id="toasts" class="toasts" role="status" aria-live="polite"></div>'));
    var t = el('<div class="toast ' + (tone || '') + '">' + esc(msg) + '</div>');
    box.appendChild(t);
    setTimeout(function () { t.remove(); }, tone === 'bad' ? 7000 : 3500);
  }

  // ---------- modal / drawer ----------
  function modal(opts) {
    var ov = el('<div class="overlay" role="dialog" aria-modal="true"><div class="modal ' + (opts.wide ? 'wide' : '') + '"><div class="modal-head"><h3>' + esc(opts.title) + '</h3><button class="icon-btn" data-close aria-label="Close">' + icon('x') + '</button></div><div class="modal-body">' + opts.body + '</div>' + (opts.foot !== false ? '<div class="modal-foot">' + (opts.foot || '<button class="btn" data-close>Cancel</button><button class="btn primary" data-ok>' + esc(opts.okText || 'Save') + '</button>') + '</div>' : '') + '</div></div>');
    document.body.appendChild(ov);
    function close() { ov.remove(); document.removeEventListener('keydown', onKey); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    ov.addEventListener('click', function (e) { if (e.target === ov || e.target.closest('[data-close]')) close(); });
    var ok = $('[data-ok]', ov);
    if (ok && opts.onOk) ok.addEventListener('click', function () {
      var errBox = $('.errors', ov); if (errBox) errBox.remove();
      ok.disabled = true;
      Promise.resolve().then(function () { return opts.onOk(ov); }).then(function (r) { if (r !== false) close(); }, function (e) {
        ok.disabled = false;
        $('.modal-body', ov).insertAdjacentHTML('afterbegin', '<div class="errors"><b>' + esc(e.message) + '</b>' + (e.details && e.details.length ? '<ul>' + e.details.map(function (d) { return '<li>' + esc(d) + '</li>'; }).join('') + '</ul>' : '') + '</div>');
      }).then(function () { if (ok) ok.disabled = false; });
    });
    if (opts.onOpen) opts.onOpen(ov);
    var first = $('input,select,textarea', ov); if (first) first.focus();
    return { el: ov, close: close };
  }
  function drawer(title, bodyHtml, actions) {
    var ov = el('<div><div class="overlay" style="z-index:60"></div><aside class="drawer" role="dialog" aria-modal="true"><div class="drawer-head"><h3>' + esc(title) + '</h3><div class="actions">' + (actions || '') + '<button class="icon-btn" data-close aria-label="Close">' + icon('x') + '</button></div></div><div class="drawer-body">' + bodyHtml + '</div></aside></div>');
    document.body.appendChild(ov);
    function close() { ov.remove(); document.removeEventListener('keydown', onKey); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    ov.addEventListener('click', function (e) { if (e.target.classList.contains('overlay') || e.target.closest('[data-close]')) close(); });
    return { el: ov, body: $('.drawer-body', ov), close: close };
  }
  function formData(root) {
    var o = {};
    $$('[name]', root).forEach(function (i) { o[i.name] = i.type === 'checkbox' ? i.checked : i.value.trim(); });
    return o;
  }
  function field(label, input, hint, cls) { return '<div class="field ' + (cls || '') + '"><label>' + esc(label) + '</label>' + input + (hint ? '<div class="hint">' + esc(hint) + '</div>' : '') + '</div>'; }
  function input(name, value, attrs) { return '<input class="input" name="' + name + '" value="' + esc(value === undefined ? '' : value) + '" ' + (attrs || '') + '>'; }
  function select(name, options, value, attrs) {
    return '<select class="input" name="' + name + '" ' + (attrs || '') + '>' + options.map(function (o) {
      var v = typeof o === 'object' ? o.value : o, l = typeof o === 'object' ? o.label : o;
      return '<option value="' + esc(v) + '"' + (String(v) === String(value) ? ' selected' : '') + '>' + esc(l) + '</option>';
    }).join('') + '</select>';
  }
  function datalist(id, items) { return '<datalist id="' + id + '">' + items.map(function (x) { return '<option value="' + esc(x) + '">'; }).join('') + '</datalist>'; }

  // ---------- period filter ----------
  var PRESETS = [
    { value: 'today', label: 'Today' }, { value: 'yesterday', label: 'Yesterday' }, { value: 'this_week', label: 'This week' },
    { value: 'this_month', label: 'This month' }, { value: 'previous_month', label: 'Previous month' }, { value: 'this_quarter', label: 'This quarter' },
    { value: 'current_fy', label: 'Current FY' }, { value: 'previous_fy', label: 'Previous FY' }, { value: 'custom', label: 'Custom range' }
  ];
  function periodFields(state) {
    return field('Period', select('preset', PRESETS, state.preset || 'current_fy')) +
      '<div class="field custom-range' + (state.preset === 'custom' ? '' : ' hidden') + '"><label>From</label><input class="input" type="date" name="from" value="' + esc(state.from || '') + '"></div>' +
      '<div class="field custom-range' + (state.preset === 'custom' ? '' : ' hidden') + '"><label>To</label><input class="input" type="date" name="to" value="' + esc(state.to || '') + '"></div>';
  }
  /** Binds a .filters form: calls onChange(values) on any change. */
  function bindFilters(root, onChange) {
    var t = null;
    function fire() { var v = formData(root); $$('.custom-range', root).forEach(function (x) { x.classList.toggle('hidden', v.preset !== 'custom'); }); if (v.preset === 'custom' && (!v.from || !v.to)) return; onChange(v); }
    root.addEventListener('change', fire);
    root.addEventListener('input', function (e) { if (e.target.type === 'search' || e.target.dataset.live !== undefined) { clearTimeout(t); t = setTimeout(fire, 300); } });
  }

  // ---------- data table ----------
  /**
   * table(container, { columns, load(params) -> Promise<{rows,total,page,pages}>, pageSize, onRow, footer(result), title })
   * Server-side paging & sorting; exports fetch all rows through the same loader.
   */
  function table(container, opts) {
    var state = { page: 1, sort: opts.sort || null, dir: opts.dir || 'desc', pageSize: opts.pageSize || 25 };
    var last = null;
    function cell(c, r) {
      var v = r[c.key];
      if (c.render) return c.render(v, r);
      switch (c.type) {
        case 'inr': return fmt.inr(v);
        case 'inr2': return fmt.inr2(v);
        case 'signed': return signed(v);
        case 'num': return fmt.num(v);
        case 'pct': return fmt.pct(v);
        case 'date': return fmt.date(v);
        case 'dt': return esc(fmt.dt(v));
        case 'badge': return v ? badge(v) : '';
        case 'bool': return v === true || v === 'TRUE' ? 'Yes' : '';
        default: return esc(v);
      }
    }
    function isNum(c) { return ['inr', 'inr2', 'signed', 'num', 'pct'].indexOf(c.type) >= 0 || c.align === 'right'; }
    function render(res) {
      last = res;
      var head = '<tr>' + opts.columns.map(function (c) {
        var s = c.sortable === false ? '' : ' sortable';
        var arrow = state.sort === c.key ? (state.dir === 'asc' ? '▲' : '▼') : '';
        return '<th class="' + (isNum(c) ? 'num' : '') + s + '" data-key="' + c.key + '">' + esc(c.label) + ' <span class="arrow">' + arrow + '</span></th>';
      }).join('') + '</tr>';
      var body = res.rows.length ? res.rows.map(function (r, i) {
        return '<tr data-i="' + i + '" class="' + (opts.onRow ? 'clickable ' : '') + (opts.rowClass ? opts.rowClass(r) : '') + '">' + opts.columns.map(function (c) { return '<td class="' + (isNum(c) ? 'num' : '') + '">' + cell(c, r) + '</td>'; }).join('') + '</tr>';
      }).join('') : '<tr><td colspan="' + opts.columns.length + '">' + empty(opts.emptyText) + '</td></tr>';
      var foot = opts.footer ? opts.footer(res) : null;
      var tfoot = foot ? '<tfoot><tr>' + opts.columns.map(function (c) { var v = foot[c.key]; return '<td class="' + (isNum(c) ? 'num' : '') + '">' + (v === undefined ? '' : (typeof v === 'number' ? (c.type === 'num' ? fmt.num(v) : fmt.inr(v)) : esc(v))) + '</td>'; }).join('') + '</tr></tfoot>' : '';
      var from = res.total ? (res.page - 1) * res.pageSize + 1 : 0, to = Math.min(res.total, res.page * res.pageSize);
      container.innerHTML = '<div class="table-wrap"><table class="data"><thead>' + head + '</thead><tbody>' + body + '</tbody>' + tfoot + '</table></div>' +
        '<div class="table-foot"><span>' + (res.total ? 'Showing ' + from + '-' + to + ' of ' + fmt.num(res.total, 0) : '') + '</span>' +
        (res.pages > 1 ? '<div class="pager"><button class="btn sm" data-p="prev" ' + (res.page <= 1 ? 'disabled' : '') + '>Prev</button><span>Page ' + res.page + ' of ' + res.pages + '</span><button class="btn sm" data-p="next" ' + (res.page >= res.pages ? 'disabled' : '') + '>Next</button></div>' : '') + '</div>';
      $$('th.sortable', container).forEach(function (th) { th.addEventListener('click', function () { var k = th.dataset.key; state.dir = state.sort === k && state.dir === 'desc' ? 'asc' : 'desc'; state.sort = k; state.page = 1; reload(); }); });
      $$('[data-p]', container).forEach(function (b) { b.addEventListener('click', function () { state.page += b.dataset.p === 'next' ? 1 : -1; reload(); }); });
      if (opts.onRow) $$('tbody tr[data-i]', container).forEach(function (tr) { tr.addEventListener('click', function (e) { if (e.target.closest('button,a')) return; opts.onRow(res.rows[+tr.dataset.i]); }); });
      if (opts.afterRender) opts.afterRender(container, res);
    }
    function reload() {
      container.innerHTML = loading();
      return opts.load({ page: state.page, pageSize: state.pageSize, sort: state.sort, dir: state.dir }).then(render, function (e) { container.innerHTML = errorBox(e); });
    }
    reload();
    return {
      reload: function (resetPage) { if (resetPage) state.page = 1; return reload(); },
      last: function () { return last; },
      exportRows: function () { return opts.load({ page: 1, pageSize: 5000, sort: state.sort, dir: state.dir }).then(function (r) { return r.rows; }); },
      columns: opts.columns
    };
  }

  /** Static table from rows (for statements already computed). */
  function staticTable(columns, rows, opts) {
    opts = opts || {};
    function isNum(c) { return ['inr', 'inr2', 'signed', 'num', 'pct'].indexOf(c.type) >= 0; }
    var h = '<div class="table-wrap"><table class="data ' + (opts.cls || '') + '"><thead><tr>' + columns.map(function (c) { return '<th class="' + (isNum(c) ? 'num' : '') + '">' + esc(c.label) + '</th>'; }).join('') + '</tr></thead><tbody>';
    h += rows.length ? rows.map(function (r) {
      return '<tr class="' + (r._cls || '') + '">' + columns.map(function (c) {
        var v = r[c.key], out;
        if (c.render) out = c.render(v, r);
        else if (c.type === 'inr') out = fmt.inr(v); else if (c.type === 'inr2') out = fmt.inr2(v); else if (c.type === 'signed') out = signed(v);
        else if (c.type === 'num') out = fmt.num(v); else if (c.type === 'pct') out = fmt.pct(v); else if (c.type === 'date') out = fmt.date(v); else if (c.type === 'badge') out = v ? badge(v) : '';
        else out = esc(v);
        return '<td class="' + (isNum(c) ? 'num' : '') + (c.indent && r._indent ? ' indent' : '') + '">' + out + '</td>';
      }).join('') + '</tr>';
    }).join('') : '<tr><td colspan="' + columns.length + '">' + empty(opts.emptyText) + '</td></tr>';
    h += '</tbody>';
    if (opts.foot) h += '<tfoot><tr>' + columns.map(function (c) { var v = opts.foot[c.key]; return '<td class="' + (isNum(c) ? 'num' : '') + '">' + (v === undefined ? '' : typeof v === 'number' ? (c.type === 'num' ? fmt.num(v) : c.type === 'inr2' ? fmt.inr2(v) : fmt.inr(v)) : esc(v)) + '</td>'; }).join('') + '</tr></tfoot>';
    return h + '</table></div>';
  }

  // ---------- export ----------
  function exportValue(c, r) {
    var v = r[c.key];
    if (c.exportValue) return c.exportValue(v, r);
    if (['inr', 'inr2', 'signed', 'num', 'pct'].indexOf(c.type) >= 0) return v === '' || v === null || v === undefined ? '' : Number(v);
    if (c.type === 'date') return U.D(v) || '';
    return v === null || v === undefined ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
  }
  function download(name, blob) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
  function exportCSV(name, columns, rows) {
    var q = function (s) { s = String(s); if (/^[=+\-@]/.test(s) && isNaN(Number(s))) s = "'" + s; return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    var csv = [columns.map(function (c) { return q(c.label); }).join(',')].concat(rows.map(function (r) { return columns.map(function (c) { return q(exportValue(c, r)); }).join(','); })).join('\r\n');
    download(name + '.csv', new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
  }
  var xlsxPromise = null;
  function loadXLSX() {
    if (window.XLSX) return Promise.resolve(window.XLSX);
    return xlsxPromise || (xlsxPromise = new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
      s.onload = function () { res(window.XLSX); }; s.onerror = function () { xlsxPromise = null; rej(new Error('Could not load the Excel library.')); };
      document.head.appendChild(s);
    }));
  }
  function exportXLSX(name, columns, rows) {
    return loadXLSX().then(function (X) {
      var aoa = [columns.map(function (c) { return c.label; })].concat(rows.map(function (r) { return columns.map(function (c) { return exportValue(c, r); }); }));
      var ws = X.utils.aoa_to_sheet(aoa);
      ws['!cols'] = columns.map(function (c) { return { wch: Math.max(10, Math.min(40, c.label.length + 4)) }; });
      var wb = X.utils.book_new(); X.utils.book_append_sheet(wb, ws, name.slice(0, 31));
      X.writeFile(wb, name + '.xlsx');
    });
  }
  /** Export menu: getRows() -> Promise<rows>. */
  function exportButtons(name, getColumns, getRows) {
    var id = 'x' + Math.random().toString(36).slice(2, 8);
    setTimeout(function () {
      var root = document.getElementById(id); if (!root) return;
      root.addEventListener('click', function (e) {
        var b = e.target.closest('[data-x]'); if (!b) return;
        var kind = b.dataset.x;
        if (kind === 'print') { window.print(); return; }
        b.disabled = true;
        Promise.resolve(getRows()).then(function (rows) {
          var cols = getColumns();
          return kind === 'csv' ? exportCSV(name, cols, rows) : exportXLSX(name, cols, rows);
        }).then(function () { Audit && Audit.exported(name, kind); }, function (err) { toast(err.message, 'bad'); }).then(function () { b.disabled = false; });
      });
    });
    return '<div class="actions no-print" id="' + id + '"><button class="btn sm" data-x="xlsx">' + icon('download') + 'Excel</button><button class="btn sm" data-x="csv">CSV</button><button class="btn sm" data-x="print" title="Print or save as PDF">' + icon('print') + 'Print / PDF</button></div>';
  }
  var Audit = { exported: function () { /* hook for export logging */ } };

  // ---------- charts ----------
  var charts = [];
  function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
  function series(i) { return cssVar('--series-' + (i + 1)); }
  function chart(canvasHost, cfg) {
    if (!window.Chart) { canvasHost.innerHTML = '<div class="empty">Chart library unavailable (offline). Data is shown in the tables.</div>'; return null; }
    canvasHost.innerHTML = '<canvas></canvas>';
    var ctx = canvasHost.querySelector('canvas');
    var text2 = cssVar('--text-2'), grid = cssVar('--grid'), axis = cssVar('--axis');
    var money = cfg.money !== false;
    var datasets = cfg.datasets.map(function (d, i) {
      var color = d.color || series(d.slot !== undefined ? d.slot : i);
      var base = { label: d.label, data: d.data, borderColor: color, backgroundColor: d.colors || color };
      if (cfg.type === 'line') { base.borderWidth = 2; base.pointRadius = 0; base.pointHoverRadius = 4; base.cubicInterpolationMode = 'monotone'; base.fill = false; }
      else { base.borderRadius = 4; base.borderSkipped = 'start'; base.maxBarThickness = 28; base.borderWidth = 0; }
      return base;
    });
    // Only the value axis gets a money formatter; the category axis keeps Chart.js's default label callback.
    var moneyTick = function (v) { return money ? fmt.compact(v) : v; };
    var xTicks = { color: axis, maxRotation: 0, autoSkipPadding: 12, font: { size: 11 } };
    var yTicks = { color: axis, font: { size: 11 } };
    if (cfg.horizontal) xTicks.callback = moneyTick; else yTicks.callback = moneyTick;
    var c = new window.Chart(ctx, {
      type: cfg.type || 'bar',
      data: { labels: cfg.labels, datasets: datasets },
      options: {
        responsive: true, maintainAspectRatio: false, animation: false,
        indexAxis: cfg.horizontal ? 'y' : 'x',
        interaction: { mode: cfg.type === 'line' ? 'index' : 'nearest', intersect: cfg.type !== 'line' },
        plugins: {
          legend: { display: datasets.length > 1, position: 'top', align: 'start', labels: { color: text2, boxWidth: 10, boxHeight: 10, useBorderRadius: true, borderRadius: 3, font: { size: 12 } } },
          tooltip: { callbacks: { label: function (it) { var v = cfg.horizontal ? it.parsed.x : it.parsed.y; return (datasets.length > 1 ? it.dataset.label + ': ' : '') + (money ? fmt.inr(v) : fmt.num(v)); } } }
        },
        scales: {
          x: { stacked: !!cfg.stacked, beginAtZero: !!cfg.horizontal, grid: { display: !!cfg.horizontal, color: grid }, border: { color: axis }, ticks: xTicks },
          y: { stacked: !!cfg.stacked, beginAtZero: !cfg.horizontal, grid: { display: !cfg.horizontal, color: grid }, border: { display: false }, ticks: yTicks }
        }
      }
    });
    charts.push(c);
    return c;
  }
  function destroyCharts() { charts.forEach(function (c) { try { c.destroy(); } catch (e) { /* noop */ } }); charts = []; }
  function seqColors(n) { var steps = [2, 3, 4, 5, 6, 7]; var out = []; for (var i = 0; i < n; i++) out.push(cssVar('--seq-' + steps[Math.min(steps.length - 1, Math.round(i * (steps.length - 1) / Math.max(1, n - 1)))])); return out; }

  return {
    fmt: fmt, esc: esc, $: $, $$: $$, el: el, icon: icon, kpi: kpi, badge: badge, signed: signed, loading: loading, empty: empty, errorBox: errorBox, card: card,
    toast: toast, modal: modal, drawer: drawer, formData: formData, field: field, input: input, select: select, datalist: datalist,
    PRESETS: PRESETS, periodFields: periodFields, bindFilters: bindFilters, table: table, staticTable: staticTable,
    exportCSV: exportCSV, exportXLSX: exportXLSX, exportButtons: exportButtons, chart: chart, destroyCharts: destroyCharts, seqColors: seqColors, series: series
  };
})();
