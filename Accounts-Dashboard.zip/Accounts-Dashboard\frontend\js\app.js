/**
 * App shell: login, permission-based navigation, hash router, global search, theme.
 * Pages register themselves in window.Pages = { key: { title, perm, render(root, query) } }.
 */
var Pages = window.Pages || {};
var App = (function () {
  'use strict';
  var esc = UI.esc, icon = UI.icon, $ = UI.$, $$ = UI.$$;

  var NAV = [
    { group: 'Overview', items: [
      { key: 'dashboard', label: 'Dashboard', icon: 'dashboard', perm: 'view.dashboard' },
      { key: 'mis', label: 'Management MIS', icon: 'mis', perm: 'view.reports' },
      { key: 'alerts', label: 'Alert Center', icon: 'bell', perm: 'view.dashboard', badge: 'alerts' }] },
    { group: 'Transactions', items: [
      { key: 'sales', label: 'Sales', icon: 'sales', perm: 'view.accounts' },
      { key: 'offline-sales', label: 'Offline Sales', icon: 'offline', perm: 'write.offline_sales' },
      { key: 'purchases', label: 'Purchases', icon: 'purchase', perm: 'view.accounts' },
      { key: 'receipts', label: 'Receipts', icon: 'in', perm: 'view.accounts' },
      { key: 'payments', label: 'Payments', icon: 'out', perm: 'view.accounts' },
      { key: 'expenses', label: 'Expenses', icon: 'expense', perm: 'submit.expenses|view.accounts' }] },
    { group: 'Parties', items: [
      { key: 'customers', label: 'Customers', icon: 'users', perm: 'view.accounts' },
      { key: 'vendors', label: 'Vendors', icon: 'truck', perm: 'view.accounts' },
      { key: 'receivables', label: 'Receivables', icon: 'receipt', perm: 'view.accounts' },
      { key: 'payables', label: 'Payables', icon: 'payment', perm: 'view.accounts' }] },
    { group: 'Accounts', items: [
      { key: 'ledgers', label: 'Ledgers', icon: 'book', perm: 'view.accounts' },
      { key: 'cash-bank', label: 'Cash & Bank', icon: 'bank', perm: 'view.accounts' },
      { key: 'trial-balance', label: 'Trial Balance', icon: 'scale', perm: 'view.reports' },
      { key: 'inventory', label: 'Inventory', icon: 'box', perm: 'view.accounts' }] },
    { group: 'Statements', items: [
      { key: 'profit-loss', label: 'Profit & Loss', icon: 'pl', perm: 'view.reports' },
      { key: 'balance-sheet', label: 'Balance Sheet', icon: 'bs', perm: 'view.reports' },
      { key: 'cash-flow', label: 'Cash Flow', icon: 'flow', perm: 'view.reports' },
      { key: 'gst', label: 'GST', icon: 'tax', perm: 'view.reports' }] },
    { group: 'Insights', items: [
      { key: 'analytics', label: 'Analytics', icon: 'chart', perm: 'view.reports' },
      { key: 'health', label: 'Financial Health', icon: 'heart', perm: 'view.reports' }] },
    { group: 'System', items: [
      { key: 'tally', label: 'Tally Integration', icon: 'sync', perm: 'view.tally' },
      { key: 'audit', label: 'Audit Trail', icon: 'audit', perm: 'view.audit' },
      { key: 'settings', label: 'Settings', icon: 'settings', perm: 'admin.settings' }] }
  ];
  var ROLE_LABELS = { ADMIN: 'Admin', ACCOUNTANT: 'Accountant', FINANCE_MANAGER: 'Finance Manager', MANAGEMENT: 'Management', DATA_ENTRY: 'Data Entry', AUDITOR: 'Auditor' };

  function allowed(perm) { return String(perm || '').split('|').some(function (p) { return Api.can(p); }); }
  function firstAllowed() { for (var g = 0; g < NAV.length; g++) for (var i = 0; i < NAV[g].items.length; i++) if (allowed(NAV[g].items[i].perm)) return NAV[g].items[i].key; return null; }

  // ---------------- theme ----------------
  function applyTheme(t) { if (t) document.documentElement.setAttribute('data-theme', t); else document.documentElement.removeAttribute('data-theme'); }
  function toggleTheme() {
    var cur = document.documentElement.getAttribute('data-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    var next = cur === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { localStorage.setItem('acctdash.theme', next); } catch (e) { /* ignore */ }
    route();
  }
  try { applyTheme(localStorage.getItem('acctdash.theme')); } catch (e) { /* ignore */ }

  // ---------------- login ----------------
  function renderLogin(msg) {
    var demo = Api.mode() === 'demo';
    document.getElementById('root').innerHTML =
      '<div class="login-wrap"><div class="login-art"><div class="brand" style="border:0;padding:0"><div class="brand-mark">A</div><div><div class="brand-name">' + esc(APP_CONFIG.APP_NAME) + '</div><div class="brand-sub">' + esc(APP_CONFIG.COMPANY_NAME) + '</div></div></div>' +
      '<div><h2>The accounting intelligence layer on top of Tally.</h2><p>Tally and offline transactions in one set of books, with live receivables, payables, GST, statements and MIS.</p>' +
      '<ul><li>Bill-wise receivables & payables with ageing</li><li>Double-entry validated: every voucher balances</li><li>Trial balance, P&L, balance sheet and cash flow from postings</li><li>Automated alerts, reminders and scheduled reports</li></ul></div>' +
      '<div class="small" style="color:#7b879c">Figures are derived from posted vouchers. GST summaries are indicative, not tax advice.</div></div>' +
      '<div class="login-form"><div class="login-card"><h1>Sign in</h1><div class="muted">' + (demo ? 'Demo mode: no backend is configured. Choose a role to explore.' : 'Use your company account.') + '</div>' +
      (msg ? '<div class="errors" style="margin-top:12px">' + esc(msg) + '</div>' : '') +
      (demo ? '<div class="role-pick">' + Object.keys(ROLE_LABELS).map(function (r) { return '<button data-role="' + r + '"><b>' + ROLE_LABELS[r] + '</b><span class="muted">' + ({ ADMIN: 'Full access', ACCOUNTANT: 'Accounting modules', FINANCE_MANAGER: 'Reports & approvals', MANAGEMENT: 'Dashboards & reports', DATA_ENTRY: 'Entry screens only', AUDITOR: 'Read-only + audit' })[r] + '</span></button>'; }).join('') + '</div>'
        : '<form id="loginForm">' + UI.field('Email', '<input class="input" name="email" type="email" autocomplete="username" required>') + UI.field('Password', '<input class="input" name="password" type="password" autocomplete="current-password" required>') + '<button class="btn primary" style="width:100%;justify-content:center;margin-top:16px" type="submit">Sign in</button></form>') +
      '</div></div></div>';
    if (demo) $$('[data-role]').forEach(function (b) { b.addEventListener('click', function () { Api.login({ role: b.dataset.role }).then(boot); }); });
    else $('#loginForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = $('button[type=submit]', e.target); btn.disabled = true;
      Api.login(UI.formData(e.target)).then(boot, function (err) { renderLogin(err.message); });
    });
  }

  // ---------------- shell ----------------
  function renderShell() {
    var s = Api.session();
    var nav = NAV.map(function (g) {
      var items = g.items.filter(function (i) { return allowed(i.perm); });
      if (!items.length) return '';
      return '<div class="nav-group"><div class="nav-group-title">' + g.group + '</div>' + items.map(function (i) {
        return '<a href="#/' + i.key + '" data-key="' + i.key + '">' + icon(i.icon) + '<span>' + i.label + '</span>' + (i.badge ? '<span class="badge-count hidden" data-badge="' + i.badge + '"></span>' : '') + '</a>';
      }).join('') + '</div>';
    }).join('');
    var initials = (s.user.name || s.user.email).split(/\s+/).map(function (x) { return x[0]; }).join('').slice(0, 2).toUpperCase();
    document.getElementById('root').innerHTML =
      '<div class="app"><aside class="sidebar" id="sidebar"><div class="brand"><div class="brand-mark">A</div><div><div class="brand-name">' + esc(APP_CONFIG.APP_NAME) + '</div><div class="brand-sub">' + esc(APP_CONFIG.COMPANY_NAME) + '</div></div></div><nav class="nav">' + nav + '</nav>' +
      '<div class="sidebar-foot">Engine v' + Engine.VERSION + ' · ' + (Api.mode() === 'demo' ? 'Demo data' : 'Live') + '</div></aside>' +
      '<div class="main"><header class="topbar"><button class="icon-btn menu-btn" id="menuBtn" aria-label="Menu">' + icon('menu') + '</button>' +
      '<div class="search">' + icon('search') + '<input id="globalSearch" type="search" placeholder="Search invoice, voucher, party, GSTIN, mobile…" autocomplete="off" aria-label="Global search"><kbd>Ctrl K</kbd><div class="search-results hidden" id="searchResults"></div></div>' +
      '<div class="top-actions">' + (Api.mode() === 'demo' ? '<span class="pill demo" title="No API_URL configured - using in-browser demo data">Demo mode</span>' : '') +
      '<span class="pill" id="syncPill"><span class="dot"></span><span>Tally sync</span></span>' +
      '<button class="icon-btn" id="bellBtn" aria-label="Alerts">' + icon('bell') + '</button>' +
      '<button class="icon-btn" id="themeBtn" aria-label="Toggle dark mode">' + icon('moon') + '</button>' +
      '<div class="user" id="userBtn"><div class="avatar">' + esc(initials) + '</div><div class="user-meta"><b>' + esc(s.user.name || s.user.email) + '</b><span>' + esc(ROLE_LABELS[s.user.role] || s.user.role) + '</span></div></div></div></header>' +
      '<main class="content" id="page"></main></div></div><div id="toasts" class="toasts" role="status" aria-live="polite"></div>';
    $('#themeBtn').addEventListener('click', toggleTheme);
    $('#bellBtn').addEventListener('click', function () { location.hash = '#/alerts'; });
    $('#menuBtn').addEventListener('click', function () { $('#sidebar').classList.toggle('open'); });
    $('#userBtn').addEventListener('click', userMenu);
    bindSearch();
    refreshIndicators();
  }

  function userMenu(e) {
    e.stopPropagation();
    var existing = $('#userMenu'); if (existing) { existing.remove(); return; }
    var s = Api.session();
    var m = UI.el('<div class="menu" id="userMenu"><div class="small muted" style="padding:6px 10px">' + esc(s.user.email) + '<br>Role: ' + esc(ROLE_LABELS[s.user.role]) + '</div>' +
      (Api.mode() === 'demo' ? '<button data-a="role">Switch role</button><button data-a="reset">Reset demo data</button>' : '') + '<button data-a="logout">Sign out</button></div>');
    $('#userBtn').appendChild(m);
    m.addEventListener('click', function (ev) {
      var a = ev.target.dataset.a; if (!a) return;
      if (a === 'reset') { Api.resetDemo(); UI.toast('Demo data reset.'); route(); }
      if (a === 'logout' || a === 'role') { Api.logout(); location.hash = ''; renderLogin(); }
      m.remove();
    });
    setTimeout(function () { document.addEventListener('click', function h() { m.remove(); document.removeEventListener('click', h); }); });
  }

  function refreshIndicators() {
    if (Api.can('view.dashboard')) Api.call('getAlerts', {}).then(function (a) {
      var n = a.counts.critical + a.counts.warning;
      $$('[data-badge="alerts"]').forEach(function (b) { b.textContent = n; b.classList.toggle('hidden', !n); });
      var bell = $('#bellBtn'); if (bell) { var d = $('.dotn', bell); if (d) d.remove(); if (a.counts.critical) bell.insertAdjacentHTML('beforeend', '<span class="dotn">' + a.counts.critical + '</span>'); }
    }).catch(function () { /* indicator only */ });
    var pill = $('#syncPill');
    if (pill && Api.can('view.tally')) Api.call('getTallyStatus', {}).then(function (t) {
      var last = t.lastSuccess, when = last ? (last.end_time || last.start_time) : null;
      pill.className = 'pill ' + (t.unresolvedErrors ? 'warn' : last ? 'ok' : 'bad');
      pill.querySelector('span:last-child').textContent = last ? 'Tally synced ' + String(when).slice(11, 16) : 'Tally: not synced';
      pill.title = last ? 'Last successful sync ' + when + (t.unresolvedErrors ? ' · ' + t.unresolvedErrors + ' unresolved errors' : '') : 'No successful sync yet';
    }).catch(function () { pill.classList.add('hidden'); });
    else if (pill) pill.classList.add('hidden');
  }

  // ---------------- search ----------------
  function bindSearch() {
    var inp = $('#globalSearch'), box = $('#searchResults'), t = null, sel = -1, results = [];
    document.addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); inp.focus(); inp.select(); } });
    inp.addEventListener('input', function () {
      clearTimeout(t);
      var q = inp.value.trim();
      if (q.length < 2 || !Api.can('view.accounts')) { box.classList.add('hidden'); return; }
      t = setTimeout(function () {
        Api.call('searchTransactions', { q: q }).then(function (r) {
          results = r.results; sel = -1;
          box.innerHTML = results.length ? results.map(function (x, i) { return '<div class="item" data-i="' + i + '"><span class="kind">' + esc(x.kind) + '</span><div><div>' + esc(x.title) + (x.amount ? ' · <b>' + UI.fmt.inr(x.amount) + '</b>' : '') + '</div><div class="small muted">' + esc(x.subtitle) + '</div></div></div>'; }).join('') : '<div class="empty">No matches.</div>';
          box.classList.remove('hidden');
        }).catch(function (e) { box.innerHTML = '<div class="empty">' + esc(e.message) + '</div>'; box.classList.remove('hidden'); });
      }, 250);
    });
    inp.addEventListener('keydown', function (e) {
      var items = $$('.item', box);
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, Math.min(items.length - 1, sel + (e.key === 'ArrowDown' ? 1 : -1))); items.forEach(function (it, i) { it.classList.toggle('sel', i === sel); }); }
      if (e.key === 'Enter' && results[sel < 0 ? 0 : sel]) openResult(results[sel < 0 ? 0 : sel]);
      if (e.key === 'Escape') box.classList.add('hidden');
    });
    box.addEventListener('click', function (e) { var it = e.target.closest('.item'); if (it) openResult(results[+it.dataset.i]); });
    document.addEventListener('click', function (e) { if (!e.target.closest('.search')) box.classList.add('hidden'); });
    function openResult(r) {
      box.classList.add('hidden'); inp.value = '';
      if (r.kind === 'voucher') Shared.openVoucher(r.id);
      else Shared.openLedger(r.id);
    }
  }

  // ---------------- router ----------------
  function parseHash() {
    var h = location.hash.replace(/^#\/?/, '');
    var parts = h.split('?'), q = {};
    (parts[1] || '').split('&').forEach(function (kv) { if (!kv) return; var p = kv.split('='); q[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); });
    return { key: parts[0], query: q };
  }
  function route() {
    if (!Api.session()) { renderLogin(); return; }
    if (!$('#page')) renderShell();
    var r = parseHash();
    var key = r.key || firstAllowed();
    var navItem = null;
    NAV.forEach(function (g) { g.items.forEach(function (i) { if (i.key === key) navItem = i; }); });
    var page = Pages[key];
    var root = $('#page');
    UI.destroyCharts();
    $('#sidebar').classList.remove('open');
    $$('.nav a').forEach(function (a) { a.classList.toggle('active', a.dataset.key === key); });
    if (!page || !navItem) { location.hash = '#/' + firstAllowed(); return; }
    if (!allowed(navItem.perm)) { root.innerHTML = UI.errorBox({ message: 'You do not have permission to open ' + navItem.label + '.' }); return; }
    document.title = navItem.label + ' · ' + APP_CONFIG.APP_NAME;
    root.innerHTML = UI.loading();
    try { page.render(root, r.query); } catch (e) { console.error(e); root.innerHTML = UI.errorBox(e); }
  }
  function boot() { renderShell(); route(); }

  function start() {
    Api.onUnauthorized(function (e) { renderLogin(e.message); });
    window.addEventListener('hashchange', route);
    document.addEventListener('click', function (e) { if (e.target.closest('[data-print]')) window.print(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.matches && e.target.matches('a[role="button"]')) e.target.click(); });
    if (Api.session()) boot(); else renderLogin();
  }

  return { start: start, route: route, refreshIndicators: refreshIndicators, allowed: allowed, ROLE_LABELS: ROLE_LABELS };
})();
