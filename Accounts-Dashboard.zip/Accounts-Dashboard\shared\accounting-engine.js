/**
 * Accounts Dashboard - Accounting Engine
 *
 * Pure, storage-agnostic double-entry engine. The SAME file runs in:
 *   - Google Apps Script (copied to backend/apps-script/Engine.gs by tools/build.py)
 *   - the browser (copied to frontend/js/engine.js; used by the demo adapter)
 *   - any future Node/Java-hosted API (the contract is plain objects in, plain objects out)
 *
 * Input is a `db` object of row arrays (exactly the sheet rows, as objects keyed by header):
 *   { vouchers, entries, bills, ledgers, groups, voucherTypes, inventory,
 *     salesItems, purchaseItems, customers, vendors, products, company }
 *
 * Every report is derived from VOUCHERS + VOUCHER_ENTRIES (+ BILL_REFERENCES for bill-wise
 * outstanding). Nothing is computed from free-standing "total" columns.
 *
 * Sign convention inside the engine: nd ("net debit") = debit - credit.
 *   Assets/expenses carry positive nd; liabilities/income carry negative nd.
 */
var Engine = (function () {
  'use strict';

  var VERSION = '1.0.0';

  // ---------------------------------------------------------------------------
  // Tally's 28 reserved groups. Custom groups (GROUPS sheet) hang under these.
  // ---------------------------------------------------------------------------
  var RESERVED_GROUPS = {
    'Capital Account':          { parent: null, nature: 'Liabilities' },
    'Reserves & Surplus':       { parent: 'Capital Account', nature: 'Liabilities' },
    'Loans (Liability)':        { parent: null, nature: 'Liabilities' },
    'Bank OD A/c':              { parent: 'Loans (Liability)', nature: 'Liabilities' },
    'Secured Loans':            { parent: 'Loans (Liability)', nature: 'Liabilities' },
    'Unsecured Loans':          { parent: 'Loans (Liability)', nature: 'Liabilities' },
    'Current Liabilities':      { parent: null, nature: 'Liabilities' },
    'Duties & Taxes':           { parent: 'Current Liabilities', nature: 'Liabilities' },
    'Provisions':               { parent: 'Current Liabilities', nature: 'Liabilities' },
    'Sundry Creditors':         { parent: 'Current Liabilities', nature: 'Liabilities' },
    'Suspense A/c':             { parent: null, nature: 'Liabilities' },
    'Branch / Divisions':       { parent: null, nature: 'Liabilities' },
    'Fixed Assets':             { parent: null, nature: 'Assets' },
    'Investments':              { parent: null, nature: 'Assets' },
    'Current Assets':           { parent: null, nature: 'Assets' },
    'Bank Accounts':            { parent: 'Current Assets', nature: 'Assets' },
    'Cash-in-Hand':             { parent: 'Current Assets', nature: 'Assets' },
    'Deposits (Asset)':         { parent: 'Current Assets', nature: 'Assets' },
    'Loans & Advances (Asset)': { parent: 'Current Assets', nature: 'Assets' },
    'Stock-in-Hand':            { parent: 'Current Assets', nature: 'Assets' },
    'Sundry Debtors':           { parent: 'Current Assets', nature: 'Assets' },
    'Misc. Expenses (ASSET)':   { parent: null, nature: 'Assets' },
    'Sales Accounts':           { parent: null, nature: 'Income', gp: true },
    'Direct Incomes':           { parent: null, nature: 'Income', gp: true },
    'Indirect Incomes':         { parent: null, nature: 'Income', gp: false },
    'Purchase Accounts':        { parent: null, nature: 'Expenses', gp: true },
    'Direct Expenses':          { parent: null, nature: 'Expenses', gp: true },
    'Indirect Expenses':        { parent: null, nature: 'Expenses', gp: false }
  };

  var BASE_TYPES = ['Sales', 'Purchase', 'Receipt', 'Payment', 'Journal', 'Contra', 'Credit Note', 'Debit Note'];

  // Every accounting ambiguity is a named, documented, overridable rule.
  var DEFAULT_SETTINGS = {
    FY_START_MONTH: 4,                    // Indian FY: 1 April - 31 March
    BOOKS_BEGIN_DATE: '',                 // blank = company.books_begin_date
    COMPANY_STATE: 'Delhi',               // decides CGST+SGST vs IGST on offline sales
    AGEING_BASIS: 'DUE_DATE',             // DUE_DATE | BILL_DATE
    AGEING_BUCKETS: '30,60,90,180,365',   // upper bounds (days) of each bucket
    DEFAULT_CREDIT_DAYS: 30,              // when neither bill nor ledger gives credit days
    BILL_ALLOCATION_FALLBACK: 'FIFO',     // FIFO | NONE - how to apply receipts that carry no bill reference
    STOCK_VALUATION_SOURCE: 'INVENTORY',  // INVENTORY (valuations, falling back to stock ledgers) | LEDGER | NONE
    INCLUDE_OPTIONAL_VOUCHERS: false,     // Tally optional (memo) vouchers
    BANK_OD_AS_CASH_EQUIVALENT: false,    // treat Bank OD A/c as cash in cash-flow
    INTEREST_PAID_ACTIVITY: 'Financing',  // Financing | Operating (Ind AS 7 allows either)
    EBITDA_INCLUDES_OTHER_INCOME: false,
    DSO_USE_GROSS_SALES: true,            // debtors include GST, so compare with GST-inclusive sales
    ROUND_INVOICE_TOTAL: true,            // round offline invoice totals to the rupee
    ROUND_OFF_LEDGER: 'Round Off',
    OFFLINE_SALES_LEDGER: 'Sales - Offline',
    WALK_IN_CUSTOMER_LEDGER: 'Walk-in Customers',
    OUTPUT_CGST_LEDGER: 'Output CGST',
    OUTPUT_SGST_LEDGER: 'Output SGST',
    OUTPUT_IGST_LEDGER: 'Output IGST',
    INPUT_CGST_LEDGER: 'Input CGST',
    INPUT_SGST_LEDGER: 'Input SGST',
    INPUT_IGST_LEDGER: 'Input IGST',
    TDS_RECEIVABLE_LEDGER: 'TDS Receivable',
    TDS_PAYABLE_LEDGER: 'TDS Payable',
    PAYMENT_MODE_LEDGERS: '{"Cash":"Cash","UPI":"UPI Collections","Bank Transfer":"Bank Account","Cheque":"Bank Account","Other":"Cash"}',
    INACTIVE_CUSTOMER_DAYS: 90,
    CASH_SHORTAGE_THRESHOLD: 100000,
    HIGH_EXPENSE_INCREASE_PCT: 25,
    UPCOMING_WINDOW_DAYS: 7,
    MSME_MAX_PAYMENT_DAYS: 45,
    BALANCE_TOLERANCE: 0.01
  };

  // ---------------------------------------------------------------------------
  // Primitive helpers
  // ---------------------------------------------------------------------------
  function r2(n) { return Math.round((Number(n) || 0) * 100 + (n >= 0 ? 1e-9 : -1e-9)) / 100; }
  function num(v) {
    if (v === null || v === undefined || v === '') return 0;
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var n = Number(String(v).replace(/[,\s₹]/g, ''));
    return isFinite(n) ? n : 0;
  }
  function str(v) { return v === null || v === undefined ? '' : String(v).trim(); }
  function bool(v) { return v === true || v === 1 || /^(true|yes|y|1)$/i.test(str(v)); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function key(s) { return str(s).toLowerCase(); }

  /** Normalise any date-ish value to 'YYYY-MM-DD' ('' if invalid). */
  function D(v) {
    if (!v && v !== 0) return '';
    if (Object.prototype.toString.call(v) === '[object Date]') {
      if (isNaN(v.getTime())) return '';
      return v.getFullYear() + '-' + pad(v.getMonth() + 1) + '-' + pad(v.getDate());
    }
    var s = String(v).trim();
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return m[1] + '-' + m[2] + '-' + m[3];
    m = s.match(/^(\d{4})(\d{2})(\d{2})$/);               // Tally YYYYMMDD
    if (m) return m[1] + '-' + m[2] + '-' + m[3];
    m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/); // DD-MM-YYYY (Indian)
    if (m) return m[3] + '-' + pad(+m[2]) + '-' + pad(+m[1]);
    return '';
  }
  function toUTC(ds) { var p = ds.split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function fromUTC(t) { var d = new Date(t); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function addDays(ds, n) { return fromUTC(toUTC(ds) + n * 86400000); }
  function daysBetween(a, b) { return Math.round((toUTC(b) - toUTC(a)) / 86400000); }
  function monthKey(ds) { return ds.slice(0, 7); }
  function endOfMonth(ds) { var p = ds.split('-'); return fromUTC(Date.UTC(+p[0], +p[1], 0)); }
  function fyStart(ds, startMonth) {
    var y = +ds.slice(0, 4), m = +ds.slice(5, 7);
    if (m < startMonth) y -= 1;
    return y + '-' + pad(startMonth) + '-01';
  }
  function fyEnd(ds, startMonth) { var s = fyStart(ds, startMonth); return addDays(fromUTC(Date.UTC(+s.slice(0, 4) + 1, startMonth - 1, 1)), -1); }
  function fyLabel(ds, startMonth) {
    var y = +fyStart(ds, startMonth).slice(0, 4);
    return startMonth === 1 ? String(y) : 'FY ' + y + '-' + String(y + 1).slice(2);
  }
  function quarterKey(ds, startMonth) {
    var s = fyStart(ds, startMonth);
    var months = (+ds.slice(0, 4) - +s.slice(0, 4)) * 12 + (+ds.slice(5, 7) - startMonth);
    return fyLabel(ds, startMonth) + ' Q' + (Math.floor(months / 3) + 1);
  }
  function weekKey(ds) {             // ISO week start (Monday)
    var t = toUTC(ds), dow = (new Date(t).getUTCDay() + 6) % 7;
    return fromUTC(t - dow * 86400000);
  }
  function inRange(ds, from, to) { return (!from || ds >= from) && (!to || ds <= to); }
  function sum(arr, fn) { var s = 0; for (var i = 0; i < arr.length; i++) s += fn ? fn(arr[i]) : arr[i]; return r2(s); }
  function groupBy(arr, fn) { var o = {}; arr.forEach(function (x) { var k = fn(x); (o[k] = o[k] || []).push(x); }); return o; }
  function sortBy(arr, fn, desc) {
    return arr.slice().sort(function (a, b) { var x = fn(a), y = fn(b); return (x < y ? -1 : x > y ? 1 : 0) * (desc ? -1 : 1); });
  }
  function pct(a, b) { return b ? r2(a / b * 100) : null; }

  function mergeSettings(overrides) {
    var s = {};
    Object.keys(DEFAULT_SETTINGS).forEach(function (k) { s[k] = DEFAULT_SETTINGS[k]; });
    if (overrides) {
      Object.keys(overrides).forEach(function (k) {
        var v = overrides[k], def = DEFAULT_SETTINGS[k];
        if (v === '' || v === null || v === undefined) return;
        if (typeof def === 'number') s[k] = num(v);
        else if (typeof def === 'boolean') s[k] = bool(v);
        else s[k] = v;
      });
    }
    return s;
  }
  function jsonSetting(s, k) {
    var v = s[k];
    if (v && typeof v === 'object') return v;
    try { return JSON.parse(v); } catch (e) { return JSON.parse(DEFAULT_SETTINGS[k]); }
  }

  // Period presets used by every filter bar (Today ... Previous FY).
  function periodRange(preset, today, fyStartMonth) {
    today = D(today); fyStartMonth = fyStartMonth || 4;
    var y = +today.slice(0, 4), m = +today.slice(5, 7);
    switch (preset) {
      case 'today': return { from: today, to: today };
      case 'yesterday': var yd = addDays(today, -1); return { from: yd, to: yd };
      case 'this_week': return { from: weekKey(today), to: today };
      case 'this_month': return { from: today.slice(0, 8) + '01', to: today };
      case 'previous_month':
        var pm = fromUTC(Date.UTC(y, m - 2, 1)); return { from: pm, to: endOfMonth(pm) };
      case 'this_quarter':
        var fs = fyStart(today, fyStartMonth);
        var mi = (y - +fs.slice(0, 4)) * 12 + (m - fyStartMonth);
        var qs = fromUTC(Date.UTC(+fs.slice(0, 4), fyStartMonth - 1 + Math.floor(mi / 3) * 3, 1));
        return { from: qs, to: today };
      case 'current_fy': return { from: fyStart(today, fyStartMonth), to: today };
      case 'previous_fy':
        var pfs = fyStart(addDays(fyStart(today, fyStartMonth), -1), fyStartMonth);
        return { from: pfs, to: addDays(fyStart(today, fyStartMonth), -1) };
      default: return { from: fyStart(today, fyStartMonth), to: today };
    }
  }

  // ---------------------------------------------------------------------------
  // Context: indexes built once per request
  // ---------------------------------------------------------------------------
  function createContext(db, settingsOverrides) {
    db = db || {};
    var S = mergeSettings(settingsOverrides);
    var company = db.company || {};
    var fyM = num(S.FY_START_MONTH) || num(company.fy_start_month) || 4;
    var booksBegin = D(S.BOOKS_BEGIN_DATE) || D(company.books_begin_date) || '1900-04-01';
    if (company.state && !(settingsOverrides || {}).COMPANY_STATE) S.COMPANY_STATE = company.state;

    // Groups
    var groups = {};
    Object.keys(RESERVED_GROUPS).forEach(function (g) {
      var r = RESERVED_GROUPS[g];
      groups[key(g)] = { name: g, parent: r.parent, nature: r.nature, gp: !!r.gp };
    });
    (db.groups || []).forEach(function (g) {
      var name = str(g.group_name); if (!name) return;
      var existing = groups[key(name)];
      groups[key(name)] = {
        name: name,
        parent: str(g.parent_group) || (existing ? existing.parent : null),
        nature: str(g.nature) || (existing ? existing.nature : ''),
        gp: g.affects_gross_profit === '' || g.affects_gross_profit === undefined ? (existing ? existing.gp : false) : bool(g.affects_gross_profit)
      };
    });
    var groupMemo = {};
    function groupInfo(name) {
      var k = key(name);
      if (groupMemo[k]) return groupMemo[k];
      var chain = [], seen = {}, cur = groups[k], nature = '', gp = null;
      if (!cur) cur = groups[key('Suspense A/c')];
      while (cur && !seen[key(cur.name)]) {
        seen[key(cur.name)] = true; chain.push(cur.name);
        if (!nature && cur.nature) nature = cur.nature;
        if (RESERVED_GROUPS[cur.name] && gp === null && (cur.nature === 'Income' || cur.nature === 'Expenses')) gp = cur.gp;
        cur = cur.parent ? groups[key(cur.parent)] : null;
      }
      var primary = chain[chain.length - 1];
      var r = RESERVED_GROUPS[primary];
      nature = (r && r.nature) || nature || 'Liabilities';
      if (gp === null) gp = r ? !!r.gp : false;
      var info = { name: chain[0], chain: chain, primary: primary, nature: nature, gp: gp };
      groupMemo[k] = info;
      return info;
    }
    function inChain(info, g) { return info.chain.indexOf(g) >= 0; }

    // Ledgers
    var ledgerRows = {};
    (db.ledgers || []).forEach(function (l) { if (str(l.ledger_name)) ledgerRows[key(l.ledger_name)] = l; });
    var ledgerMemo = {};
    var warnings = [];
    function ledgerInfo(name) {
      var k = key(name);
      if (ledgerMemo[k]) return ledgerMemo[k];
      var row = ledgerRows[k];
      if (!row) warnings.push({ code: 'UNKNOWN_LEDGER', message: 'Ledger "' + name + '" is used in vouchers but missing from LEDGERS; treated as Suspense A/c.' });
      var g = groupInfo(row ? row.parent_group : 'Suspense A/c');
      var ob = row ? num(row.opening_balance) : 0;
      var obNd = r2(str(row && row.opening_dr_cr) === 'Cr' ? -Math.abs(ob) : Math.abs(ob));
      var taxType = str(row && row.tax_type).toUpperCase();
      if (!taxType && inChain(g, 'Duties & Taxes')) {
        var m = str(name).toUpperCase().match(/\b(CGST|SGST|UTGST|IGST|CESS)\b/);
        if (m) taxType = m[1] === 'UTGST' ? 'SGST' : m[1];
      }
      var info = {
        name: row ? str(row.ledger_name) : str(name),
        known: !!row,
        group: g.name, primary: g.primary, chain: g.chain, nature: g.nature, gp: g.gp,
        isPL: g.nature === 'Income' || g.nature === 'Expenses',
        openingNd: obNd,
        type: str(row && row.ledger_type),
        mis: str(row && row.mis_category).toUpperCase(),
        taxType: taxType,
        isGst: ['CGST', 'SGST', 'IGST', 'CESS'].indexOf(taxType) >= 0,
        gstin: str(row && row.gstin),
        state: str(row && row.state),
        creditDays: row && str(row.credit_days) !== '' ? num(row.credit_days) : null,
        isDebtor: inChain(g, 'Sundry Debtors'),
        isCreditor: inChain(g, 'Sundry Creditors'),
        isCash: inChain(g, 'Cash-in-Hand'),
        isBank: inChain(g, 'Bank Accounts') || (S.BANK_OD_AS_CASH_EQUIVALENT && inChain(g, 'Bank OD A/c')),
        isStock: inChain(g, 'Stock-in-Hand')
      };
      info.isCashEq = info.isCash || info.isBank;
      ledgerMemo[k] = info;
      return info;
    }

    // Voucher types
    var vtMap = {};
    (db.voucherTypes || []).forEach(function (t) { vtMap[key(t.voucher_type)] = str(t.base_voucher_type); });
    function baseType(v) {
      var b = str(v.base_voucher_type);
      if (BASE_TYPES.indexOf(b) >= 0) return b;
      var m = vtMap[key(v.voucher_type)];
      if (m) return m;
      var t = str(v.voucher_type);
      for (var i = 0; i < BASE_TYPES.length; i++) if (key(t).indexOf(key(BASE_TYPES[i])) >= 0) return BASE_TYPES[i];
      return 'Other';
    }

    // Vouchers
    var vouchers = [], vById = {};
    (db.vouchers || []).forEach(function (row) {
      var st = str(row.status || 'ACTIVE').toUpperCase();
      if (st !== 'ACTIVE' && !(st === 'OPTIONAL' && S.INCLUDE_OPTIONAL_VOUCHERS)) return;
      var date = D(row.voucher_date); if (!date) return;
      var v = {
        id: str(row.voucher_id), date: date, type: str(row.voucher_type), base: baseType(row),
        number: str(row.voucher_number), ref: str(row.reference_no), party: str(row.party_ledger),
        partyGstin: str(row.party_gstin), pos: str(row.place_of_supply), amount: num(row.amount),
        narration: str(row.narration), salesperson: str(row.salesperson), costCentre: str(row.cost_centre),
        source: str(row.source) || 'MANUAL', revision: num(row.revision) || 1, uniqueKey: str(row.unique_key),
        lines: [], bills: []
      };
      vouchers.push(v); vById[v.id] = v;
    });

    var lines = [];
    (db.entries || []).forEach(function (e) {
      var v = vById[str(e.voucher_id)];
      if (!v || (num(e.revision) || 1) !== v.revision) return;
      var dr = r2(num(e.debit)), cr = r2(num(e.credit));
      var ln = { v: v, date: v.date, ledger: str(e.ledger_name), dr: dr, cr: cr, nd: r2(dr - cr), lineNo: num(e.line_no), isParty: bool(e.is_party_line), costCentre: str(e.cost_centre) };
      ln.info = ledgerInfo(ln.ledger);
      v.lines.push(ln); lines.push(ln);
    });
    (db.bills || []).forEach(function (b) {
      var v = vById[str(b.voucher_id)];
      if (!v || (num(b.revision) || 1) !== v.revision) return;
      v.bills.push({
        party: str(b.party_ledger), name: str(b.bill_name), type: str(b.bill_type) || 'New Ref',
        date: D(b.bill_date) || v.date, due: D(b.due_date), creditDays: str(b.credit_days) === '' ? null : num(b.credit_days),
        nd: r2(str(b.dr_cr) === 'Cr' ? -Math.abs(num(b.amount)) : Math.abs(num(b.amount))), v: v
      });
    });
    vouchers.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.number < b.number ? -1 : a.number > b.number ? 1 : 0); });
    lines.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.v.number < b.v.number ? -1 : a.v.number > b.v.number ? 1 : a.lineNo - b.lineNo); });

    vouchers.forEach(function (v) {
      v.lines.sort(function (a, b) { return a.lineNo - b.lineNo; });
      // Party: explicit header, else the first debtor/creditor line
      if (!v.party) {
        var p = v.lines.filter(function (l) { return l.info.isDebtor || l.info.isCreditor; })[0];
        if (p) v.party = p.ledger;
      }
      v.partyInfo = v.party ? ledgerInfo(v.party) : null;
      var pl = v.lines.filter(function (l) { return key(l.ledger) === key(v.party); });
      v.partyNd = sum(pl, function (l) { return l.nd; });
      v.totalDr = sum(v.lines, function (l) { return l.dr; });
      v.totalCr = sum(v.lines, function (l) { return l.cr; });
      if (!v.amount) v.amount = v.totalDr;
    });

    var byLedger = groupBy(lines, function (l) { return key(l.ledger); });
    var allLedgerNames = {};
    Object.keys(ledgerRows).forEach(function (k) { allLedgerNames[k] = str(ledgerRows[k].ledger_name); });
    lines.forEach(function (l) { if (!allLedgerNames[key(l.ledger)]) allLedgerNames[key(l.ledger)] = l.ledger; });

    var ctx = {
      S: S, fyM: fyM, booksBegin: booksBegin, company: company, db: db,
      vouchers: vouchers, vById: vById, lines: lines, byLedger: byLedger,
      ledgerInfo: ledgerInfo, groupInfo: groupInfo, allLedgerNames: allLedgerNames,
      warnings: warnings, today: D(db.today) || D(new Date())
    };
    return ctx;
  }

  // ---------------------------------------------------------------------------
  // Balances
  // ---------------------------------------------------------------------------
  /** Closing nd of a ledger at end of `date` (inclusive). For P&L ledgers pass fyFrom to reset at FY start. */
  function balanceAt(ctx, name, date, sinceDate) {
    var info = ctx.ledgerInfo(name);
    var bal = sinceDate ? 0 : info.openingNd;
    var arr = ctx.byLedger[key(name)] || [];
    for (var i = 0; i < arr.length; i++) {
      var l = arr[i];
      if (date && l.date > date) break;
      if (sinceDate && l.date < sinceDate) continue;
      bal += l.nd;
    }
    return r2(bal);
  }
  function ledgerNames(ctx, pred) {
    return Object.keys(ctx.allLedgerNames).map(function (k) { return ctx.allLedgerNames[k]; })
      .filter(function (n) { return !pred || pred(ctx.ledgerInfo(n)); });
  }
  function sumBalances(ctx, pred, date) {
    return r2(ledgerNames(ctx, pred).reduce(function (s, n) { return s + balanceAt(ctx, n, date); }, 0));
  }
  /** Movement (nd) of ledgers matching pred between from and to inclusive. */
  function movement(ctx, pred, from, to) {
    var s = 0;
    for (var i = 0; i < ctx.lines.length; i++) {
      var l = ctx.lines[i];
      if (l.date < from) continue;
      if (l.date > to) break;
      if (pred(l.info, l)) s += l.nd;
    }
    return r2(s);
  }

  /** Stock value at end of `date` (see STOCK_VALUATION_SOURCE). */
  function stockLedgerBalance(ctx, date) { return sumBalances(ctx, function (i) { return i.isStock; }, date); }
  function stockAt(ctx, date) {
    var src = str(ctx.S.STOCK_VALUATION_SOURCE).toUpperCase();
    if (src === 'NONE') return 0;
    if (src === 'LEDGER') return stockLedgerBalance(ctx, date);
    var latest = {};
    (ctx.db.inventory || []).forEach(function (r) {
      var d = D(r.as_of_date); if (!d || d > date) return;
      var k = key(r.product_name) + '|' + key(r.godown);
      if (!latest[k] || latest[k].d < d) latest[k] = { d: d, v: num(r.closing_value) };
    });
    var keys = Object.keys(latest);
    if (!keys.length) return stockLedgerBalance(ctx, date);
    return r2(keys.reduce(function (s, k) { return s + latest[k].v; }, 0));
  }

  // ---------------------------------------------------------------------------
  // Trial balance
  // ---------------------------------------------------------------------------
  function trialBalance(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var fs = fyStart(from, ctx.fyM);
    var rows = [], retainedNd = 0;
    ledgerNames(ctx).forEach(function (name) {
      var info = ctx.ledgerInfo(name), arr = ctx.byLedger[key(name)] || [];
      var open = info.isPL ? 0 : info.openingNd, pdr = 0, pcr = 0;
      if (info.isPL) retainedNd += info.openingNd;
      for (var i = 0; i < arr.length; i++) {
        var l = arr[i];
        if (l.date > to) break;
        if (l.date < from) {
          if (info.isPL && l.date < fs) retainedNd += l.nd; else open += l.nd;
        } else { pdr += l.dr; pcr += l.cr; }
      }
      open = r2(open); pdr = r2(pdr); pcr = r2(pcr);
      var close = r2(open + pdr - pcr);
      if (!open && !pdr && !pcr && !p.includeZero) return;
      rows.push(tbRow(name, info.group, info.primary, info.nature, open, pdr, pcr, close));
    });
    retainedNd = r2(retainedNd);
    if (retainedNd) rows.push(tbRow('Profit & Loss A/c (brought forward)', 'Reserves & Surplus', 'Capital Account', 'Liabilities', retainedNd, 0, 0, retainedNd));
    var openDiff = r2(sum(rows, function (r) { return r.openingDr - r.openingCr; }));
    if (Math.abs(openDiff) >= ctx.S.BALANCE_TOLERANCE) {
      rows.push(tbRow('Difference in opening balances', '', '', 'Liabilities', -openDiff, 0, 0, -openDiff));
    }
    rows = sortBy(rows, function (r) { return r.primary + '|' + r.ledger; });
    var t = {
      openingDr: sum(rows, function (r) { return r.openingDr; }), openingCr: sum(rows, function (r) { return r.openingCr; }),
      periodDr: sum(rows, function (r) { return r.periodDr; }), periodCr: sum(rows, function (r) { return r.periodCr; }),
      closingDr: sum(rows, function (r) { return r.closingDr; }), closingCr: sum(rows, function (r) { return r.closingCr; })
    };
    var diff = r2(t.closingDr - t.closingCr);
    return {
      from: from, to: to, rows: rows, totals: t,
      balanced: Math.abs(diff) < ctx.S.BALANCE_TOLERANCE && Math.abs(t.periodDr - t.periodCr) < ctx.S.BALANCE_TOLERANCE,
      difference: diff, periodDifference: r2(t.periodDr - t.periodCr),
      openingDifference: openDiff,
      unbalancedVouchers: unbalancedVouchers(ctx, from, to)
    };
  }
  function tbRow(ledger, group, primary, nature, open, pdr, pcr, close) {
    return {
      ledger: ledger, group: group, primary: primary, nature: nature,
      openingDr: open > 0 ? open : 0, openingCr: open < 0 ? -open : 0,
      periodDr: pdr, periodCr: pcr,
      closingDr: close > 0 ? close : 0, closingCr: close < 0 ? -close : 0
    };
  }
  function unbalancedVouchers(ctx, from, to) {
    return ctx.vouchers.filter(function (v) { return inRange(v.date, from, to) && Math.abs(v.totalDr - v.totalCr) >= ctx.S.BALANCE_TOLERANCE; })
      .map(function (v) { return { voucher_id: v.id, voucher_number: v.number, date: v.date, debit: v.totalDr, credit: v.totalCr, difference: r2(v.totalDr - v.totalCr) }; });
  }

  // ---------------------------------------------------------------------------
  // Ledger statement
  // ---------------------------------------------------------------------------
  function ledgerStatement(ctx, p) {
    var name = str(p.ledger);
    if (!name) throw new Error('Ledger name is required.');
    var info = ctx.ledgerInfo(name);
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var fs = fyStart(from, ctx.fyM);
    var opening = info.isPL ? balanceAt(ctx, name, addDays(from, -1), fs) : balanceAt(ctx, name, addDays(from, -1));
    if (info.isPL && from === fs) opening = 0;
    var run = opening, rows = [];
    (ctx.byLedger[key(name)] || []).forEach(function (l) {
      if (!inRange(l.date, from, to)) return;
      if (p.voucherType && l.v.base !== p.voucherType && l.v.type !== p.voucherType) return;
      run = r2(run + l.nd);
      var others = l.v.lines.filter(function (o) { return o !== l && (l.nd >= 0 ? o.nd < 0 : o.nd > 0); });
      var particulars = others.length ? others[0].ledger + (others.length > 1 ? ' (+' + (others.length - 1) + ' more)' : '') : '';
      rows.push({
        date: l.date, voucher_id: l.v.id, voucher_number: l.v.number, voucher_type: l.v.type || l.v.base,
        particulars: particulars, debit: l.dr, credit: l.cr, balance: run,
        balance_label: fmtDrCr(run), reference: l.v.ref, narration: l.v.narration, source: l.v.source
      });
    });
    return {
      ledger: info.name, group: info.group, primary: info.primary, nature: info.nature, from: from, to: to,
      opening: opening, opening_label: fmtDrCr(opening), rows: rows,
      totalDebit: sum(rows, function (r) { return r.debit; }), totalCredit: sum(rows, function (r) { return r.credit; }),
      closing: run, closing_label: fmtDrCr(run)
    };
  }
  function fmtDrCr(nd) { return Math.abs(r2(nd)).toFixed(2) + (nd < 0 ? ' Cr' : ' Dr'); }

  // ---------------------------------------------------------------------------
  // Profit & Loss
  // ---------------------------------------------------------------------------
  function profitLoss(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var buckets = {
      revenue: [], directIncome: [], purchases: [], directExpenses: [], otherIncome: [],
      operating: [], depreciation: [], interest: [], tax: []
    };
    var mv = {};
    ctx.lines.forEach(function (l) {
      if (!l.info.isPL || !inRange(l.date, from, to)) return;
      mv[l.info.name] = (mv[l.info.name] || 0) + l.nd;
    });
    Object.keys(mv).forEach(function (name) {
      var info = ctx.ledgerInfo(name), nd = r2(mv[name]);
      if (!nd) return;
      var item = { ledger: name, group: info.group, amount: info.nature === 'Income' ? -nd : nd };
      var prim = info.primary;
      if (info.nature === 'Income') {
        if (prim === 'Sales Accounts') buckets.revenue.push(item);
        else if (prim === 'Direct Incomes' || info.gp) buckets.directIncome.push(item);
        else buckets.otherIncome.push(item);
      } else {
        if (info.mis === 'DEPRECIATION') buckets.depreciation.push(item);
        else if (info.mis === 'INTEREST') buckets.interest.push(item);
        else if (info.mis === 'INCOME_TAX') buckets.tax.push(item);
        else if (prim === 'Purchase Accounts') buckets.purchases.push(item);
        else if (prim === 'Direct Expenses' || info.gp) buckets.directExpenses.push(item);
        else buckets.operating.push(item);
      }
    });
    function tot(b) { return sum(buckets[b], function (x) { return x.amount; }); }
    var openingStock = stockAt(ctx, addDays(from, -1)), closingStock = stockAt(ctx, to);
    var revenue = tot('revenue'), directIncome = tot('directIncome'), purchases = tot('purchases'), directExp = tot('directExpenses');
    var cogs = r2(openingStock + purchases + directExp - closingStock);
    var grossProfit = r2(revenue + directIncome - cogs);
    var operating = tot('operating'), otherIncome = tot('otherIncome');
    var ebitda = r2(grossProfit - operating + (ctx.S.EBITDA_INCLUDES_OTHER_INCOME ? otherIncome : 0));
    var dep = tot('depreciation'), interest = tot('interest'), tax = tot('tax');
    var pbt = r2(ebitda - dep - interest + (ctx.S.EBITDA_INCLUDES_OTHER_INCOME ? 0 : otherIncome));
    var net = r2(pbt - tax);
    Object.keys(buckets).forEach(function (b) { buckets[b] = sortBy(buckets[b], function (x) { return Math.abs(x.amount); }, true); });
    return {
      from: from, to: to,
      lines: [
        { code: 'REVENUE', label: 'Revenue from operations (Sales)', amount: revenue, detail: buckets.revenue },
        { code: 'DIRECT_INCOME', label: 'Direct incomes', amount: directIncome, detail: buckets.directIncome },
        { code: 'OPENING_STOCK', label: 'Opening stock', amount: openingStock, detail: [] },
        { code: 'PURCHASES', label: 'Purchases', amount: purchases, detail: buckets.purchases },
        { code: 'DIRECT_EXPENSES', label: 'Direct expenses', amount: directExp, detail: buckets.directExpenses },
        { code: 'CLOSING_STOCK', label: 'Less: Closing stock', amount: closingStock, detail: [] },
        { code: 'COGS', label: 'Cost of goods sold', amount: cogs, total: true },
        { code: 'GROSS_PROFIT', label: 'Gross profit', amount: grossProfit, total: true, strong: true },
        { code: 'OPERATING_EXPENSES', label: 'Operating (indirect) expenses', amount: operating, detail: buckets.operating },
        { code: 'OTHER_INCOME', label: 'Other income', amount: otherIncome, detail: buckets.otherIncome },
        { code: 'EBITDA', label: 'EBITDA', amount: ebitda, total: true, strong: true },
        { code: 'DEPRECIATION', label: 'Depreciation', amount: dep, detail: buckets.depreciation },
        { code: 'INTEREST', label: 'Interest / finance cost', amount: interest, detail: buckets.interest },
        { code: 'PBT', label: 'Profit before tax', amount: pbt, total: true, strong: true },
        { code: 'TAX', label: 'Income tax', amount: tax, detail: buckets.tax },
        { code: 'NET_PROFIT', label: 'Net profit', amount: net, total: true, strong: true }
      ],
      revenue: revenue, cogs: cogs, grossProfit: grossProfit, operating: operating, otherIncome: otherIncome,
      ebitda: ebitda, depreciation: dep, interest: interest, pbt: pbt, tax: tax, netProfit: net,
      openingStock: openingStock, closingStock: closingStock, purchases: purchases, directExpenses: directExp,
      grossMargin: pct(grossProfit, revenue), netMargin: pct(net, revenue),
      notes: [
        'Closing stock source: ' + ctx.S.STOCK_VALUATION_SOURCE + ' (setting STOCK_VALUATION_SOURCE).',
        'Depreciation, interest and income-tax lines are identified by LEDGERS.mis_category.',
        ctx.S.EBITDA_INCLUDES_OTHER_INCOME ? 'EBITDA includes other income.' : 'EBITDA excludes other income (added back before PBT).'
      ]
    };
  }

  /** P&L for current/previous month, current/previous FY and YTD in one call. */
  function profitLossComparative(ctx, p) {
    var asOf = D(p && p.asOf) || ctx.today;
    var fs = fyStart(asOf, ctx.fyM);
    var pm = periodRange('previous_month', asOf, ctx.fyM);
    var pfy = periodRange('previous_fy', asOf, ctx.fyM);
    var sameDayLastYear = addDays(asOf, -365);
    function pick(r) { return { revenue: r.revenue, grossProfit: r.grossProfit, operating: r.operating, ebitda: r.ebitda, pbt: r.pbt, netProfit: r.netProfit, grossMargin: r.grossMargin, netMargin: r.netMargin }; }
    return {
      asOf: asOf,
      currentMonth: pick(profitLoss(ctx, { from: asOf.slice(0, 8) + '01', to: asOf })),
      previousMonth: pick(profitLoss(ctx, pm)),
      ytd: pick(profitLoss(ctx, { from: fs, to: asOf })),
      previousYtd: pick(profitLoss(ctx, { from: fyStart(sameDayLastYear, ctx.fyM), to: sameDayLastYear })),
      previousFy: pick(profitLoss(ctx, pfy)),
      trend: monthlyTrend(ctx, { from: fs, to: asOf })
    };
  }

  function monthlyTrend(ctx, p) {
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var out = [], m = from.slice(0, 8) + '01';
    while (m <= to) {
      var e = endOfMonth(m); if (e > to) e = to;
      var s = m < from ? from : m;
      var pl = profitLoss(ctx, { from: s, to: e });
      out.push({ month: m.slice(0, 7), revenue: pl.revenue, grossProfit: pl.grossProfit, operating: pl.operating, netProfit: pl.netProfit });
      m = addDays(endOfMonth(m), 1);
    }
    return out;
  }

  // ---------------------------------------------------------------------------
  // Balance sheet
  // ---------------------------------------------------------------------------
  function balanceSheet(ctx, p) {
    p = p || {};
    var asOf = D(p.asOf || p.to) || ctx.today;
    var fs = fyStart(asOf, ctx.fyM);
    var sections = {}, openingSum = 0, plBeforeFy = 0, plCurrent = 0;
    ledgerNames(ctx).forEach(function (name) {
      var info = ctx.ledgerInfo(name);
      openingSum += info.openingNd;
      if (info.isPL) {
        plBeforeFy += info.openingNd;
        (ctx.byLedger[key(name)] || []).forEach(function (l) {
          if (l.date > asOf) return;
          if (l.date < fs) plBeforeFy += l.nd; else plCurrent += l.nd;
        });
        return;
      }
      if (info.isStock) return; // replaced by closing-stock valuation
      var bal = balanceAt(ctx, name, asOf);
      if (!bal) return;
      var side = info.nature === 'Assets' ? 'Assets' : 'Liabilities';
      var sectionName = info.primary;
      var sub = info.chain.length > 1 ? info.chain[info.chain.length - 2] : info.primary;
      var s = sections[side + '|' + sectionName] = sections[side + '|' + sectionName] || { side: side, section: sectionName, subgroups: {} };
      var g = s.subgroups[sub] = s.subgroups[sub] || { name: sub, amount: 0, ledgers: [] };
      var amt = side === 'Assets' ? bal : -bal;
      g.amount = r2(g.amount + amt);
      g.ledgers.push({ ledger: name, amount: amt });
    });
    // Stock: valuation replaces stock ledgers; the difference flows through retained / current profit.
    var stockLedgerBal = stockLedgerBalance(ctx, asOf);
    var stockFy = stockAt(ctx, addDays(fs, -1)), stockClose = stockAt(ctx, asOf);
    if (stockClose) {
      var ca = sections['Assets|Current Assets'] = sections['Assets|Current Assets'] || { side: 'Assets', section: 'Current Assets', subgroups: {} };
      ca.subgroups['Closing Stock'] = { name: 'Closing Stock', amount: stockClose, ledgers: [{ ledger: 'Closing stock (valuation)', amount: stockClose }] };
    }
    var retained = r2(-plBeforeFy + (stockFy - stockLedgerBal));
    var currentProfit = r2(-plCurrent + (stockClose - stockFy));
    var eq = sections['Liabilities|Capital Account'] = sections['Liabilities|Capital Account'] || { side: 'Liabilities', section: 'Capital Account', subgroups: {} };
    if (retained) eq.subgroups['Retained earnings (P&L b/f)'] = { name: 'Retained earnings (P&L b/f)', amount: retained, ledgers: [] };
    eq.subgroups['Profit for the period'] = { name: 'Profit for the period (' + fyLabel(asOf, ctx.fyM) + ')', amount: currentProfit, ledgers: [] };
    openingSum = r2(openingSum);
    if (Math.abs(openingSum) >= ctx.S.BALANCE_TOLERANCE) {
      sections['Liabilities|Difference in opening balances'] = { side: 'Liabilities', section: 'Difference in opening balances', subgroups: { 'Difference': { name: 'Difference in opening balances', amount: openingSum, ledgers: [] } } };
    }
    var list = Object.keys(sections).map(function (k) {
      var s = sections[k];
      var subs = Object.keys(s.subgroups).map(function (n) { return s.subgroups[n]; });
      return { side: s.side, section: s.section, amount: sum(subs, function (g) { return g.amount; }), groups: subs };
    });
    var order = ['Capital Account', 'Loans (Liability)', 'Current Liabilities', 'Suspense A/c', 'Branch / Divisions', 'Difference in opening balances', 'Fixed Assets', 'Investments', 'Current Assets', 'Misc. Expenses (ASSET)'];
    list = sortBy(list, function (s) { var i = order.indexOf(s.section); return i < 0 ? 99 : i; });
    var assets = list.filter(function (s) { return s.side === 'Assets'; });
    var liabilities = list.filter(function (s) { return s.side === 'Liabilities'; });
    var totalAssets = sum(assets, function (s) { return s.amount; });
    var totalLiab = sum(liabilities, function (s) { return s.amount; });
    return {
      asOf: asOf, assets: assets, liabilities: liabilities,
      totalAssets: totalAssets, totalLiabilities: totalLiab,
      difference: r2(totalAssets - totalLiab),
      balanced: Math.abs(totalAssets - totalLiab) < ctx.S.BALANCE_TOLERANCE,
      equity: eq ? sum(Object.keys(eq.subgroups).map(function (k) { return eq.subgroups[k]; }), function (g) { return g.amount; }) : 0,
      currentProfit: currentProfit, retainedEarnings: retained, closingStock: stockClose
    };
  }

  // ---------------------------------------------------------------------------
  // Cash flow (direct method, derived from cash/bank postings)
  // ---------------------------------------------------------------------------
  function classifyCashLine(ctx, info) {
    var c = info.chain;
    function has(g) { return c.indexOf(g) >= 0; }
    if (info.isDebtor) return ['Operating', 'Receipts from customers', 'Refunds to customers'];
    if (info.isCreditor) return ['Operating', 'Refunds from suppliers', 'Payments to suppliers'];
    if (has('Duties & Taxes')) return ['Operating', 'Tax refunds', 'GST / TDS paid'];
    if (info.isPL) {
      if (info.mis === 'INTEREST') return [ctx.S.INTEREST_PAID_ACTIVITY === 'Operating' ? 'Operating' : 'Financing', 'Interest received', 'Interest paid'];
      if (info.mis === 'INCOME_TAX') return ['Operating', 'Income tax refund', 'Income tax paid'];
      if (info.mis === 'SALARY') return ['Operating', 'Salary recoveries', 'Payments to employees'];
      if (info.nature === 'Income') return ['Operating', info.primary === 'Sales Accounts' ? 'Cash sales' : 'Other income received', 'Income reversed'];
      return ['Operating', 'Expense refunds', 'Operating expenses paid'];
    }
    if (has('Fixed Assets')) return ['Investing', 'Sale of fixed assets', 'Purchase of fixed assets'];
    if (has('Investments')) return ['Investing', 'Sale of investments', 'Purchase of investments'];
    if (has('Loans & Advances (Asset)')) return ['Investing', 'Loans & advances recovered', 'Loans & advances given'];
    if (has('Capital Account')) return ['Financing', 'Capital introduced', 'Drawings / distributions'];
    if (has('Loans (Liability)')) return ['Financing', 'Borrowings raised', 'Borrowings repaid'];
    if (has('Suspense A/c')) return ['Operating', 'Unclassified receipts (Suspense)', 'Unclassified payments (Suspense)'];
    return ['Operating', 'Other operating receipts', 'Other operating payments'];
  }

  function cashFlow(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var isCash = function (i) { return i.isCashEq; };
    var opening = sumBalances(ctx, isCash, addDays(from, -1));
    var closing = sumBalances(ctx, isCash, to);
    var agg = {};
    ctx.vouchers.forEach(function (v) {
      if (!inRange(v.date, from, to)) return;
      var cashNd = sum(v.lines.filter(function (l) { return l.info.isCashEq; }), function (l) { return l.nd; });
      if (!cashNd) return;
      var counter = v.lines.filter(function (l) { return !l.info.isCashEq && (cashNd > 0 ? l.nd < 0 : l.nd > 0); });
      var totalOpp = sum(counter, function (l) { return -l.nd; });
      if (!totalOpp) return;
      counter.forEach(function (l) {
        var share = r2(cashNd * (-l.nd) / totalOpp);
        var cls = classifyCashLine(ctx, l.info);
        var label = share > 0 ? cls[1] : cls[2];
        var k = cls[0] + '|' + label;
        var a = agg[k] = agg[k] || { activity: cls[0], label: label, inflow: 0, outflow: 0 };
        if (share > 0) a.inflow = r2(a.inflow + share); else a.outflow = r2(a.outflow - share);
      });
    });
    var sections = ['Operating', 'Investing', 'Financing'].map(function (act) {
      var ls = Object.keys(agg).map(function (k) { return agg[k]; }).filter(function (a) { return a.activity === act; })
        .map(function (a) { a.net = r2(a.inflow - a.outflow); return a; });
      ls = sortBy(ls, function (a) { return -Math.abs(a.net); });
      return { activity: act, lines: ls, inflow: sum(ls, function (a) { return a.inflow; }), outflow: sum(ls, function (a) { return a.outflow; }), net: sum(ls, function (a) { return a.net; }) };
    });
    var net = sum(sections, function (s) { return s.net; });
    return {
      from: from, to: to, method: 'Direct', opening: opening, sections: sections,
      inflow: sum(sections, function (s) { return s.inflow; }), outflow: sum(sections, function (s) { return s.outflow; }),
      net: net, closing: closing, reconciles: Math.abs(opening + net - closing) < 1,
      difference: r2(opening + net - closing)
    };
  }

  // ---------------------------------------------------------------------------
  // Bill-wise outstanding, receivables, payables, ageing
  // ---------------------------------------------------------------------------
  function bucketFor(ctx, days) {
    var bounds = String(ctx.S.AGEING_BUCKETS).split(',').map(function (x) { return num(x); }).filter(Boolean);
    if (days < 0) return 'Not Due';
    var lo = 0;
    for (var i = 0; i < bounds.length; i++) {
      if (days <= bounds[i]) return (lo === 0 ? 0 : lo + 1) + '-' + bounds[i];
      lo = bounds[i];
    }
    return lo + '+';
  }
  function bucketLabels(ctx) {
    var bounds = String(ctx.S.AGEING_BUCKETS).split(',').map(function (x) { return num(x); }).filter(Boolean);
    var out = ['Not Due'], lo = 0;
    bounds.forEach(function (b) { out.push((lo === 0 ? 0 : lo + 1) + '-' + b); lo = b; });
    out.push(lo + '+');
    return out;
  }

  /**
   * Bill-wise position for all debtor (kind='receivable') or creditor ('payable') ledgers.
   * Explicit bill allocations are used first; vouchers without allocations become synthetic bills;
   * any remaining difference to the ledger balance is applied FIFO (BILL_ALLOCATION_FALLBACK) or
   * shown as On Account. The total ALWAYS ties to the ledger balance.
   */
  function outstanding(ctx, p) {
    p = p || {};
    var kind = p.kind === 'payable' ? 'payable' : 'receivable';
    var asOf = D(p.asOf) || ctx.today;
    var sign = kind === 'receivable' ? 1 : -1;      // converts nd into "amount owed" in natural direction
    var isParty = kind === 'receivable' ? function (i) { return i.isDebtor; } : function (i) { return i.isCreditor; };
    var bills = {}, parties = {};
    function party(name) { return parties[key(name)] = parties[key(name)] || { party: ctx.ledgerInfo(name).name, bills: [] }; }
    function billKey(pn, bn) { return key(pn) + '|' + key(bn); }
    function defaultDue(pn, date, creditDays) {
      var cd = creditDays !== null && creditDays !== undefined ? creditDays : ctx.ledgerInfo(pn).creditDays;
      if (cd === null || cd === undefined) cd = ctx.S.DEFAULT_CREDIT_DAYS;
      return addDays(date, cd);
    }
    function newBill(pn, name, date, due, v) {
      var k = billKey(pn, name);
      if (!bills[k]) {
        bills[k] = { party: ctx.ledgerInfo(pn).name, bill_name: name, bill_date: date, due_date: due, amount: 0, settled: 0, voucher_id: v ? v.id : '', voucher_number: v ? v.number : '', settlements: [], synthetic: false };
        party(pn).bills.push(bills[k]);
      }
      return bills[k];
    }

    ctx.vouchers.forEach(function (v) {
      if (v.date > asOf) return;
      var partyLines = v.lines.filter(function (l) { return isParty(l.info); });
      if (!partyLines.length) return;
      var explicit = v.bills.filter(function (b) { return isParty(ctx.ledgerInfo(b.party)); });
      var covered = {};
      explicit.forEach(function (b) {
        covered[key(b.party)] = r2((covered[key(b.party)] || 0) + b.nd);
        var amt = r2(b.nd * sign);
        if (b.type === 'Agst Ref') {
          var bill = bills[billKey(b.party, b.name)] || newBill(b.party, b.name, b.date, b.due || b.date, null);
          bill.settled = r2(bill.settled - amt);
          bill.settlements.push({ date: v.date, amount: -amt, voucher_number: v.number });
        } else if (b.type === 'On Account') {
          party(b.party).onAccount = r2((party(b.party).onAccount || 0) + amt);
        } else { // New Ref / Advance
          var nb = newBill(b.party, b.name, b.date, b.due || defaultDue(b.party, b.date, b.creditDays), v);
          nb.amount = r2(nb.amount + amt);
          if (b.type === 'Advance') nb.advance = true;
        }
      });
      // Party lines not covered by explicit allocations -> synthetic bill (debit side for receivables, credit side for payables)
      var perParty = groupBy(partyLines, function (l) { return key(l.ledger); });
      Object.keys(perParty).forEach(function (pk) {
        var lnd = sum(perParty[pk], function (l) { return l.nd; });
        var rest = r2(lnd - (covered[pk] || 0));
        if (!rest) return;
        var pn = perParty[pk][0].ledger;
        if (rest * sign > 0) {
          var sb = newBill(pn, v.number || v.id, v.date, defaultDue(pn, v.date, null), v);
          sb.amount = r2(sb.amount + rest * sign); sb.synthetic = true;
        } else {
          var pr = party(pn);
          pr.unallocated = r2((pr.unallocated || 0) + rest * sign);
          (pr.credits = pr.credits || []).push({ date: v.date, amount: -rest * sign, voucher_number: v.number });
        }
      });
    });

    // Opening balances (master) -> synthetic opening bill or unallocated credit
    ledgerNames(ctx, isParty).forEach(function (n) {
      var info = ctx.ledgerInfo(n), ob = r2(info.openingNd * sign);
      if (!ob) return;
      if (ob > 0) {
        var b = newBill(n, 'Opening Balance', ctx.booksBegin, ctx.booksBegin, null);
        b.amount = r2(b.amount + ob); b.synthetic = true;
      } else {
        var pr = party(n); pr.unallocated = r2((pr.unallocated || 0) + ob);
        (pr.credits = pr.credits || []).unshift({ date: ctx.booksBegin, amount: -ob, voucher_number: 'Opening' });
      }
    });

    var fifo = str(ctx.S.BILL_ALLOCATION_FALLBACK).toUpperCase() === 'FIFO';
    var allBills = [], partyRows = [], labels = bucketLabels(ctx), bucketTotals = {};
    labels.forEach(function (b) { bucketTotals[b] = 0; });

    Object.keys(parties).forEach(function (pk) {
      var pr = parties[pk];
      var credit = r2(-(pr.unallocated || 0) - (pr.onAccount || 0)); // unapplied money in favour of the party's debt
      // Settlements against bills we never saw raised (e.g. bills inside an opening balance) are unapplied credit too.
      var list = sortBy(pr.bills.filter(function (b) {
        if (b.amount === 0 && b.settled > 0) { credit = r2(credit + b.settled); return false; }
        return true;
      }), function (b) { return b.bill_date + '|' + b.bill_name; });
      if (fifo && credit > 0) {
        var credits = (pr.credits || []).slice();
        list.forEach(function (b) {
          var open = r2(b.amount - b.settled);
          if (open <= 0 || credit <= 0) return;
          var apply = Math.min(open, credit);
          b.settled = r2(b.settled + apply); credit = r2(credit - apply);
          b.settlements.push({ date: credits.length ? credits[0].date : asOf, amount: apply, voucher_number: 'FIFO' });
        });
      }
      var ledgerBal = r2(balanceAt(ctx, pr.party, asOf) * sign);
      var billTotal = sum(list, function (b) { return r2(b.amount - b.settled); });
      var onAccount = r2(ledgerBal - billTotal); // what bills don't explain (advances, unallocated debits)
      var rows = [];
      list.forEach(function (b) {
        var out = r2(b.amount - b.settled);
        if (Math.abs(out) < 0.005) return;
        var basis = str(ctx.S.AGEING_BASIS).toUpperCase() === 'BILL_DATE' ? b.bill_date : b.due_date;
        var daysOut = daysBetween(b.bill_date, asOf);
        var overdue = daysBetween(b.due_date, asOf);
        var ageDays = daysBetween(basis, asOf);
        var row = {
          party: b.party, bill_name: b.bill_name, bill_date: b.bill_date, due_date: b.due_date,
          bill_amount: b.amount, settled_amount: b.settled, outstanding: out,
          days_outstanding: daysOut, days_overdue: Math.max(0, overdue),
          ageing_bucket: out < 0 ? 'Advance' : bucketFor(ctx, ageDays),
          status: out < 0 ? 'Advance' : (overdue > 0 ? 'Overdue' : 'Current'),
          voucher_id: b.voucher_id, voucher_number: b.voucher_number, synthetic: b.synthetic
        };
        rows.push(row);
      });
      if (Math.abs(onAccount) >= 0.01) {
        rows.push({
          party: pr.party, bill_name: onAccount < 0 ? 'On Account (advance / unallocated)' : 'Unallocated debit',
          bill_date: asOf, due_date: asOf, bill_amount: onAccount, settled_amount: 0, outstanding: onAccount,
          days_outstanding: 0, days_overdue: 0, ageing_bucket: onAccount < 0 ? 'Advance' : 'Not Due', status: onAccount < 0 ? 'Advance' : 'Current',
          voucher_id: '', voucher_number: '', synthetic: true
        });
      }
      if (!rows.length && !ledgerBal) return;
      rows.forEach(function (r) {
        if (bucketTotals[r.ageing_bucket] !== undefined) bucketTotals[r.ageing_bucket] = r2(bucketTotals[r.ageing_bucket] + r.outstanding);
        else bucketTotals[r.ageing_bucket] = r2((bucketTotals[r.ageing_bucket] || 0) + r.outstanding);
      });
      allBills = allBills.concat(rows);
      var overdueRows = rows.filter(function (r) { return r.status === 'Overdue'; });
      var info = ctx.ledgerInfo(pr.party);
      partyRows.push({
        party: pr.party, gstin: info.gstin, balance: ledgerBal,
        outstanding_bills: rows.filter(function (r) { return r.outstanding > 0; }).length,
        overdue_bills: overdueRows.length, overdue_amount: sum(overdueRows, function (r) { return r.outstanding; }),
        oldest_due: overdueRows.length ? sortBy(overdueRows, function (r) { return r.due_date; })[0].due_date : '',
        max_days_overdue: overdueRows.reduce(function (m, r) { return Math.max(m, r.days_overdue); }, 0),
        buckets: labels.reduce(function (o, l) { o[l] = sum(rows.filter(function (r) { return r.ageing_bucket === l; }), function (r) { return r.outstanding; }); return o; }, {}),
        advance: sum(rows.filter(function (r) { return r.outstanding < 0; }), function (r) { return r.outstanding; })
      });
    });
    partyRows = sortBy(partyRows, function (r) { return r.balance; }, true);
    allBills = sortBy(allBills, function (r) { return r.due_date; });
    var totalOutstanding = sum(partyRows, function (r) { return r.balance; });
    var overdue = sum(allBills.filter(function (r) { return r.status === 'Overdue'; }), function (r) { return r.outstanding; });
    return {
      kind: kind, asOf: asOf, basis: ctx.S.AGEING_BASIS, bucketLabels: labels, bucketTotals: bucketTotals,
      total: totalOutstanding, overdue: overdue, current: r2(totalOutstanding - overdue),
      parties: partyRows, bills: allBills,
      summary: {
        overdue30: sum(allBills.filter(function (r) { return r.days_overdue > 30; }), function (r) { return r.outstanding; }),
        overdue60: sum(allBills.filter(function (r) { return r.days_overdue > 60; }), function (r) { return r.outstanding; }),
        overdue90: sum(allBills.filter(function (r) { return r.days_overdue > 90; }), function (r) { return r.outstanding; }),
        overdue180: sum(allBills.filter(function (r) { return r.days_overdue > 180; }), function (r) { return r.outstanding; }),
        overdue365: sum(allBills.filter(function (r) { return r.days_overdue > 365; }), function (r) { return r.outstanding; })
      }
    };
  }

  /** Customer / vendor account summary: opening, sales/purchases, notes, receipts/payments, adjustments, closing. */
  function partyAccounts(ctx, p) {
    p = p || {};
    var kind = p.kind === 'vendor' ? 'vendor' : 'customer';
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var sign = kind === 'customer' ? 1 : -1;
    var pred = kind === 'customer' ? function (i) { return i.isDebtor; } : function (i) { return i.isCreditor; };
    var os = outstanding(ctx, { kind: kind === 'customer' ? 'receivable' : 'payable', asOf: to });
    var osBy = {}; os.parties.forEach(function (r) { osBy[key(r.party)] = r; });
    var rows = ledgerNames(ctx, pred).map(function (name) {
      var r = { party: ctx.ledgerInfo(name).name, gstin: ctx.ledgerInfo(name).gstin, opening: r2(balanceAt(ctx, name, addDays(from, -1)) * sign), invoices: 0, notes: 0, settlements: 0, adjustments: 0 };
      (ctx.byLedger[key(name)] || []).forEach(function (l) {
        if (!inRange(l.date, from, to)) return;
        var amt = r2(l.nd * sign), b = l.v.base;
        if (kind === 'customer') {
          if (b === 'Sales') r.invoices = r2(r.invoices + amt);
          else if (b === 'Credit Note') r.notes = r2(r.notes - amt);
          else if (b === 'Receipt') r.settlements = r2(r.settlements - amt);
          else r.adjustments = r2(r.adjustments + amt);
        } else {
          if (b === 'Purchase') r.invoices = r2(r.invoices + amt);
          else if (b === 'Debit Note') r.notes = r2(r.notes - amt);
          else if (b === 'Payment') r.settlements = r2(r.settlements - amt);
          else r.adjustments = r2(r.adjustments + amt);
        }
      });
      r.closing = r2(r.opening + r.invoices - r.notes - r.settlements + r.adjustments);
      var o = osBy[key(name)] || {};
      r.outstanding_bills = o.outstanding_bills || 0; r.overdue_bills = o.overdue_bills || 0;
      r.overdue_amount = o.overdue_amount || 0; r.oldest_due = o.oldest_due || ''; r.max_days_overdue = o.max_days_overdue || 0;
      r.ageing = o.buckets || {};
      return r;
    }).filter(function (r) { return r.opening || r.invoices || r.notes || r.settlements || r.adjustments || r.closing; });
    rows = sortBy(rows, function (r) { return r.closing; }, true);
    var labels = kind === 'customer'
      ? { invoices: 'Sales', notes: 'Credit notes', settlements: 'Receipts' }
      : { invoices: 'Purchases', notes: 'Debit notes', settlements: 'Payments' };
    return {
      kind: kind, from: from, to: to, labels: labels, rows: rows,
      totals: ['opening', 'invoices', 'notes', 'settlements', 'adjustments', 'closing', 'overdue_amount'].reduce(function (o, k) { o[k] = sum(rows, function (r) { return r[k]; }); return o; }, {})
    };
  }

  // ---------------------------------------------------------------------------
  // Registers (sales / purchases / receipts / payments)
  // ---------------------------------------------------------------------------
  function taxBreakup(v) {
    var t = { taxable: 0, cgst: 0, sgst: 0, igst: 0, cess: 0, roundOff: 0 };
    var income = v.base === 'Sales' || v.base === 'Credit Note';
    v.lines.forEach(function (l) {
      var natural = income ? -l.nd : l.nd; // positive for the invoice direction
      if (l.info.isGst) { var k = l.info.taxType.toLowerCase(); t[k] = r2(t[k] + natural); return; }
      if (income && l.info.nature === 'Income') t.taxable = r2(t.taxable + natural);
      else if (!income && l.info.nature === 'Expenses') t.taxable = r2(t.taxable + natural);
      else if (!income && (l.info.chain.indexOf('Fixed Assets') >= 0)) t.taxable = r2(t.taxable + natural);
      else if (/round/i.test(l.ledger)) t.roundOff = r2(t.roundOff + natural);
    });
    t.tax = r2(t.cgst + t.sgst + t.igst + t.cess);
    return t;
  }

  function register(ctx, p) {
    p = p || {};
    var kind = p.kind === 'purchase' ? 'purchase' : 'sales';
    var base = kind === 'sales' ? 'Sales' : 'Purchase';
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var os = outstanding(ctx, { kind: kind === 'sales' ? 'receivable' : 'payable', asOf: D(p.asOf) || ctx.today });
    var byVoucher = {};
    os.bills.forEach(function (b) { if (b.voucher_id) byVoucher[b.voucher_id] = (byVoucher[b.voucher_id] || 0) + b.outstanding; });
    var sign = kind === 'sales' ? 1 : -1;
    var items = groupBy((kind === 'sales' ? ctx.db.salesItems : ctx.db.purchaseItems) || [], function (i) { return str(i.voucher_id); });
    var rows = [];
    ctx.vouchers.forEach(function (v) {
      if (v.base !== base || !inRange(v.date, from, to)) return;
      var tb = taxBreakup(v);
      var amount = v.partyNd ? r2(v.partyNd * sign) : r2(tb.taxable + tb.tax + tb.roundOff);
      var cashSale = v.partyInfo && v.partyInfo.isCashEq;
      var out = cashSale ? 0 : (byVoucher[v.id] !== undefined ? r2(byVoucher[v.id]) : 0);
      var paid = r2(amount - out);
      var due = '';
      v.bills.forEach(function (b) { if (b.type !== 'Agst Ref' && b.due && !due) due = b.due; });
      if (!due) due = addDays(v.date, v.partyInfo && v.partyInfo.creditDays !== null ? v.partyInfo.creditDays : ctx.S.DEFAULT_CREDIT_DAYS);
      var status = out <= 0.005 ? 'Paid' : (due < (D(p.asOf) || ctx.today) ? 'Overdue' : (paid > 0.005 ? 'Partially Paid' : 'Outstanding'));
      var its = (items[v.id] || []).filter(function (i) { return (num(i.revision) || 1) === v.revision; });
      rows.push({
        voucher_id: v.id, invoice_no: v.number, invoice_date: v.date, voucher_type: v.type,
        party: v.party, party_gstin: v.partyGstin || (v.partyInfo ? v.partyInfo.gstin : ''), place_of_supply: v.pos,
        salesperson: v.salesperson, source: v.source, cost_centre: v.costCentre,
        products: its.map(function (i) { return str(i.product_name); }).join(', '),
        quantity: sum(its, function (i) { return num(i.qty); }),
        discount: sum(its, function (i) { return num(i.discount_amount); }),
        taxable: tb.taxable, cgst: tb.cgst, sgst: tb.sgst, igst: tb.igst, cess: tb.cess, tax: tb.tax,
        amount: amount, paid: paid, outstanding: out, due_date: due, status: status,
        days_overdue: status === 'Overdue' ? daysBetween(due, D(p.asOf) || ctx.today) : 0,
        reference: v.ref, narration: v.narration
      });
    });
    if (p.party) rows = rows.filter(function (r) { return key(r.party) === key(p.party); });
    if (p.status) rows = rows.filter(function (r) { return r.status === p.status; });
    if (p.source) rows = rows.filter(function (r) { return r.source === p.source; });
    if (p.salesperson) rows = rows.filter(function (r) { return key(r.salesperson) === key(p.salesperson); });
    rows = sortBy(rows, function (r) { return r.invoice_date + '|' + r.invoice_no; }, true);
    return {
      kind: kind, from: from, to: to, rows: rows,
      totals: {
        count: rows.length, taxable: sum(rows, function (r) { return r.taxable; }), tax: sum(rows, function (r) { return r.tax; }),
        amount: sum(rows, function (r) { return r.amount; }), paid: sum(rows, function (r) { return r.paid; }),
        outstanding: sum(rows, function (r) { return r.outstanding; }),
        bySource: groupTotals(rows, 'source', 'amount'), byStatus: groupTotals(rows, 'status', 'amount')
      }
    };
  }

  function groupTotals(rows, field, valueField) {
    var g = groupBy(rows, function (r) { return r[field] || '(blank)'; });
    return Object.keys(g).map(function (k) { return { key: k, count: g[k].length, amount: sum(g[k], function (r) { return r[valueField]; }) }; })
      .sort(function (a, b) { return b.amount - a.amount; });
  }

  /** Sales report grouped by day/week/month/customer/product/salesperson/state/source/gst_rate/channel. */
  function salesReport(ctx, p) {
    var reg = register(ctx, { kind: p.kind || 'sales', from: p.from, to: p.to });
    var by = p.groupBy || 'month';
    var rows;
    if (by === 'product' || by === 'gst_rate') {
      var items = (p.kind === 'purchase' ? ctx.db.purchaseItems : ctx.db.salesItems) || [];
      var ids = {}; reg.rows.forEach(function (r) { ids[r.voucher_id] = true; });
      var live = items.filter(function (i) { var v = ctx.vById[str(i.voucher_id)]; return ids[str(i.voucher_id)] && v && (num(i.revision) || 1) === v.revision; });
      var g = groupBy(live, function (i) { return by === 'product' ? str(i.product_name) : (num(i.gst_rate) + '%'); });
      rows = Object.keys(g).map(function (k) {
        var its = g[k], qty = sum(its, function (i) { return num(i.qty); }), taxable = sum(its, function (i) { return num(i.taxable_amount); });
        return { key: k, count: its.length, quantity: qty, taxable: taxable, tax: sum(its, function (i) { return num(i.cgst) + num(i.sgst) + num(i.igst) + num(i.cess); }), amount: sum(its, function (i) { return num(i.line_total); }), avg_price: qty ? r2(taxable / qty) : 0 };
      });
    } else {
      var keyFn = {
        day: function (r) { return r.invoice_date; }, week: function (r) { return weekKey(r.invoice_date); },
        month: function (r) { return monthKey(r.invoice_date); }, quarter: function (r) { return quarterKey(r.invoice_date, ctx.fyM); },
        year: function (r) { return fyLabel(r.invoice_date, ctx.fyM); }, customer: function (r) { return r.party; }, vendor: function (r) { return r.party; },
        salesperson: function (r) { return r.salesperson || '(unassigned)'; }, source: function (r) { return r.source; },
        state: function (r) { return r.place_of_supply || (ctx.ledgerInfo(r.party).state) || '(unknown)'; },
        channel: function (r) { return r.cost_centre || r.source; }
      }[by] || function (r) { return monthKey(r.invoice_date); };
      var g2 = groupBy(reg.rows, keyFn);
      rows = Object.keys(g2).map(function (k) {
        var rs = g2[k];
        return { key: k, count: rs.length, taxable: sum(rs, function (r) { return r.taxable; }), tax: sum(rs, function (r) { return r.tax; }), amount: sum(rs, function (r) { return r.amount; }), outstanding: sum(rs, function (r) { return r.outstanding; }) };
      });
    }
    var total = sum(rows, function (r) { return r.amount; });
    rows.forEach(function (r) { r.share = pct(r.amount, total); });
    var timeKeys = ['day', 'week', 'month', 'quarter', 'year'];
    rows = timeKeys.indexOf(by) >= 0 ? sortBy(rows, function (r) { return r.key; }) : sortBy(rows, function (r) { return r.amount; }, true);
    return { groupBy: by, from: reg.from, to: reg.to, rows: rows, total: total, count: reg.rows.length };
  }

  function cashRegister(ctx, p) {
    // Receipts or payments: vouchers of that base type, amount = cash/bank movement.
    p = p || {};
    var base = p.kind === 'payment' ? 'Payment' : 'Receipt';
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var rows = ctx.vouchers.filter(function (v) { return v.base === base && inRange(v.date, from, to); }).map(function (v) {
      var cash = v.lines.filter(function (l) { return l.info.isCashEq; });
      var other = v.lines.filter(function (l) { return !l.info.isCashEq; });
      var againsts = v.bills.filter(function (b) { return b.type === 'Agst Ref'; }).map(function (b) { return b.name; });
      return {
        voucher_id: v.id, date: v.date, number: v.number, voucher_type: v.type,
        party: v.party || (other[0] ? other[0].ledger : ''),
        account: cash.map(function (l) { return l.ledger; }).join(', '),
        amount: Math.abs(sum(cash, function (l) { return l.nd; })) || v.amount,
        against: againsts.join(', ') || (v.bills.length ? v.bills[0].type : ''),
        reference: v.ref, narration: v.narration, source: v.source
      };
    });
    if (p.party) rows = rows.filter(function (r) { return key(r.party) === key(p.party); });
    rows = sortBy(rows, function (r) { return r.date + r.number; }, true);
    return { kind: p.kind || 'receipt', from: from, to: to, rows: rows, total: sum(rows, function (r) { return r.amount; }), count: rows.length };
  }

  function cashBook(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var accounts = ledgerNames(ctx, function (i) { return i.isCashEq; }).map(function (n) {
      var info = ctx.ledgerInfo(n);
      return { ledger: info.name, type: info.isCash ? 'Cash' : 'Bank', opening: balanceAt(ctx, n, addDays(from, -1)), closing: balanceAt(ctx, n, to), inflow: 0, outflow: 0 };
    });
    var accBy = {}; accounts.forEach(function (a) { accBy[key(a.ledger)] = a; });
    var selected = p.ledger ? key(p.ledger) : null;
    var run = selected ? (accBy[selected] ? accBy[selected].opening : 0) : sum(accounts, function (a) { return a.opening; });
    var rows = [];
    ctx.lines.forEach(function (l) {
      if (!l.info.isCashEq || !inRange(l.date, from, to)) return;
      var a = accBy[key(l.ledger)];
      if (l.nd > 0) a.inflow = r2(a.inflow + l.nd); else a.outflow = r2(a.outflow - l.nd);
      if (selected && key(l.ledger) !== selected) return;
      var isContraInternal = !selected && l.v.lines.every(function (o) { return o.info.isCashEq; });
      if (isContraInternal) return;
      run = r2(run + l.nd);
      var others = l.v.lines.filter(function (o) { return !o.info.isCashEq; });
      rows.push({ date: l.date, voucher_id: l.v.id, voucher_number: l.v.number, voucher_type: l.v.type || l.v.base, account: l.ledger, particulars: others.length ? others[0].ledger : l.v.lines.filter(function (o) { return o !== l; }).map(function (o) { return o.ledger; }).join(', '), receipt: l.nd > 0 ? l.nd : 0, payment: l.nd < 0 ? -l.nd : 0, balance: run, narration: l.v.narration });
    });
    return {
      from: from, to: to, accounts: accounts, rows: rows,
      opening: selected ? (accBy[selected] || {}).opening || 0 : sum(accounts, function (a) { return a.opening; }),
      closing: run,
      cash: sum(accounts.filter(function (a) { return a.type === 'Cash'; }), function (a) { return a.closing; }),
      bank: sum(accounts.filter(function (a) { return a.type === 'Bank'; }), function (a) { return a.closing; })
    };
  }

  // ---------------------------------------------------------------------------
  // GST
  // ---------------------------------------------------------------------------
  function gstDirection(v) {
    var hasIncome = v.lines.some(function (l) { return l.info.nature === 'Income'; });
    if (hasIncome) return 'OUTPUT';
    var hasCost = v.lines.some(function (l) { return l.info.nature === 'Expenses' || l.info.chain.indexOf('Fixed Assets') >= 0; });
    if (hasCost) return 'INPUT';
    return 'SETTLEMENT';
  }
  function gstTransactions(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var out = [];
    ctx.vouchers.forEach(function (v) {
      if (!inRange(v.date, from, to)) return;
      var gl = v.lines.filter(function (l) { return l.info.isGst; });
      if (!gl.length) return;
      var dir = gstDirection(v);
      var s = dir === 'OUTPUT' ? -1 : 1; // output: Cr - Dr ; input & settlement: Dr - Cr
      var t = { cgst: 0, sgst: 0, igst: 0, cess: 0 };
      gl.forEach(function (l) { var k = l.info.taxType.toLowerCase(); t[k] = r2(t[k] + s * l.nd); });
      var taxable = 0;
      v.lines.forEach(function (l) {
        if (dir === 'OUTPUT' && l.info.nature === 'Income') taxable += -l.nd;
        if (dir === 'INPUT' && (l.info.nature === 'Expenses' || l.info.chain.indexOf('Fixed Assets') >= 0)) taxable += l.nd;
      });
      var totalTax = r2(t.cgst + t.sgst + t.igst + t.cess);
      out.push({
        voucher_id: v.id, voucher_date: v.date, voucher_number: v.number, base_voucher_type: v.base, direction: dir,
        party_ledger: v.party, party_gstin: v.partyGstin || (v.partyInfo ? v.partyInfo.gstin : ''),
        place_of_supply: v.pos || (v.partyInfo ? v.partyInfo.state : ''),
        supply_type: t.igst ? 'Inter-State' : 'Intra-State',
        taxable_value: r2(taxable), gst_rate: taxable ? Math.round(totalTax / taxable * 1000) / 10 : 0,
        cgst: t.cgst, sgst: t.sgst, igst: t.igst, cess: t.cess, total_tax: totalTax
      });
    });
    return out;
  }
  function gstSummary(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var tx = gstTransactions(ctx, { from: from, to: to });
    function agg(rows) { return ['taxable_value', 'cgst', 'sgst', 'igst', 'cess', 'total_tax'].reduce(function (o, k) { o[k] = sum(rows, function (r) { return r[k]; }); return o; }, {}); }
    var output = agg(tx.filter(function (r) { return r.direction === 'OUTPUT'; }));
    var input = agg(tx.filter(function (r) { return r.direction === 'INPUT'; }));
    var settled = agg(tx.filter(function (r) { return r.direction === 'SETTLEMENT'; }));
    var net = { cgst: r2(output.cgst - input.cgst), sgst: r2(output.sgst - input.sgst), igst: r2(output.igst - input.igst), cess: r2(output.cess - input.cess) };
    net.total = r2(net.cgst + net.sgst + net.igst + net.cess);
    var months = groupBy(tx, function (r) { return monthKey(r.voucher_date); });
    var monthly = Object.keys(months).sort().map(function (m) {
      var o = agg(months[m].filter(function (r) { return r.direction === 'OUTPUT'; })), i = agg(months[m].filter(function (r) { return r.direction === 'INPUT'; }));
      return { period: m, output: o.total_tax, input: i.total_tax, net: r2(o.total_tax - i.total_tax), outputTaxable: o.taxable_value, inputTaxable: i.taxable_value };
    });
    function byField(dir, field) {
      var g = groupBy(tx.filter(function (r) { return r.direction === dir; }), function (r) { return r[field] || '(blank)'; });
      return Object.keys(g).map(function (k) { var a = agg(g[k]); a.key = k; a.count = g[k].length; if (field === 'party_ledger') a.gstin = g[k][0].party_gstin; return a; }).sort(function (a, b) { return b.total_tax - a.total_tax; });
    }
    // HSN summary from item tables
    function hsn(items, dirVouchers) {
      var g = groupBy(items.filter(function (i) { var v = ctx.vById[str(i.voucher_id)]; return v && dirVouchers[v.id] && (num(i.revision) || 1) === v.revision; }), function (i) { return str(i.hsn_sac) || '(none)'; });
      return Object.keys(g).map(function (k) { var its = g[k]; return { hsn_sac: k, quantity: sum(its, function (i) { return num(i.qty); }), taxable_value: sum(its, function (i) { return num(i.taxable_amount); }), cgst: sum(its, function (i) { return num(i.cgst); }), sgst: sum(its, function (i) { return num(i.sgst); }), igst: sum(its, function (i) { return num(i.igst); }), cess: sum(its, function (i) { return num(i.cess); }) }; }).sort(function (a, b) { return b.taxable_value - a.taxable_value; });
    }
    var outV = {}, inV = {};
    tx.forEach(function (r) { if (r.direction === 'OUTPUT') outV[r.voucher_id] = true; if (r.direction === 'INPUT') inV[r.voucher_id] = true; });
    return {
      from: from, to: to, output: output, input: input, settled: settled, net: net,
      monthly: monthly, customers: byField('OUTPUT', 'party_ledger'), vendors: byField('INPUT', 'party_ledger'),
      states: byField('OUTPUT', 'place_of_supply'),
      hsnOutward: hsn(ctx.db.salesItems || [], outV), hsnInward: hsn(ctx.db.purchaseItems || [], inV),
      transactions: tx,
      disclaimer: 'Indicative summary derived from books. Net liability is output tax minus input tax per head; statutory ITC set-off order (Sec. 49/49A/49B CGST Act), blocked credits, RCM and GSTR-2B matching are not applied. Verify with your GST practitioner before filing.'
    };
  }

  // ---------------------------------------------------------------------------
  // Dashboards, MIS, financial health, analytics
  // ---------------------------------------------------------------------------
  function daySummary(ctx, date) {
    var sales = ctx.vouchers.filter(function (v) { return v.base === 'Sales' && v.date === date; });
    var purchases = ctx.vouchers.filter(function (v) { return v.base === 'Purchase' && v.date === date; });
    function invAmt(v, sign) { return v.partyNd ? r2(v.partyNd * sign) : (function (t) { return r2(t.taxable + t.tax + t.roundOff); })(taxBreakup(v)); }
    var inflow = 0, outflow = 0;
    ctx.vouchers.forEach(function (v) {
      if (v.date !== date) return;
      var cash = sum(v.lines.filter(function (l) { return l.info.isCashEq; }), function (l) { return l.nd; });
      if (v.lines.every(function (l) { return l.info.isCashEq; })) return; // contra
      if (cash > 0) inflow += cash; else outflow -= cash;
    });
    var expenses = movement(ctx, function (i) { return i.nature === 'Expenses' && i.primary !== 'Purchase Accounts'; }, date, date);
    return {
      date: date,
      salesBills: sales.length, salesAmount: sum(sales, function (v) { return invAmt(v, 1); }),
      offlineSalesBills: sales.filter(function (v) { return v.source === 'OFFLINE'; }).length,
      offlineSalesAmount: sum(sales.filter(function (v) { return v.source === 'OFFLINE'; }), function (v) { return invAmt(v, 1); }),
      purchaseBills: purchases.length, purchaseAmount: sum(purchases, function (v) { return invAmt(v, -1); }),
      receipts: r2(inflow), payments: r2(outflow), netCashFlow: r2(inflow - outflow), expenses: expenses
    };
  }

  function dashboard(ctx, p) {
    p = p || {};
    var date = D(p.date) || ctx.today;
    var fs = fyStart(date, ctx.fyM);
    var today = daySummary(ctx, date);
    var rec = outstanding(ctx, { kind: 'receivable', asOf: date });
    var pay = outstanding(ctx, { kind: 'payable', asOf: date });
    var cash = sumBalances(ctx, function (i) { return i.isCash; }, date);
    var bank = sumBalances(ctx, function (i) { return i.isBank; }, date);
    var mtdFrom = date.slice(0, 8) + '01';
    var mtdSales = register(ctx, { kind: 'sales', from: mtdFrom, to: date, asOf: date });
    var ytdSales = register(ctx, { kind: 'sales', from: fs, to: date, asOf: date });
    var trend = [];
    for (var i = 29; i >= 0; i--) {
      var d = addDays(date, -i), s = daySummary(ctx, d);
      trend.push({ date: d, sales: s.salesAmount, receipts: s.receipts, payments: s.payments });
    }
    var pl = profitLoss(ctx, { from: fs, to: date });
    var topCustomers = salesReport(ctx, { groupBy: 'customer', from: fs, to: date }).rows.slice(0, 5);
    return {
      date: date, fy: fyLabel(date, ctx.fyM), today: today,
      cashBalance: cash, bankBalance: bank,
      receivables: rec.total, payables: pay.total,
      overdueReceivables: rec.overdue, overduePayables: pay.overdue,
      outstanding: r2(rec.total - pay.total),
      mtd: { salesBills: mtdSales.totals.count, sales: mtdSales.totals.amount, collected: mtdSales.totals.paid },
      ytd: { salesBills: ytdSales.totals.count, sales: ytdSales.totals.amount, revenue: pl.revenue, grossProfit: pl.grossProfit, netProfit: pl.netProfit, grossMargin: pl.grossMargin },
      salesBySource: ytdSales.totals.bySource,
      trend: trend, monthly: monthlyTrend(ctx, { from: fs, to: date }),
      receivableBuckets: rec.bucketTotals, payableBuckets: pay.bucketTotals, bucketLabels: rec.bucketLabels,
      topOverdue: sortBy(rec.bills.filter(function (b) { return b.status === 'Overdue'; }), function (b) { return b.outstanding; }, true).slice(0, 8),
      topCustomers: topCustomers,
      warnings: ctx.warnings.slice(0, 20)
    };
  }

  function managementDashboard(ctx, p) {
    p = p || {};
    var date = D(p.date) || ctx.today, fs = fyStart(date, ctx.fyM);
    var today = daySummary(ctx, date);
    var rec = outstanding(ctx, { kind: 'receivable', asOf: date });
    var pay = outstanding(ctx, { kind: 'payable', asOf: date });
    var pl = profitLoss(ctx, { from: fs, to: date });
    var months = [];
    for (var i = 5; i >= 0; i--) {
      var m = fromUTC(Date.UTC(+date.slice(0, 4), +date.slice(5, 7) - 1 - i, 1));
      var e = endOfMonth(m); if (e > date) e = date;
      var cf = cashFlow(ctx, { from: m, to: e });
      months.push({
        month: m.slice(0, 7), receivables: outstanding(ctx, { kind: 'receivable', asOf: e }).total,
        payables: outstanding(ctx, { kind: 'payable', asOf: e }).total,
        inflow: cf.inflow, outflow: cf.outflow, net: cf.net,
        revenue: profitLoss(ctx, { from: m, to: e }).revenue
      });
    }
    function direction(arr, k) {
      if (arr.length < 2) return 'flat';
      var a = arr[arr.length - 2][k], b = arr[arr.length - 1][k];
      return b > a * 1.02 ? 'increasing' : b < a * 0.98 ? 'decreasing' : 'flat';
    }
    var expenses = {};
    ctx.lines.forEach(function (l) {
      if (!inRange(l.date, fs, date) || l.info.nature !== 'Expenses' || l.info.primary === 'Purchase Accounts') return;
      expenses[l.info.name] = r2((expenses[l.info.name] || 0) + l.nd);
    });
    return {
      date: date,
      q1_salesToday: { bills: today.salesBills, amount: today.salesAmount },
      q2_purchaseToday: { bills: today.purchaseBills, amount: today.purchaseAmount },
      q3_cashIn: today.receipts, q4_cashOut: today.payments,
      q5_customersOwe: rec.total, q6_weOweVendors: pay.total,
      q7_overdueInvoices: sortBy(rec.bills.filter(function (b) { return b.status === 'Overdue'; }), function (b) { return b.days_overdue; }, true).slice(0, 10),
      q8_topCustomers: salesReport(ctx, { groupBy: 'customer', from: fs, to: date }).rows.slice(0, 10),
      q9_topVendorOutstanding: pay.parties.slice(0, 10),
      q10_currentProfit: { revenue: pl.revenue, grossProfit: pl.grossProfit, netProfit: pl.netProfit, netMargin: pl.netMargin },
      q11_revenueTrend: months.map(function (m) { return { month: m.month, revenue: m.revenue }; }),
      q12_cashFlowTrend: months.map(function (m) { return { month: m.month, inflow: m.inflow, outflow: m.outflow, net: m.net }; }),
      q13_majorExpenses: Object.keys(expenses).map(function (k) { return { ledger: k, amount: expenses[k] }; }).sort(function (a, b) { return b.amount - a.amount; }).slice(0, 10),
      q14_receivablesTrend: { direction: direction(months, 'receivables'), series: months.map(function (m) { return { month: m.month, value: m.receivables }; }) },
      q15_payablesTrend: { direction: direction(months, 'payables'), series: months.map(function (m) { return { month: m.month, value: m.payables }; }) }
    };
  }

  function financialHealth(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var days = daysBetween(from, to) + 1;
    var bs = balanceSheet(ctx, { asOf: to });
    var pl = profitLoss(ctx, { from: from, to: to });
    var cf = cashFlow(ctx, { from: from, to: to });
    function sec(side, name) { var s = (side === 'A' ? bs.assets : bs.liabilities).filter(function (x) { return x.section === name; })[0]; return s ? s.amount : 0; }
    var ca = sec('A', 'Current Assets'), cl = sec('L', 'Current Liabilities'), stock = bs.closingStock;
    var loans = sec('L', 'Loans (Liability)'), equity = sec('L', 'Capital Account');
    var cash = sumBalances(ctx, function (i) { return i.isCashEq; }, to);
    var rec = outstanding(ctx, { kind: 'receivable', asOf: to }).total;
    var pay = outstanding(ctx, { kind: 'payable', asOf: to }).total;
    var salesReg = register(ctx, { kind: 'sales', from: from, to: to });
    var purReg = register(ctx, { kind: 'purchase', from: from, to: to });
    var grossSales = ctx.S.DSO_USE_GROSS_SALES ? salesReg.totals.amount : pl.revenue;
    var grossPurch = ctx.S.DSO_USE_GROSS_SALES ? purReg.totals.amount : pl.purchases;
    var openRec = outstanding(ctx, { kind: 'receivable', asOf: addDays(from, -1) }).total;
    var openPay = outstanding(ctx, { kind: 'payable', asOf: addDays(from, -1) }).total;
    var custReceipts = sum(cf.sections[0].lines.filter(function (l) { return l.label === 'Receipts from customers'; }), function (l) { return l.inflow; });
    var vendPayments = sum(cf.sections[0].lines.filter(function (l) { return l.label === 'Payments to suppliers'; }), function (l) { return l.outflow; });
    var dso = grossSales ? r2(rec / grossSales * days) : null;
    var dpo = grossPurch ? r2(pay / grossPurch * days) : null;
    var avgStock = (pl.openingStock + pl.closingStock) / 2;
    var dio = pl.cogs ? r2(avgStock / pl.cogs * days) : null;
    function m(k, label, value, unit, formula, inputs, good, bad, higherIsBetter) {
      var status = 'neutral';
      if (value !== null && good !== undefined) {
        status = higherIsBetter ? (value >= good ? 'good' : value <= bad ? 'bad' : 'warn') : (value <= good ? 'good' : value >= bad ? 'bad' : 'warn');
      }
      return { key: k, label: label, value: value === null ? null : r2(value), unit: unit, formula: formula, inputs: inputs, status: status };
    }
    var ratio = function (a, b) { return b ? a / b : null; };
    var metrics = [
      m('current_ratio', 'Current ratio', ratio(ca, cl), 'x', 'Current assets / Current liabilities', { 'Current assets': ca, 'Current liabilities': cl }, 1.5, 1, true),
      m('quick_ratio', 'Quick ratio', ratio(ca - stock, cl), 'x', '(Current assets - Closing stock) / Current liabilities', { 'Current assets': ca, 'Closing stock': stock, 'Current liabilities': cl }, 1, 0.7, true),
      m('gross_margin', 'Gross margin', pl.grossMargin, '%', 'Gross profit / Revenue x 100', { 'Gross profit': pl.grossProfit, 'Revenue': pl.revenue }, 30, 15, true),
      m('net_margin', 'Net margin', pl.netMargin, '%', 'Net profit / Revenue x 100', { 'Net profit': pl.netProfit, 'Revenue': pl.revenue }, 10, 0, true),
      m('receivable_days', 'Receivable days (DSO)', dso, 'days', 'Closing receivables / ' + (ctx.S.DSO_USE_GROSS_SALES ? 'Gross sales incl. GST' : 'Revenue') + ' x Days in period', { 'Closing receivables': rec, 'Sales': grossSales, 'Days': days }, 45, 90, false),
      m('payable_days', 'Payable days (DPO)', dpo, 'days', 'Closing payables / ' + (ctx.S.DSO_USE_GROSS_SALES ? 'Gross purchases incl. GST' : 'Purchases') + ' x Days in period', { 'Closing payables': pay, 'Purchases': grossPurch, 'Days': days }),
      m('inventory_days', 'Inventory days (DIO)', dio, 'days', 'Average stock / COGS x Days', { 'Opening stock': pl.openingStock, 'Closing stock': pl.closingStock, 'COGS': pl.cogs, 'Days': days }),
      m('cash_conversion_cycle', 'Cash conversion cycle', dso !== null && dpo !== null ? (dio || 0) + dso - dpo : null, 'days', 'DIO + DSO - DPO', { 'DIO': dio, 'DSO': dso, 'DPO': dpo }, 60, 120, false),
      m('working_capital', 'Working capital', ca - cl, '₹', 'Current assets - Current liabilities', { 'Current assets': ca, 'Current liabilities': cl }, 0, -1, true),
      m('cash_position', 'Cash position', cash, '₹', 'Cash-in-Hand + Bank Accounts', { 'Cash & bank': cash }, ctx.S.CASH_SHORTAGE_THRESHOLD * 2, ctx.S.CASH_SHORTAGE_THRESHOLD, true),
      m('debt_to_equity', 'Debt-to-equity', ratio(loans, equity), 'x', 'Loans (Liability) / Capital Account incl. reserves & profit', { 'Loans': loans, 'Equity': equity }, 1, 2, false),
      m('operating_cash_flow', 'Operating cash flow', cf.sections[0].net, '₹', 'Net cash from operating activities (direct method)', { 'Operating inflow': cf.sections[0].inflow, 'Operating outflow': cf.sections[0].outflow }, 0, -1, true),
      m('collection_efficiency', 'Collection efficiency', ratio(custReceipts, openRec + grossSales) !== null ? ratio(custReceipts, openRec + grossSales) * 100 : null, '%', 'Receipts from customers / (Opening receivables + Sales) x 100', { 'Receipts': custReceipts, 'Opening receivables': openRec, 'Sales': grossSales }, 70, 40, true),
      m('payment_efficiency', 'Payment efficiency', ratio(vendPayments, openPay + grossPurch) !== null ? ratio(vendPayments, openPay + grossPurch) * 100 : null, '%', 'Payments to suppliers / (Opening payables + Purchases) x 100', { 'Payments': vendPayments, 'Opening payables': openPay, 'Purchases': grossPurch }),
      m('expense_ratio', 'Expense ratio', pct(pl.operating, pl.revenue), '%', 'Operating expenses / Revenue x 100', { 'Operating expenses': pl.operating, 'Revenue': pl.revenue }, 20, 35, false)
    ];
    // Growth vs the previous period of equal length
    var prevTo = addDays(from, -1), prevFrom = addDays(prevTo, -(days - 1));
    var prevSales = register(ctx, { kind: 'sales', from: prevFrom, to: prevTo }).totals.amount;
    var prevPurch = register(ctx, { kind: 'purchase', from: prevFrom, to: prevTo }).totals.amount;
    function distinct(rows) { var o = {}; rows.forEach(function (r) { o[key(r.party)] = 1; }); return Object.keys(o).length; }
    var custNow = distinct(salesReg.rows), custPrev = distinct(register(ctx, { kind: 'sales', from: prevFrom, to: prevTo }).rows);
    var vendNow = distinct(purReg.rows), vendPrev = distinct(register(ctx, { kind: 'purchase', from: prevFrom, to: prevTo }).rows);
    function growth(a, b) { return b ? r2((a - b) / b * 100) : null; }
    metrics.push(
      m('sales_growth', 'Sales growth', growth(salesReg.totals.amount, prevSales), '%', '(Sales this period - previous period) / previous period', { 'This period': salesReg.totals.amount, 'Previous period': prevSales }, 10, 0, true),
      m('purchase_growth', 'Purchase growth', growth(purReg.totals.amount, prevPurch), '%', '(Purchases this period - previous) / previous', { 'This period': purReg.totals.amount, 'Previous period': prevPurch }),
      m('customer_growth', 'Active customer growth', growth(custNow, custPrev), '%', 'Distinct billed customers vs previous period', { 'This period': custNow, 'Previous period': custPrev }),
      m('vendor_growth', 'Active vendor growth', growth(vendNow, vendPrev), '%', 'Distinct billed vendors vs previous period', { 'This period': vendNow, 'Previous period': vendPrev })
    );
    return { from: from, to: to, days: days, previous: { from: prevFrom, to: prevTo }, metrics: metrics };
  }

  function analytics(ctx, p) {
    p = p || {};
    var to = D(p.to) || ctx.today, from = D(p.from) || fyStart(to, ctx.fyM);
    var reg = register(ctx, { kind: 'sales', from: from, to: to });
    var all = register(ctx, { kind: 'sales', from: '1900-01-01', to: to });
    var firstSale = {}, lastSale = {};
    all.rows.forEach(function (r) {
      var k = key(r.party);
      if (!firstSale[k] || r.invoice_date < firstSale[k]) firstSale[k] = r.invoice_date;
      if (!lastSale[k] || r.invoice_date > lastSale[k]) lastSale[k] = r.invoice_date;
    });
    var byCust = groupBy(reg.rows, function (r) { return r.party; });
    var total = reg.totals.amount;
    var customers = Object.keys(byCust).map(function (c) {
      var rs = byCust[c], amt = sum(rs, function (r) { return r.amount; });
      return { customer: c, invoices: rs.length, amount: amt, share: pct(amt, total), outstanding: sum(rs, function (r) { return r.outstanding; }), first_sale: firstSale[key(c)], type: firstSale[key(c)] >= from ? 'New' : 'Repeat' };
    }).sort(function (a, b) { return b.amount - a.amount; });
    var inactiveCut = addDays(to, -ctx.S.INACTIVE_CUSTOMER_DAYS);
    var inactive = Object.keys(lastSale).filter(function (k) { return lastSale[k] < inactiveCut; }).map(function (k) {
      var name = ctx.ledgerInfo(k).name; return { customer: name, last_sale: lastSale[k], days_since: daysBetween(lastSale[k], to) };
    });
    // Vendors
    var pur = register(ctx, { kind: 'purchase', from: from, to: to });
    var pay = outstanding(ctx, { kind: 'payable', asOf: to });
    var payBy = {}; pay.parties.forEach(function (x) { payBy[key(x.party)] = x; });
    var byVend = groupBy(pur.rows, function (r) { return r.party; });
    var vendors = Object.keys(byVend).map(function (vn) {
      var rs = byVend[vn], amt = sum(rs, function (r) { return r.amount; });
      var o = payBy[key(vn)] || {};
      return { vendor: vn, bills: rs.length, amount: amt, share: pct(amt, pur.totals.amount), outstanding: o.balance || 0, overdue: o.overdue_amount || 0, risk: o.balance ? pct(o.overdue_amount || 0, o.balance) : 0 };
    }).sort(function (a, b) { return b.amount - a.amount; });
    // Products (margin estimated from PRODUCTS.purchase_rate - flagged)
    var prodRates = {}; (ctx.db.products || []).forEach(function (pr) { prodRates[key(pr.product_name)] = num(pr.purchase_rate); });
    var products = salesReport(ctx, { groupBy: 'product', from: from, to: to }).rows.map(function (r) {
      var cost = prodRates[key(r.key)] ? r2(prodRates[key(r.key)] * r.quantity) : null;
      return { product: r.key, quantity: r.quantity, revenue: r.taxable, avg_price: r.avg_price, share: r.share, est_margin: cost === null ? null : r2(r.taxable - cost), est_margin_pct: cost === null ? null : pct(r.taxable - cost, r.taxable) };
    });
    return {
      from: from, to: to,
      revenue: {
        daily: salesReport(ctx, { groupBy: 'day', from: from, to: to }).rows,
        weekly: salesReport(ctx, { groupBy: 'week', from: from, to: to }).rows,
        monthly: salesReport(ctx, { groupBy: 'month', from: from, to: to }).rows,
        quarterly: salesReport(ctx, { groupBy: 'quarter', from: from, to: to }).rows,
        yearly: salesReport(ctx, { groupBy: 'year', from: '1900-01-01', to: to }).rows
      },
      customers: { top: customers.slice(0, 20), newCount: customers.filter(function (c) { return c.type === 'New'; }).length, repeatCount: customers.filter(function (c) { return c.type === 'Repeat'; }).length, inactive: inactive },
      vendors: vendors.slice(0, 20),
      products: products,
      notes: ['Product margin is an estimate using PRODUCTS.purchase_rate as standard cost, not actual FIFO/average cost.']
    };
  }

  // ---------------------------------------------------------------------------
  // Alerts & integrity
  // ---------------------------------------------------------------------------
  function alerts(ctx, p) {
    p = p || {};
    var date = D(p.date) || ctx.today, S = ctx.S, out = [];
    function add(sev, cat, title, msg, rec, dk) { out.push({ severity: sev, category: cat, title: title, message: msg, record_id: rec || '', dedupe_key: cat + '|' + (dk || rec || title) }); }
    var rec = outstanding(ctx, { kind: 'receivable', asOf: date });
    var pay = outstanding(ctx, { kind: 'payable', asOf: date });
    var win = addDays(date, S.UPCOMING_WINDOW_DAYS);
    rec.bills.forEach(function (b) {
      if (b.outstanding <= 0) return;
      if (b.status === 'Overdue') add('CRITICAL', 'OVERDUE_RECEIVABLE', 'Overdue receivable: ' + b.party, 'Bill ' + b.bill_name + ' of ' + inr(b.outstanding) + ' is ' + b.days_overdue + ' days overdue', b.bill_name, b.party + '|' + b.bill_name);
      else if (b.due_date <= win) add('WARNING', 'UPCOMING_COLLECTION', 'Collection due: ' + b.party, 'Bill ' + b.bill_name + ' of ' + inr(b.outstanding) + ' falls due on ' + b.due_date, b.bill_name, b.party + '|' + b.bill_name);
    });
    var vendors = {}; (ctx.db.vendors || []).forEach(function (v) { vendors[key(v.vendor_name)] = v; });
    pay.bills.forEach(function (b) {
      if (b.outstanding <= 0) return;
      var msme = vendors[key(b.party)] && bool(vendors[key(b.party)].msme_registered);
      var msmeDue = addDays(b.bill_date, S.MSME_MAX_PAYMENT_DAYS);
      if (msme && msmeDue <= win) add(msmeDue < date ? 'CRITICAL' : 'WARNING', 'MSME_DUE', 'MSME payment limit: ' + b.party, 'Bill ' + b.bill_name + ' must be paid by ' + msmeDue + ' (45-day MSME limit; Sec. 43B(h) disallowance risk)', b.bill_name, b.party + '|' + b.bill_name);
      if (b.status === 'Overdue') add('CRITICAL', 'OVERDUE_PAYABLE', 'Overdue payable: ' + b.party, 'Bill ' + b.bill_name + ' of ' + inr(b.outstanding) + ' is ' + b.days_overdue + ' days overdue', b.bill_name, b.party + '|' + b.bill_name);
      else if (b.due_date <= win) add('WARNING', 'UPCOMING_PAYMENT', 'Payment due: ' + b.party, 'Bill ' + b.bill_name + ' of ' + inr(b.outstanding) + ' falls due on ' + b.due_date, b.bill_name, b.party + '|' + b.bill_name);
    });
    var cash = sumBalances(ctx, function (i) { return i.isCashEq; }, date);
    var dueSoon = sum(pay.bills.filter(function (b) { return b.outstanding > 0 && b.due_date <= win; }), function (b) { return b.outstanding; });
    if (cash < S.CASH_SHORTAGE_THRESHOLD || cash < dueSoon) add('CRITICAL', 'CASH_SHORTAGE', 'Cash shortage risk', 'Cash & bank ' + inr(cash) + ' vs payables due in ' + S.UPCOMING_WINDOW_DAYS + ' days ' + inr(dueSoon), '', date.slice(0, 7));
    var mStart = date.slice(0, 8) + '01', prevStart = fromUTC(Date.UTC(+date.slice(0, 4), +date.slice(5, 7) - 2, 1));
    var elapsed = daysBetween(mStart, date) + 1;
    var isExp = function (i) { return i.nature === 'Expenses' && i.primary !== 'Purchase Accounts'; };
    var thisM = movement(ctx, isExp, mStart, date), prevM = movement(ctx, isExp, prevStart, addDays(prevStart, elapsed - 1));
    if (prevM > 0 && thisM > prevM * (1 + S.HIGH_EXPENSE_INCREASE_PCT / 100)) add('WARNING', 'HIGH_EXPENSE', 'Expenses up ' + Math.round((thisM / prevM - 1) * 100) + '%', 'Month-to-date expenses ' + inr(thisM) + ' vs ' + inr(prevM) + ' for the same days last month', '', date.slice(0, 7));
    integrity(ctx).duplicates.forEach(function (d) { add('WARNING', 'DUPLICATE_VOUCHER', 'Duplicate voucher number ' + d.voucher_number, d.count + ' ' + d.voucher_type + ' vouchers share number ' + d.voucher_number + ' in ' + d.fy, d.voucher_number, d.voucher_type + '|' + d.voucher_number + '|' + d.fy); });
    unbalancedVouchers(ctx).forEach(function (u) { add('CRITICAL', 'UNBALANCED_VOUCHER', 'Unbalanced voucher ' + u.voucher_number, 'Debit ' + u.debit + ' vs credit ' + u.credit, u.voucher_id); });
    return out;
  }

  function integrity(ctx) {
    var seen = {};
    ctx.vouchers.forEach(function (v) {
      if (!v.number) return;
      var k = v.type + '|' + v.number + '|' + fyLabel(v.date, ctx.fyM);
      (seen[k] = seen[k] || []).push(v);
    });
    var dups = Object.keys(seen).filter(function (k) { return seen[k].length > 1; }).map(function (k) {
      var vs = seen[k]; return { voucher_type: vs[0].type, voucher_number: vs[0].number, fy: fyLabel(vs[0].date, ctx.fyM), count: vs.length, voucher_ids: vs.map(function (v) { return v.id; }) };
    });
    return { duplicates: dups, unbalanced: unbalancedVouchers(ctx), unknownLedgers: ctx.warnings.filter(function (w) { return w.code === 'UNKNOWN_LEDGER'; }) };
  }

  function search(ctx, p) {
    var q = key(p.q || p.query);
    if (!q || q.length < 2) return { query: q, results: [] };
    var res = [];
    ctx.vouchers.forEach(function (v) {
      var hay = [v.id, v.number, v.ref, v.party, v.partyGstin, v.narration, v.uniqueKey].join(' ').toLowerCase();
      if (hay.indexOf(q) >= 0) res.push({ kind: 'voucher', id: v.id, title: v.type + ' ' + v.number, subtitle: v.party + ' · ' + v.date, amount: v.amount, date: v.date });
    });
    Object.keys(ctx.allLedgerNames).forEach(function (k) {
      var info = ctx.ledgerInfo(ctx.allLedgerNames[k]);
      if ((k + ' ' + key(info.gstin)).indexOf(q) >= 0) res.push({ kind: 'ledger', id: info.name, title: info.name, subtitle: info.group + (info.gstin ? ' · ' + info.gstin : '') });
    });
    (ctx.db.customers || []).concat(ctx.db.vendors || []).forEach(function (c) {
      var name = str(c.customer_name || c.vendor_name);
      var hay = [name, c.mobile, c.gstin, c.email, c.pan].join(' ').toLowerCase();
      if (hay.indexOf(q) >= 0 && !res.some(function (r) { return r.kind === 'ledger' && key(r.id) === key(name); })) res.push({ kind: c.customer_name ? 'customer' : 'vendor', id: name, title: name, subtitle: [c.mobile, c.gstin].filter(Boolean).join(' · ') });
    });
    return { query: q, results: res.slice(0, 50), total: res.length };
  }

  // ---------------------------------------------------------------------------
  // Voucher builders (write side). Return plain rows; the host persists them.
  // ---------------------------------------------------------------------------
  function validateVoucher(v, lines, tolerance) {
    var errs = [];
    tolerance = tolerance || 0.01;
    if (!D(v.voucher_date)) errs.push('Voucher date is missing or invalid.');
    if (!str(v.voucher_type)) errs.push('Voucher type is required.');
    if (!lines || lines.length < 2) errs.push('A voucher needs at least two ledger lines.');
    var dr = 0, cr = 0;
    (lines || []).forEach(function (l, i) {
      if (!str(l.ledger_name)) errs.push('Line ' + (i + 1) + ': ledger is required.');
      var d = num(l.debit), c = num(l.credit);
      if (d < 0 || c < 0) errs.push('Line ' + (i + 1) + ': amounts cannot be negative.');
      if (d && c) errs.push('Line ' + (i + 1) + ': a line cannot carry both debit and credit.');
      dr += d; cr += c;
    });
    dr = r2(dr); cr = r2(cr);
    if (Math.abs(dr - cr) >= tolerance) errs.push('Total debit ' + dr.toFixed(2) + ' does not equal total credit ' + cr.toFixed(2) + '.');
    if (dr === 0) errs.push('Voucher amount cannot be zero.');
    return { valid: errs.length === 0, errors: errs, totalDebit: dr, totalCredit: cr };
  }

  function line(n, ledger, dr, cr, isParty, cc) {
    return { line_no: n, ledger_name: ledger, debit: r2(dr || 0), credit: r2(cr || 0), is_party_line: !!isParty, cost_centre: cc || '' };
  }

  /**
   * Offline sale -> Sales voucher (+ Receipt voucher for amount paid at the counter).
   * input: { invoice_no, invoice_date, customer_name, customer_gstin, mobile, address, state,
   *          items: [{ product, hsn_sac, qty, uom, rate, discount_pct, tax_rate }],
   *          payment_mode, paid_amount, salesperson, remarks, credit_days }
   */
  function buildOfflineSale(input, settings, knownLedgers) {
    var S = mergeSettings(settings);
    var errs = [];
    var date = D(input.invoice_date);
    if (!date) errs.push('Invoice date is required.');
    if (!str(input.invoice_no)) errs.push('Invoice number is required.');
    var items = (input.items && input.items.length) ? input.items : [{ product: input.product, hsn_sac: input.hsn_sac, qty: input.qty, uom: input.uom, rate: input.rate, discount_pct: input.discount_pct, tax_rate: input.tax_rate }];
    var gstin = str(input.customer_gstin).toUpperCase();
    if (gstin && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gstin)) errs.push('Customer GSTIN format is invalid.');
    var state = str(input.state) || S.COMPANY_STATE;
    var intra = key(state) === key(S.COMPANY_STATE);
    var modes = jsonSetting(S, 'PAYMENT_MODE_LEDGERS');
    var mode = str(input.payment_mode) || 'Credit';
    var paid = r2(num(input.paid_amount));
    if (mode === 'Credit' && paid > 0) errs.push('Payment mode "Credit" cannot have a paid amount; choose the mode used for the part payment.');
    var outItems = [], taxable = 0, cgst = 0, sgst = 0, igst = 0, disc = 0;
    items.forEach(function (it, i) {
      var qty = num(it.qty), rate = num(it.rate), dp = num(it.discount_pct), tr = num(it.tax_rate);
      if (!str(it.product)) errs.push('Item ' + (i + 1) + ': product is required.');
      if (qty <= 0) errs.push('Item ' + (i + 1) + ': quantity must be greater than zero.');
      if (rate < 0) errs.push('Item ' + (i + 1) + ': rate cannot be negative.');
      if (dp < 0 || dp > 100) errs.push('Item ' + (i + 1) + ': discount % must be 0-100.');
      if ([0, 0.25, 3, 5, 12, 18, 28, 40].indexOf(tr) < 0) errs.push('Item ' + (i + 1) + ': GST rate ' + tr + '% is not a standard rate.');
      var gross = r2(qty * rate), d = r2(gross * dp / 100), tv = r2(gross - d);
      var c = intra ? r2(tv * tr / 200) : 0, s = intra ? r2(tv * tr / 200) : 0, g = intra ? 0 : r2(tv * tr / 100);
      taxable += tv; cgst += c; sgst += s; igst += g; disc += d;
      outItems.push({ line_no: i + 1, product_name: str(it.product), hsn_sac: str(it.hsn_sac), qty: qty, uom: str(it.uom) || 'Nos', rate: rate, discount_pct: dp, discount_amount: d, taxable_amount: tv, gst_rate: tr, cgst: c, sgst: s, igst: g, cess: 0, line_total: r2(tv + c + s + g), godown: str(it.godown), sales_ledger: S.OFFLINE_SALES_LEDGER });
    });
    taxable = r2(taxable); cgst = r2(cgst); sgst = r2(sgst); igst = r2(igst); disc = r2(disc);
    var gross = r2(taxable + cgst + sgst + igst);
    var total = S.ROUND_INVOICE_TOTAL ? Math.round(gross) : gross;
    var roundOff = r2(total - gross);
    if (paid > total) errs.push('Paid amount cannot exceed the invoice total of ' + total.toFixed(2) + '.');
    if (paid > 0 && !modes[mode]) errs.push('No ledger is mapped for payment mode "' + mode + '" (setting PAYMENT_MODE_LEDGERS).');
    if (errs.length) return { valid: false, errors: errs };

    var customer = str(input.customer_name) || S.WALK_IN_CUSTOMER_LEDGER;
    var newLedgers = [];
    var known = {}; (knownLedgers || []).forEach(function (n) { known[key(n)] = true; });
    function need(name, group, type, extra) {
      if (known[key(name)]) return; known[key(name)] = true;
      var l = { ledger_name: name, parent_group: group, ledger_type: type, opening_balance: 0, opening_dr_cr: 'Dr', source: 'AUTO', is_active: true, needs_review: false };
      Object.keys(extra || {}).forEach(function (k) { l[k] = extra[k]; });
      newLedgers.push(l);
    }
    need(customer, 'Sundry Debtors', 'Customer', { gstin: gstin, state: state, credit_days: str(input.credit_days) === '' ? '' : num(input.credit_days) });
    need(S.OFFLINE_SALES_LEDGER, 'Sales Accounts', 'Sales');
    if (cgst) need(S.OUTPUT_CGST_LEDGER, 'Duties & Taxes', 'Tax', { tax_type: 'CGST' });
    if (sgst) need(S.OUTPUT_SGST_LEDGER, 'Duties & Taxes', 'Tax', { tax_type: 'SGST' });
    if (igst) need(S.OUTPUT_IGST_LEDGER, 'Duties & Taxes', 'Tax', { tax_type: 'IGST' });
    if (roundOff) need(S.ROUND_OFF_LEDGER, 'Indirect Expenses', 'Expense');

    var cd = str(input.credit_days) === '' ? S.DEFAULT_CREDIT_DAYS : num(input.credit_days);
    var due = paid >= total ? date : addDays(date, cd);
    var n = 1, sl = [line(n++, customer, total, 0, true)];
    sl.push(line(n++, S.OFFLINE_SALES_LEDGER, 0, taxable));
    if (cgst) sl.push(line(n++, S.OUTPUT_CGST_LEDGER, 0, cgst));
    if (sgst) sl.push(line(n++, S.OUTPUT_SGST_LEDGER, 0, sgst));
    if (igst) sl.push(line(n++, S.OUTPUT_IGST_LEDGER, 0, igst));
    if (roundOff) sl.push(roundOff > 0 ? line(n++, S.ROUND_OFF_LEDGER, 0, roundOff) : line(n++, S.ROUND_OFF_LEDGER, -roundOff, 0));
    var sale = {
      header: { voucher_date: date, voucher_type: 'Sales', base_voucher_type: 'Sales', voucher_number: str(input.invoice_no), reference_no: str(input.reference_no), party_ledger: customer, party_gstin: gstin, place_of_supply: state, amount: total, narration: str(input.remarks) || ('Offline sale ' + str(input.invoice_no)), salesperson: str(input.salesperson), cost_centre: str(input.cost_centre), source: 'OFFLINE', status: 'ACTIVE', unique_key: 'OFFLINE:SALES:' + key(input.invoice_no) },
      lines: sl,
      bills: [{ party_ledger: customer, bill_name: str(input.invoice_no), bill_type: 'New Ref', bill_date: date, due_date: due, credit_days: cd, amount: total, dr_cr: 'Dr' }]
    };
    var v1 = validateVoucher(sale.header, sale.lines, S.BALANCE_TOLERANCE);
    if (!v1.valid) return { valid: false, errors: v1.errors };
    var vouchers = [sale];
    if (paid > 0) {
      var bankLedger = modes[mode];
      need(bankLedger, mode === 'Cash' || bankLedger === 'Cash' ? 'Cash-in-Hand' : 'Bank Accounts', mode === 'Cash' ? 'Cash' : 'Bank');
      var rc = {
        header: { voucher_date: date, voucher_type: 'Receipt', base_voucher_type: 'Receipt', voucher_number: str(input.invoice_no) + '/R', reference_no: str(input.instrument_no), party_ledger: customer, amount: paid, narration: mode + ' received against ' + str(input.invoice_no), source: 'OFFLINE', status: 'ACTIVE', unique_key: 'OFFLINE:RECEIPT:' + key(input.invoice_no) },
        lines: [line(1, bankLedger, paid, 0), line(2, customer, 0, paid, true)],
        bills: [{ party_ledger: customer, bill_name: str(input.invoice_no), bill_type: 'Agst Ref', bill_date: date, due_date: due, credit_days: '', amount: paid, dr_cr: 'Cr' }]
      };
      vouchers.push(rc);
    }
    return {
      valid: true, errors: [], vouchers: vouchers, items: outItems, newLedgers: newLedgers,
      totals: { taxable: taxable, discount: disc, cgst: cgst, sgst: sgst, igst: igst, roundOff: roundOff, total: total, paid: paid, outstanding: r2(total - paid), intraState: intra },
      offlineRow: {
        invoice_no: str(input.invoice_no), invoice_date: date, customer_name: customer, customer_gstin: gstin, mobile: str(input.mobile), address: str(input.address), state: state,
        product: outItems.length === 1 ? outItems[0].product_name : outItems[0].product_name + ' +' + (outItems.length - 1) + ' more',
        qty: sum(outItems, function (i) { return i.qty; }), rate: outItems.length === 1 ? outItems[0].rate : '', discount_pct: outItems.length === 1 ? outItems[0].discount_pct : '',
        tax_rate: outItems.length === 1 ? outItems[0].gst_rate : '', taxable_amount: taxable, cgst: cgst, sgst: sgst, igst: igst, total_amount: total,
        payment_mode: mode, paid_amount: paid, outstanding_at_entry: r2(total - paid), salesperson: str(input.salesperson), remarks: str(input.remarks), status: 'POSTED'
      },
      salesRow: { invoice_no: str(input.invoice_no), invoice_date: date, customer_ledger: customer, customer_gstin: gstin, customer_state: state, place_of_supply: state, salesperson: str(input.salesperson), channel: str(input.channel) || 'Showroom', taxable_amount: taxable, discount_amount: disc, cgst: cgst, sgst: sgst, igst: igst, cess: 0, round_off: roundOff, invoice_amount: total, due_date: due, source: 'OFFLINE', status: 'ACTIVE' }
    };
  }

  /** Receipt (kind='receipt') or payment (kind='payment') against a party, optionally against a bill, with TDS. */
  function buildCashVoucher(kind, input, settings, knownLedgers) {
    var S = mergeSettings(settings);
    var errs = [], date = D(input.date), amt = r2(num(input.amount)), tds = r2(num(input.tds_amount));
    var party = str(input.party_ledger), bank = str(input.bank_ledger);
    if (!date) errs.push('Date is required.');
    if (!party) errs.push('Party ledger is required.');
    if (!bank) errs.push('Cash/bank ledger is required.');
    if (amt <= 0) errs.push('Amount must be greater than zero.');
    if (tds < 0) errs.push('TDS cannot be negative.');
    if (errs.length) return { valid: false, errors: errs };
    var isR = kind === 'receipt', gross = r2(amt + tds);
    var lines = isR
      ? [line(1, bank, amt, 0)].concat(tds ? [line(2, S.TDS_RECEIVABLE_LEDGER, tds, 0)] : []).concat([line(tds ? 3 : 2, party, 0, gross, true)])
      : [line(1, party, gross, 0, true), line(2, bank, 0, amt)].concat(tds ? [line(3, S.TDS_PAYABLE_LEDGER, 0, tds)] : []);
    var bill = str(input.against_bill);
    var header = {
      voucher_date: date, voucher_type: isR ? 'Receipt' : 'Payment', base_voucher_type: isR ? 'Receipt' : 'Payment',
      voucher_number: str(input.number), reference_no: str(input.instrument_no), party_ledger: party, amount: gross,
      narration: str(input.narration) || ((isR ? 'Received from ' : 'Paid to ') + party + (bill ? ' against ' + bill : '')),
      source: 'MANUAL', status: 'ACTIVE', unique_key: 'MANUAL:' + (isR ? 'RECEIPT:' : 'PAYMENT:') + key(input.number)
    };
    var v = validateVoucher(header, lines, S.BALANCE_TOLERANCE);
    if (!v.valid) return { valid: false, errors: v.errors };
    var newLedgers = [], known = {}; (knownLedgers || []).forEach(function (n) { known[key(n)] = true; });
    if (tds) { var tl = isR ? S.TDS_RECEIVABLE_LEDGER : S.TDS_PAYABLE_LEDGER; if (!known[key(tl)]) newLedgers.push({ ledger_name: tl, parent_group: isR ? 'Loans & Advances (Asset)' : 'Duties & Taxes', ledger_type: 'Tax', tax_type: 'TDS', opening_balance: 0, opening_dr_cr: 'Dr', source: 'AUTO', is_active: true }); }
    return {
      valid: true, errors: [], newLedgers: newLedgers,
      vouchers: [{ header: header, lines: lines, bills: [{ party_ledger: party, bill_name: bill || 'On Account', bill_type: bill ? 'Agst Ref' : 'On Account', bill_date: date, due_date: '', credit_days: '', amount: gross, dr_cr: isR ? 'Cr' : 'Dr' }] }]
    };
  }

  /** Approved expense -> Payment voucher (paid) or Journal crediting the vendor (on credit). */
  function buildExpenseVoucher(exp, settings) {
    var S = mergeSettings(settings);
    var errs = [], date = D(exp.expense_date), amt = r2(num(exp.amount)), gst = r2(num(exp.gst_amount));
    if (!date) errs.push('Expense date is required.');
    if (amt <= 0) errs.push('Amount must be greater than zero.');
    if (!str(exp.expense_ledger)) errs.push('Expense ledger is required.');
    var credit = str(exp.payment_mode) === 'Credit';
    if (credit && !str(exp.vendor_ledger)) errs.push('Vendor is required for expenses on credit.');
    if (!credit && !str(exp.paid_from_ledger)) errs.push('Paid-from (cash/bank) ledger is required.');
    if (errs.length) return { valid: false, errors: errs };
    var total = r2(amt + gst), n = 1;
    var lines = [line(n++, str(exp.expense_ledger), amt, 0, false, str(exp.cost_centre))];
    if (gst) {
      if (bool(exp.inter_state)) lines.push(line(n++, S.INPUT_IGST_LEDGER, gst, 0));
      else { var half = r2(gst / 2); lines.push(line(n++, S.INPUT_CGST_LEDGER, half, 0)); lines.push(line(n++, S.INPUT_SGST_LEDGER, r2(gst - half), 0)); }
    }
    lines.push(credit ? line(n++, str(exp.vendor_ledger), 0, total, true) : line(n++, str(exp.paid_from_ledger), 0, total));
    var header = {
      voucher_date: date, voucher_type: credit ? 'Journal' : 'Payment', base_voucher_type: credit ? 'Journal' : 'Payment',
      voucher_number: str(exp.expense_id), party_ledger: credit ? str(exp.vendor_ledger) : '', amount: total,
      narration: str(exp.category) + ': ' + str(exp.description), cost_centre: str(exp.cost_centre),
      source: 'MANUAL', status: 'ACTIVE', unique_key: 'EXPENSE:' + key(exp.expense_id)
    };
    var v = validateVoucher(header, lines, S.BALANCE_TOLERANCE);
    if (!v.valid) return { valid: false, errors: v.errors };
    return {
      valid: true, errors: [],
      vouchers: [{ header: header, lines: lines, bills: credit ? [{ party_ledger: str(exp.vendor_ledger), bill_name: str(exp.expense_id), bill_type: 'New Ref', bill_date: date, due_date: addDays(date, S.DEFAULT_CREDIT_DAYS), credit_days: S.DEFAULT_CREDIT_DAYS, amount: total, dr_cr: 'Cr' }] : [] }]
    };
  }

  function inr(n) {
    var neg = n < 0, x = Math.abs(r2(n)).toFixed(2).split('.'), i = x[0], last3 = i.slice(-3), rest = i.slice(0, -3);
    if (rest) last3 = ',' + last3;
    return (neg ? '-' : '') + 'Rs ' + rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + last3 + (x[1] !== '00' ? '.' + x[1] : '');
  }

  return {
    VERSION: VERSION, RESERVED_GROUPS: RESERVED_GROUPS, DEFAULT_SETTINGS: DEFAULT_SETTINGS, BASE_TYPES: BASE_TYPES,
    util: { D: D, r2: r2, num: num, addDays: addDays, daysBetween: daysBetween, fyStart: fyStart, fyEnd: fyEnd, fyLabel: fyLabel, periodRange: periodRange, inr: inr, mergeSettings: mergeSettings },
    createContext: createContext, balanceAt: balanceAt, stockAt: stockAt,
    trialBalance: trialBalance, ledgerStatement: ledgerStatement,
    profitLoss: profitLoss, profitLossComparative: profitLossComparative, monthlyTrend: monthlyTrend,
    balanceSheet: balanceSheet, cashFlow: cashFlow,
    outstanding: outstanding, partyAccounts: partyAccounts,
    register: register, salesReport: salesReport, cashRegister: cashRegister, cashBook: cashBook,
    gstTransactions: gstTransactions, gstSummary: gstSummary,
    dashboard: dashboard, managementDashboard: managementDashboard, financialHealth: financialHealth, analytics: analytics,
    alerts: alerts, integrity: integrity, search: search,
    validateVoucher: validateVoucher, buildOfflineSale: buildOfflineSale, buildCashVoucher: buildCashVoucher, buildExpenseVoucher: buildExpenseVoucher
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Engine;
