/**
 * Database initializer and maintenance utilities.
 *
 * initializeDatabase() is idempotent - safe to run any number of times:
 *   - creates missing sheets, never deletes or reorders existing ones
 *   - writes headers on empty sheets; appends NEW schema columns to existing sheets (non-destructive migration)
 *   - inserts the sample row(s) only once per table (remembered in Script Properties), so purged
 *     samples are not re-added and headers/samples are never duplicated
 *   - (re)applies formatting, number formats, dropdowns and checkboxes
 *   - maintains an _INDEX sheet describing every table
 */

var SAMPLE_ID_RESERVE = 100; // real IDs start after this so they never collide with sample references

var FORMATS = {
  date: 'dd-mmm-yyyy',
  dt: 'dd-mmm-yyyy hh:mm',
  cur: '[$₹]#,##,##0.00;[Red]-[$₹]#,##,##0.00',
  pct: '0.00',
  num: '#,##0.###'
};

function initializeDatabase() {
  return Db.withLock(function () {
    var ss = Db.ss();
    ss.setSpreadsheetTimeZone('Asia/Kolkata');
    try { ss.setSpreadsheetLocale('en_IN'); } catch (e) { /* locale change not permitted - formats still apply */ }
    var props = PropertiesService.getScriptProperties();
    var report = [];

    SCHEMA.tables.forEach(function (t, idx) {
      var sh = ss.getSheetByName(t.name);
      var created = false;
      if (!sh) { sh = ss.insertSheet(t.name, ss.getNumSheets()); created = true; }
      var cols = t.columns.map(function (c) { return c.split(':')[0]; });

      // Headers (never duplicated; new schema columns appended)
      var lastCol = sh.getLastColumn();
      var existing = lastCol ? sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String) : [];
      var hasHeaders = existing.some(function (x) { return x !== ''; });
      var added = [];
      if (!hasHeaders) {
        sh.getRange(1, 1, 1, cols.length).setValues([cols]);
      } else {
        added = cols.filter(function (c) { return existing.indexOf(c) < 0; });
        if (added.length) sh.getRange(1, existing.length + 1, 1, added.length).setValues([added]);
      }
      Db.reset();
      var headers = Db.headers(t.name);

      formatSheet_(sh, t, headers);

      // Sample rows - once only
      var flag = 'SAMPLE_' + t.name;
      var sampleInserted = false;
      if (!props.getProperty(flag) && sh.getLastRow() <= 1 && t.samples && t.samples.length) {
        Db.insert(t.name, t.samples.map(function (s) { return JSON.parse(JSON.stringify(s)); }));
        sampleInserted = true;
      }
      if (!props.getProperty(flag)) props.setProperty(flag, '1');

      // Reserve the sample ID range
      if (t.idPrefix) {
        var seqKey = 'SEQ_' + t.name;
        var cur = Number(props.getProperty(seqKey)) || 0;
        if (cur < SAMPLE_ID_RESERVE) {
          var maxExisting = 0;
          var idCol = headers[0];
          Db.column(t.name, idCol).forEach(function (id) { var m = String(id).match(/(\d+)$/); if (m) maxExisting = Math.max(maxExisting, Number(m[1])); });
          props.setProperty(seqKey, String(Math.max(SAMPLE_ID_RESERVE, maxExisting)));
        }
      }
      report.push({ table: t.name, created: created, columnsAdded: added, sampleInserted: sampleInserted });
    });

    writeIndexSheet_(ss);
    var def = ss.getSheetByName('Sheet1');
    if (def && def.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(def);
    props.setProperty('SCHEMA_VERSION', SCHEMA.version);
    if (!props.getProperty('DATA_VERSION')) props.setProperty('DATA_VERSION', String(Date.now()));
    Audit.log({ action: 'CONFIG', entity: 'DATABASE', record_id: 'initializeDatabase', new_value: { schema: SCHEMA.version, tables: report.length }, user: Session.getEffectiveUser().getEmail() || 'editor' });
    console.log(JSON.stringify(report));
    return report;
  });
}

function formatSheet_(sh, t, headers) {
  var n = headers.length;
  var maxRows = Math.max(sh.getMaxRows(), 1000);
  if (sh.getMaxRows() < 1000) sh.insertRowsAfter(sh.getMaxRows(), 1000 - sh.getMaxRows());
  sh.setFrozenRows(1);
  var head = sh.getRange(1, 1, 1, n);
  head.setFontWeight('bold').setBackground('#1f2a44').setFontColor('#ffffff').setWrap(true).setVerticalAlignment('middle');
  sh.setRowHeight(1, 36);
  var types = {};
  var enums = t.enums || {};
  t.columns.forEach(function (c) { var p = c.split(':'); types[p[0]] = p[1] || 'str'; });
  headers.forEach(function (h, i) {
    var col = i + 1, type = types[h];
    var body = sh.getRange(2, col, maxRows - 1, 1);
    if (FORMATS[type]) body.setNumberFormat(FORMATS[type]);
    else if (type === 'id' || type === 'ref' || type === 'str' || type === 'email' || type === 'json') body.setNumberFormat('@');
    if (type === 'bool') {
      body.setDataValidation(SpreadsheetApp.newDataValidation().requireCheckbox().build());
    } else if (enums[h]) {
      var list = enums[h].filter(function (x) { return x !== ''; });
      body.setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(list, true).setAllowInvalid(false).build());
    } else if (type === 'date' || type === 'dt') {
      body.setDataValidation(SpreadsheetApp.newDataValidation().requireDate().setAllowInvalid(false).build());
    }
    if (type === 'cur' || type === 'num' || type === 'pct') body.setHorizontalAlignment('right');
    sh.setColumnWidth(col, type === 'json' || h === 'payload' || h === 'narration' || h === 'message' || h === 'description' ? 320 : type === 'cur' ? 130 : 150);
  });
  if (t.name === 'AUDIT_LOG' && !sh.getProtections(SpreadsheetApp.ProtectionType.SHEET).length) {
    sh.protect().setDescription('Audit log is append-only (written by the API)').setWarningOnly(true);
  }
  sh.setTabColor({ System: '#64748b', Masters: '#2563eb', Posting: '#0f766e', Registers: '#7c3aed', Snapshots: '#94a3b8', 'Cash & Bank': '#0891b2', Tax: '#b45309', Inventory: '#4d7c0f', Tally: '#be123c' }[t.group] || '#64748b');
}

function writeIndexSheet_(ss) {
  var sh = ss.getSheetByName('_INDEX') || ss.insertSheet('_INDEX', 0);
  sh.clear();
  var rows = [['Table', 'Group', 'Columns', 'ID prefix', 'Description']];
  SCHEMA.tables.forEach(function (t) { rows.push([t.name, t.group, t.columns.length, t.idPrefix || '(key/value)', t.description]); });
  sh.getRange(1, 1, rows.length, 5).setValues(rows);
  sh.getRange(1, 1, 1, 5).setFontWeight('bold').setBackground('#1f2a44').setFontColor('#ffffff');
  sh.setFrozenRows(1);
  sh.setColumnWidth(1, 190); sh.setColumnWidth(2, 110); sh.setColumnWidth(5, 700);
  sh.getRange(rows.length + 2, 1).setValue('Schema version ' + SCHEMA.version + '. Generated by initializeDatabase(). Posting tables are the book of record; snapshot tables are rebuilt nightly.');
}

/** Removes the illustrative sample rows (USERS, CONFIG and SETTINGS are kept). */
function purgeSampleData() {
  return Db.withLock(function () {
    var removed = {};
    SCHEMA.tables.forEach(function (t) {
      if (!t.idPrefix || t.name === 'USERS' || t.name === 'AUDIT_LOG') return;
      var idCol = t.columns[0].split(':')[0];
      var ids = {};
      (t.samples || []).forEach(function (s) { ids[s[idCol]] = true; });
      var before = Db.read(t.name).length;
      Db.replaceWhere(t.name, function (r) { return ids[r[idCol]]; }, []);
      removed[t.name] = before - Db.read(t.name).length;
    });
    Audit.log({ action: 'DELETE', entity: 'DATABASE', record_id: 'purgeSampleData', new_value: removed, user: Session.getEffectiveUser().getEmail() || 'editor' });
    return removed;
  });
}

/** Menu helper: set a user's password through dialogs (the password is never stored in code). */
function setPasswordFromMenu() {
  var ui = SpreadsheetApp.getUi();
  var e = ui.prompt('Set user password', 'User email (must exist in USERS):', ui.ButtonSet.OK_CANCEL);
  if (e.getSelectedButton() !== ui.Button.OK) return;
  var p = ui.prompt('Set user password', 'New password (min 10 characters, letters and digits):', ui.ButtonSet.OK_CANCEL);
  if (p.getSelectedButton() !== ui.Button.OK) return;
  Db.withLock(function () { setUserPassword(e.getResponseText().trim(), p.getResponseText()); });
  ui.alert('Password set. The user can now sign in to the web app.');
}
