"""Turn Tally XML vouchers and masters into Accounts Dashboard's normalized shapes.

Sign convention (Tally): in ledger entries a NEGATIVE amount is a DEBIT and a
POSITIVE amount is a CREDIT. ``ISDEEMEDPOSITIVE=Yes`` normally accompanies a
debit; the amount sign is treated as the truth and a ``SIGN_MISMATCH`` warning
is recorded when the two disagree.

Private keys (prefixed with ``_``: ``_warnings``, ``_errors``,
``_line_heads``) are added to normalized vouchers for local reporting and are
removed by :func:`strip_private` before anything is sent to the server.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, Iterator, List, Optional, Tuple

from .xml_parser import (
    MASTER_TAGS,
    ZERO,
    add_days,
    child,
    children,
    clean_parent,
    extract_masters,
    extract_vouchers,
    first_text,
    list_texts,
    master_name,
    money,
    parse_amount,
    parse_bool,
    parse_credit_period,
    parse_int,
    parse_percent,
    parse_quantity,
    parse_rate,
    parse_tally_date,
    parse_xml,
    path_text,
    round2,
    text_of,
    value_to_element,
)

BASE_VOUCHER_TYPES = ("Sales", "Purchase", "Receipt", "Payment", "Journal", "Contra", "Credit Note", "Debit Note")
OTHER = "Other"
GST_HEADS = ("CGST", "SGST", "IGST", "CESS")

BILL_TYPES = {
    "new ref": "New Ref",
    "agst ref": "Agst Ref",
    "against ref": "Agst Ref",
    "advance": "Advance",
    "on account": "On Account",
}

DUTY_HEADS = {
    "central tax": "CGST", "cgst": "CGST",
    "state tax": "SGST", "ut tax": "SGST", "state/ut tax": "SGST", "sgst": "SGST", "utgst": "SGST",
    "sgst/utgst": "SGST",
    "integrated tax": "IGST", "igst": "IGST",
    "cess": "CESS", "state cess": "CESS",
}

# Tally's 28 reserved (primary and sub) groups and their nature.
RESERVED_GROUP_NATURE = {
    "current assets": "Assets", "fixed assets": "Assets", "investments": "Assets",
    "misc. expenses (asset)": "Assets", "bank accounts": "Assets", "cash-in-hand": "Assets",
    "deposits (asset)": "Assets", "loans & advances (asset)": "Assets", "stock-in-hand": "Assets",
    "sundry debtors": "Assets",
    "capital account": "Liabilities", "current liabilities": "Liabilities",
    "loans (liability)": "Liabilities", "branch / divisions": "Liabilities",
    "reserves & surplus": "Liabilities", "secured loans": "Liabilities",
    "unsecured loans": "Liabilities", "duties & taxes": "Liabilities", "provisions": "Liabilities",
    "sundry creditors": "Liabilities", "bank od a/c": "Liabilities", "suspense a/c": "Liabilities",
    "sales accounts": "Income", "direct incomes": "Income", "indirect incomes": "Income",
    "purchase accounts": "Expenses", "direct expenses": "Expenses", "indirect expenses": "Expenses",
}
GROSS_PROFIT_GROUPS = {"sales accounts", "purchase accounts", "direct incomes", "direct expenses"}

RESERVED_VOUCHER_TYPES = {name.lower(): name for name in BASE_VOUCHER_TYPES}
RESERVED_OTHER_VOUCHER_TYPES = {
    "stock journal", "delivery note", "receipt note", "rejections in", "rejections out",
    "sales order", "purchase order", "memorandum", "reversing journal", "physical stock",
    "material in", "material out", "job work in order", "job work out order", "payroll",
    "attendance",
}

_BASE_TYPE_PATTERNS: Tuple[Tuple[str, str], ...] = (
    (r"credit\s*note|\bcr\.?\s*note|sales?\s*return", "Credit Note"),
    (r"debit\s*note|\bdr\.?\s*note|purchase\s*return", "Debit Note"),
    (r"stock\s*journal|physical\s*stock|delivery\s*note|receipt\s*note|rejections?\b|\border\b"
     r"|memorandum|\bmemo\b|material\s*(?:in|out)\b|job\s*work|payroll|attendance|reversing", OTHER),
    (r"contra", "Contra"),
    (r"purchase", "Purchase"),
    (r"\bsales?\b|invoice", "Sales"),
    (r"receipt", "Receipt"),
    (r"payment", "Payment"),
    (r"journal", "Journal"),
)

_STANDARD_GST_RATES = (0, 0.1, 0.25, 1, 1.5, 3, 5, 6, 7.5, 12, 14, 18, 28, 40)
_ROUND_OFF_RE = re.compile(r"round(?:ing)?\s*-?\s*off|rounding", re.I)
_SALESPERSON_TAG_RE = re.compile(r"SALES(?:PERSON|MAN)", re.I)


def _key(value: Any) -> str:
    """Case/whitespace-insensitive lookup key."""
    return " ".join(str(value or "").split()).lower()


def _issue(code: str, message: str) -> Dict[str, str]:
    return {"code": code, "message": message}


def guess_base_type(name: str) -> str:
    """Base voucher type from a voucher type name alone (fallback)."""
    n = _key(name)
    if not n:
        return ""
    if n in RESERVED_VOUCHER_TYPES:
        return RESERVED_VOUCHER_TYPES[n]
    if n in RESERVED_OTHER_VOUCHER_TYPES:
        return OTHER
    for pattern, base in _BASE_TYPE_PATTERNS:
        if re.search(pattern, n):
            return base
    return OTHER


def guess_tax_head(ledger_name: str) -> str:
    """GST head from a ledger name (CGST|SGST|UTGST|IGST|CESS), '' if none."""
    n = str(ledger_name or "").upper()
    if "IGST" in n or re.search(r"INTEGRATED\s+TAX", n):
        return "IGST"
    if "CGST" in n or re.search(r"CENTRAL\s+TAX", n):
        return "CGST"
    if "SGST" in n or "UTGST" in n or re.search(r"STATE\s+TAX|\bUT\s+TAX", n):
        return "SGST"
    if re.search(r"(?<![A-Z])CESS\b", n):
        return "CESS"
    return ""


# ---------------------------------------------------------------------------
# Context
# ---------------------------------------------------------------------------

@dataclass
class NormalizerContext:
    """Lookups built from masters that voucher normalization depends on.

    All keys are matched case/whitespace-insensitively, so callers may pass
    plain Tally names.
    """

    vtype_base: Dict[str, str] = field(default_factory=dict)
    ledger_tax_head: Dict[str, str] = field(default_factory=dict)
    ledger_credit_days: Dict[str, int] = field(default_factory=dict)
    ledger_gstin: Dict[str, str] = field(default_factory=dict)
    stock_items: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.vtype_base = {_key(k): v for k, v in (self.vtype_base or {}).items()}
        self.ledger_tax_head = {_key(k): str(v or "").upper() for k, v in (self.ledger_tax_head or {}).items()}
        self.ledger_credit_days = {_key(k): int(v) for k, v in (self.ledger_credit_days or {}).items()
                                   if v not in (None, "")}
        self.ledger_gstin = {_key(k): v for k, v in (self.ledger_gstin or {}).items()}
        self.stock_items = {_key(k): dict(v or {}) for k, v in (self.stock_items or {}).items()}

    @classmethod
    def from_masters(cls, masters: Dict[str, List[Dict[str, Any]]]) -> "NormalizerContext":
        masters = masters or {}
        ledgers = masters.get("ledgers") or []
        return cls(
            vtype_base={r["voucher_type"]: r.get("base_voucher_type") or ""
                        for r in masters.get("voucher_types") or [] if r.get("voucher_type")},
            ledger_tax_head={r["ledger_name"]: r.get("tax_type") or ""
                             for r in ledgers if r.get("ledger_name") and r.get("tax_type")},
            ledger_credit_days={r["ledger_name"]: r.get("credit_days")
                                for r in ledgers if r.get("ledger_name") and r.get("credit_days")},
            ledger_gstin={r["ledger_name"]: r.get("gstin")
                          for r in ledgers if r.get("ledger_name") and r.get("gstin")},
            stock_items={r["product_name"]: {"hsn_sac": r.get("hsn_sac") or "",
                                             "gst_rate": r.get("gst_rate"),
                                             "uom": r.get("uom") or ""}
                         for r in masters.get("stock_items") or [] if r.get("product_name")},
        )

    @classmethod
    def coerce(cls, context: Any) -> "NormalizerContext":
        if context is None:
            return cls()
        if isinstance(context, cls):
            return context
        if isinstance(context, dict):
            names = ("vtype_base", "ledger_tax_head", "ledger_credit_days", "ledger_gstin", "stock_items")
            return cls(**{k: context[k] for k in names if k in context})
        raise TypeError("context must be a NormalizerContext, dict or None")

    def base_type(self, voucher_type: str) -> str:
        n = _key(voucher_type)
        if not n:
            return ""
        mapped = self.vtype_base.get(n, "")
        if mapped in BASE_VOUCHER_TYPES or mapped == OTHER:
            return mapped
        return guess_base_type(voucher_type)

    def tax_head(self, ledger_name: str) -> str:
        head = self.ledger_tax_head.get(_key(ledger_name), "")
        if head in GST_HEADS:
            return head
        if head:  # known non-GST duty ledger (TDS, ...)
            return ""
        return guess_tax_head(ledger_name)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _latest(el: Optional[ET.Element], tag: str) -> Optional[ET.Element]:
    """Latest (by APPLICABLEFROM) descendant ``tag`` list entry."""
    if el is None:
        return None
    candidates = list(el.iter(tag))
    if not candidates:
        return None
    return sorted(candidates, key=lambda d: parse_tally_date(text_of(d, "APPLICABLEFROM")) or "")[-1]


def _gst_rate_in(scope: Optional[ET.Element]) -> Optional[Decimal]:
    """Integrated GST rate found in RATEDETAILS lists (or CGST+SGST)."""
    if scope is None:
        return None
    direct = text_of(scope, "GSTRATE")
    if direct:
        return parse_percent(direct)
    rates: Dict[str, Decimal] = {}
    for rd in scope.iter("RATEDETAILS.LIST"):
        head = DUTY_HEADS.get(_key(text_of(rd, "GSTRATEDUTYHEAD")), "")
        value = text_of(rd, "GSTRATE")
        if head and value:
            rates[head] = parse_percent(value)
    if "IGST" in rates:
        return rates["IGST"]
    if "CGST" in rates or "SGST" in rates:
        return rates.get("CGST", ZERO) + rates.get("SGST", ZERO)
    return None


def _hsn_and_rate(el: ET.Element) -> Tuple[str, Optional[Decimal]]:
    latest = _latest(el, "GSTDETAILS.LIST")
    hsn = text_of(latest, "HSNCODE") if latest is not None else ""
    if not hsn:
        hsn = text_of(_latest(el, "HSNDETAILS.LIST"), "HSNCODE")
    if not hsn:
        hsn = first_text(el, "HSNCODE", "GSTHSNNAME", "HSNSACCODE", "GSTHSNSACCODE")
    rate = _gst_rate_in(latest) if latest is not None else None
    if rate is None:
        rate = _gst_rate_in(el)
    return hsn, rate


def _chain(name: str, parents: Dict[str, str]) -> Iterator[str]:
    """``name`` and its ancestors (loop-safe)."""
    seen = set()
    cur = name
    while cur and _key(cur) not in seen:
        seen.add(_key(cur))
        yield cur
        cur = parents.get(_key(cur), "")


def _snap_rate(rate: Decimal) -> Decimal:
    for std in _STANDARD_GST_RATES:
        std_d = Decimal(str(std))
        if abs(rate - std_d) <= Decimal("0.05"):
            return std_d
    return round2(rate)


def _allocate(total: Decimal, weights: List[Decimal]) -> List[Decimal]:
    """Split ``total`` by ``weights``; rounding remainder goes to the largest weight."""
    n = len(weights)
    if n == 0:
        return []
    wsum = sum(weights, ZERO)
    if total == 0 or wsum == 0:
        return [ZERO] * n
    parts = [round2(total * w / wsum) for w in weights]
    diff = round2(total - sum(parts, ZERO))
    if diff:
        biggest = max(range(n), key=lambda j: weights[j])
        parts[biggest] += diff
    return parts


# ---------------------------------------------------------------------------
# Masters
# ---------------------------------------------------------------------------

def _as_element(value: Any, tag: str) -> ET.Element:
    if ET.iselement(value):
        return value
    if isinstance(value, dict):
        if len(value) == 1 and tag in value:
            return value_to_element(tag, value[tag])
        return value_to_element(tag, value)
    if isinstance(value, (bytes, bytearray, str)):
        root = parse_xml(value)
        if root.tag == tag:
            return root
        found = next(root.iter(tag), None)
        if found is None:
            raise ValueError("No <%s> element found in the given XML" % tag)
        return found
    raise TypeError("Cannot convert %r to a <%s> element" % (type(value).__name__, tag))


def normalize_groups(elements: List[ET.Element]) -> List[Dict[str, Any]]:
    parents = {_key(master_name(e)): clean_parent(text_of(e, "PARENT")) for e in elements}
    rows = []
    for el in elements:
        name = master_name(el)
        if not name:
            continue
        nature = ""
        for ancestor in _chain(name, parents):
            nature = RESERVED_GROUP_NATURE.get(_key(ancestor), "")
            if nature:
                break
        if not nature:
            is_rev, deemed = text_of(el, "ISREVENUE"), text_of(el, "ISDEEMEDPOSITIVE")
            if is_rev or deemed:
                if parse_bool(is_rev):
                    nature = "Expenses" if parse_bool(deemed) else "Income"
                else:
                    nature = "Assets" if parse_bool(deemed) else "Liabilities"
        agp_text = text_of(el, "AFFECTSGROSSPROFIT")
        if agp_text:
            agp = parse_bool(agp_text)
        else:
            agp = any(_key(a) in GROSS_PROFIT_GROUPS for a in _chain(name, parents))
        rows.append({
            "group_name": name,
            "parent_group": parents.get(_key(name), ""),
            "nature": nature,
            "affects_gross_profit": agp,
            "tally_guid": text_of(el, "GUID"),
            "alter_id": parse_int(text_of(el, "ALTERID")),
        })
    return rows


def _ledger_tax_type(name: str, el: ET.Element, parent: str, group_parents: Dict[str, str]) -> str:
    tax_type = _key(text_of(el, "TAXTYPE"))
    duty = DUTY_HEADS.get(_key(text_of(el, "GSTDUTYHEAD")), "")
    if tax_type == "gst":
        return duty or guess_tax_head(name)
    if tax_type == "tds":
        return "TDS"
    if tax_type == "tcs":
        return ""
    if duty:
        return duty
    if any(_key(g) == "duties & taxes" for g in _chain(parent, group_parents)):
        return guess_tax_head(name)
    return ""


def normalize_ledgers(elements: List[ET.Element], group_parents: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    group_parents = group_parents or {}
    rows = []
    for el in elements:
        name = master_name(el)
        if not name:
            continue
        parent = clean_parent(text_of(el, "PARENT"))
        try:
            opening = round2(parse_amount(text_of(el, "OPENINGBALANCE")))
        except ValueError:
            opening = ZERO
        mailing = _latest(el, "LEDMAILINGDETAILS.LIST")
        gst_reg = _latest(el, "LEDGSTREGDETAILS.LIST")
        gstin = first_text(el, "PARTYGSTIN", "GSTIN") or (text_of(gst_reg, "GSTIN") if gst_reg is not None else "")
        state = first_text(el, "LEDSTATENAME", "STATENAME") or (text_of(mailing, "STATE") if mailing is not None else "")
        address = list_texts(el, "ADDRESS.LIST", "ADDRESS")
        if not address and mailing is not None:
            address = list_texts(mailing, "ADDRESS.LIST", "ADDRESS")
        credit_el = child(el, "BILLCREDITPERIOD")
        credit_days = parse_credit_period(credit_el)[0] if credit_el is not None else None
        _, rate = _hsn_and_rate(el)
        if rate is None:
            rate_text = text_of(el, "RATEOFTAXCALCULATION")
            rate = parse_percent(rate_text) if rate_text else ZERO
        rows.append({
            "ledger_name": name,
            "parent_group": parent,
            "opening_balance": money(abs(opening)),
            "opening_dr_cr": "Dr" if opening < 0 else "Cr",
            "gstin": gstin,
            "state": state,
            "credit_days": int(credit_days or 0),
            "email": first_text(el, "EMAIL"),
            "mobile": first_text(el, "LEDGERMOBILE", "LEDGERPHONE", "PHONENUMBER"),
            "address": ", ".join(address),
            "tax_type": _ledger_tax_type(name, el, parent, group_parents),
            "gst_rate": float(round2(rate)),
            "tally_guid": text_of(el, "GUID"),
            "alter_id": parse_int(text_of(el, "ALTERID")),
        })
    return rows


def _resolve_vtype_base(name: str, parents: Dict[str, str], reserved: Dict[str, str]) -> str:
    for ancestor in _chain(name, parents):
        for candidate in (reserved.get(_key(ancestor), ""), ancestor):
            ck = _key(candidate)
            if ck in RESERVED_VOUCHER_TYPES:
                return RESERVED_VOUCHER_TYPES[ck]
            if ck in RESERVED_OTHER_VOUCHER_TYPES:
                return OTHER
    return guess_base_type(name)


def normalize_voucher_types(elements: List[ET.Element]) -> List[Dict[str, Any]]:
    parents: Dict[str, str] = {}
    reserved: Dict[str, str] = {}
    for el in elements:
        name = master_name(el)
        parent = clean_parent(text_of(el, "PARENT"))
        if parent and _key(parent) != _key(name):
            parents[_key(name)] = parent
        reserved[_key(name)] = (el.get("RESERVEDNAME") or "").strip()
    rows = []
    for el in elements:
        name = master_name(el)
        if not name:
            continue
        rows.append({
            "voucher_type": name,
            "base_voucher_type": _resolve_vtype_base(name, parents, reserved),
            "tally_guid": text_of(el, "GUID"),
        })
    return rows


def normalize_stock_items(elements: List[ET.Element]) -> List[Dict[str, Any]]:
    rows = []
    for el in elements:
        name = master_name(el)
        if not name:
            continue
        hsn, rate = _hsn_and_rate(el)
        qty, qty_uom = parse_quantity(text_of(el, "OPENINGBALANCE"))
        try:
            value = round2(parse_amount(text_of(el, "OPENINGVALUE")))
        except ValueError:
            value = ZERO
        rows.append({
            "product_name": name,
            "stock_group": clean_parent(text_of(el, "PARENT")),
            "uom": text_of(el, "BASEUNITS") or qty_uom,
            "hsn_sac": hsn,
            "gst_rate": float(round2(rate)) if rate is not None else 0.0,
            "opening_qty": float(abs(qty)),
            "opening_value": money(abs(value)),
            "tally_guid": text_of(el, "GUID"),
        })
    return rows


def normalize_cost_centres(elements: List[ET.Element]) -> List[Dict[str, Any]]:
    rows = []
    for el in elements:
        name = master_name(el)
        if not name:
            continue
        rows.append({
            "cost_centre_name": name,
            "category": text_of(el, "CATEGORY"),
            "parent": clean_parent(text_of(el, "PARENT")),
            "tally_guid": text_of(el, "GUID"),
        })
    return rows


def normalize_masters(raw: Any) -> Dict[str, List[Dict[str, Any]]]:
    """Normalize masters.

    ``raw`` is a dict ``{groups, ledgers, voucher_types, stock_items,
    cost_centres}`` of Elements (or element dicts), or a parsed response root.
    """
    if ET.iselement(raw):
        raw = extract_masters(raw)
    raw = raw or {}

    def elements(key: str) -> List[ET.Element]:
        return [_as_element(x, MASTER_TAGS[key]) for x in raw.get(key) or []]

    groups = normalize_groups(elements("groups"))
    group_parents = {_key(g["group_name"]): g["parent_group"] for g in groups}
    return {
        "groups": groups,
        "ledgers": normalize_ledgers(elements("ledgers"), group_parents),
        "voucher_types": normalize_voucher_types(elements("voucher_types")),
        "stock_items": normalize_stock_items(elements("stock_items")),
        "cost_centres": normalize_cost_centres(elements("cost_centres")),
    }


# ---------------------------------------------------------------------------
# Vouchers
# ---------------------------------------------------------------------------

def _as_voucher_element(voucher: Any) -> ET.Element:
    if ET.iselement(voucher):
        return voucher
    if isinstance(voucher, (bytes, bytearray, str)):
        found = extract_vouchers(parse_xml(voucher))
        if not found:
            raise ValueError("No <VOUCHER> element found in the given XML")
        return found[0]
    if isinstance(voucher, dict):
        if set(voucher.keys()) == {"VOUCHER"}:
            return value_to_element("VOUCHER", voucher["VOUCHER"])
        return value_to_element("VOUCHER", voucher)
    raise TypeError("voucher must be an Element, dict or XML text, not %s" % type(voucher).__name__)


def _named(entries: List[ET.Element], tag: str) -> List[ET.Element]:
    return [e for e in entries if text_of(e, tag)]


def _collect_entries(el: ET.Element) -> Tuple[List[Tuple[ET.Element, str]], List[Tuple[ET.Element, str]]]:
    """Ledger-bearing entries and inventory entries of a voucher.

    The ALL* variants are preferred when they contain data, so the same entry
    exported under both ALLLEDGERENTRIES.LIST and LEDGERENTRIES.LIST is never
    counted twice. In invoice-mode vouchers the sales/purchase ledger lives in
    inventory entries' ACCOUNTINGALLOCATIONS.LIST.
    """
    ledger_entries = (_named(children(el, "ALLLEDGERENTRIES.LIST"), "LEDGERNAME")
                      or _named(children(el, "LEDGERENTRIES.LIST"), "LEDGERNAME"))
    inventory = (_named(children(el, "ALLINVENTORYENTRIES.LIST"), "STOCKITEMNAME")
                 or _named(children(el, "INVENTORYENTRIES.LIST"), "STOCKITEMNAME"))
    entries: List[Tuple[ET.Element, str]] = [(e, "ledger") for e in ledger_entries]
    inv_entries: List[Tuple[ET.Element, str]] = [(ie, "") for ie in inventory]
    for ie in inventory:
        for acc in _named(children(ie, "ACCOUNTINGALLOCATIONS.LIST"), "LEDGERNAME"):
            entries.append((acc, "inventory"))
    # Accounting-invoice mode: items allocated inside a ledger entry.
    for e in ledger_entries:
        for ia in _named(children(e, "INVENTORYALLOCATIONS.LIST"), "STOCKITEMNAME"):
            inv_entries.append((ia, text_of(e, "LEDGERNAME")))
    return entries, inv_entries


def _cost_centre(entry: ET.Element) -> str:
    for cat in children(entry, "CATEGORYALLOCATIONS.LIST"):
        name = path_text(cat, "COSTCENTREALLOCATIONS.LIST", "NAME")
        if name:
            return name
    return path_text(entry, "COSTCENTREALLOCATIONS.LIST", "NAME")


def _salesperson(el: ET.Element) -> str:
    for c in el:
        if _SALESPERSON_TAG_RE.search(c.tag):
            for text in c.itertext():
                if text.strip():
                    return text.strip()
    return ""


def _parse_bill(b: ET.Element, ledger_name: str, voucher_date: str, ctx: NormalizerContext,
                errors: List[Dict[str, str]]) -> Optional[Dict[str, Any]]:
    name = text_of(b, "NAME")
    raw_type = text_of(b, "BILLTYPE")
    amount_text = text_of(b, "AMOUNT")
    if not name and not raw_type and not amount_text:
        return None
    bill_type = BILL_TYPES.get(_key(raw_type)) or ("New Ref" if name else "On Account")
    try:
        amount = round2(parse_amount(amount_text))
    except ValueError as exc:
        errors.append(_issue("INVALID_AMOUNT", "Bill '%s' of '%s': %s" % (name, ledger_name, exc)))
        return None
    bill_date = parse_tally_date(text_of(b, "BILLDATE"))
    if not bill_date and bill_type in ("New Ref", "Advance"):
        bill_date = voucher_date
    days: Optional[int] = None
    due = ""
    period = child(b, "BILLCREDITPERIOD")
    if period is not None:
        days, due = parse_credit_period(period, bill_date)
    if days is None and not due and bill_type == "New Ref":
        days = ctx.ledger_credit_days.get(_key(ledger_name))
    if not due and bill_date and bill_type in ("New Ref", "Advance"):
        due = add_days(bill_date, days or 0)
    return {
        "party_ledger": ledger_name,
        "bill_name": name,
        "bill_type": bill_type,
        "bill_date": bill_date,
        "due_date": due,
        "credit_days": int(days) if days is not None else 0,
        "amount": money(abs(amount)),
        "dr_cr": "Dr" if amount < 0 else "Cr",
    }


def _parse_items(inv_entries: List[Tuple[ET.Element, str]], ctx: NormalizerContext,
                 errors: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    items = []
    for ie, fallback_ledger in inv_entries:
        name = text_of(ie, "STOCKITEMNAME")
        stock = ctx.stock_items.get(_key(name), {})
        qty, qty_uom = parse_quantity(first_text(ie, "BILLEDQTY", "ACTUALQTY"))
        qty = abs(qty)
        rate, rate_uom = parse_rate(text_of(ie, "RATE"))
        try:
            amount = round2(parse_amount(text_of(ie, "AMOUNT")))
        except ValueError as exc:
            errors.append(_issue("INVALID_AMOUNT", "Item '%s': %s" % (name, exc)))
            amount = ZERO
        taxable = abs(amount)
        gross = round2(qty * rate) if (qty and rate) else ZERO
        discount_amount = gross - taxable if gross > taxable else ZERO
        discount_pct = parse_percent(text_of(ie, "DISCOUNT"))
        if discount_pct == 0 and discount_amount > 0 and gross > 0:
            discount_pct = round2(discount_amount * 100 / gross)
        hsn, gst_rate = _hsn_and_rate(ie)
        if not hsn:
            hsn = str(stock.get("hsn_sac") or "")
        if gst_rate is None and stock.get("gst_rate") not in (None, "", 0, 0.0):
            gst_rate = Decimal(str(stock["gst_rate"]))
        items.append({
            "product_name": name,
            "hsn_sac": hsn,
            "qty": qty,
            "uom": qty_uom or rate_uom or str(stock.get("uom") or ""),
            "rate": rate,
            "discount_pct": discount_pct,
            "discount_amount": discount_amount,
            "taxable": taxable,
            "gst_rate": gst_rate,
            "godown": path_text(ie, "BATCHALLOCATIONS.LIST", "GODOWNNAME"),
            "ledger": path_text(ie, "ACCOUNTINGALLOCATIONS.LIST", "LEDGERNAME") or fallback_ledger,
        })
    return items


def _allocate_item_taxes(items: List[Dict[str, Any]], heads: Dict[str, Decimal]) -> None:
    """Fill each item's gst_rate/cgst/sgst/igst/cess/line_total.

    Voucher-level tax totals are spread across items weighted by
    taxable x rate (cess by taxable) so item taxes always add up exactly to
    the voucher's tax ledgers. Missing item rates are derived from the
    voucher's tax lines / taxable value.
    """
    if not items:
        return
    taxable_total = sum((it["taxable"] for it in items), ZERO)
    tax_total = heads["CGST"] + heads["SGST"] + heads["IGST"]
    derived = _snap_rate(tax_total * 100 / taxable_total) if taxable_total and tax_total else ZERO
    for it in items:
        if it["gst_rate"] is None:
            it["gst_rate"] = derived
    rate_weights = [it["taxable"] * it["gst_rate"] for it in items]
    if sum(rate_weights, ZERO) == 0:
        rate_weights = [it["taxable"] for it in items]
    taxable_weights = [it["taxable"] for it in items]
    for head in ("CGST", "SGST", "IGST"):
        for it, part in zip(items, _allocate(heads[head], rate_weights)):
            it[head.lower()] = part
    for it, part in zip(items, _allocate(heads["CESS"], taxable_weights)):
        it["cess"] = part
    for it in items:
        it["line_total"] = it["taxable"] + it["cgst"] + it["sgst"] + it["igst"] + it["cess"]


def make_unique_key(company: str, voucher_type: str, voucher_number: str, voucher_date: str, guid: str) -> str:
    """``GUID:<guid>`` or ``KEY:lower(company|type|number|date)``."""
    if guid:
        return "GUID:" + guid.strip()
    parts = [str(p or "").strip() for p in (company, voucher_type, voucher_number, voucher_date)]
    return "KEY:" + "|".join(parts).lower()


def normalize_tally_voucher(voucher: Any, company: str, context: Any = None) -> Dict[str, Any]:
    """Normalize one Tally VOUCHER (Element, element dict or XML text).

    ``context`` is a :class:`NormalizerContext` (or a dict with the same
    field names) holding the voucher-type -> base-type map and the
    ledger -> GST head map built from masters.
    """
    el = _as_voucher_element(voucher)
    ctx = NormalizerContext.coerce(context)
    warnings: List[Dict[str, str]] = []
    errors: List[Dict[str, str]] = []

    voucher_type = text_of(el, "VOUCHERTYPENAME") or (el.get("VCHTYPE") or "").strip()
    voucher_date = parse_tally_date(text_of(el, "DATE"))
    voucher_number = text_of(el, "VOUCHERNUMBER")
    guid = text_of(el, "GUID") or (el.get("REMOTEID") or "").strip()
    party_name = text_of(el, "PARTYLEDGERNAME")

    ledger_entries, inv_entries = _collect_entries(el)
    lines: List[Dict[str, Any]] = []
    bills: List[Dict[str, Any]] = []
    merged: Dict[Tuple[str, str, str], int] = {}
    for entry, origin in ledger_entries:
        name = text_of(entry, "LEDGERNAME")
        try:
            amount = round2(parse_amount(text_of(entry, "AMOUNT")))
        except ValueError as exc:
            errors.append(_issue("INVALID_AMOUNT", "Ledger '%s': %s" % (name, exc)))
            continue
        deemed = text_of(entry, "ISDEEMEDPOSITIVE")
        if deemed and amount != 0 and (amount < 0) != parse_bool(deemed):
            warnings.append(_issue(
                "SIGN_MISMATCH",
                "Ledger '%s': amount %s but ISDEEMEDPOSITIVE=%s; using the amount sign (%s)."
                % (name, amount, deemed, "Dr" if amount < 0 else "Cr")))
        is_party = parse_bool(text_of(entry, "ISPARTYLEDGER")) or (
            bool(party_name) and _key(name) == _key(party_name))
        if origin == "ledger":
            for b in children(entry, "BILLALLOCATIONS.LIST"):
                bill = _parse_bill(b, name, voucher_date, ctx, errors)
                if bill:
                    bills.append(bill)
        if amount == 0:
            continue
        debit = -amount if amount < 0 else ZERO
        credit = amount if amount > 0 else ZERO
        cost_centre = _cost_centre(entry)
        if origin == "inventory":
            merge_key = (_key(name), "D" if debit else "C", _key(cost_centre))
            index = merged.get(merge_key)
            if index is not None:
                lines[index]["debit"] += debit
                lines[index]["credit"] += credit
                continue
            merged[merge_key] = len(lines)
        lines.append({"ledger_name": name, "debit": debit, "credit": credit,
                      "is_party_line": is_party, "cost_centre": cost_centre})
    for i, ln in enumerate(lines, 1):
        ln["line_no"] = i
    if not party_name:
        party_name = next((ln["ledger_name"] for ln in lines if ln["is_party_line"]), "")

    # GST heads from tax ledger lines.
    heads = {h: ZERO for h in GST_HEADS}
    line_heads: Dict[int, str] = {}
    tax_debit = tax_credit = ZERO
    for ln in lines:
        if ln["is_party_line"]:
            continue
        head = ctx.tax_head(ln["ledger_name"])
        if not head:
            continue
        line_heads[ln["line_no"]] = head
        heads[head] += ln["credit"] - ln["debit"]
        tax_debit += ln["debit"]
        tax_credit += ln["credit"]
    heads = {h: abs(v) for h, v in heads.items()}

    items = _parse_items(inv_entries, ctx, errors)
    if items:
        taxable = sum((it["taxable"] for it in items), ZERO)
    elif line_heads:
        side = "credit" if tax_credit >= tax_debit else "debit"
        taxable = sum((ln[side] for ln in lines
                       if not ln["is_party_line"] and ln["line_no"] not in line_heads
                       and not _ROUND_OFF_RE.search(ln["ledger_name"])), ZERO)
    else:
        taxable = ZERO
    _allocate_item_taxes(items, heads)

    total_debit = sum((ln["debit"] for ln in lines), ZERO)
    party_lines = [ln for ln in lines if ln["is_party_line"]]
    amount = total_debit
    if party_lines:
        net = sum((ln["debit"] - ln["credit"] for ln in party_lines), ZERO)
        if net != 0:
            amount = abs(net)

    if parse_bool(text_of(el, "ISCANCELLED")):
        status = "CANCELLED"
    elif parse_bool(text_of(el, "ISOPTIONAL")):
        status = "OPTIONAL"
    else:
        status = "ACTIVE"

    header = {
        "unique_key": make_unique_key(company, voucher_type, voucher_number,
                                      voucher_date or text_of(el, "DATE"), guid),
        "company": company,
        "voucher_date": voucher_date,
        "voucher_type": voucher_type,
        "base_voucher_type": ctx.base_type(voucher_type) if voucher_type else "",
        "voucher_number": voucher_number,
        "reference_no": text_of(el, "REFERENCE"),
        "reference_date": parse_tally_date(text_of(el, "REFERENCEDATE")),
        "party_ledger": party_name,
        "party_gstin": first_text(el, "PARTYGSTIN") or ctx.ledger_gstin.get(_key(party_name), ""),
        "place_of_supply": first_text(el, "PLACEOFSUPPLY", "STATENAME"),
        "amount": money(amount),
        "narration": text_of(el, "NARRATION"),
        "salesperson": _salesperson(el),
        "cost_centre": next((ln["cost_centre"] for ln in lines if ln["cost_centre"]), ""),
        "status": status,
        "tally_guid": guid,
        "tally_master_id": parse_int(text_of(el, "MASTERID")),
        "tally_alter_id": parse_int(text_of(el, "ALTERID")),
    }

    return {
        "header": header,
        "lines": [{
            "line_no": ln["line_no"],
            "ledger_name": ln["ledger_name"],
            "debit": money(ln["debit"]),
            "credit": money(ln["credit"]),
            "is_party_line": bool(ln["is_party_line"]),
            "cost_centre": ln["cost_centre"],
        } for ln in lines],
        "bills": bills,
        "items": [{
            "line_no": i,
            "product_name": it["product_name"],
            "hsn_sac": it["hsn_sac"],
            "qty": float(round(it["qty"], 3)),
            "uom": it["uom"],
            "rate": float(round(it["rate"], 4)),
            "discount_pct": float(round2(it["discount_pct"])),
            "discount_amount": money(it["discount_amount"]),
            "taxable_amount": money(it["taxable"]),
            "gst_rate": float(round2(it["gst_rate"])),
            "cgst": money(it["cgst"]),
            "sgst": money(it["sgst"]),
            "igst": money(it["igst"]),
            "cess": money(it["cess"]),
            "line_total": money(it["line_total"]),
            "godown": it["godown"],
            "ledger": it["ledger"],
        } for i, it in enumerate(items, 1)],
        "gst": {
            "taxable": money(taxable),
            "cgst": money(heads["CGST"]),
            "sgst": money(heads["SGST"]),
            "igst": money(heads["IGST"]),
            "cess": money(heads["CESS"]),
        },
        "raw_xml": ET.tostring(el, encoding="unicode").strip(),
        "_warnings": warnings,
        "_errors": errors,
        "_line_heads": line_heads,
    }


def strip_private(voucher: Dict[str, Any]) -> Dict[str, Any]:
    """Copy of a normalized voucher without connector-private ``_`` keys."""
    return {k: v for k, v in voucher.items() if not k.startswith("_")}


def to_flat_transactions(voucher: Dict[str, Any], sync_timestamp: Optional[str] = None,
                         context: Any = None) -> List[Dict[str, Any]]:
    """One row per ledger line (for flat/tabular consumers).

    ``amount`` is the non-negative line value (the debit or the credit);
    ``gst`` is filled on tax-ledger lines and ``taxable_amount`` on the
    income/expense lines that sit on the same side as the tax lines.
    """
    header = voucher.get("header") or {}
    lines = voucher.get("lines") or []
    timestamp = sync_timestamp or datetime.now().replace(microsecond=0).isoformat()
    line_heads = voucher.get("_line_heads")
    if line_heads is None:
        ctx = NormalizerContext.coerce(context)
        line_heads = {ln["line_no"]: ctx.tax_head(ln["ledger_name"])
                      for ln in lines if not ln.get("is_party_line")}
        line_heads = {k: v for k, v in line_heads.items() if v}
    due_by_ledger: Dict[str, str] = {}
    for bill in voucher.get("bills") or []:
        if bill.get("due_date") and bill.get("bill_type") in ("New Ref", "Advance"):
            due_by_ledger.setdefault(_key(bill.get("party_ledger")), bill["due_date"])
    taxable_side = ""
    if line_heads:
        tax_dr = sum(float(ln["debit"]) for ln in lines if ln["line_no"] in line_heads)
        tax_cr = sum(float(ln["credit"]) for ln in lines if ln["line_no"] in line_heads)
        taxable_side = "credit" if tax_cr >= tax_dr else "debit"
    rows = []
    for ln in lines:
        debit, credit = float(ln["debit"]), float(ln["credit"])
        is_tax = ln["line_no"] in line_heads
        line_amount = debit if debit else credit
        taxable = 0.0
        if taxable_side and not is_tax and not ln.get("is_party_line") \
                and not _ROUND_OFF_RE.search(ln["ledger_name"]):
            taxable = float(ln[taxable_side])
        rows.append({
            "transaction_id": "%s#%d" % (header.get("unique_key", ""), ln["line_no"]),
            "voucher_id": header.get("unique_key", ""),
            "voucher_number": header.get("voucher_number", ""),
            "voucher_type": header.get("voucher_type", ""),
            "voucher_date": header.get("voucher_date", ""),
            "company": header.get("company", ""),
            "ledger": ln["ledger_name"],
            "party": header.get("party_ledger", ""),
            "debit": debit,
            "credit": credit,
            "amount": line_amount,
            "reference": header.get("reference_no", ""),
            "due_date": due_by_ledger.get(_key(ln["ledger_name"]), ""),
            "gst": line_amount if is_tax else 0.0,
            "taxable_amount": taxable,
            "narration": header.get("narration", ""),
            "source": "TALLY",
            "sync_timestamp": timestamp,
        })
    return rows


__all__ = [
    "NormalizerContext", "normalize_tally_voucher", "normalize_masters", "to_flat_transactions",
    "strip_private", "make_unique_key", "guess_base_type", "guess_tax_head",
    "BASE_VOUCHER_TYPES", "GST_HEADS",
]
