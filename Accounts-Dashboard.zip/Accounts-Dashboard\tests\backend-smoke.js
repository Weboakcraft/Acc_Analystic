/**
 * Backend smoke test: runs the real Apps Script files against an in-memory mock of the Google
 * services (SpreadsheetApp, PropertiesService, CacheService, LockService, Utilities, ...).
 * It exercises initializeDatabase (twice), login, every read route, offline sale posting and a
 * Tally connector sync (new, duplicate, altered, unbalanced, deletion reconcile).
 * Open tests/backend-smoke.html through a server rooted at the repository (tools\serve.ps1 -Root .).
 * The mock is behavioural, not a full emulation: formatting calls are accepted and ignored.
 */
var BackendSmoke = (function () {
  var MOCK = function () {
    function Range(sh, r, c, nr, nc) { this.sh = sh; this.r = r; this.c = c; this.nr = nr || 1; this.nc = nc || 1; }
    ['setNumberFormat', 'setDataValidation', 'setHorizontalAlignment', 'setFontWeight', 'setBackground', 'setFontColor', 'setWrap', 'setVerticalAlignment'].forEach(function (m) { Range.prototype[m] = function () { return this; }; });
    Range.prototype.getValues = function () { var out = []; for (var i = 0; i < this.nr; i++) { var row = []; for (var j = 0; j < this.nc; j++) { var v = (this.sh.data[this.r - 1 + i] || [])[this.c - 1 + j]; row.push(v === undefined ? '' : v); } out.push(row); } return out; };
    Range.prototype.setValues = function (v) { if (v.length !== this.nr || v[0].length !== this.nc) throw new Error('setValues dimension mismatch ' + v.length + 'x' + v[0].length + ' vs ' + this.nr + 'x' + this.nc); for (var i = 0; i < this.nr; i++) { var ri = this.r - 1 + i; this.sh.data[ri] = this.sh.data[ri] || []; for (var j = 0; j < this.nc; j++) this.sh.data[ri][this.c - 1 + j] = v[i][j]; } return this; };
    Range.prototype.setValue = function (v) { return this.setValues([[v]]); };
    Range.prototype.clearContent = function () { for (var i = 0; i < this.nr; i++) { var row = this.sh.data[this.r - 1 + i]; if (row) for (var j = 0; j < this.nc; j++) row[this.c - 1 + j] = ''; } return this; };
    function Sheet(name) { this.name = name; this.data = []; this.maxRows = 1000; this.prot = []; }
    Sheet.prototype.getName = function () { return this.name; };
    Sheet.prototype.getRange = function (r, c, nr, nc) { if (r < 1 || c < 1) throw new Error('bad range'); return new Range(this, r, c, nr, nc); };
    Sheet.prototype.getLastRow = function () { for (var i = this.data.length - 1; i >= 0; i--) if (this.data[i] && this.data[i].some(function (v) { return v !== '' && v !== undefined && v !== null; })) return i + 1; return 0; };
    Sheet.prototype.getLastColumn = function () { var m = 0; this.data.forEach(function (row) { if (row) for (var j = row.length - 1; j >= 0; j--) if (row[j] !== '' && row[j] !== undefined) { m = Math.max(m, j + 1); break; } }); return m; };
    Sheet.prototype.getMaxRows = function () { return Math.max(this.maxRows, this.data.length); };
    Sheet.prototype.insertRowsAfter = function (a, n) { this.maxRows += n; };
    Sheet.prototype.clear = function () { this.data = []; };
    Sheet.prototype.protect = function () { var p = { setDescription: function () { return p; }, setWarningOnly: function () { return p; } }; this.prot.push(p); return p; };
    Sheet.prototype.getProtections = function () { return this.prot; };
    ['setFrozenRows', 'setRowHeight', 'setColumnWidth', 'setTabColor'].forEach(function (m) { Sheet.prototype[m] = function () { return this; }; });
    var sheets = [new Sheet('Sheet1')];
    var ss = {
      getSheetByName: function (n) { return sheets.filter(function (s) { return s.name === n; })[0] || null; },
      insertSheet: function (n, i) { var s = new Sheet(n); sheets.splice(i === undefined ? sheets.length : i, 0, s); return s; },
      deleteSheet: function (s) { sheets.splice(sheets.indexOf(s), 1); },
      getNumSheets: function () { return sheets.length; }, getSheets: function () { return sheets; },
      setSpreadsheetTimeZone: function () {}, setSpreadsheetLocale: function () {}
    };
    var props = {}, cache = {};
    function hashBytes(s) { var h = [0x811c9dc5, 0x01000193, 0x12345678, 0x9abcdef0]; for (var i = 0; i < s.length; i++) { for (var k = 0; k < 4; k++) h[k] = Math.imul(h[k] ^ s.charCodeAt(i), 16777619 + k * 2); } var out = []; for (var r = 0; r < 8; r++) h.forEach(function (x, k) { out.push(((x >>> (r * 4 + k)) & 255) - 128); }); return out; }
    function b64(x) { var s = typeof x === 'string' ? x : x.map(function (b) { return String.fromCharCode(b & 255); }).join(''); return btoa(unescape(encodeURIComponent(s)).replace(/[^\x00-\xff]/g, '?')); }
    return {
      sheets: sheets,
      SpreadsheetApp: { getActiveSpreadsheet: function () { return ss; }, newDataValidation: function () { var b = { requireCheckbox: function () { return b; }, requireValueInList: function () { return b; }, requireDate: function () { return b; }, setAllowInvalid: function () { return b; }, build: function () { return {}; } }; return b; }, ProtectionType: { SHEET: 'SHEET' }, getUi: function () { throw new Error('no UI'); } },
      PropertiesService: { getScriptProperties: function () { return { getProperty: function (k) { return props[k] === undefined ? null : props[k]; }, setProperty: function (k, v) { props[k] = String(v); } }; } },
      CacheService: { getScriptCache: function () { return { get: function (k) { return cache[k] || null; }, put: function (k, v) { cache[k] = v; }, remove: function (k) { delete cache[k]; } }; } },
      LockService: { getScriptLock: function () { return { tryLock: function () { return true; }, releaseLock: function () {} }; } },
      Utilities: { getUuid: function () { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function () { return (Math.random() * 16 | 0).toString(16); }); }, computeDigest: function (alg, s) { return hashBytes(String(s)); }, base64Encode: b64, base64EncodeWebSafe: function (x) { return b64(x).replace(/\+/g, '-').replace(/\//g, '_'); }, formatDate: function (d) { return d.toISOString().slice(0, 19).replace(/[-:T]/g, ''); }, DigestAlgorithm: { SHA_256: 1, MD5: 2 }, Charset: { UTF_8: 1 } },
      Session: { getEffectiveUser: function () { return { getEmail: function () { return 'owner@company.example'; } }; } },
      ContentService: { createTextOutput: function (s) { return { body: s, setMimeType: function () { return this; } }; }, MimeType: { JSON: 'json' } },
      MailApp: { sent: [], sendEmail: function (o) { this.sent.push(o); } },
      ScriptApp: { WeekDay: { MONDAY: 1 }, getProjectTriggers: function () { return []; }, newTrigger: function () { var b = { timeBased: function () { return b; }, everyHours: function () { return b; }, everyDays: function () { return b; }, atHour: function () { return b; }, onWeekDay: function () { return b; }, onMonthDay: function () { return b; }, inTimezone: function () { return b; }, create: function () { return b; } }; return b; } },
      Logger: { log: function () {} }
    };
  };

  var SCENARIO = function () {
    var log = [], fail = 0;
    function check(name, cond, detail) { log.push({ ok: !!cond, name: name, detail: cond ? '' : JSON.stringify(detail) }); if (!cond) fail++; }
    function post(body) { return JSON.parse(doPost({ postData: { contents: JSON.stringify(body) } }).body); }

    var rep = initializeDatabase();
    check('initializeDatabase creates 42 tables', rep.length === 42 && __M.sheets.length === 43, { tables: rep.length, sheets: __M.sheets.length });
    var counts1 = {}; __M.sheets.forEach(function (s) { counts1[s.name] = s.getLastRow(); });
    initializeDatabase();
    var dup = __M.sheets.filter(function (s) { return s.getLastRow() !== counts1[s.name] && s.name !== 'AUDIT_LOG'; }).map(function (s) { return s.name; });
    check('re-running initializeDatabase adds no rows (idempotent)', dup.length === 0, dup);
    check('VOUCHER_ENTRIES has the 4 sample lines', Db.read('VOUCHER_ENTRIES').length === 4);
    check('Sheet1 removed, _INDEX created', !__M.sheets.some(function (s) { return s.name === 'Sheet1'; }) && __M.sheets.some(function (s) { return s.name === '_INDEX'; }));

    setUserPassword('admin@company.example', 'Str0ngPassw0rd2026');
    var bad = post({ action: 'login', params: { email: 'admin@company.example', password: 'wrong-pass-123' } });
    check('wrong password rejected', !bad.ok && bad.error.code === 'UNAUTHENTICATED', bad);
    var lg = post({ action: 'login', params: { email: 'admin@company.example', password: 'Str0ngPassw0rd2026' } });
    check('login returns token + permissions', lg.ok && lg.data.token && lg.data.user.permissions[0] === '*', lg);
    var T = lg.data && lg.data.token;
    var noTok = post({ action: 'getDashboard', params: {} });
    check('no token -> UNAUTHENTICATED', !noTok.ok && noTok.error.code === 'UNAUTHENTICATED', noTok);

    var tb0 = post({ action: 'getTrialBalance', token: T, params: { preset: 'current_fy' } });
    check('sample data trial balance is balanced', tb0.ok && tb0.data.balanced, tb0);

    var sale = post({ action: 'saveOfflineSale', token: T, params: { invoice_date: '2026-09-26', customer_name: 'Kapoor Dental Clinic', state: 'Uttar Pradesh', payment_mode: 'UPI', paid_amount: 20000, items: [{ product: 'Ergonomic Mesh Chair', qty: 3, rate: 12000, discount_pct: 5, tax_rate: 18 }] } });
    check('saveOfflineSale posts sale + receipt', sale.ok && sale.data.voucher_ids.length === 2 && sale.data.totals.igst === 6156, sale);
    var dupSale = post({ action: 'saveOfflineSale', token: T, params: { invoice_no: sale.data && sale.data.invoice_no, invoice_date: '2026-09-26', customer_name: 'X', payment_mode: 'Credit', items: [{ product: 'A', qty: 1, rate: 1, tax_rate: 18 }] } });
    check('duplicate offline invoice rejected', !dupSale.ok && dupSale.error.code === 'DUPLICATE_VOUCHER', dupSale);
    var badSale = post({ action: 'saveOfflineSale', token: T, params: { invoice_date: '2026-09-26', customer_gstin: 'BAD', payment_mode: 'Credit', items: [{ product: 'A', qty: 0, rate: 1, tax_rate: 7 }] } });
    check('invalid offline invoice rejected with details', !badSale.ok && badSale.error.code === 'VALIDATION', badSale);
    check('customer ledger + profile auto-created', Db.read('LEDGERS').some(function (l) { return l.ledger_name === 'Kapoor Dental Clinic'; }) && Db.read('CUSTOMERS').some(function (c) { return c.customer_name === 'Kapoor Dental Clinic'; }));

    PropertiesService.getScriptProperties().setProperty('CONNECTOR_API_KEY', 'test-key-123');
    var badKey = post({ action: 'tallyConfig', api_key: 'nope', params: { company: 'Demo Company' } });
    check('connector with wrong key rejected', !badKey.ok, badKey);
    var cfg = post({ action: 'tallyConfig', api_key: 'test-key-123', params: { company: 'Demo Company' } });
    check('tallyConfig returns watermark', cfg.ok && cfg.data.last_alter_id === 5001, cfg);
    var st = post({ action: 'tallySyncStart', api_key: 'test-key-123', params: { company: 'Demo Company', mode: 'INCREMENTAL', connector_host: 'TEST' } });
    var sid = st.data && st.data.sync_id;
    function tv(guid, alter, amt, no) { var tax = amt * 0.09; return { header: { unique_key: 'GUID:' + guid, voucher_date: '2026-09-25', voucher_type: 'Sales GST', base_voucher_type: 'Sales', voucher_number: no, party_ledger: 'ABC Interiors', amount: amt + 2 * tax, status: 'ACTIVE', tally_guid: guid, tally_alter_id: alter }, lines: [{ ledger_name: 'ABC Interiors', debit: amt + 2 * tax, credit: 0, is_party_line: true }, { ledger_name: 'Sales - Furniture (GST 18%)', debit: 0, credit: amt }, { ledger_name: 'Output CGST', debit: 0, credit: tax }, { ledger_name: 'Output SGST', debit: 0, credit: tax }], bills: [{ party_ledger: 'ABC Interiors', bill_name: no, bill_type: 'New Ref', bill_date: '2026-09-25', due_date: '2026-10-25', amount: amt + 2 * tax, dr_cr: 'Dr' }], items: [], gst: { taxable: amt, cgst: tax, sgst: tax }, raw_xml: '<VOUCHER/>' }; }
    var unbal = tv('g-bad', 6003, 1000, 'AC/S/0099'); unbal.lines[1].credit = 999;
    var s1 = post({ action: 'syncTallyData', api_key: 'test-key-123', params: { sync_id: sid, company: 'Demo Company', vouchers: [tv('g-1', 6001, 50000, 'AC/S/0002'), tv('g-1', 6001, 50000, 'AC/S/0002'), unbal, { header: { unique_key: 'GUID:g-new-ledger', voucher_date: '2026-09-25', voucher_type: 'Receipt', base_voucher_type: 'Receipt', voucher_number: 'AC/R/9', party_ledger: 'Brand New Customer', amount: 100, tally_alter_id: 6004 }, lines: [{ ledger_name: 'Brand New Customer', debit: 0, credit: 100, is_party_line: true }, { ledger_name: 'HDFC Bank CA 4521', debit: 100, credit: 0 }] }] } });
    check('sync: 2 added, 1 duplicate skipped, 1 unbalanced failed', s1.ok && s1.data.added === 2 && s1.data.skipped === 1 && s1.data.failed === 1, s1);
    var again = post({ action: 'syncTallyData', api_key: 'test-key-123', params: { sync_id: sid, company: 'Demo Company', vouchers: [tv('g-1', 6001, 50000, 'AC/S/0002')] } });
    check('re-sending the same voucher is skipped (no duplicate import)', again.ok && again.data.skipped === 1 && again.data.added === 0, again);
    var alt = post({ action: 'syncTallyData', api_key: 'test-key-123', params: { sync_id: sid, company: 'Demo Company', vouchers: [tv('g-1', 6010, 60000, 'AC/S/0002')] } });
    var v = Db.read('VOUCHERS').filter(function (x) { return x.unique_key === 'GUID:g-1'; })[0];
    check('altered voucher -> revision 2 with new amount', alt.ok && alt.data.updated === 1 && Number(v.revision) === 2 && Number(v.amount) === 70800, { alt: alt, v: v });
    check('unknown ledger auto-created under Sundry Debtors and flagged', Db.read('LEDGERS').some(function (l) { return l.ledger_name === 'Brand New Customer' && l.parent_group === 'Sundry Debtors' && l.needs_review === true; }));
    var rec = post({ action: 'syncTallyData', api_key: 'test-key-123', params: { sync_id: sid, company: 'Demo Company', vouchers: [], reconcile: { from_date: '2026-09-25', to_date: '2026-09-25', unique_keys: ['GUID:g-1'] } } });
    check('full-sync reconcile marks missing voucher DELETED_IN_TALLY', rec.ok && rec.data.deleted === 1, rec);
    var fin = post({ action: 'tallySyncFinish', api_key: 'test-key-123', params: { sync_id: sid, status: 'PARTIAL', records_fetched: 6, to_alter_id: 6010 } });
    var logRow = Db.read('TALLY_SYNC_LOG').filter(function (l) { return l.sync_id === sid; })[0];
    check('sync log counters accumulated', fin.ok && Number(logRow.records_added) === 2 && Number(logRow.records_failed) === 1 && logRow.status === 'PARTIAL', logRow);
    check('rejected voucher logged in TALLY_ERRORS', Db.read('TALLY_ERRORS').some(function (e) { return e.error_code === 'UNBALANCED'; }));

    var tb = post({ action: 'getTrialBalance', token: T, params: { preset: 'current_fy' } });
    check('trial balance still balanced after all postings', tb.ok && tb.data.balanced, tb.data && { d: tb.data.difference, p: tb.data.periodDifference, o: tb.data.openingDifference });
    var bs = post({ action: 'getBalanceSheet', token: T, params: {} });
    check('balance sheet balanced', bs.ok && bs.data.balanced, bs.data && bs.data.difference);

    var reads = { getDashboard: {}, getManagementDashboard: {}, getFinancialHealth: {}, getAnalytics: {}, getAlerts: {}, searchTransactions: { q: 'abc' }, getLookups: {}, getSales: { preset: 'current_fy' }, getSalesReport: { groupBy: 'customer' }, getPurchases: {}, getPurchaseReport: { groupBy: 'month' }, getCustomers: {}, getVendors: {}, getReceivables: {}, getPayables: {}, getAgeing: { kind: 'payable' }, getPartyAccounts: { kind: 'customer' }, getReceipts: {}, getPayments: {}, getExpenses: {}, getVoucher: { voucher_id: 'VCH-000001' }, getInventory: {}, getLedgers: {}, getLedgerStatement: { ledger: 'ABC Interiors' }, getCashBook: {}, getBankTransactions: { bank_account_id: 'BNK-0001' }, getProfitLoss: { comparative: true }, getCashFlow: {}, getGSTSummary: {}, getTallyStatus: {}, getSyncLog: {}, getTallyErrors: {}, getTallyData: { voucher_id: 'VCH-000001' }, getAuditLog: {}, getSettings: {}, getUsers: {} };
    var failedReads = Object.keys(reads).filter(function (a) { var r = post({ action: a, token: T, params: reads[a] }); if (!r.ok) { r._a = a; log.push({ ok: false, name: 'read ' + a, detail: JSON.stringify(r.error) }); } return !r.ok; });
    check('all ' + Object.keys(reads).length + ' read endpoints succeed', failedReads.length === 0, failedReads);

    var exp = post({ action: 'saveExpense', token: T, params: { expense_date: '2026-09-26', category: 'Repairs', expense_ledger: 'Repairs & Maintenance', amount: 1000, gst_rate: 18, payment_mode: 'Bank Transfer', paid_from_ledger: 'HDFC Bank CA 4521', description: 'test' } });
    var ap = post({ action: 'approveExpense', token: T, params: { expense_id: exp.data && exp.data.expense_id } });
    check('expense submit + approve posts a voucher', exp.ok && ap.ok && ap.data.voucher_id, { exp: exp, ap: ap });
    var jv = post({ action: 'saveJournal', token: T, params: { date: '2026-09-26', narration: 'bad', lines: [{ ledger_name: 'Output CGST', debit: 10 }, { ledger_name: 'HDFC Bank CA 4521', credit: 9 }] } });
    check('unbalanced manual journal rejected', !jv.ok && jv.error.code === 'UNBALANCED', jv);
    var inj = post({ action: 'createLedger', token: T, params: { ledger_name: '=HYPERLINK("x")', parent_group: 'Indirect Expenses' } });
    var stored = Db.sheet('LEDGERS').data.filter(function (r) { return String(r[2]).indexOf('HYPERLINK') >= 0; })[0];
    check('formula injection neutralised on write', inj.ok && stored && String(stored[2]).charAt(0) === "'", stored);
    var st2 = post({ action: 'updateSetting', token: T, params: { key: 'AGEING_BASIS', value: 'BILL_DATE' } });
    check('setting update persisted', st2.ok && Settings.all().AGEING_BASIS === 'BILL_DATE', st2);
    check('audit trail recorded writes', Db.read('AUDIT_LOG').length > 10 && Db.read('AUDIT_LOG').some(function (a) { return a.action === 'APPROVE'; }));
    runAlertScan(); rebuildReportSnapshots();
    check('alert scan + snapshot rebuild run', Db.read('NOTIFICATIONS').length >= 1 && Db.read('RECEIVABLES').length >= 1);
    return { log: log, fail: fail };
  };

  function run(done) {
    var files = ['Code', 'Routes', 'Auth', 'Db', 'Setup', 'Services', 'Tally', 'Automation', 'Schema', 'Engine'];
    Promise.all(files.map(function (f) { return fetch('../backend/apps-script/' + f + '.gs').then(function (r) { return r.text(); }); })).then(function (srcs) {
      var M = MOCK();
      var names = Object.keys(M).filter(function (k) { return k !== 'sheets'; });
      var body = srcs.join('\n;\n') + '\n;return (' + SCENARIO.toString() + ')();';
      var fn = new Function(['__M'].concat(names).join(','), body);
      var res;
      try { res = fn.apply(null, [M].concat(names.map(function (n) { return M[n]; }))); }
      catch (e) { res = { log: [{ ok: false, name: 'scenario crashed', detail: e.message + '\n' + e.stack }], fail: 1 }; }
      done(res);
    });
  }
  return { run: run };
})();
