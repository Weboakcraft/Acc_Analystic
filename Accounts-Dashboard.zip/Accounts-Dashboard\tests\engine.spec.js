/**
 * Accounting engine test suite. Runs in any browser (open tests/engine-tests.html) or Node:
 *   node -e "global.Engine=require('./shared/accounting-engine.js');require('./tests/engine.spec.js').run()"
 * Each test builds a tiny set of books so the expected figures can be checked by hand.
 */
(function (root) {
  var E = root.Engine || (typeof require !== 'undefined' ? require('../shared/accounting-engine.js') : null);
  var tests = [];
  function test(name, fn) { tests.push({ name: name, fn: fn }); }
  function eq(a, b, msg) { if (Math.abs(Number(a) - Number(b)) > 0.005 && a !== b) throw new Error((msg || 'expected') + ': got ' + JSON.stringify(a) + ', want ' + JSON.stringify(b)); }
  function ok(c, msg) { if (!c) throw new Error(msg || 'assertion failed'); }

  // ---------- fixture helpers ----------
  function books(extra) {
    var ledgers = [
      L('Capital', 'Capital Account', 500000, 'Cr'), L('Bank', 'Bank Accounts', 400000, 'Dr'), L('Cash', 'Cash-in-Hand', 100000, 'Dr'),
      L('ABC Interiors', 'Sundry Debtors', 0, 'Dr', { credit_days: 30 }), L('XYZ Hardware', 'Sundry Creditors', 0, 'Cr', { credit_days: 45 }),
      L('Sales', 'Sales Accounts'), L('Purchases', 'Purchase Accounts'), L('Rent', 'Indirect Expenses', 0, 'Dr', { mis_category: 'RENT' }),
      L('Depreciation', 'Indirect Expenses', 0, 'Dr', { mis_category: 'DEPRECIATION' }), L('Machinery', 'Fixed Assets'), L('Loan', 'Secured Loans'),
      L('Output CGST', 'Duties & Taxes', 0, 'Cr', { tax_type: 'CGST' }), L('Output SGST', 'Duties & Taxes', 0, 'Cr', { tax_type: 'SGST' }),
      L('Input CGST', 'Duties & Taxes', 0, 'Dr', { tax_type: 'CGST' }), L('Input SGST', 'Duties & Taxes', 0, 'Dr', { tax_type: 'SGST' })
    ];
    var db = { company: { company_id: 'C1', state: 'Delhi', fy_start_month: 4, books_begin_date: '2026-04-01' }, today: '2026-09-26', ledgers: ledgers, vouchers: [], entries: [], bills: [], inventory: [], groups: [] };
    (extra || []).forEach(function (v) { V(db, v); });
    return db;
  }
  function L(n, g, ob, dc, x) { var l = { ledger_name: n, parent_group: g, opening_balance: ob || 0, opening_dr_cr: dc || 'Dr' }; Object.keys(x || {}).forEach(function (k) { l[k] = x[k]; }); return l; }
  var seq = 0;
  function V(db, v) {
    var id = v.id || 'V' + (++seq);
    db.vouchers.push({ voucher_id: id, voucher_date: v.date, voucher_type: v.type, base_voucher_type: v.type, voucher_number: v.no || id, party_ledger: v.party || '', status: v.status || 'ACTIVE', revision: v.rev || 1, source: v.source || 'TALLY' });
    v.lines.forEach(function (l, i) { db.entries.push({ voucher_id: id, revision: l[3] || v.rev || 1, line_no: i + 1, ledger_name: l[0], debit: l[1], credit: l[2] }); });
    (v.bills || []).forEach(function (b) { b.voucher_id = id; b.revision = v.rev || 1; db.bills.push(b); });
    return id;
  }
  function sale(date, no, amt, extra) {
    var tax = Math.round(amt * 0.09 * 100) / 100, total = amt + 2 * tax;
    return Object.assign({ date: date, type: 'Sales', no: no, party: 'ABC Interiors', lines: [['ABC Interiors', total, 0], ['Sales', 0, amt], ['Output CGST', 0, tax], ['Output SGST', 0, tax]], bills: [{ party_ledger: 'ABC Interiors', bill_name: no, bill_type: 'New Ref', bill_date: date, due_date: E.util.addDays(date, 30), amount: total, dr_cr: 'Dr' }] }, extra || {});
  }
  function receipt(date, amt, against) {
    return { date: date, type: 'Receipt', party: 'ABC Interiors', lines: [['Bank', amt, 0], ['ABC Interiors', 0, amt]], bills: against ? [{ party_ledger: 'ABC Interiors', bill_name: against, bill_type: 'Agst Ref', amount: amt, dr_cr: 'Cr' }] : [] };
  }
  function purchase(date, no, amt) {
    var tax = amt * 0.09, total = amt + 2 * tax;
    return { date: date, type: 'Purchase', no: no, party: 'XYZ Hardware', lines: [['Purchases', amt, 0], ['Input CGST', tax, 0], ['Input SGST', tax, 0], ['XYZ Hardware', 0, total]], bills: [{ party_ledger: 'XYZ Hardware', bill_name: no, bill_type: 'New Ref', bill_date: date, due_date: E.util.addDays(date, 45), amount: total, dr_cr: 'Cr' }] };
  }
  function ctx(db, s) { return E.createContext(db, s || {}); }

  // ---------- Sales & receipts ----------
  test('Sales voucher posts party Dr = sales + GST Cr and registers as Outstanding', function () {
    var c = ctx(books([sale('2026-09-20', 'S1', 100000)]));
    var r = E.register(c, { kind: 'sales' }).rows[0];
    eq(r.amount, 118000, 'invoice amount'); eq(r.taxable, 100000, 'taxable'); eq(r.cgst, 9000); eq(r.sgst, 9000);
    eq(r.outstanding, 118000); eq(r.status, 'Outstanding', 'status');
  });
  test('Partial receipt against bill -> Partially Paid; full -> Paid', function () {
    var c = ctx(books([sale('2026-09-20', 'S1', 100000), receipt('2026-09-22', 50000, 'S1')]));
    var r = E.register(c, { kind: 'sales' }).rows[0];
    eq(r.paid, 50000); eq(r.outstanding, 68000); eq(r.status, 'Partially Paid');
    c = ctx(books([sale('2026-09-20', 'S1', 100000), receipt('2026-09-22', 118000, 'S1')]));
    eq(E.register(c, { kind: 'sales' }).rows[0].status, 'Paid');
  });
  test('Overdue status once due date passes', function () {
    var c = ctx(books([sale('2026-07-01', 'S1', 10000)]));
    var r = E.register(c, { kind: 'sales' }).rows[0];
    eq(r.status, 'Overdue'); ok(r.days_overdue > 50, 'days overdue');
  });
  test('Receipt without bill reference is applied FIFO to the oldest bill', function () {
    var c = ctx(books([sale('2026-08-01', 'S1', 10000), sale('2026-09-01', 'S2', 10000), receipt('2026-09-10', 11800)]));
    var o = E.outstanding(c, { kind: 'receivable' });
    eq(o.total, 11800, 'total ties to ledger');
    var s1 = o.bills.filter(function (b) { return b.bill_name === 'S1'; });
    eq(s1.length, 0, 'S1 fully settled by FIFO');
  });
  test('BILL_ALLOCATION_FALLBACK=NONE leaves unallocated receipt On Account', function () {
    var c = ctx(books([sale('2026-08-01', 'S1', 10000), receipt('2026-09-10', 5000)]), { BILL_ALLOCATION_FALLBACK: 'NONE' });
    var o = E.outstanding(c, { kind: 'receivable' });
    eq(o.total, 6800); ok(o.bills.some(function (b) { return b.status === 'Advance' && b.outstanding === -5000; }), 'advance line');
  });

  // ---------- Ageing ----------
  test('Ageing buckets by due date', function () {
    var c = ctx(books([sale('2026-09-20', 'A', 1000), sale('2026-07-15', 'B', 1000), sale('2026-04-10', 'C', 1000)]));
    var o = E.outstanding(c, { kind: 'receivable', asOf: '2026-09-26' });
    var by = {}; o.bills.forEach(function (b) { by[b.bill_name] = b.ageing_bucket; });
    eq(by.A, 'Not Due'); eq(by.B, '31-60'); eq(by.C, '91-180');
  });
  test('Ageing by bill date when AGEING_BASIS=BILL_DATE', function () {
    var c = ctx(books([sale('2026-09-20', 'A', 1000)]), { AGEING_BASIS: 'BILL_DATE' });
    eq(E.outstanding(c, { kind: 'receivable', asOf: '2026-09-26' }).bills[0].ageing_bucket, '0-30');
  });

  // ---------- Payables ----------
  test('Vendor ledger: purchases, payments and closing computed from vouchers', function () {
    var c = ctx(books([purchase('2026-09-01', 'P1', 10000), { date: '2026-09-10', type: 'Payment', party: 'XYZ Hardware', lines: [['XYZ Hardware', 5000, 0], ['Bank', 0, 5000]], bills: [{ party_ledger: 'XYZ Hardware', bill_name: 'P1', bill_type: 'Agst Ref', amount: 5000, dr_cr: 'Dr' }] }]));
    var a = E.partyAccounts(c, { kind: 'vendor' }).rows[0];
    eq(a.invoices, 11800, 'purchases'); eq(a.settlements, 5000, 'payments'); eq(a.closing, 6800, 'closing');
    eq(E.outstanding(c, { kind: 'payable' }).total, 6800);
  });

  // ---------- Double entry / trial balance ----------
  test('Trial balance balances and opening balances agree', function () {
    var c = ctx(books([sale('2026-09-20', 'S1', 100000), receipt('2026-09-22', 50000, 'S1'), purchase('2026-09-05', 'P1', 40000)]));
    var tb = E.trialBalance(c, {});
    ok(tb.balanced, 'balanced'); eq(tb.openingDifference, 0); eq(tb.totals.periodDr, tb.totals.periodCr);
  });
  test('Unbalanced voucher is detected and fails validation', function () {
    var v = E.validateVoucher({ voucher_date: '2026-09-01', voucher_type: 'Journal' }, [{ ledger_name: 'Rent', debit: 100 }, { ledger_name: 'Bank', credit: 99 }]);
    ok(!v.valid, 'invalid'); ok(v.errors.join(' ').indexOf('does not equal') >= 0);
    var c = ctx(books([{ date: '2026-09-01', type: 'Journal', lines: [['Rent', 100, 0], ['Bank', 0, 99]] }]));
    eq(E.trialBalance(c, {}).unbalancedVouchers.length, 1);
  });
  test('Opening balance mismatch shows as Difference in opening balances', function () {
    var db = books(); db.ledgers[1].opening_balance = 401000;
    var tb = E.trialBalance(ctx(db), {});
    eq(tb.openingDifference, 1000); ok(tb.balanced, 'still balanced after the difference line');
  });
  test('Cancelled and superseded revisions are excluded', function () {
    var db = books([sale('2026-09-20', 'S1', 100000, { status: 'CANCELLED' })]);
    eq(E.register(ctx(db), { kind: 'sales' }).rows.length, 0, 'cancelled excluded');
    db = books([sale('2026-09-20', 'S2', 100000, { rev: 2 })]);
    db.entries.push({ voucher_id: db.vouchers[0].voucher_id, revision: 1, line_no: 9, ledger_name: 'Rent', debit: 5, credit: 0 });
    ok(E.trialBalance(ctx(db), {}).balanced, 'old revision line ignored');
  });

  // ---------- P&L / balance sheet / cash flow ----------
  test('P&L: gross profit, EBITDA and net profit with stock valuation', function () {
    var db = books([sale('2026-09-20', 'S1', 100000), purchase('2026-09-05', 'P1', 60000), { date: '2026-09-10', type: 'Payment', lines: [['Rent', 10000, 0], ['Bank', 0, 10000]] }, { date: '2026-09-30', type: 'Journal', lines: [['Depreciation', 2000, 0], ['Machinery', 0, 2000]] }]);
    db.today = '2026-09-30';
    db.inventory = [{ product_name: 'All', as_of_date: '2026-09-30', closing_value: 15000 }];
    var pl = E.profitLoss(ctx(db), { from: '2026-09-01', to: '2026-09-30' });
    eq(pl.revenue, 100000); eq(pl.cogs, 45000, 'COGS = 0 + 60000 - 15000'); eq(pl.grossProfit, 55000); eq(pl.ebitda, 45000); eq(pl.netProfit, 43000);
  });
  test('Balance sheet balances including stock and current profit', function () {
    var db = books([sale('2026-09-20', 'S1', 100000), purchase('2026-09-05', 'P1', 60000)]);
    db.inventory = [{ product_name: 'All', as_of_date: '2026-09-25', closing_value: 15000 }];
    var bs = E.balanceSheet(ctx(db), { asOf: '2026-09-26' });
    ok(bs.balanced, 'balanced, diff ' + bs.difference); eq(bs.closingStock, 15000);
  });
  test('Prior-year profit moves to retained earnings', function () {
    var db = books([sale('2026-03-10', 'S0', 50000)]);
    db.company.books_begin_date = '2025-04-01';
    var bs = E.balanceSheet(ctx(db), { asOf: '2026-09-26' });
    ok(bs.balanced); eq(bs.retainedEarnings, 50000); eq(bs.currentProfit, 0);
    var tb = E.trialBalance(ctx(db), {});
    ok(tb.rows.some(function (r) { return r.ledger.indexOf('brought forward') >= 0 && r.closingCr === 50000; }), 'P&L b/f row');
  });
  test('Cash flow (direct) reconciles opening + net = closing and classifies activities', function () {
    var c = ctx(books([sale('2026-09-01', 'S1', 100000), receipt('2026-09-05', 118000, 'S1'), { date: '2026-09-06', type: 'Payment', lines: [['Machinery', 50000, 0], ['Bank', 0, 50000]] }, { date: '2026-09-07', type: 'Receipt', lines: [['Bank', 200000, 0], ['Loan', 0, 200000]] }, { date: '2026-09-08', type: 'Contra', lines: [['Cash', 10000, 0], ['Bank', 0, 10000]] }]));
    var cf = E.cashFlow(c, { from: '2026-09-01', to: '2026-09-30' });
    ok(cf.reconciles); eq(cf.sections[0].net, 118000, 'operating'); eq(cf.sections[1].net, -50000, 'investing'); eq(cf.sections[2].net, 200000, 'financing');
  });

  // ---------- GST ----------
  test('GST: output from sales, input from purchases, credit note reduces output', function () {
    var cn = { date: '2026-09-25', type: 'Credit Note', party: 'ABC Interiors', lines: [['Sales', 10000, 0], ['Output CGST', 900, 0], ['Output SGST', 900, 0], ['ABC Interiors', 0, 11800]] };
    var g = E.gstSummary(ctx(books([sale('2026-09-20', 'S1', 100000), purchase('2026-09-05', 'P1', 40000), cn])), { from: '2026-09-01', to: '2026-09-30' });
    eq(g.output.cgst, 8100); eq(g.input.cgst, 3600); eq(g.net.total, 9000); eq(g.output.taxable_value, 90000);
  });
  test('GST paid (payment voucher) is a settlement, not input credit', function () {
    var pay = { date: '2026-09-26', type: 'Payment', lines: [['Output CGST', 5000, 0], ['Bank', 0, 5000]] };
    var g = E.gstSummary(ctx(books([pay])), { from: '2026-09-01', to: '2026-09-30' });
    eq(g.input.total_tax, 0); eq(g.settled.cgst, 5000);
  });

  // ---------- Offline sales ----------
  test('Offline sale intra-state: CGST+SGST, round-off, receipt voucher, auto customer ledger', function () {
    var b = E.buildOfflineSale({ invoice_no: 'OFF1', invoice_date: '2026-09-26', customer_name: 'New Cust', state: 'Delhi', payment_mode: 'Cash', paid_amount: 1000, items: [{ product: 'Chair', qty: 3, rate: 999.5, discount_pct: 0, tax_rate: 18 }] }, { COMPANY_STATE: 'Delhi' }, []);
    ok(b.valid, b.errors.join(';'));
    eq(b.totals.taxable, 2998.5); eq(b.totals.cgst, 269.87); eq(b.totals.total, 3538); eq(b.totals.roundOff, -0.24);
    eq(b.vouchers.length, 2, 'sale + receipt'); ok(E.validateVoucher(b.vouchers[0].header, b.vouchers[0].lines).valid, 'sale balances');
    ok(b.newLedgers.some(function (l) { return l.ledger_name === 'New Cust' && l.parent_group === 'Sundry Debtors'; }), 'customer ledger created');
    eq(b.totals.outstanding, 2538);
  });
  test('Offline sale inter-state uses IGST', function () {
    var b = E.buildOfflineSale({ invoice_no: 'OFF2', invoice_date: '2026-09-26', customer_name: 'UP Cust', state: 'Uttar Pradesh', payment_mode: 'Credit', items: [{ product: 'Desk', qty: 1, rate: 10000, tax_rate: 18 }] }, { COMPANY_STATE: 'Delhi' }, []);
    eq(b.totals.igst, 1800); eq(b.totals.cgst, 0); eq(b.vouchers.length, 1);
  });
  test('Offline sale validation: bad GSTIN, zero qty, non-standard rate, overpayment', function () {
    var b = E.buildOfflineSale({ invoice_no: 'X', invoice_date: '2026-09-26', customer_gstin: 'ABC', payment_mode: 'Cash', paid_amount: 999999, items: [{ product: 'D', qty: 0, rate: 10, tax_rate: 7 }] }, {}, []);
    ok(!b.valid); ok(b.errors.length >= 3, b.errors.join(' | '));
  });
  test('Offline sales are included in consolidated sales with source split', function () {
    var db = books([sale('2026-09-20', 'S1', 100000)]);
    var b = E.buildOfflineSale({ invoice_no: 'OFF3', invoice_date: '2026-09-21', customer_name: 'ABC Interiors', payment_mode: 'Credit', items: [{ product: 'Desk', qty: 1, rate: 10000, tax_rate: 18 }] }, { COMPANY_STATE: 'Delhi' }, []);
    b.vouchers.forEach(function (v) { V(db, { id: 'OFFV', date: v.header.voucher_date, type: 'Sales', no: v.header.voucher_number, party: v.header.party_ledger, source: 'OFFLINE', lines: v.lines.map(function (l) { return [l.ledger_name, l.debit, l.credit]; }), bills: v.bills }); });
    db.ledgers.push(L('Sales - Offline', 'Sales Accounts'));
    var t = E.register(ctx(db), { kind: 'sales' }).totals;
    eq(t.count, 2); eq(t.amount, 129800);
    eq(t.bySource.filter(function (s) { return s.key === 'OFFLINE'; })[0].amount, 11800);
  });

  // ---------- Ledger ----------
  test('Ledger statement: opening, running balance, closing', function () {
    var c = ctx(books([sale('2026-09-20', 'S1', 100000), receipt('2026-09-22', 50000, 'S1')]));
    var s = E.ledgerStatement(c, { ledger: 'Bank', from: '2026-09-01', to: '2026-09-30' });
    eq(s.opening, 400000); eq(s.rows[0].balance, 450000); eq(s.closing, 450000); eq(s.rows[0].particulars, 'ABC Interiors');
  });

  // ---------- Duplicates / periods ----------
  test('Duplicate voucher numbers in the same FY are flagged', function () {
    var c = ctx(books([sale('2026-09-20', 'S1', 100), sale('2026-09-21', 'S1', 200)]));
    eq(E.integrity(c).duplicates.length, 1);
  });
  test('Indian FY and period presets', function () {
    eq(E.util.fyStart('2026-03-31', 4), '2025-04-01'); eq(E.util.fyStart('2026-04-01', 4), '2026-04-01');
    var p = E.util.periodRange('previous_fy', '2026-09-26', 4); eq(p.from, '2025-04-01'); eq(p.to, '2026-03-31');
    eq(E.util.periodRange('this_quarter', '2026-09-26', 4).from, '2026-07-01');
  });

  function run(report) {
    var pass = 0, fail = 0, lines = [];
    tests.forEach(function (t) {
      try { t.fn(); pass++; lines.push({ ok: true, name: t.name }); }
      catch (e) { fail++; lines.push({ ok: false, name: t.name, error: e.message }); }
    });
    (report || function (l) { l.forEach(function (x) { console.log((x.ok ? 'PASS ' : 'FAIL ') + x.name + (x.error ? '\n     ' + x.error : '')); }); })(lines);
    return { pass: pass, fail: fail, lines: lines };
  }
  var api = { run: run, count: function () { return tests.length; } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.EngineTests = api;
})(this);
