# Deployment guide

Five steps, about 45 minutes: **Sheet → Apps Script → first admin → GitHub Pages → Tally connector.**

## 1. Google Sheets setup
1. Create a new Google Sheet named, for example, `Accounts Dashboard DB`, using the Google account that will own the data (preferably a company account, not a personal one).
2. Set **File → Settings → Locale: India, Time zone: (GMT+05:30) India Standard Time**. The initializer tries to set these too.
3. Don't create tabs by hand. The initializer creates all 42.

## 2. Apps Script backend
1. In the Sheet: **Extensions → Apps Script**. The script must be *bound* to the Sheet.
2. Delete the default `Code.gs`. Create script files named exactly as in `backend/apps-script/` and paste each one in: `Code.gs, Routes.gs, Auth.gs, Db.gs, Setup.gs, Services.gs, Tally.gs, Automation.gs, Schema.gs, Engine.gs`.
   - `Schema.gs` and `Engine.gs` are **generated**. After changing `database/schema.json` or `shared/accounting-engine.js`, run `python tools/build.py` (or `tools\build.ps1` on Windows) and paste them again.
   - To avoid copy-pasting, you can use [clasp](https://github.com/google/clasp): `clasp clone <scriptId>` into `backend/apps-script`, then `clasp push`.
3. **Project Settings → Show "appsscript.json"**, then replace its contents with `backend/apps-script/appsscript.json` (V8, Asia/Kolkata, web-app access).
4. Reload the Sheet. An **Accounts Dashboard** menu appears.
5. **Accounts Dashboard → Initialize / repair database** and approve the permissions. This creates the sheets, headers, formats, dropdowns and one sample row each, plus an `_INDEX` tab. It is safe to run again: it never duplicates headers or samples, and it adds any new schema columns.
6. Fill in `COMPANIES` (the sample row is Demo Company). `tally_company_name` must match the company name in Tally **exactly**.
7. **Deploy → New deployment → Web app**: *Execute as* **Me**, *Who has access* **Anyone**. Copy the `/exec` URL.
   - "Anyone" is needed because the browser and the connector call it without a Google login. Access control is done by the app's own sign-in and the connector API key.
   - After each code change, use **Manage deployments → Edit → New version**. The URL stays the same.

## 3. First administrator
1. **Accounts Dashboard → Set a user password**, then enter `admin@company.example` (the sample USERS row; you can change the email in the sheet first) and a strong password. The password goes only into the hashed columns.
2. Sign in to the web app and add real users under **Settings → Users & roles**.
3. **Accounts Dashboard → Generate connector API key**. Copy the key shown and keep it for step 5. It is stored in Script Properties and never shown again. Run it again to rotate the key.
4. **Accounts Dashboard → Install scheduled automations** creates the time-driven triggers (alerts hourly, daily MIS at 20:00, snapshots at 23:00, reminders at 09:00, weekly report on Monday, monthly pack on the 1st).
5. In `CONFIG`, add `REPORT_RECIPIENTS` (comma-separated emails). Optional keys: `OFFLINE_INVOICE_SERIES` (default `OFF`), `SYNC_STALE_HOURS` (default 6), `SEND_CUSTOMER_REMINDERS` (default FALSE).
6. After go-live checks, **Accounts Dashboard → Remove sample rows** (USERS, CONFIG and SETTINGS are kept).

## 4. Frontend on GitHub Pages
1. Edit `frontend/js/config.js` and set `API_URL: 'https://script.google.com/macros/s/<id>/exec'`. Put nothing secret here.
2. Push the repository to GitHub. Under **Settings → Pages**, choose *Deploy from a branch*, then the branch `main` and the folder `/frontend`. If Pages only offers `/` or `/docs`, either rename `frontend` to `docs`, or add a GitHub Actions workflow that publishes `frontend/` (the standard "Static HTML" starter workflow with `path: frontend`).
3. Open `https://<user>.github.io/<repo>/` and sign in.
4. With `API_URL` left empty, the app runs in **demo mode** on generated data. That is useful for training and UAT without touching real books.

Local preview (Windows, no Python/Node): `powershell -ExecutionPolicy Bypass -File tools\serve.ps1`, then open http://localhost:8080.

## 5. Tally configuration and connector
1. Tally Prime: **F1 (Help) → Settings → Connectivity → Client/Server configuration**. Set *TallyPrime acts as* **Both** (or Server), *Enable ODBC* **Yes**, *Port* **9000**. On Tally ERP 9 the equivalent is F12 → Advanced Configuration.
2. Keep the company **open** in Tally while syncing.
3. On the Tally PC (or a PC that can reach it), install Python 3.9 or newer and copy `backend/python`.
4. Store the key as a user environment variable (not in the ini): `setx ACCOUNTS_CONNECTOR_API_KEY "<key from step 3.3>"`.
5. `copy config.example.ini config.ini` and set `[tally] url/company`, `[api] apps_script_url` and `[sync] from_date` (the books-begin date).
6. Test: `python -m tally_connector test-connection`, then `python -m tally_connector sync --mode masters`, then `python -m tally_connector sync --mode full`.
7. Automatic sync: Windows **Task Scheduler → Create Task**. Trigger: *At log on*. Action: `python -m tally_connector watch`, starting in the `backend\python` folder. Enable *Restart if the task fails*. `watch` runs an incremental sync every `interval_seconds` and picks up **Sync now** requests from the web app every `poll_seconds`.

See `backend/python/README.md` for all modes and flags.

## User roles
| Role | Typical user |
|---|---|
| Admin | Accounts head / IT |
| Accountant | Accounts executives |
| Finance Manager | Finance manager (approves expenses) |
| Management | Directors (dashboards, reports) |
| Data Entry | Showroom counter (offline sales, expenses) |
| Auditor | Statutory/internal auditor (read-only + audit trail) |

## Security checklist
- [ ] The web app runs as the owner account. Share the Sheet only with admins; users work through the web app.
- [ ] The connector key is set via environment variable on the Tally PC only. Rotate it if the PC changes hands.
- [ ] `config.js` contains only the public `/exec` URL.
- [ ] Remove sample USERS rows you do not use. Every account has a strong password.
- [ ] Only admins can edit the `AUDIT_LOG` sheet (the initializer adds a warning-level protection; tighten it to "Only you" under Data → Protect sheets).

## Backup
- Google Sheets keeps version history (**File → Version history**).
- Monthly: **File → Download → Microsoft Excel** and store the file in a separate Drive folder or offline. A simple time-driven Apps Script using `DriveApp.getFileById(id).makeCopy()` can automate this if required.
- Tally stays the source of truth for Tally vouchers. A **FULL** sync rebuilds them if needed. Offline and manual vouchers exist only in the Sheet, so back it up.

## Troubleshooting
| Symptom | Cause / fix |
|---|---|
| Web app says "unexpected response" | The deployment access is not **Anyone**, or you are using a `/dev` URL. Redeploy and use `/exec`. |
| "Table X is missing" | Run **Initialize / repair database**. |
| "Please sign in again" after a while | Sessions last 6 hours (the Apps Script cache limit). |
| Account locked | Admin: Settings → Users → set status ACTIVE, or set the password again from the menu. |
| "Tally connection unavailable" | Tally is closed, the company is not open, the port is not 9000, or a firewall is blocking it. Check `test-connection`. |
| Sync PARTIAL with rejected vouchers | Tally Integration → Errors. Usually an unbalanced or blank voucher: fix it in Tally and the next sync imports it. |
| Unknown ledger warnings | Vouchers arrived before masters. Run a **MASTERS** sync, then review ledgers flagged *Review*. |
| Balance sheet difference | Check *Difference in opening balances* in the trial balance, and any unbalanced vouchers listed there. |
| Stale Tally data alert | The connector PC is off or the task stopped. Check Task Scheduler and `backend/python/logs`. |
| Slow screens | Very large Sheet. Archive old years to another Sheet, or plan the SQL migration (ARCHITECTURE.md §1). |
| Emails not received | Set `REPORT_RECIPIENTS`. Check the Apps Script quota (100 recipients/day on consumer accounts). |
