/**
 * Repository layer over Google Sheets.
 *
 * This is the ONLY file that touches SpreadsheetApp for business data. Replacing Google Sheets with
 * PostgreSQL/MySQL means re-implementing this interface (read / insert / update / updateWhere /
 * replaceWhere / nextId / dataVersion) in the new backend - services, engine and frontend stay as they are.
 *
 * Performance rules
 *   - Each sheet is read at most once per request (per-execution memo) with a single getValues().
 *   - Writes are batched: one setValues() per table per request.
 *   - Any write bumps DATA_VERSION, which invalidates the API response cache.
 */
var Db = (function () {
  var memo = {};
  var headerMemo = {};
  var SCHEMA_BY_NAME = null;

  function schema(name) {
    if (!SCHEMA_BY_NAME) {
      SCHEMA_BY_NAME = {};
      SCHEMA.tables.forEach(function (t) {
        t.cols = t.columns.map(function (c) { var p = c.split(':'); return { name: p[0], type: p[1] || 'str' }; });
        SCHEMA_BY_NAME[t.name] = t;
      });
    }
    var t = SCHEMA_BY_NAME[name];
    if (!t) throw new AppError('DB_TABLE_UNKNOWN', 'Unknown table ' + name);
    return t;
  }

  function ss() {
    var s = SpreadsheetApp.getActiveSpreadsheet();
    if (!s) throw new AppError('CONFIG', 'This script must be bound to the database spreadsheet (Extensions > Apps Script).');
    return s;
  }

  function sheet(name) {
    var sh = ss().getSheetByName(name);
    if (!sh) throw new AppError('DB_TABLE_MISSING', 'Table ' + name + ' is missing. Run initializeDatabase() from the Accounts Dashboard menu.');
    return sh;
  }

  function headers(name) {
    if (headerMemo[name]) return headerMemo[name];
    var sh = sheet(name);
    var h = sh.getRange(1, 1, 1, Math.max(1, sh.getLastColumn())).getValues()[0].map(String);
    headerMemo[name] = h;
    return h;
  }

  /** All rows as objects (memoised for this execution). Each object carries a hidden _row index. */
  function read(name) {
    if (memo[name]) return memo[name];
    var sh = sheet(name);
    var h = headers(name);
    var last = sh.getLastRow();
    var rows = [];
    if (last > 1) {
      var values = sh.getRange(2, 1, last - 1, h.length).getValues();
      for (var i = 0; i < values.length; i++) {
        var r = values[i];
        if (r.join('') === '') continue;
        var o = {};
        for (var j = 0; j < h.length; j++) o[h[j]] = r[j];
        Object.defineProperty(o, '_row', { value: i + 2, enumerable: false, writable: true });
        rows.push(o);
      }
    }
    memo[name] = rows;
    return rows;
  }

  /** Cheap column read (one column) - used for duplicate checks on large tables. */
  function column(name, col) {
    var h = headers(name), idx = h.indexOf(col);
    if (idx < 0) throw new AppError('DB_COLUMN', 'Column ' + col + ' not in ' + name);
    var sh = sheet(name), last = sh.getLastRow();
    if (last < 2) return [];
    return sh.getRange(2, idx + 1, last - 1, 1).getValues().map(function (r) { return r[0]; });
  }

  // Prevent formula injection: user text starting with = + - @ is stored as literal text.
  function safe(v, type) {
    if (v === null || v === undefined) return '';
    if (Object.prototype.toString.call(v) === '[object Date]') return v;
    if (type === 'date' || type === 'dt') {
      if (v === '') return '';
      var s = String(v);
      var m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?/);
      if (m) return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
      return '';
    }
    if (type === 'cur' || type === 'num' || type === 'pct') {
      if (v === '') return '';
      var n = Number(v);
      return isFinite(n) ? n : '';
    }
    if (type === 'bool') return v === true || v === 'TRUE' || v === 'true' || v === 1 || v === '1';
    if (type === 'json' && typeof v === 'object') v = JSON.stringify(v);
    v = String(v);
    if (v.length > 49000) v = v.slice(0, 49000);
    if (/^[=+\-@]/.test(v)) v = "'" + v;
    return v;
  }

  function toRow(name, obj) {
    var t = schema(name);
    var h = headers(name);
    var types = {};
    t.cols.forEach(function (c) { types[c.name] = c.type; });
    return h.map(function (col) { return safe(obj[col], types[col]); });
  }

  function idColumn(name) {
    var t = schema(name);
    return t.cols[0].type === 'id' ? t.cols[0].name : null;
  }

  /** Allocates sequential IDs (PREFIX-000123). Caller must hold the script lock. */
  function nextIds(name, count) {
    var t = schema(name);
    var prefix = t.idPrefix;
    var width = ['VOUCHER_ENTRIES', 'BILL_REFERENCES', 'SALES_ITEMS', 'PURCHASE_ITEMS', 'AUDIT_LOG', 'TALLY_RAW_DATA', 'GST_TRANSACTIONS', 'CASH_BOOK', 'RECEIVABLES', 'PAYABLES', 'BANK_TRANSACTIONS'].indexOf(name) >= 0 ? 7 : 6;
    var props = PropertiesService.getScriptProperties();
    var keyName = 'SEQ_' + name;
    var cur = Number(props.getProperty(keyName));
    if (!cur) {
      cur = 0;
      var idCol = idColumn(name);
      if (idCol) column(name, idCol).forEach(function (id) {
        var m = String(id).match(/(\d+)$/);
        if (m) cur = Math.max(cur, Number(m[1]));
      });
    }
    var ids = [];
    for (var i = 1; i <= count; i++) {
      var n = String(cur + i);
      while (n.length < width) n = '0' + n;
      ids.push(prefix + '-' + n);
    }
    props.setProperty(keyName, String(cur + count));
    return ids;
  }

  /** Inserts rows (objects). Assigns IDs and created_at/updated_at where the table has them. */
  function insert(name, objs, session) {
    if (!objs || !objs.length) return [];
    var t = schema(name);
    var idCol = idColumn(name);
    var h = headers(name);
    var now = new Date();
    var ids = idCol ? nextIds(name, objs.filter(function (o) { return !o[idCol]; }).length) : [];
    var k = 0;
    objs.forEach(function (o) {
      if (idCol && !o[idCol]) o[idCol] = ids[k++];
      if (h.indexOf('created_at') >= 0 && !o.created_at) o.created_at = now;
      if (h.indexOf('updated_at') >= 0 && !o.updated_at) o.updated_at = now;
      if (h.indexOf('created_by') >= 0 && !o.created_by && session) o.created_by = session.email;
    });
    var sh = sheet(name);
    var values = objs.map(function (o) { return toRow(name, o); });
    sh.getRange(sh.getLastRow() + 1, 1, values.length, h.length).setValues(values);
    if (memo[name]) delete memo[name];
    bump();
    return objs;
  }

  /** Updates one row found by idField=id. Returns { old, row }. */
  function update(name, idField, id, patch, session) {
    var rows = read(name);
    var row = rows.filter(function (r) { return String(r[idField]) === String(id); })[0];
    if (!row) throw new AppError('NOT_FOUND', name + ' record ' + id + ' not found.');
    var old = JSON.parse(JSON.stringify(row));
    Object.keys(patch).forEach(function (k) { row[k] = patch[k]; });
    var h = headers(name);
    if (h.indexOf('updated_at') >= 0) row.updated_at = new Date();
    if (h.indexOf('updated_by') >= 0 && session) row.updated_by = session.email;
    sheet(name).getRange(row._row, 1, 1, h.length).setValues([toRow(name, row)]);
    bump();
    return { old: old, row: row };
  }

  /** Applies patchFn to every row matching pred, writing only the touched row blocks. */
  function updateWhere(name, pred, patchFn) {
    var rows = read(name).filter(pred);
    if (!rows.length) return 0;
    var h = headers(name), sh = sheet(name);
    rows.forEach(function (r) { patchFn(r); if (h.indexOf('updated_at') >= 0) r.updated_at = new Date(); });
    // group contiguous rows into ranges to minimise calls
    rows.sort(function (a, b) { return a._row - b._row; });
    var start = 0;
    for (var i = 1; i <= rows.length; i++) {
      if (i === rows.length || rows[i]._row !== rows[i - 1]._row + 1) {
        var block = rows.slice(start, i);
        sh.getRange(block[0]._row, 1, block.length, h.length).setValues(block.map(function (r) { return toRow(name, r); }));
        start = i;
      }
    }
    bump();
    return rows.length;
  }

  /** Rewrites the table body: rows matching pred are removed and newRows appended. For snapshot tables. */
  function replaceWhere(name, pred, newRows) {
    var keep = read(name).filter(function (r) { return !pred(r); });
    var idCol = idColumn(name);
    var needIds = newRows.filter(function (o) { return idCol && !o[idCol]; }).length;
    var ids = needIds ? nextIds(name, needIds) : [];
    var k = 0, now = new Date(), h = headers(name);
    newRows.forEach(function (o) {
      if (idCol && !o[idCol]) o[idCol] = ids[k++];
      if (h.indexOf('generated_at') >= 0 && !o.generated_at) o.generated_at = now;
      if (h.indexOf('created_at') >= 0 && !o.created_at) o.created_at = now;
    });
    var all = keep.concat(newRows);
    var sh = sheet(name);
    var last = sh.getLastRow();
    if (last > 1) sh.getRange(2, 1, last - 1, h.length).clearContent();
    if (all.length) sh.getRange(2, 1, all.length, h.length).setValues(all.map(function (r) { return toRow(name, r); }));
    delete memo[name];
    bump();
    return all.length;
  }

  function bump() { PropertiesService.getScriptProperties().setProperty('DATA_VERSION', String(Date.now())); }
  function dataVersion() { return PropertiesService.getScriptProperties().getProperty('DATA_VERSION') || '0'; }
  function reset() { memo = {}; headerMemo = {}; }

  /** Runs fn while holding the script lock (all writes go through here). */
  function withLock(fn) {
    var lock = LockService.getScriptLock();
    if (!lock.tryLock(30000)) throw new AppError('LOCK_TIMEOUT', Errors.FRIENDLY.LOCK_TIMEOUT, 503);
    try { reset(); return fn(); } finally { lock.releaseLock(); }
  }

  return {
    schema: schema, ss: ss, sheet: sheet, headers: headers, read: read, column: column,
    insert: insert, update: update, updateWhere: updateWhere, replaceWhere: replaceWhere,
    nextIds: nextIds, withLock: withLock, dataVersion: dataVersion, reset: reset, safe: safe
  };
})();

// ---------------------------------------------------------------------------
// Audit trail (append-only)
// ---------------------------------------------------------------------------
var Audit = {
  log: function (e, session) {
    Audit.logMany([e], session);
  },
  logMany: function (events, session) {
    if (!events.length) return;
    var now = new Date();
    Db.insert('AUDIT_LOG', events.map(function (e) {
      return {
        timestamp: now,
        user: e.user || (session && session.email) || 'system',
        role: e.role || (session && session.role) || '',
        action: e.action, entity: e.entity, record_id: e.record_id || '',
        old_value: e.old_value === undefined || e.old_value === '' ? '' : JSON.stringify(e.old_value),
        new_value: e.new_value === undefined || e.new_value === '' ? '' : JSON.stringify(e.new_value),
        source: e.source || (session && session.role === 'CONNECTOR' ? 'TALLY' : 'WEB'),
        client_info: e.client_info || ''
      };
    }));
  }
};
