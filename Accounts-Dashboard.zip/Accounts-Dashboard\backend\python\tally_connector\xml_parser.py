"""Sanitising, parsing and value helpers for Tally XML.

Tally's XML server output is frequently not well-formed XML:

* it may be UTF-8, UTF-16 (with or without BOM) or Windows-1252;
* it contains character references that are illegal in XML 1.0 (``&#4;`` is
  used as a prefix for reserved names such as ``&#4; Primary``) and raw
  control characters;
* UDF tags use namespace prefixes (``<UDF:SALESMAN.LIST>``) that are not
  always declared;
* amounts, quantities and rates are strings such as ``-1,18,000.00``,
  ``" 2 Nos"`` or ``"50000.00/Nos"``.

This module turns such responses into :class:`xml.etree.ElementTree.Element`
trees and offers small, well-tested helpers to read Tally values.
"""

from __future__ import annotations

import codecs
import re
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Dict, List, Optional, Tuple, Union

ZERO = Decimal("0")
TWO_PLACES = Decimal("0.01")

MASTER_TAGS = {
    "groups": "GROUP",
    "ledgers": "LEDGER",
    "voucher_types": "VOUCHERTYPE",
    "stock_items": "STOCKITEM",
    "cost_centres": "COSTCENTRE",
}


class TallyParseError(ValueError):
    """Raised when a Tally response cannot be turned into an XML tree."""


# ---------------------------------------------------------------------------
# Decoding and sanitising
# ---------------------------------------------------------------------------

_XML_DECL_ENCODING_RE = re.compile(rb"""^\s*<\?xml[^>]*?encoding\s*=\s*["']([A-Za-z0-9._-]+)["']""")
_CHARREF_RE = re.compile(r"&#([xX][0-9a-fA-F]+|[0-9]+);")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")
_XML_DECL_RE = re.compile(r"^\s*<\?xml[^>]*\?>")
# '&' that does not start one of the five XML entities or a character reference.
_BARE_AMP_RE = re.compile(r"&(?!(?:amp|lt|gt|quot|apos|#[0-9]+|#[xX][0-9A-Fa-f]+);)")
_NS_HINT_RE = re.compile(r"<[A-Za-z_][\w.-]*:[A-Za-z_]|\sxmlns[:=]")
_TAG_RE = re.compile(
    r"""<(/?)([A-Za-z_][\w.:-]*)((?:\s+[^\s=<>/"']+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(/?)>"""
)
_XMLNS_ATTR_RE = re.compile(r"""\s+xmlns(?::[\w.-]+)?\s*=\s*(?:"[^"]*"|'[^']*')""")
_PREFIXED_ATTR_RE = re.compile(r"""(\s)([A-Za-z_][\w.-]*):([A-Za-z_][\w.-]*)(\s*=)""")


def decode_tally_bytes(data: bytes) -> str:
    """Decode a Tally HTTP response body, detecting UTF-8/UTF-16/ANSI."""
    if not data:
        return ""
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode("utf-8", errors="replace")
    if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
        return data.decode("utf-16", errors="replace")
    if len(data) >= 2:
        # UTF-16 without BOM: every ASCII character has a zero byte beside it.
        if data[0] == 0 and data[1] != 0:
            return data.decode("utf-16-be", errors="replace")
        if data[0] != 0 and data[1] == 0:
            return data.decode("utf-16-le", errors="replace")
    match = _XML_DECL_ENCODING_RE.match(data[:256])
    if match:
        declared = match.group(1).decode("ascii", "ignore").lower()
        if not declared.startswith(("utf-16", "utf-32")):
            try:
                return data.decode(declared)
            except (LookupError, UnicodeDecodeError):
                pass
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def _is_valid_xml_codepoint(cp: int) -> bool:
    return (
        cp in (0x9, 0xA, 0xD)
        or 0x20 <= cp <= 0xD7FF
        or 0xE000 <= cp <= 0xFFFD
        or 0x10000 <= cp <= 0x10FFFF
    )


def _charref_repl(match: "re.Match[str]") -> str:
    ref = match.group(1)
    try:
        cp = int(ref[1:], 16) if ref[0] in "xX" else int(ref)
    except ValueError:
        return ""
    return match.group(0) if _is_valid_xml_codepoint(cp) else ""


def _fix_tag(match: "re.Match[str]") -> str:
    slash, name, attrs, selfclose = match.group(1), match.group(2), match.group(3) or "", match.group(4)
    name = name.replace(":", "_")
    if attrs:
        attrs = _XMLNS_ATTR_RE.sub("", attrs)
        attrs = _PREFIXED_ATTR_RE.sub(r"\1\2_\3\4", attrs)
    return "<%s%s%s%s>" % (slash, name, attrs, selfclose)


def sanitize_xml(text: str) -> str:
    """Make Tally output parseable by a strict XML parser.

    Removes illegal character references (``&#4;``) and raw control
    characters, the XML declaration (the text is already decoded), escapes
    stray ``&`` characters and flattens namespace prefixes
    (``UDF:SALESMAN`` becomes ``UDF_SALESMAN``) so undeclared prefixes do not
    break parsing.
    """
    if not text:
        return ""
    text = text.lstrip("﻿")
    text = _CHARREF_RE.sub(_charref_repl, text)
    text = _CONTROL_RE.sub("", text)
    text = _XML_DECL_RE.sub("", text, count=1)
    text = _BARE_AMP_RE.sub("&amp;", text)
    if _NS_HINT_RE.search(text):
        text = _TAG_RE.sub(_fix_tag, text)
    start = text.find("<")
    if start > 0:
        text = text[start:]
    return text.strip()


def _snippet(text: str, line: int, col: int) -> str:
    lines = text.splitlines()
    if 1 <= line <= len(lines):
        src = lines[line - 1]
        return src[max(0, col - 60): col + 60]
    return text[:120]


def parse_xml(data: Union[bytes, bytearray, str]) -> ET.Element:
    """Decode, sanitise and parse a Tally response into an Element tree."""
    if isinstance(data, (bytes, bytearray)):
        text = decode_tally_bytes(bytes(data))
    else:
        text = str(data)
    text = sanitize_xml(text)
    if not text:
        raise TallyParseError("Tally returned an empty response.")
    if not text.startswith("<"):
        raise TallyParseError("Tally returned a non-XML response: %r" % text[:200])
    try:
        return ET.fromstring(text)
    except ET.ParseError as exc:
        if "junk after document element" in str(exc):
            try:
                return ET.fromstring("<TALLYRESPONSE>" + text + "</TALLYRESPONSE>")
            except ET.ParseError:
                pass
        line, col = getattr(exc, "position", (0, 0))
        raise TallyParseError(
            "Could not parse Tally XML (line %s, column %s): %s. Near: %r"
            % (line, col, exc, _snippet(text, line, col))
        ) from exc


# ---------------------------------------------------------------------------
# Element access helpers
# ---------------------------------------------------------------------------

def children(el: Optional[ET.Element], tag: str) -> List[ET.Element]:
    """Direct children of ``el`` with the given tag (no XPath parsing)."""
    if el is None:
        return []
    return [c for c in el if c.tag == tag]


def child(el: Optional[ET.Element], tag: str) -> Optional[ET.Element]:
    if el is None:
        return None
    for c in el:
        if c.tag == tag:
            return c
    return None


def text_of(el: Optional[ET.Element], tag: str, default: str = "") -> str:
    """Stripped text of the first direct child ``tag`` of ``el``."""
    c = child(el, tag)
    if c is None or c.text is None:
        return default
    value = c.text.strip()
    return value if value else default


def first_text(el: Optional[ET.Element], *tags: str) -> str:
    """Text of the first of ``tags`` that has a non-empty value."""
    for tag in tags:
        value = text_of(el, tag)
        if value:
            return value
    return ""


def path_text(el: Optional[ET.Element], *path: str) -> str:
    """First non-empty text found by walking ``path`` through all matching children."""
    if el is None or not path:
        return ""
    head, rest = path[0], path[1:]
    for c in children(el, head):
        if not rest:
            value = (c.text or "").strip()
            if value:
                return value
        else:
            value = path_text(c, *rest)
            if value:
                return value
    return ""


def descendant_text(el: Optional[ET.Element], tag: str) -> str:
    """First non-empty text of any descendant with ``tag``."""
    if el is None:
        return ""
    for d in el.iter(tag):
        value = (d.text or "").strip()
        if value:
            return value
    return ""


def list_texts(el: Optional[ET.Element], list_tag: str, item_tag: str) -> List[str]:
    """All non-empty ``item_tag`` texts inside every ``list_tag`` child."""
    out: List[str] = []
    for lst in children(el, list_tag):
        for item in children(lst, item_tag):
            value = (item.text or "").strip()
            if value:
                out.append(value)
    return out


def master_name(el: ET.Element) -> str:
    """Name of a Tally master element (NAME attribute, NAME child or NAME.LIST)."""
    name = (el.get("NAME") or "").strip()
    if name:
        return name
    name = text_of(el, "NAME")
    if name:
        return name
    for name_list in el.iter("NAME.LIST"):
        name = text_of(name_list, "NAME")
        if name:
            return name
    return ""


def clean_parent(value: str) -> str:
    """Tally writes the root parent as '&#4; Primary'; return '' for it."""
    value = (value or "").strip()
    return "" if value.lower() == "primary" else value


def extract_vouchers(root: ET.Element) -> List[ET.Element]:
    """Every VOUCHER element anywhere in the tree (Day Book or Collection export)."""
    if root.tag == "VOUCHER":
        return [root]
    return list(root.iter("VOUCHER"))


def extract_masters(root: ET.Element) -> Dict[str, List[ET.Element]]:
    """Group master elements found anywhere in ``root`` by master kind."""
    out: Dict[str, List[ET.Element]] = {}
    for key, tag in MASTER_TAGS.items():
        out[key] = [e for e in root.iter(tag) if master_name(e)]
    return out


def extract_tally_errors(root: ET.Element) -> List[str]:
    """Error messages embedded in a Tally response (LINEERROR, RESPONSE text, STATUS=0)."""
    messages: List[str] = []
    for tag in ("LINEERROR", "ERRORMSG"):
        for e in root.iter(tag):
            value = " ".join("".join(e.itertext()).split())
            if value and value not in messages:
                messages.append(value)
    if root.tag == "RESPONSE" and not messages:
        value = " ".join("".join(root.itertext()).split())
        if value and re.search(r"unknown|error|cannot|could not|invalid", value, re.I):
            messages.append(value)
    header = child(root, "HEADER")
    if not messages and header is not None and text_of(header, "STATUS") == "0":
        body = child(root, "BODY")
        value = " ".join("".join(body.itertext()).split()) if body is not None else ""
        messages.append(value or "Tally reported STATUS 0 (request failed).")
    return messages


# ---------------------------------------------------------------------------
# Dict <-> Element conversion (lets callers pass plain dicts to the normalizer)
# ---------------------------------------------------------------------------

def element_to_value(el: ET.Element) -> Any:
    """Convert an element to plain Python values.

    Leaf elements without attributes become strings. Otherwise a dict is
    produced: attributes as ``"@NAME"``, text as ``"#text"`` and children by
    tag; repeated tags become lists.
    """
    kids = list(el)
    text = (el.text or "").strip()
    if not kids and not el.attrib:
        return text
    out: Dict[str, Any] = {"@" + k: v for k, v in el.attrib.items()}
    if text:
        out["#text"] = text
    listed = set()
    for c in kids:
        value = element_to_value(c)
        if c.tag in out:
            if c.tag in listed:
                out[c.tag].append(value)
            else:
                out[c.tag] = [out[c.tag], value]
                listed.add(c.tag)
        else:
            out[c.tag] = value
    return out


def value_to_element(tag: str, value: Any) -> ET.Element:
    """Inverse of :func:`element_to_value`."""
    el = ET.Element(tag)
    if isinstance(value, dict):
        for key, sub in value.items():
            if key.startswith("@"):
                el.set(key[1:], "" if sub is None else str(sub))
            elif key == "#text":
                el.text = "" if sub is None else str(sub)
            else:
                items = sub if isinstance(sub, list) else [sub]
                for item in items:
                    el.append(value_to_element(key, item))
    elif value is not None:
        el.text = str(value)
    return el


# ---------------------------------------------------------------------------
# Value helpers
# ---------------------------------------------------------------------------

_DRCR_SUFFIX_RE = re.compile(r"(?<![A-Za-z])(Dr|Cr)\.?\s*$", re.I)
_AMOUNT_NOISE_RE = re.compile(r"(?i)rs\.?|inr|₹|\$|,|\s")
_NUMBER_RE = re.compile(r"[-+]?(?:\d[\d,]*(?:\.\d*)?|\.\d+)")


def parse_amount(value: Any, default: Decimal = ZERO) -> Decimal:
    """Parse a Tally amount string into a Decimal.

    Handles thousands separators (Indian or western), currency symbols,
    ``Dr``/``Cr`` suffixes (Dr is returned negative, following Tally's
    "negative = debit" convention), parentheses for negatives and forex
    strings such as ``"USD 100 @ 83/USD = 8300.00"`` (the base-currency value
    after ``=`` is used). Empty values return ``default``; unparseable values
    raise :class:`ValueError`.
    """
    if value is None:
        return default
    if isinstance(value, bool):
        raise ValueError("Unparseable amount: %r" % (value,))
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("Unparseable amount: %r" % (value,))
        return value
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        return Decimal(repr(value))
    s = str(value).strip()
    if not s:
        return default
    if "=" in s:
        s = s.rsplit("=", 1)[1].strip()
    side = ""
    match = _DRCR_SUFFIX_RE.search(s)
    if match:
        side = match.group(1).lower()
        s = s[: match.start()].strip()
    negative = False
    if s.startswith("(") and s.endswith(")"):
        negative = True
        s = s[1:-1]
    s = _AMOUNT_NOISE_RE.sub("", s)
    if not s:
        if side:
            raise ValueError("Unparseable amount: %r" % (value,))
        return default
    try:
        result = Decimal(s)
    except InvalidOperation:
        raise ValueError("Unparseable amount: %r" % (value,)) from None
    if not result.is_finite():
        raise ValueError("Unparseable amount: %r" % (value,))
    if negative:
        result = -abs(result)
    if side == "dr":
        result = -abs(result)
    elif side == "cr":
        result = abs(result)
    return result


def round2(value: Decimal) -> Decimal:
    """Round half-up to 2 decimal places."""
    return Decimal(value).quantize(TWO_PLACES, rounding=ROUND_HALF_UP)


def money(value: Decimal) -> float:
    """Decimal -> float rounded to 2 dp (for JSON payloads)."""
    return float(round2(value))


def _first_number(s: str) -> Optional[Decimal]:
    match = _NUMBER_RE.search(s or "")
    if not match:
        return None
    try:
        return Decimal(match.group(0).replace(",", ""))
    except InvalidOperation:
        return None


def parse_quantity(value: Any) -> Tuple[Decimal, str]:
    """Parse ``" 2 Nos"`` / ``"2.000 Pairs"`` / ``"2 Nos = 24 Pcs"`` into (qty, uom)."""
    s = str(value or "").strip()
    if not s:
        return ZERO, ""
    if "=" in s:
        s = s.split("=", 1)[0].strip()
    match = _NUMBER_RE.search(s)
    if not match:
        return ZERO, ""
    try:
        qty = Decimal(match.group(0).replace(",", ""))
    except InvalidOperation:
        return ZERO, ""
    rest = s[match.end():].strip()
    uom = rest.split()[0] if rest else ""
    return qty, uom


def parse_rate(value: Any) -> Tuple[Decimal, str]:
    """Parse ``"50000.00/Nos"`` into (Decimal('50000.00'), 'Nos')."""
    s = str(value or "").strip()
    if not s:
        return ZERO, ""
    uom = ""
    if "/" in s:
        s, uom = s.rsplit("/", 1)
        uom = uom.strip()
    if "=" in s:
        s = s.rsplit("=", 1)[1]
    rate = _first_number(s)
    return (rate if rate is not None else ZERO), uom


def parse_percent(value: Any) -> Decimal:
    """Parse ``"10"``, ``" 10 %"`` into Decimal('10')."""
    number = _first_number(str(value or ""))
    return abs(number) if number is not None else ZERO


def parse_bool(value: Any) -> bool:
    return str(value or "").strip().lower() in ("yes", "true", "1", "y")


def parse_int(value: Any, default: int = 0) -> int:
    s = str(value if value is not None else "").strip().replace(",", "")
    if not s:
        return default
    try:
        return int(Decimal(s))
    except (InvalidOperation, ValueError):
        return default


_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}
_DATE_YMD_COMPACT = re.compile(r"^(\d{4})(\d{2})(\d{2})$")
_DATE_ISO = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ].*)?$")
_DATE_DMY = re.compile(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$")
_DATE_D_MON_Y = re.compile(r"^(\d{1,2})[-\s]([A-Za-z]{3,9})[-\s,]*(\d{2}|\d{4})$")


def parse_tally_date(value: Any) -> str:
    """Parse a Tally date into ``YYYY-MM-DD``; returns '' when missing/invalid.

    Accepts ``20260901``, ``2026-09-01``, ``01-09-2026`` / ``01/09/2026``
    (day first, Indian convention), ``1-Sep-2026`` and ``1-Sep-26``.
    """
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    s = str(value).strip()
    if not s:
        return ""
    y = m = d = 0
    match = _DATE_YMD_COMPACT.match(s)
    if match:
        y, m, d = int(match.group(1)), int(match.group(2)), int(match.group(3))
    else:
        match = _DATE_ISO.match(s)
        if match:
            y, m, d = int(match.group(1)), int(match.group(2)), int(match.group(3))
        else:
            match = _DATE_DMY.match(s)
            if match:
                d, m, y = int(match.group(1)), int(match.group(2)), int(match.group(3))
            else:
                match = _DATE_D_MON_Y.match(s)
                if not match:
                    return ""
                month = _MONTHS.get(match.group(2).lower()[:4]) or _MONTHS.get(match.group(2).lower()[:3])
                if not month:
                    return ""
                d, m, y = int(match.group(1)), month, int(match.group(3))
                if y < 100:
                    y += 2000
    try:
        return date(y, m, d).isoformat()
    except ValueError:
        return ""


def to_date(value: Any) -> Optional[date]:
    iso = parse_tally_date(value)
    return date.fromisoformat(iso) if iso else None


def format_tally_date(value: Any) -> str:
    """Date / ISO string -> ``YYYYMMDD`` as Tally expects in requests."""
    d = to_date(value)
    if d is None:
        raise ValueError("Invalid date: %r" % (value,))
    return d.strftime("%Y%m%d")


def add_days(iso_date: str, days: int) -> str:
    d = to_date(iso_date)
    if d is None:
        return ""
    return (d + timedelta(days=int(days))).isoformat()


_CREDIT_DAYS_RE = re.compile(r"^(\d{1,4})\s*(?:days?)?\.?$", re.I)
_CREDIT_DAYS_LOOSE_RE = re.compile(r"(\d{1,4})\s*days?\b", re.I)


def parse_credit_period(value: Any, base_date: str = "") -> Tuple[Optional[int], str]:
    """Parse a BILLCREDITPERIOD element or string.

    Returns ``(credit_days, explicit_due_date)``. Tally writes either a number
    of days (``<BILLCREDITPERIOD JD="46295" P="30 Days">30 Days</...>``,
    ``"30 Days"``, ``"30"``) or an explicit due date (``"15-Oct-2026"``). For
    an explicit date the days are computed against ``base_date`` when given.
    """
    texts: List[str] = []
    if ET.iselement(value):
        texts.append(value.get("P") or "")
        texts.append(value.text or "")
    else:
        texts.append(str(value or ""))
    for raw in texts:
        s = raw.strip()
        if not s:
            continue
        match = _CREDIT_DAYS_RE.match(s)
        if match:
            return int(match.group(1)), ""
        due = parse_tally_date(s)
        if due:
            base = to_date(base_date) if base_date else None
            days = (date.fromisoformat(due) - base).days if base else None
            return days, due
        match = _CREDIT_DAYS_LOOSE_RE.search(s)
        if match:
            return int(match.group(1)), ""
    return None, ""
