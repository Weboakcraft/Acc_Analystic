/**
 * Business services: thin adapters between the API and the accounting engine.
 * Reads build an engine context from the posting tables; writes post balanced vouchers.
 */

// ---------------------------------------------------------------------------
// Settings & config (code defaults, overridden by SETTINGS / CONFIG rows)
// ---------------------------------------------------------------------------
var Settings = {
  all: function () {
    var o = {};
    Db.read('SETTINGS').forEach(function (r) { if (r.setting_key) o[String(r.setting_key)] = r.setting_value; });
    return o;
  },
  effective: function () {
    return Engine.util.mergeSettings(Settings.all());
  }
};

var Config = {
  all: function () {
    var o = {};
    Db.read('CONFIG').forEach(function (r) { if (r.config_key) o[String(r.config_key)] = r.config_value; });
    return o;
  },
  get: function (k, def) { var v = Config.all()[k]; return v === undefined || v === '' ? def : v; }
};

function today_() { return Engine.util.D(new Date()); }

// ---------------------------------------------------------------------------
// Engine context
// ---------------------------------------------------------------------------
var Ctx = {
  company: function (p) {
    var list = Db.read('COMPANIES').filter(function (c) { return c.is_active !== false; });
    if (!list.length) throw new AppError('CONFIG', 'No company configured. Add a row to COMPANIES.');
    if (p && p.company_id) {
      var c = list.filter(function (x) { return x.company_id === p.company_id; })[0];
      if (!c) throw new AppError('NOT_FOUND', 'Company ' + p.company_id + ' not found.');
      return c;
    }
    return list[0];
  },
  load: function (p) {
    var company = Ctx.company(p);
    var cid = company.company_id;
    var mine = function (r) { return !r.company_id || r.company_id === cid; };
    var db = {
      company: company, today: today_(),
      vouchers: Db.read('VOUCHERS').filter(mine),
      entries: Db.read('VOUCHER_ENTRIES'),
      bills: Db.read('BILL_REFERENCES'),
      ledgers: Db.read('LEDGERS').filter(mine),
      groups: Db.read('GROUPS'),
      voucherTypes: Db.read('VOUCHER_TYPES'),
      inventory: Db.read('INVENTORY'),
      salesItems: Db.read('SALES_ITEMS'),
      purchaseItems: Db.read('PURCHASE_ITEMS'),
      customers: Db.read('CUSTOMERS'),
      vendors: Db.read('VENDORS'),
      products: Db.read('PRODUCTS')
    };
    return Engine.createContext(db, Settings.all());
  }
};

// ---------------------------------------------------------------------------
// Paging / filtering helpers (server-side so the browser never receives thousands of rows)
// ---------------------------------------------------------------------------
var Paging = {
  apply: function (rows, p) {
    p = p || {};
    if (p.q) {
      var q = String(p.q).toLowerCase();
      rows = rows.filter(function (r) { return Object.keys(r).some(function (k) { var v = r[k]; return v !== null && typeof v !== 'object' && String(v).toLowerCase().indexOf(q) >= 0; }); });
    }
    if (p.sort) {
      var dir = p.dir === 'desc' ? -1 : 1, s = p.sort;
      rows = rows.slice().sort(function (a, b) { var x = a[s], y = b[s]; return (x < y ? -1 : x > y ? 1 : 0) * dir; });
    }
    var size = Math.min(Math.max(Number(p.pageSize) || 50, 1), 1000);
    var page = Math.max(Number(p.page) || 1, 1);
    return { rows: rows.slice((page - 1) * size, page * size), total: rows.length, page: page, pageSize: size, pages: Math.max(1, Math.ceil(rows.length / size)) };
  },
  period: function (p) {
    if (p.preset) {
      var r = Engine.util.periodRange(p.preset, today_(), Settings.effective().FY_START_MONTH);
      return { from: r.from, to: r.to };
    }
    return { from: Engine.util.D(p.from), to: Engine.util.D(p.to) };
  }
};

function withPeriod_(p) { var r = Paging.period(p); var o = {}; Object.keys(p).forEach(function (k) { o[k] = p[k]; }); if (r.from) o.from = r.from; if (r.to) o.to = r.to; return o; }
function plain_(rows) { return rows.map(function (r) { var o = {}; Object.keys(r).forEach(function (k) { var v = r[k]; o[k] = Object.prototype.toString.call(v) === '[object Date]' ? Engine.util.D(v) + (v.getHours() || v.getMinutes() ? ' ' + ('0' + v.getHours()).slice(-2) + ':' + ('0' + v.getMinutes()).slice(-2) : '') : v; }); return o; }); }

// ---------------------------------------------------------------------------
// Posting (the only way vouchers are written from the web app)
// ---------------------------------------------------------------------------
var Post = {
  /** built: [{header, lines, bills}] from the engine builders. Returns inserted voucher headers. */
  vouchers: function (built, session, companyId) {
    var existing = {};
    Db.column('VOUCHERS', 'unique_key').forEach(function (k) { existing[String(k)] = true; });
    built.forEach(function (b) {
      if (b.header.unique_key && existing[b.header.unique_key]) {
        throw new AppError('DUPLICATE_VOUCHER', 'Duplicate voucher detected: ' + b.header.voucher_type + ' ' + b.header.voucher_number + ' already exists.');
      }
      var check = Engine.validateVoucher(b.header, b.lines);
      if (!check.valid) throw new AppError('UNBALANCED', check.errors.join(' '));
    });
    var ids = Db.nextIds('VOUCHERS', built.length);
    var headers = [], lines = [], bills = [];
    built.forEach(function (b, i) {
      var h = b.header;
      h.voucher_id = ids[i]; h.company_id = companyId; h.revision = 1;
      h.status = h.status || 'ACTIVE'; h.created_by = session.email; h.updated_by = session.email;
      headers.push(h);
      b.lines.forEach(function (l) { l.voucher_id = h.voucher_id; l.revision = 1; lines.push(l); });
      (b.bills || []).forEach(function (x) { x.voucher_id = h.voucher_id; x.revision = 1; bills.push(x); });
    });
    Db.insert('VOUCHERS', headers, session);
    Db.insert('VOUCHER_ENTRIES', lines, session);
    Db.insert('BILL_REFERENCES', bills, session);
    return headers;
  },

  ledgers: function (newLedgers, session, companyId) {
    if (!newLedgers || !newLedgers.length) return [];
    var known = {};
    Db.read('LEDGERS').forEach(function (l) { known[String(l.ledger_name).toLowerCase()] = true; });
    var fresh = newLedgers.filter(function (l) { return !known[String(l.ledger_name).toLowerCase()]; });
    fresh.forEach(function (l) { l.company_id = companyId; });
    Db.insert('LEDGERS', fresh, session);
    // Party ledgers get a profile row automatically (customer / vendor master)
    var cust = fresh.filter(function (l) { return l.parent_group === 'Sundry Debtors'; }).map(function (l) {
      return { ledger_id: l.ledger_id, customer_name: l.ledger_name, gstin: l.gstin || '', mobile: l.mobile || '', billing_address: l.address || '', state: l.state || '', credit_days: l.credit_days || '', status: 'ACTIVE', source: 'OFFLINE', customer_since: today_() };
    });
    var vend = fresh.filter(function (l) { return l.parent_group === 'Sundry Creditors'; }).map(function (l) {
      return { ledger_id: l.ledger_id, vendor_name: l.ledger_name, gstin: l.gstin || '', state: l.state || '', credit_days: l.credit_days || '', status: 'ACTIVE', source: 'MANUAL', msme_registered: false };
    });
    Db.insert('CUSTOMERS', cust, session);
    Db.insert('VENDORS', vend, session);
    Audit.logMany(fresh.map(function (l) { return { action: 'CREATE', entity: 'LEDGERS', record_id: l.ledger_id, new_value: { ledger_name: l.ledger_name, parent_group: l.parent_group, source: l.source } }; }), session);
    return fresh;
  },

  ledgerNames: function () { return Db.read('LEDGERS').map(function (l) { return String(l.ledger_name); }); },

  /** FY-wise running document number, e.g. OFF/2627/0001. */
  nextNumber: function (series, date) {
    var S = Settings.effective();
    var fs = Engine.util.fyStart(date || today_(), S.FY_START_MONTH);
    var fyTag = fs.slice(2, 4) + String(Number(fs.slice(2, 4)) + 1).slice(-2);
    var props = PropertiesService.getScriptProperties();
    var k = 'DOCSEQ_' + series + '_' + fyTag;
    var n = (Number(props.getProperty(k)) || 0) + 1;
    props.setProperty(k, String(n));
    return series + '/' + fyTag + '/' + ('000' + n).slice(-4);
  }
};

// ---------------------------------------------------------------------------
// Read services
// ---------------------------------------------------------------------------
var Svc = {
  health: function () {
    return { status: 'ok', version: APP_VERSION, engine: Engine.VERSION, schema: SCHEMA.version, time: new Date().toISOString() };
  },

  getDashboard: function (p) {
    var ctx = Ctx.load(p);
    var d = Engine.dashboard(ctx, { date: p.date });
    var lastSync = Db.read('TALLY_SYNC_LOG').filter(function (r) { return r.status === 'SUCCESS' || r.status === 'PARTIAL'; }).sort(function (a, b) { return b.end_time - a.end_time; })[0];
    d.lastSync = lastSync ? plain_([lastSync])[0] : null;
    d.openAlerts = Db.read('NOTIFICATIONS').filter(function (n) { return n.status === 'OPEN'; }).length;
    d.company = ctx.company.company_name;
    return d;
  },
  getManagementDashboard: function (p) { return Engine.managementDashboard(Ctx.load(p), { date: p.date }); },

  getSales: function (p) {
    p = withPeriod_(p);
    var reg = Engine.register(Ctx.load(p), { kind: 'sales', from: p.from, to: p.to, party: p.customer, status: p.status, source: p.source, salesperson: p.salesperson });
    var paged = Paging.apply(reg.rows, p);
    paged.totals = reg.totals; paged.from = reg.from; paged.to = reg.to;
    return paged;
  },
  getSalesReport: function (p) { p = withPeriod_(p); return Engine.salesReport(Ctx.load(p), { kind: 'sales', groupBy: p.groupBy, from: p.from, to: p.to }); },
  getPurchases: function (p) {
    p = withPeriod_(p);
    var reg = Engine.register(Ctx.load(p), { kind: 'purchase', from: p.from, to: p.to, party: p.vendor, status: p.status, source: p.source });
    var paged = Paging.apply(reg.rows, p);
    paged.totals = reg.totals; paged.from = reg.from; paged.to = reg.to;
    return paged;
  },
  getPurchaseReport: function (p) { p = withPeriod_(p); return Engine.salesReport(Ctx.load(p), { kind: 'purchase', groupBy: p.groupBy === 'customer' ? 'vendor' : p.groupBy, from: p.from, to: p.to }); },

  getLedgers: function (p) {
    p = withPeriod_(p);
    var ctx = Ctx.load(p);
    var tb = Engine.trialBalance(ctx, { from: p.from, to: p.to, includeZero: true });
    var masters = {};
    Db.read('LEDGERS').forEach(function (l) { masters[String(l.ledger_name).toLowerCase()] = l; });
    var rows = tb.rows.map(function (r) {
      var m = masters[r.ledger.toLowerCase()] || {};
      return { ledger: r.ledger, group: r.group, primary: r.primary, nature: r.nature, ledger_type: m.ledger_type || '', gstin: m.gstin || '', source: m.source || '', needs_review: m.needs_review === true,
        opening: Engine.util.r2(r.openingDr - r.openingCr), debit: r.periodDr, credit: r.periodCr, closing: Engine.util.r2(r.closingDr - r.closingCr) };
    });
    if (p.group) rows = rows.filter(function (r) { return r.group === p.group || r.primary === p.group; });
    return Paging.apply(rows, p);
  },
  getLedgerStatement: function (p) { p = withPeriod_(p); Validate.required(p, ['ledger']); return Engine.ledgerStatement(Ctx.load(p), p); },

  getCustomers: function (p) { return Svc.partyList_('customer', withPeriod_(p)); },
  getVendors: function (p) { return Svc.partyList_('vendor', withPeriod_(p)); },
  partyList_: function (kind, p) {
    var ctx = Ctx.load(p);
    var acc = Engine.partyAccounts(ctx, { kind: kind, from: p.from, to: p.to });
    var profiles = {};
    Db.read(kind === 'customer' ? 'CUSTOMERS' : 'VENDORS').forEach(function (r) { profiles[String(r.customer_name || r.vendor_name).toLowerCase()] = r; });
    var seen = {};
    var rows = acc.rows.map(function (r) {
      var pr = profiles[r.party.toLowerCase()] || {};
      seen[r.party.toLowerCase()] = true;
      return Svc.mergeProfile_(r, pr, kind);
    });
    Object.keys(profiles).forEach(function (k) {
      if (seen[k]) return;
      var pr = profiles[k];
      rows.push(Svc.mergeProfile_({ party: pr.customer_name || pr.vendor_name, opening: 0, invoices: 0, notes: 0, settlements: 0, adjustments: 0, closing: 0, outstanding_bills: 0, overdue_bills: 0, overdue_amount: 0 }, pr, kind));
    });
    var paged = Paging.apply(rows, p);
    paged.totals = acc.totals; paged.labels = acc.labels; paged.from = acc.from; paged.to = acc.to;
    return paged;
  },
  mergeProfile_: function (r, pr, kind) {
    r.profile_id = pr.customer_id || pr.vendor_id || '';
    r.gstin = r.gstin || pr.gstin || '';
    r.mobile = pr.mobile || ''; r.email = pr.email || ''; r.city = pr.city || ''; r.state = pr.state || '';
    r.credit_days = pr.credit_days || ''; r.status = pr.status || 'ACTIVE';
    if (kind === 'customer') { r.credit_limit = pr.credit_limit || ''; r.salesperson = pr.salesperson || ''; r.over_limit = pr.credit_limit ? r.closing > Number(pr.credit_limit) : false; }
    else { r.msme = pr.msme_registered === true; r.category = pr.vendor_category || ''; }
    delete r.ageing;
    return r;
  },

  getReceivables: function (p) { return Svc.outstanding_('receivable', p); },
  getPayables: function (p) { return Svc.outstanding_('payable', p); },
  getAgeing: function (p) { return Svc.outstanding_(p.kind === 'payable' ? 'payable' : 'receivable', p); },
  outstanding_: function (kind, p) {
    var o = Engine.outstanding(Ctx.load(p), { kind: kind, asOf: p.asOf });
    var bills = o.bills;
    if (p.party) bills = bills.filter(function (b) { return b.party.toLowerCase() === String(p.party).toLowerCase(); });
    if (p.status) bills = bills.filter(function (b) { return b.status === p.status; });
    if (p.bucket) bills = bills.filter(function (b) { return b.ageing_bucket === p.bucket; });
    o.bills = Paging.apply(bills, p);
    return o;
  },
  getPartyAccounts: function (p) { p = withPeriod_(p); return Engine.partyAccounts(Ctx.load(p), { kind: p.kind, from: p.from, to: p.to }); },

  getReceipts: function (p) { p = withPeriod_(p); var r = Engine.cashRegister(Ctx.load(p), { kind: 'receipt', from: p.from, to: p.to, party: p.party }); var pg = Paging.apply(r.rows, p); pg.total_amount = r.total; return pg; },
  getPayments: function (p) { p = withPeriod_(p); var r = Engine.cashRegister(Ctx.load(p), { kind: 'payment', from: p.from, to: p.to, party: p.party }); var pg = Paging.apply(r.rows, p); pg.total_amount = r.total; return pg; },

  getExpenses: function (p) {
    p = withPeriod_(p);
    var rows = plain_(Db.read('EXPENSES')).filter(function (e) {
      return (!p.from || e.expense_date >= p.from) && (!p.to || e.expense_date <= p.to) &&
        (!p.status || e.approval_status === p.status) && (!p.category || e.category === p.category);
    });
    rows.sort(function (a, b) { return a.expense_date < b.expense_date ? 1 : -1; });
    var byCat = {}, byMonth = {};
    rows.filter(function (e) { return e.approval_status !== 'Rejected'; }).forEach(function (e) {
      byCat[e.category] = Engine.util.r2((byCat[e.category] || 0) + Number(e.total_amount || 0));
      var m = String(e.expense_date).slice(0, 7);
      byMonth[m] = Engine.util.r2((byMonth[m] || 0) + Number(e.total_amount || 0));
    });
    var paged = Paging.apply(rows, p);
    paged.byCategory = Object.keys(byCat).map(function (k) { return { category: k, amount: byCat[k] }; }).sort(function (a, b) { return b.amount - a.amount; });
    paged.byMonth = Object.keys(byMonth).sort().map(function (k) { return { month: k, amount: byMonth[k] }; });
    paged.pending = rows.filter(function (e) { return e.approval_status === 'Pending'; }).length;
    return paged;
  },

  getVoucher: function (p) {
    Validate.required(p, ['voucher_id']);
    var h = Db.read('VOUCHERS').filter(function (v) { return v.voucher_id === p.voucher_id; })[0];
    if (!h) throw new AppError('NOT_FOUND', 'Voucher not found.');
    var rev = Number(h.revision) || 1;
    var mine = function (r) { return r.voucher_id === h.voucher_id && (Number(r.revision) || 1) === rev; };
    var lines = plain_(Db.read('VOUCHER_ENTRIES').filter(mine)).sort(function (a, b) { return a.line_no - b.line_no; });
    var dr = Engine.util.r2(lines.reduce(function (s, l) { return s + (Number(l.debit) || 0); }, 0));
    var cr = Engine.util.r2(lines.reduce(function (s, l) { return s + (Number(l.credit) || 0); }, 0));
    return {
      header: plain_([h])[0], lines: lines, bills: plain_(Db.read('BILL_REFERENCES').filter(mine)),
      items: plain_(Db.read('SALES_ITEMS').filter(mine).concat(Db.read('PURCHASE_ITEMS').filter(mine))),
      totalDebit: dr, totalCredit: cr, balanced: Math.abs(dr - cr) < 0.01
    };
  },

  getInventory: function (p) {
    var ctx = Ctx.load(p), asOf = Engine.util.D(p.asOf) || ctx.today;
    var sold = {};
    Engine.salesReport(ctx, { groupBy: 'product', from: Engine.util.fyStart(asOf, ctx.fyM), to: asOf }).rows.forEach(function (r) { sold[r.key] = r; });
    return {
      asOf: asOf, stockValue: Engine.stockAt(ctx, asOf), source: ctx.S.STOCK_VALUATION_SOURCE,
      valuations: plain_(Db.read('INVENTORY')).filter(function (r) { return r.as_of_date <= asOf; }).sort(function (a, b) { return a.as_of_date < b.as_of_date ? 1 : -1; }).slice(0, 200),
      products: Db.read('PRODUCTS').map(function (x) { var s = sold[x.product_name] || {}; return { product: x.product_name, hsn_sac: x.hsn_sac, uom: x.uom, gst_rate: x.gst_rate, sale_rate: x.sale_rate, purchase_rate: x.purchase_rate, qty_sold: s.quantity || 0, revenue: s.taxable || 0, avg_price: s.avg_price || 0 }; })
    };
  },

  getCashBook: function (p) { p = withPeriod_(p); var cb = Engine.cashBook(Ctx.load(p), p); var rows = cb.rows; cb.rows = Paging.apply(rows.slice().reverse(), p); return cb; },

  getBankTransactions: function (p) {
    var rows = plain_(Db.read('BANK_TRANSACTIONS')).filter(function (t) { return (!p.bank_account_id || t.bank_account_id === p.bank_account_id) && (!p.status || t.reconciliation_status === p.status); });
    rows.sort(function (a, b) { return a.txn_date < b.txn_date ? 1 : -1; });
    var out = Paging.apply(rows, p);
    out.accounts = plain_(Db.read('BANK_ACCOUNTS'));
    out.summary = Bank.summary(p.bank_account_id);
    return out;
  },

  getGSTSummary: function (p) { p = withPeriod_(p); var g = Engine.gstSummary(Ctx.load(p), p); g.transactions = Paging.apply(g.transactions, p); return g; },
  getTrialBalance: function (p) { p = withPeriod_(p); return Engine.trialBalance(Ctx.load(p), p); },
  getProfitLoss: function (p) {
    p = withPeriod_(p);
    var ctx = Ctx.load(p);
    var pl = Engine.profitLoss(ctx, p);
    if (p.comparative) pl.comparative = Engine.profitLossComparative(ctx, { asOf: p.to });
    else pl.trend = Engine.monthlyTrend(ctx, { from: pl.from, to: pl.to });
    return pl;
  },
  getBalanceSheet: function (p) { return Engine.balanceSheet(Ctx.load(p), { asOf: p.asOf || Paging.period(p).to }); },
  getCashFlow: function (p) { p = withPeriod_(p); return Engine.cashFlow(Ctx.load(p), p); },
  getFinancialHealth: function (p) { p = withPeriod_(p); return Engine.financialHealth(Ctx.load(p), p); },
  getAnalytics: function (p) { p = withPeriod_(p); return Engine.analytics(Ctx.load(p), p); },

  getAlerts: function (p) {
    var live = Engine.alerts(Ctx.load(p), { date: p.date });
    var stored = {};
    Db.read('NOTIFICATIONS').forEach(function (n) { stored[n.dedupe_key] = n; });
    live.forEach(function (a) { var s = stored[a.dedupe_key]; a.status = s ? s.status : 'OPEN'; a.notification_id = s ? s.notification_id : ''; });
    var sys = plain_(Db.read('NOTIFICATIONS')).filter(function (n) { return n.status !== 'RESOLVED' && ['SYNC_FAILED', 'UNRECONCILED_BANK'].indexOf(n.category) >= 0; });
    var all = live.filter(function (a) { return a.status !== 'RESOLVED'; }).concat(sys);
    var rank = { CRITICAL: 0, WARNING: 1, INFO: 2 };
    all.sort(function (a, b) { return rank[a.severity] - rank[b.severity]; });
    return { alerts: all, counts: { critical: all.filter(function (a) { return a.severity === 'CRITICAL'; }).length, warning: all.filter(function (a) { return a.severity === 'WARNING'; }).length } };
  },

  searchTransactions: function (p) {
    Validate.required(p, ['q']);
    return Engine.search(Ctx.load(p), { q: Validate.text(p.q, 100) });
  },

  getAuditLog: function (p) {
    p = withPeriod_(p);
    var rows = plain_(Db.read('AUDIT_LOG')).filter(function (a) {
      var d = String(a.timestamp).slice(0, 10);
      return (!p.from || d >= p.from) && (!p.to || d <= p.to) && (!p.entity || a.entity === p.entity) &&
        (!p.action_type || a.action === p.action_type) && (!p.user || String(a.user).toLowerCase().indexOf(String(p.user).toLowerCase()) >= 0) &&
        (!p.record_id || a.record_id === p.record_id);
    }).reverse();
    return Paging.apply(rows, p);
  },

  getLookups: function (p) {
    var ctx = Ctx.load(p);
    var names = function (pred) { return Object.keys(ctx.allLedgerNames).map(function (k) { return ctx.allLedgerNames[k]; }).filter(function (n) { return pred(ctx.ledgerInfo(n)); }).sort(); };
    var S = ctx.S;
    return {
      customers: names(function (i) { return i.isDebtor; }),
      vendors: names(function (i) { return i.isCreditor; }),
      cashBank: names(function (i) { return i.isCashEq; }),
      expenseLedgers: names(function (i) { return i.nature === 'Expenses' && i.primary !== 'Purchase Accounts'; }),
      allLedgers: names(function () { return true; }),
      groups: Object.keys(Engine.RESERVED_GROUPS).concat(Db.read('GROUPS').map(function (g) { return g.group_name; })).sort(),
      products: Db.read('PRODUCTS').map(function (x) { return { name: x.product_name, hsn: x.hsn_sac, uom: x.uom, rate: x.sale_rate, gst: x.gst_rate }; }),
      salespersons: Object.keys(ctx.vouchers.reduce(function (o, v) { if (v.salesperson) o[v.salesperson] = 1; return o; }, {})).sort(),
      costCentres: Db.read('COST_CENTRES').map(function (c) { return c.cost_centre_name; }),
      bankAccounts: plain_(Db.read('BANK_ACCOUNTS')),
      paymentModeLedgers: JSON.parse(S.PAYMENT_MODE_LEDGERS),
      companyState: S.COMPANY_STATE, fyStartMonth: S.FY_START_MONTH,
      expenseCategories: SCHEMA.tables.filter(function (t) { return t.name === 'EXPENSES'; })[0].enums.category
    };
  },

  getSettings: function () {
    var s = Settings.all(), eff = Settings.effective();
    return {
      settings: Object.keys(Engine.DEFAULT_SETTINGS).map(function (k) { return { key: k, value: eff[k], default: Engine.DEFAULT_SETTINGS[k], overridden: s[k] !== undefined && s[k] !== '' }; }),
      config: plain_(Db.read('CONFIG')),
      connectorKeyConfigured: !!PropertiesService.getScriptProperties().getProperty('CONNECTOR_API_KEY')
    };
  },

  // ---- Writes -------------------------------------------------------------
  updateSetting: function (p, session) {
    Validate.required(p, ['key']);
    if (!(p.key in Engine.DEFAULT_SETTINGS)) throw new AppError('VALIDATION', 'Unknown setting ' + p.key + '.');
    var val = Validate.text(p.value, 2000);
    if (p.key === 'PAYMENT_MODE_LEDGERS') { try { JSON.parse(val); } catch (e) { throw new AppError('VALIDATION', 'PAYMENT_MODE_LEDGERS must be valid JSON.'); } }
    var row = Db.read('SETTINGS').filter(function (r) { return r.setting_key === p.key; })[0];
    var type = typeof Engine.DEFAULT_SETTINGS[p.key];
    if (row) {
      var res = Db.update('SETTINGS', 'setting_key', p.key, { setting_value: val, updated_by: session.email, updated_at: new Date() });
      Audit.log({ action: 'CONFIG', entity: 'SETTINGS', record_id: p.key, old_value: res.old.setting_value, new_value: val }, session);
    } else {
      Db.insert('SETTINGS', [{ setting_key: p.key, setting_value: val, data_type: type === 'object' ? 'json' : type, description: 'Set from web app', updated_by: session.email, updated_at: new Date() }]);
      Audit.log({ action: 'CONFIG', entity: 'SETTINGS', record_id: p.key, new_value: val }, session);
    }
    return { key: p.key, value: val };
  },

  updateConfig: function (p, session) {
    Validate.required(p, ['key']);
    if (/KEY|SECRET|PASSWORD|TOKEN/i.test(p.key)) throw new AppError('VALIDATION', 'Secrets cannot be stored in CONFIG. Use Script Properties.');
    var val = Validate.text(p.value, 1000);
    var row = Db.read('CONFIG').filter(function (r) { return r.config_key === p.key; })[0];
    if (row) {
      var res = Db.update('CONFIG', 'config_key', p.key, { config_value: val, updated_by: session.email, updated_at: new Date() });
      Audit.log({ action: 'CONFIG', entity: 'CONFIG', record_id: p.key, old_value: res.old.config_value, new_value: val }, session);
    } else {
      Db.insert('CONFIG', [{ config_key: p.key, config_value: val, category: p.category || 'APP', description: p.description || '', updated_by: session.email, updated_at: new Date() }]);
      Audit.log({ action: 'CONFIG', entity: 'CONFIG', record_id: p.key, new_value: val }, session);
    }
    return { key: p.key, value: val };
  },

  saveOfflineSale: function (p, session) {
    var company = Ctx.company(p);
    var S = Settings.all();
    p.invoice_date = Validate.date(p.invoice_date || today_(), 'Invoice date');
    if (!p.invoice_no) p.invoice_no = Post.nextNumber(Config.get('OFFLINE_INVOICE_SERIES', 'OFF'), p.invoice_date);
    p.invoice_no = Validate.text(p.invoice_no, 40);
    if (p.mobile) p.mobile = Validate.mobile(p.mobile);
    p.customer_gstin = Validate.gstin(p.customer_gstin);
    if (!S.COMPANY_STATE && company.state) S.COMPANY_STATE = company.state;
    var dupInv = Db.read('OFFLINE_SALES').some(function (r) { return String(r.invoice_no).toLowerCase() === String(p.invoice_no).toLowerCase() && r.status !== 'CANCELLED'; });
    if (dupInv) throw new AppError('DUPLICATE_VOUCHER', 'Offline invoice ' + p.invoice_no + ' already exists.');
    var built = Engine.buildOfflineSale(p, S, Post.ledgerNames());
    if (!built.valid) { var e = new AppError('INVALID_INVOICE', 'Invalid invoice data: ' + built.errors.join(' ')); e.details = built.errors; throw e; }
    built.newLedgers.forEach(function (l) { if (l.parent_group === 'Sundry Debtors') { l.mobile = p.mobile || ''; l.address = p.address || ''; } });
    Post.ledgers(built.newLedgers, session, company.company_id);
    var heads = Post.vouchers(built.vouchers, session, company.company_id);
    var saleV = heads[0], rcV = heads[1];
    Db.insert('SALES_ITEMS', built.items.map(function (it) { it.voucher_id = saleV.voucher_id; it.revision = 1; return it; }), session);
    var sr = built.salesRow; sr.voucher_id = saleV.voucher_id;
    Db.insert('SALES', [sr], session);
    var or = built.offlineRow; or.voucher_id = saleV.voucher_id; or.receipt_voucher_id = rcV ? rcV.voucher_id : '';
    Db.insert('OFFLINE_SALES', [or], session);
    if (rcV) {
      Db.insert('RECEIPTS', [{ voucher_id: rcV.voucher_id, receipt_no: rcV.voucher_number, receipt_date: rcV.voucher_date, party_ledger: rcV.party_ledger, amount: built.totals.paid, mode: p.payment_mode, bank_ledger: built.vouchers[1].lines[0].ledger_name, instrument_no: p.instrument_no || '', against_bill: p.invoice_no, source: 'OFFLINE', status: 'ACTIVE' }], session);
    }
    Audit.log({ action: 'CREATE', entity: 'OFFLINE_SALES', record_id: or.offline_sale_id, new_value: { invoice_no: p.invoice_no, customer: or.customer_name, total: built.totals.total, paid: built.totals.paid, vouchers: heads.map(function (h) { return h.voucher_id; }) }, source: 'OFFLINE' }, session);
    return { offline_sale_id: or.offline_sale_id, invoice_no: p.invoice_no, voucher_ids: heads.map(function (h) { return h.voucher_id; }), totals: built.totals, ledgersCreated: built.newLedgers.map(function (l) { return l.ledger_name; }) };
  },

  saveReceipt: function (p, session) { return Svc.cashVoucher_('receipt', p, session); },
  savePayment: function (p, session) { return Svc.cashVoucher_('payment', p, session); },
  cashVoucher_: function (kind, p, session) {
    var company = Ctx.company(p);
    p.date = Validate.date(p.date || today_());
    p.amount = Validate.amount(p.amount);
    if (!p.number) p.number = Post.nextNumber(kind === 'receipt' ? 'RCPT' : 'PYMT', p.date);
    var known = Post.ledgerNames().map(function (n) { return n.toLowerCase(); });
    [p.party_ledger, p.bank_ledger].forEach(function (n) { if (n && known.indexOf(String(n).toLowerCase()) < 0) throw new AppError('VALIDATION', 'Ledger "' + n + '" does not exist. Create it first.'); });
    var built = Engine.buildCashVoucher(kind, p, Settings.all(), Post.ledgerNames());
    if (!built.valid) throw new AppError('VALIDATION', built.errors.join(' '));
    Post.ledgers(built.newLedgers, session, company.company_id);
    var h = Post.vouchers(built.vouchers, session, company.company_id)[0];
    var reg = { voucher_id: h.voucher_id, party_ledger: p.party_ledger, amount: p.amount, mode: p.mode || 'Bank Transfer', bank_ledger: p.bank_ledger, instrument_no: p.instrument_no || '', instrument_date: p.instrument_date || '', against_bill: p.against_bill || '', source: 'MANUAL', status: 'ACTIVE' };
    if (kind === 'receipt') { reg.receipt_no = p.number; reg.receipt_date = p.date; reg.tds_deducted = p.tds_amount || 0; Db.insert('RECEIPTS', [reg], session); }
    else { reg.payment_no = p.number; reg.payment_date = p.date; reg.tds_amount = p.tds_amount || 0; reg.approved_by = session.email; Db.insert('PAYMENTS', [reg], session); }
    Audit.log({ action: 'CREATE', entity: kind === 'receipt' ? 'RECEIPTS' : 'PAYMENTS', record_id: h.voucher_id, new_value: reg }, session);
    return { voucher_id: h.voucher_id, number: p.number };
  },

  saveJournal: function (p, session) {
    var company = Ctx.company(p);
    var date = Validate.date(p.date || today_());
    if (!Array.isArray(p.lines)) throw new AppError('VALIDATION', 'lines[] is required.');
    var known = {}; Post.ledgerNames().forEach(function (n) { known[n.toLowerCase()] = true; });
    var lines = p.lines.map(function (l, i) {
      if (!known[String(l.ledger_name).toLowerCase()]) throw new AppError('VALIDATION', 'Line ' + (i + 1) + ': ledger "' + l.ledger_name + '" does not exist.');
      return { line_no: i + 1, ledger_name: String(l.ledger_name), debit: Number(l.debit) || 0, credit: Number(l.credit) || 0, cost_centre: l.cost_centre || '', is_party_line: false };
    });
    var number = p.number || Post.nextNumber('JV', date);
    var header = { voucher_date: date, voucher_type: 'Journal', base_voucher_type: 'Journal', voucher_number: number, narration: Validate.text(p.narration, 500), source: 'MANUAL', status: 'ACTIVE', unique_key: 'MANUAL:JOURNAL:' + number.toLowerCase(), amount: 0 };
    var check = Engine.validateVoucher(header, lines);
    if (!check.valid) throw new AppError('UNBALANCED', check.errors.join(' '));
    header.amount = check.totalDebit;
    var h = Post.vouchers([{ header: header, lines: lines, bills: p.bills || [] }], session, company.company_id)[0];
    Db.insert('JOURNALS', [{ voucher_id: h.voucher_id, journal_no: number, journal_date: date, journal_type: p.journal_type || 'Adjustment', total_debit: check.totalDebit, total_credit: check.totalCredit, narration: header.narration, source: 'MANUAL', status: 'ACTIVE', approved_by: '' }], session);
    Audit.log({ action: 'CREATE', entity: 'JOURNALS', record_id: h.voucher_id, new_value: { number: number, lines: lines } }, session);
    return { voucher_id: h.voucher_id, number: number };
  },

  /** Soft delete. Tally-sourced vouchers must be cancelled in Tally (the next sync picks it up). */
  cancelVoucher: function (p, session) {
    Validate.required(p, ['voucher_id', 'reason']);
    var v = Db.read('VOUCHERS').filter(function (x) { return x.voucher_id === p.voucher_id; })[0];
    if (!v) throw new AppError('NOT_FOUND', 'Voucher not found.');
    if (v.source === 'TALLY') throw new AppError('FORBIDDEN', 'Tally vouchers must be cancelled in Tally; the next sync will reflect it.', 403);
    if (v.status !== 'ACTIVE') throw new AppError('VALIDATION', 'Voucher is already ' + v.status + '.');
    Db.update('VOUCHERS', 'voucher_id', p.voucher_id, { status: 'CANCELLED', narration: String(v.narration || '') + ' [Cancelled: ' + Validate.text(p.reason, 200) + ']' }, session);
    ['SALES', 'PURCHASES', 'RECEIPTS', 'PAYMENTS', 'JOURNALS'].forEach(function (t) {
      Db.updateWhere(t, function (r) { return r.voucher_id === p.voucher_id; }, function (r) { r.status = 'CANCELLED'; });
    });
    Db.updateWhere('OFFLINE_SALES', function (r) { return r.voucher_id === p.voucher_id; }, function (r) { r.status = 'CANCELLED'; });
    Audit.log({ action: 'DELETE', entity: 'VOUCHERS', record_id: p.voucher_id, old_value: { status: v.status }, new_value: { status: 'CANCELLED', reason: p.reason } }, session);
    return { voucher_id: p.voucher_id, status: 'CANCELLED' };
  },

  createLedger: function (p, session) {
    Validate.required(p, ['ledger_name', 'parent_group']);
    var company = Ctx.company(p);
    var name = Validate.text(p.ledger_name, 120);
    if (Post.ledgerNames().some(function (n) { return n.toLowerCase() === name.toLowerCase(); })) throw new AppError('DUPLICATE', 'Ledger "' + name + '" already exists.');
    var groups = Object.keys(Engine.RESERVED_GROUPS).concat(Db.read('GROUPS').map(function (g) { return String(g.group_name); }));
    if (groups.indexOf(p.parent_group) < 0) throw new AppError('VALIDATION', 'Unknown group "' + p.parent_group + '".');
    var l = {
      ledger_name: name, parent_group: p.parent_group, ledger_type: p.ledger_type || 'Other',
      opening_balance: p.opening_balance ? Validate.amount(p.opening_balance, 'Opening balance', true) : 0,
      opening_dr_cr: p.opening_dr_cr === 'Cr' ? 'Cr' : 'Dr', gstin: Validate.gstin(p.gstin), state: Validate.text(p.state, 60),
      tax_type: p.tax_type || '', gst_rate: p.gst_rate || '', mis_category: p.mis_category || '', credit_days: p.credit_days || '',
      mobile: p.mobile ? Validate.mobile(p.mobile) : '', address: Validate.text(p.address, 300), email: Validate.email(p.email),
      is_active: true, needs_review: false, source: 'MANUAL'
    };
    var created = Post.ledgers([l], session, company.company_id)[0];
    return { ledger_id: created.ledger_id, ledger_name: name };
  },
  createCustomer: function (p, session) {
    p.parent_group = 'Sundry Debtors'; p.ledger_type = 'Customer'; p.ledger_name = p.ledger_name || p.customer_name;
    var r = Svc.createLedger(p, session);
    Db.updateWhere('CUSTOMERS', function (c) { return c.ledger_id === r.ledger_id; }, function (c) {
      c.pan = p.pan || ''; c.email = p.email || ''; c.city = p.city || ''; c.state_code = p.state_code || ''; c.credit_limit = p.credit_limit || ''; c.salesperson = p.salesperson || ''; c.source = 'MANUAL';
    });
    return r;
  },
  createVendor: function (p, session) {
    p.parent_group = 'Sundry Creditors'; p.ledger_type = 'Vendor'; p.ledger_name = p.ledger_name || p.vendor_name;
    var r = Svc.createLedger(p, session);
    Db.updateWhere('VENDORS', function (v) { return v.ledger_id === r.ledger_id; }, function (v) {
      v.pan = p.pan || ''; v.email = p.email || ''; v.mobile = p.mobile || ''; v.address = p.address || ''; v.city = p.city || '';
      v.msme_registered = p.msme_registered === true || p.msme_registered === 'true'; v.msme_number = p.msme_number || ''; v.vendor_category = p.vendor_category || '';
    });
    return r;
  },

  saveExpense: function (p, session) {
    Validate.required(p, ['expense_date', 'category', 'amount', 'expense_ledger', 'payment_mode']);
    var cats = SCHEMA.tables.filter(function (t) { return t.name === 'EXPENSES'; })[0].enums.category;
    var row = {
      expense_date: Validate.date(p.expense_date), category: Validate.oneOf(p.category, cats, 'Category'),
      vendor_ledger: Validate.text(p.vendor_ledger, 120), description: Validate.text(p.description, 500),
      amount: Validate.amount(p.amount), gst_rate: Number(p.gst_rate) || 0,
      gst_amount: p.gst_amount !== undefined && p.gst_amount !== '' ? Validate.amount(p.gst_amount, 'GST', true) : Engine.util.r2(Number(p.amount) * (Number(p.gst_rate) || 0) / 100),
      payment_mode: Validate.oneOf(p.payment_mode, ['Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Credit', 'Other'], 'Payment mode'),
      paid_from_ledger: Validate.text(p.paid_from_ledger, 120), expense_ledger: Validate.text(p.expense_ledger, 120),
      cost_centre: Validate.text(p.cost_centre, 80), receipt_url: /^https:\/\//.test(p.receipt_url || '') ? p.receipt_url : '',
      approval_status: 'Pending'
    };
    row.total_amount = Engine.util.r2(row.amount + row.gst_amount);
    Db.insert('EXPENSES', [row], session);
    Audit.log({ action: 'CREATE', entity: 'EXPENSES', record_id: row.expense_id, new_value: row }, session);
    return { expense_id: row.expense_id, approval_status: 'Pending' };
  },
  approveExpense: function (p, session) {
    Validate.required(p, ['expense_id']);
    var company = Ctx.company(p);
    var exp = Db.read('EXPENSES').filter(function (e) { return e.expense_id === p.expense_id; })[0];
    if (!exp) throw new AppError('NOT_FOUND', 'Expense not found.');
    if (exp.approval_status !== 'Pending') throw new AppError('VALIDATION', 'Expense is already ' + exp.approval_status + '.');
    if (String(exp.created_by).toLowerCase() === session.email && session.role !== 'ADMIN') throw new AppError('FORBIDDEN', 'Maker-checker: you cannot approve an expense you entered.', 403);
    var e = plain_([exp])[0];
    e.inter_state = p.inter_state;
    var built = Engine.buildExpenseVoucher(e, Settings.all());
    if (!built.valid) throw new AppError('VALIDATION', built.errors.join(' '));
    var known = Post.ledgerNames().map(function (n) { return n.toLowerCase(); });
    var S = Settings.effective();
    var needed = built.vouchers[0].lines.map(function (l) { return l.ledger_name; }).filter(function (n) { return known.indexOf(n.toLowerCase()) < 0; });
    Post.ledgers(needed.map(function (n) {
      var isTax = [S.INPUT_CGST_LEDGER, S.INPUT_SGST_LEDGER, S.INPUT_IGST_LEDGER].indexOf(n) >= 0;
      if (!isTax && n !== e.expense_ledger) throw new AppError('VALIDATION', 'Ledger "' + n + '" does not exist. Create it first.');
      return isTax ? { ledger_name: n, parent_group: 'Duties & Taxes', ledger_type: 'Tax', tax_type: n === S.INPUT_IGST_LEDGER ? 'IGST' : n === S.INPUT_CGST_LEDGER ? 'CGST' : 'SGST', source: 'AUTO', is_active: true, opening_balance: 0, opening_dr_cr: 'Dr' }
        : { ledger_name: n, parent_group: 'Indirect Expenses', ledger_type: 'Expense', source: 'AUTO', is_active: true, needs_review: true, opening_balance: 0, opening_dr_cr: 'Dr' };
    }), session, company.company_id);
    var h = Post.vouchers(built.vouchers, session, company.company_id)[0];
    var res = Db.update('EXPENSES', 'expense_id', p.expense_id, { approval_status: 'Approved', approved_by: session.email, approved_at: new Date(), voucher_id: h.voucher_id });
    Audit.log({ action: 'APPROVE', entity: 'EXPENSES', record_id: p.expense_id, old_value: { approval_status: res.old.approval_status }, new_value: { approval_status: 'Approved', voucher_id: h.voucher_id } }, session);
    return { expense_id: p.expense_id, voucher_id: h.voucher_id };
  },
  rejectExpense: function (p, session) {
    Validate.required(p, ['expense_id', 'reason']);
    var cur = Db.read('EXPENSES').filter(function (e) { return e.expense_id === p.expense_id; })[0];
    if (!cur) throw new AppError('NOT_FOUND', 'Expense not found.');
    if (cur.approval_status !== 'Pending') throw new AppError('VALIDATION', 'Only pending expenses can be rejected.');
    Db.update('EXPENSES', 'expense_id', p.expense_id, { approval_status: 'Rejected', approved_by: session.email, approved_at: new Date() });
    Audit.log({ action: 'REJECT', entity: 'EXPENSES', record_id: p.expense_id, old_value: { approval_status: 'Pending' }, new_value: { approval_status: 'Rejected', reason: Validate.text(p.reason, 300) } }, session);
    return { expense_id: p.expense_id, approval_status: 'Rejected' };
  },

  resolveNotification: function (p, session) {
    Validate.required(p, ['dedupe_key']);
    var n = Db.read('NOTIFICATIONS').filter(function (x) { return x.dedupe_key === p.dedupe_key; })[0];
    if (n) Db.update('NOTIFICATIONS', 'notification_id', n.notification_id, { status: 'RESOLVED', resolved_by: session.email, resolved_at: new Date() });
    else Db.insert('NOTIFICATIONS', [{ created_at: new Date(), severity: p.severity || 'INFO', category: p.category || 'OVERDUE_RECEIVABLE', title: p.title || '', message: p.message || '', status: 'RESOLVED', resolved_by: session.email, resolved_at: new Date(), dedupe_key: p.dedupe_key }]);
    Audit.log({ action: 'UPDATE', entity: 'NOTIFICATIONS', record_id: p.dedupe_key, new_value: { status: 'RESOLVED' } }, session);
    return { resolved: true };
  }
};

// ---------------------------------------------------------------------------
// Bank statement import & reconciliation
// ---------------------------------------------------------------------------
var Bank = {
  WINDOW_DAYS: 5,

  importStatement: function (p, session) {
    Validate.required(p, ['bank_account_id']);
    if (!Array.isArray(p.rows) || !p.rows.length) throw new AppError('VALIDATION', 'rows[] is required.');
    var acct = Db.read('BANK_ACCOUNTS').filter(function (a) { return a.bank_account_id === p.bank_account_id; })[0];
    if (!acct) throw new AppError('NOT_FOUND', 'Bank account not found.');
    var existing = {};
    Db.read('BANK_TRANSACTIONS').forEach(function (t) { existing[Bank.fingerprint_(t.bank_account_id, Engine.util.D(t.txn_date), t.debit, t.credit, t.reference, t.description)] = true; });
    var batch = 'STMT-' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyyMMdd-HHmmss');
    var fresh = [], dup = 0;
    p.rows.forEach(function (r, i) {
      var d = Engine.util.D(r.txn_date || r.date);
      if (!d) throw new AppError('VALIDATION', 'Row ' + (i + 1) + ': invalid date.');
      var dr = Number(r.debit) || 0, cr = Number(r.credit) || 0;
      if ((dr && cr) || (!dr && !cr)) throw new AppError('VALIDATION', 'Row ' + (i + 1) + ': exactly one of debit/credit is required.');
      var fp = Bank.fingerprint_(p.bank_account_id, d, dr, cr, r.reference, r.description);
      if (existing[fp]) { dup++; return; }
      existing[fp] = true;
      fresh.push({ bank_account_id: p.bank_account_id, txn_date: d, value_date: Engine.util.D(r.value_date) || d, description: Validate.text(r.description, 300), reference: Validate.text(r.reference, 100), debit: dr, credit: cr, balance: r.balance === undefined ? '' : Number(r.balance), import_batch: batch, reconciliation_status: 'Pending' });
    });
    Db.insert('BANK_TRANSACTIONS', fresh, session);
    Audit.log({ action: 'IMPORT', entity: 'BANK_TRANSACTIONS', record_id: batch, new_value: { account: p.bank_account_id, imported: fresh.length, duplicates: dup } }, session);
    return { batch: batch, imported: fresh.length, duplicatesSkipped: dup };
  },
  fingerprint_: function (acct, d, dr, cr, ref, desc) { return [acct, d, Number(dr) || 0, Number(cr) || 0, String(ref || '').trim(), String(desc || '').trim().slice(0, 40)].join('|'); },

  /** Rule-based auto-match: 1) amount + reference token, 2) amount + same date (unique), 3) amount within window (unique) -> Partially Matched. */
  autoReconcile: function (p, session) {
    Validate.required(p, ['bank_account_id']);
    var acct = Db.read('BANK_ACCOUNTS').filter(function (a) { return a.bank_account_id === p.bank_account_id; })[0];
    if (!acct) throw new AppError('NOT_FOUND', 'Bank account not found.');
    var ctx = Ctx.load(p);
    var used = {};
    Db.read('BANK_RECONCILIATION').forEach(function (r) { if (r.voucher_id && r.reconciliation_status !== 'Unmatched') used[r.voucher_id + '|' + r.bank_account_id] = true; });
    var book = ctx.lines.filter(function (l) { return l.ledger.toLowerCase() === String(acct.ledger_name).toLowerCase() && !used[l.v.id + '|' + acct.bank_account_id]; });
    var txns = Db.read('BANK_TRANSACTIONS').filter(function (t) { return t.bank_account_id === p.bank_account_id && (t.reconciliation_status === 'Pending' || t.reconciliation_status === 'Unmatched'); });
    var recs = [], matched = 0, partial = 0, unmatched = 0;
    txns.forEach(function (t) {
      var d = Engine.util.D(t.txn_date), amt = Number(t.credit) || -Number(t.debit);   // bank credit = book debit
      var cands = book.filter(function (l) { return Math.abs(l.nd - amt) < 0.005 && Math.abs(Engine.util.daysBetween(l.date, d)) <= Bank.WINDOW_DAYS; });
      var tokens = String(t.reference + ' ' + t.description).toUpperCase().split(/[^A-Z0-9]+/).filter(function (x) { return x.length >= 6; });
      var byRef = cands.filter(function (l) { var hay = (l.v.ref + ' ' + l.v.narration + ' ' + l.v.number).toUpperCase(); return tokens.some(function (tk) { return hay.indexOf(tk) >= 0; }); });
      var sameDay = cands.filter(function (l) { return l.date === d; });
      var pick = null, rule = '', status = 'Unmatched';
      if (byRef.length === 1) { pick = byRef[0]; rule = 'AMOUNT+REFERENCE'; status = 'Matched'; }
      else if (sameDay.length === 1) { pick = sameDay[0]; rule = 'AMOUNT+DATE'; status = 'Matched'; }
      else if (cands.length === 1) { pick = cands[0]; rule = 'AMOUNT+WINDOW'; status = 'Partially Matched'; }
      if (pick) { book.splice(book.indexOf(pick), 1); if (status === 'Matched') matched++; else partial++; } else unmatched++;
      t.reconciliation_status = status; t.matched_voucher_id = pick ? pick.v.id : '';
      recs.push({ bank_account_id: p.bank_account_id, bank_txn_id: t.bank_txn_id, voucher_id: pick ? pick.v.id : '', txn_date: d, description: t.description, reference: t.reference, amount: Math.abs(amt), dr_cr: amt > 0 ? 'Dr' : 'Cr', tally_status: pick ? 'In Books' : 'Not in Books', bank_statement_status: 'In Statement', reconciliation_status: status, match_rule: rule, reconciled_by: 'auto', reconciled_at: new Date(), remarks: '' });
    });
    var ids = {}; txns.forEach(function (t) { ids[t.bank_txn_id] = t; });
    Db.updateWhere('BANK_TRANSACTIONS', function (t) { return !!ids[t.bank_txn_id]; }, function (t) { t.reconciliation_status = ids[t.bank_txn_id].reconciliation_status; t.matched_voucher_id = ids[t.bank_txn_id].matched_voucher_id; });
    Db.replaceWhere('BANK_RECONCILIATION', function (r) { return !!ids[r.bank_txn_id]; }, recs);
    Audit.log({ action: 'RECONCILE', entity: 'BANK_RECONCILIATION', record_id: p.bank_account_id, new_value: { matched: matched, partial: partial, unmatched: unmatched } }, session);
    if (unmatched) Notify.raise('WARNING', 'UNRECONCILED_BANK', 'Unreconciled bank lines: ' + acct.ledger_name, unmatched + ' statement lines have no matching book entry', acct.bank_account_id, 'UNRECONCILED_BANK|' + acct.bank_account_id);
    return { matched: matched, partiallyMatched: partial, unmatched: unmatched, summary: Bank.summary(p.bank_account_id, ctx) };
  },

  /** Manual match / unmatch of one statement line. */
  setMatch: function (p, session) {
    Validate.required(p, ['bank_txn_id']);
    var status = p.voucher_id ? 'Matched' : 'Unmatched';
    var res = Db.update('BANK_TRANSACTIONS', 'bank_txn_id', p.bank_txn_id, { reconciliation_status: status, matched_voucher_id: p.voucher_id || '' });
    var t = res.row;
    Db.replaceWhere('BANK_RECONCILIATION', function (r) { return r.bank_txn_id === p.bank_txn_id; }, [{
      bank_account_id: t.bank_account_id, bank_txn_id: t.bank_txn_id, voucher_id: p.voucher_id || '', txn_date: t.txn_date, description: t.description, reference: t.reference,
      amount: Number(t.credit) || Number(t.debit), dr_cr: Number(t.credit) ? 'Dr' : 'Cr', tally_status: p.voucher_id ? 'In Books' : 'Not in Books', bank_statement_status: 'In Statement',
      reconciliation_status: status, match_rule: 'MANUAL', reconciled_by: session.email, reconciled_at: new Date(), remarks: Validate.text(p.remarks, 300)
    }]);
    Audit.log({ action: 'RECONCILE', entity: 'BANK_TRANSACTIONS', record_id: p.bank_txn_id, old_value: { status: res.old.reconciliation_status, voucher: res.old.matched_voucher_id }, new_value: { status: status, voucher: p.voucher_id || '' } }, session);
    return { bank_txn_id: p.bank_txn_id, reconciliation_status: status };
  },

  /** Bank reconciliation statement: balance as per books vs as per statement with the unmatched items on each side. */
  summary: function (bankAccountId, ctx) {
    if (!bankAccountId) return null;
    var acct = Db.read('BANK_ACCOUNTS').filter(function (a) { return a.bank_account_id === bankAccountId; })[0];
    if (!acct) return null;
    ctx = ctx || Ctx.load({});
    var txns = Db.read('BANK_TRANSACTIONS').filter(function (t) { return t.bank_account_id === bankAccountId; });
    var matchedV = {}; txns.forEach(function (t) { if (t.matched_voucher_id) matchedV[t.matched_voucher_id] = true; });
    var bookBal = Engine.balanceAt(ctx, acct.ledger_name, ctx.today);
    var withBal = txns.filter(function (t) { return t.balance !== '' && t.balance !== null; }).sort(function (a, b) { return a.txn_date - b.txn_date; });
    var stmtBal = withBal.length ? Number(withBal[withBal.length - 1].balance) : null;
    var firstStmt = txns.length ? Engine.util.D(txns.reduce(function (m, t) { return t.txn_date < m ? t.txn_date : m; }, txns[0].txn_date)) : ctx.today;
    var notInBank = ctx.lines.filter(function (l) { return l.ledger.toLowerCase() === String(acct.ledger_name).toLowerCase() && l.date >= firstStmt && !matchedV[l.v.id]; });
    var notInBooks = txns.filter(function (t) { return t.reconciliation_status === 'Unmatched' || t.reconciliation_status === 'Pending'; });
    return {
      account: acct.ledger_name, balanceAsPerBooks: bookBal, balanceAsPerStatement: stmtBal,
      depositsNotCredited: Engine.util.r2(notInBank.filter(function (l) { return l.nd > 0; }).reduce(function (s, l) { return s + l.nd; }, 0)),
      chequesNotPresented: Engine.util.r2(notInBank.filter(function (l) { return l.nd < 0; }).reduce(function (s, l) { return s - l.nd; }, 0)),
      creditsNotInBooks: Engine.util.r2(notInBooks.reduce(function (s, t) { return s + (Number(t.credit) || 0); }, 0)),
      debitsNotInBooks: Engine.util.r2(notInBooks.reduce(function (s, t) { return s + (Number(t.debit) || 0); }, 0)),
      unmatchedBookEntries: notInBank.length, unmatchedStatementLines: notInBooks.length
    };
  }
};

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------
var Notify = {
  raise: function (severity, category, title, message, recordId, dedupeKey, targetRole) {
    var existing = Db.read('NOTIFICATIONS').filter(function (n) { return n.dedupe_key === dedupeKey && n.status !== 'RESOLVED'; })[0];
    if (existing) return existing;
    return Db.insert('NOTIFICATIONS', [{ created_at: new Date(), severity: severity, category: category, title: title, message: message, entity: category.split('_')[0], record_id: recordId || '', target_role: targetRole || '', status: 'OPEN', dedupe_key: dedupeKey }])[0];
  }
};
