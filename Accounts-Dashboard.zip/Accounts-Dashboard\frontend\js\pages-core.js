/* Pages: shared helpers, dashboards, alerts, transactions. */
var Pages = window.Pages = window.Pages || {};
var Shared = (function () {
  'use strict';
  var esc = UI.esc, fmt = UI.fmt, $ = UI.$, icon = UI.icon;

  function head(title, sub, actions) {
    return '<div class="print-head"><b>' + esc(APP_CONFIG.COMPANY_NAME) + '</b> - ' + esc(title) + '<br><span class="small">' + esc(sub || '') + ' · Printed ' + new Date().toLocaleString('en-IN') + '</span></div>' +
      '<div class="page-head"><div><h1>' + esc(title) + '</h1>' + (sub ? '<div class="sub">' + esc(sub) + '</div>' : '') + '</div><div class="actions">' + (actions || '') + '</div></div>';
  }
  var lookupsP = null;
  function lookups() { return lookupsP || (lookupsP = Api.call('getLookups', {}).catch(function (e) { lookupsP = null; throw e; })); }
  function invalidate() { lookupsP = null; App.refreshIndicators(); }
  function periodLabel(r) { return r && r.from ? fmt.date(r.from) + ' to ' + fmt.date(r.to) : ''; }

  function openVoucher(id) {
    var d = UI.drawer('Voucher', UI.loading());
    Api.call('getVoucher', { voucher_id: id }).then(function (v) {
      var h = v.header;
      d.el.querySelector('.drawer-head h3').textContent = h.voucher_type + ' ' + h.voucher_number;
      var cancel = Api.can('write.transactions') && h.source !== 'TALLY' && h.status === 'ACTIVE' ? '<button class="btn danger sm" id="cancelV">Cancel voucher</button>' : '';
      var raw = Api.can('view.tally') && h.source === 'TALLY' ? '<button class="btn sm" id="rawV">View Tally XML</button>' : '';
      d.body.innerHTML =
        '<div class="kpis">' + UI.kpi('Date', fmt.date(h.voucher_date)) + UI.kpi('Amount', fmt.inr(h.amount)) + UI.kpi('Source', h.source) + UI.kpi('Status', h.status) + '</div>' +
        '<div class="card mt"><div class="card-body"><div class="stat-line"><span class="muted">Party</span><b>' + esc(h.party_ledger || '-') + '</b></div><div class="stat-line"><span class="muted">Reference</span><span>' + esc(h.reference_no || '-') + '</span></div><div class="stat-line"><span class="muted">Narration</span><span>' + esc(h.narration || '-') + '</span></div><div class="stat-line"><span class="muted">Voucher ID / key</span><span class="small">' + esc(h.voucher_id + ' · ' + (h.unique_key || '')) + '</span></div><div class="stat-line"><span class="muted">Revision</span><span>' + esc(h.revision) + (h.tally_alter_id ? ' (Tally AlterID ' + esc(h.tally_alter_id) + ')' : '') + '</span></div></div></div>' +
        '<div class="section-title">Ledger entries (double entry)</div><div class="card">' + UI.staticTable([{ key: 'ledger_name', label: 'Ledger', render: function (v) { return '<a role="button" tabindex="0" data-ledger="' + esc(v) + '">' + esc(v) + '</a>'; } }, { key: 'debit', label: 'Debit', type: 'inr2' }, { key: 'credit', label: 'Credit', type: 'inr2' }], v.lines, { foot: { ledger_name: v.balanced ? 'Balanced' : 'NOT BALANCED', debit: v.totalDebit, credit: v.totalCredit } }) + '</div>' +
        (v.bills.length ? '<div class="section-title">Bill allocations</div><div class="card">' + UI.staticTable([{ key: 'party_ledger', label: 'Party' }, { key: 'bill_name', label: 'Bill' }, { key: 'bill_type', label: 'Type' }, { key: 'due_date', label: 'Due', type: 'date' }, { key: 'amount', label: 'Amount', type: 'inr2' }, { key: 'dr_cr', label: 'Dr/Cr' }], v.bills) + '</div>' : '') +
        (v.items.length ? '<div class="section-title">Items</div><div class="card">' + UI.staticTable([{ key: 'product_name', label: 'Product' }, { key: 'hsn_sac', label: 'HSN' }, { key: 'qty', label: 'Qty', type: 'num' }, { key: 'rate', label: 'Rate', type: 'inr2' }, { key: 'taxable_amount', label: 'Taxable', type: 'inr2' }, { key: 'gst_rate', label: 'GST %', type: 'num' }, { key: 'line_total', label: 'Total', type: 'inr2' }], v.items) + '</div>' : '') +
        '<div class="actions mt">' + raw + cancel + '</div>';
      d.body.addEventListener('click', function (e) { var a = e.target.closest('[data-ledger]'); if (a) { d.close(); openLedger(a.dataset.ledger); } });
      var cb = $('#cancelV', d.body);
      if (cb) cb.addEventListener('click', function () {
        UI.modal({ title: 'Cancel voucher ' + h.voucher_number, okText: 'Cancel voucher', body: UI.field('Reason (recorded in the audit trail)', '<textarea class="input" name="reason" rows="3"></textarea>'), onOk: function (m) {
          return Api.call('cancelVoucher', { voucher_id: id, reason: UI.formData(m).reason }).then(function () { UI.toast('Voucher cancelled.', 'good'); d.close(); invalidate(); App.route(); });
        } });
      });
      var rb = $('#rawV', d.body);
      if (rb) rb.addEventListener('click', function () {
        Api.call('getTallyData', { voucher_id: id }).then(function (r) { UI.modal({ title: 'Raw Tally payload', wide: true, foot: false, body: (r.note ? '<div class="note">' + esc(r.note) + '</div>' : '') + '<pre style="white-space:pre-wrap;font-size:12px;max-height:60vh;overflow:auto">' + esc(r.xml || 'Not available') + '</pre>' }); });
      });
    }, function (e) { d.body.innerHTML = UI.errorBox(e); });
  }

  function openLedger(name, range) {
    var st = { preset: range ? 'custom' : 'current_fy', from: range && range.from, to: range && range.to };
    var d = UI.drawer('Ledger: ' + name, '<form class="filters">' + UI.periodFields(st) + '</form><div id="lsBody">' + UI.loading() + '</div>');
    var last = null;
    function load(v) {
      var body = $('#lsBody', d.body); body.innerHTML = UI.loading();
      var p = { ledger: name, preset: v.preset }; if (v.preset === 'custom') { p.from = v.from; p.to = v.to; }
      Api.call('getLedgerStatement', p).then(function (s) {
        last = s;
        var cols = [{ key: 'date', label: 'Date', type: 'date' }, { key: 'voucher_number', label: 'Voucher', render: function (x, r) { return '<a role="button" tabindex="0" data-v="' + esc(r.voucher_id) + '">' + esc(x) + '</a>'; } }, { key: 'voucher_type', label: 'Type' }, { key: 'particulars', label: 'Particulars' }, { key: 'debit', label: 'Debit', type: 'inr2' }, { key: 'credit', label: 'Credit', type: 'inr2' }, { key: 'balance', label: 'Balance', render: function (x) { return fmt.drcr(x); }, exportValue: function (x) { return x; } }, { key: 'reference', label: 'Reference' }, { key: 'narration', label: 'Narration' }];
        var rows = [{ date: s.from, voucher_number: '', particulars: 'Opening balance', debit: s.opening > 0 ? s.opening : 0, credit: s.opening < 0 ? -s.opening : 0, balance: s.opening, _cls: 'group-row' }].concat(s.rows);
        body.innerHTML = '<div class="kpis">' + UI.kpi('Group', s.group) + UI.kpi('Opening', fmt.drcr(s.opening)) + UI.kpi('Debits', fmt.inr(s.totalDebit)) + UI.kpi('Credits', fmt.inr(s.totalCredit)) + UI.kpi('Closing', fmt.drcr(s.closing), '', 'accent') + '</div>' +
          '<div class="card mt"><div class="card-head"><h3>' + esc(s.ledger) + '</h3>' + UI.exportButtons('Ledger - ' + s.ledger, function () { return cols; }, function () { return rows; }) + '</div>' +
          UI.staticTable(cols, rows, { foot: { particulars: 'Closing balance', debit: s.totalDebit, credit: s.totalCredit, balance: fmt.drcr(s.closing) } }) + '</div>';
      }, function (e) { body.innerHTML = UI.errorBox(e); });
    }
    d.body.addEventListener('click', function (e) { var a = e.target.closest('[data-v]'); if (a) openVoucher(a.dataset.v); });
    UI.bindFilters($('.filters', d.body), load);
    load(st);
    return last;
  }

  /** Standard filter bar + remote table page. */
  function registerPage(root, cfg) {
    var state = Object.assign({ preset: cfg.defaultPreset || 'current_fy' }, cfg.initial || {});
    root.innerHTML = head(cfg.title, cfg.sub, cfg.actions || '') + (cfg.kpis ? '<div class="kpis" id="rpKpis"></div>' : '') + (cfg.above || '') +
      '<form class="filters mt">' + (cfg.noPeriod ? '' : UI.periodFields(state)) + (cfg.filters || '') + '<div class="field grow"><label>Search</label><input class="input" type="search" name="q" placeholder="Filter rows…"></div></form>' +
      '<div class="card"><div class="card-head"><h3>' + esc(cfg.tableTitle || cfg.title) + '</h3><span id="rpExport"></span></div><div id="rpTable"></div></div>' + (cfg.below || '');
    var tbl;
    function params(extra) {
      var p = Object.assign({}, state, extra || {});
      if (p.preset !== 'custom') { delete p.from; delete p.to; }
      return p;
    }
    tbl = UI.table($('#rpTable', root), {
      columns: cfg.columns, pageSize: cfg.pageSize || 25, sort: cfg.sort, dir: cfg.dir, onRow: cfg.onRow, rowClass: cfg.rowClass, footer: cfg.footer, emptyText: cfg.emptyText,
      load: function (pg) {
        return Api.call(cfg.action, params(pg)).then(function (res) {
          if (cfg.kpis) $('#rpKpis', root).innerHTML = cfg.kpis(res);
          if (cfg.after) cfg.after(res, root);
          return res;
        });
      }
    });
    $('#rpExport', root).outerHTML = UI.exportButtons(cfg.title, function () { return cfg.columns; }, function () { return tbl.exportRows(); });
    UI.bindFilters($('.filters', root), function (v) { Object.assign(state, v); tbl.reload(true); });
    return { reload: function () { tbl.reload(); }, state: state };
  }

  return { head: head, lookups: lookups, invalidate: invalidate, openVoucher: openVoucher, openLedger: openLedger, registerPage: registerPage, periodLabel: periodLabel };
})();

// =============================================================================
// Dashboard
// =============================================================================
Pages.dashboard = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  Api.call('getDashboard', {}).then(function (d) {
    var t = d.today;
    var sync = d.lastSync ? 'Last Tally sync ' + fmt.dt(d.lastSync.end_time || d.lastSync.start_time) : 'Tally not synced yet';
    root.innerHTML = Shared.head('Dashboard', (d.company || APP_CONFIG.COMPANY_NAME) + ' · ' + fmt.date(d.date) + ' · ' + d.fy + ' · ' + sync,
      (Api.can('write.offline_sales') ? '<a class="btn primary" href="#/offline-sales">' + UI.icon('plus') + 'Offline sale</a>' : '') + '<button class="btn" data-print>' + UI.icon('print') + 'Print</button>') +
      '<div class="section-title">Today</div><div class="kpis">' +
      UI.kpi('Sales bills', fmt.num(t.salesBills, 0), t.offlineSalesBills ? t.offlineSalesBills + ' offline' : 'Tally + offline', 'accent') +
      UI.kpi('Sales billing', fmt.inr(t.salesAmount), t.offlineSalesAmount ? fmt.inr(t.offlineSalesAmount) + ' offline' : 'incl. GST', 'accent') +
      UI.kpi('Purchase bills', fmt.num(t.purchaseBills, 0), fmt.inr(t.purchaseAmount)) +
      UI.kpi('Receipts', fmt.inr(t.receipts), 'cash & bank inflow') +
      UI.kpi('Payments', fmt.inr(t.payments), 'cash & bank outflow') +
      UI.kpi('Net cash flow', fmt.inr(t.netCashFlow), '', t.netCashFlow < 0 ? 'bad' : 'good') +
      UI.kpi("Today's expenses", fmt.inr(t.expenses)) + '</div>' +
      '<div class="section-title">Position</div><div class="kpis">' +
      UI.kpi('Cash balance', fmt.inr(d.cashBalance)) + UI.kpi('Bank balance', fmt.inr(d.bankBalance)) +
      UI.kpi('Receivables', fmt.inr(d.receivables), fmt.inr(d.overdueReceivables) + ' overdue', d.overdueReceivables > 0 ? '' : 'good') +
      UI.kpi('Payables', fmt.inr(d.payables), fmt.inr(d.overduePayables) + ' overdue') +
      UI.kpi('Overdue receivables', fmt.inr(d.overdueReceivables), '', d.overdueReceivables > 0 ? 'bad' : '') +
      UI.kpi('Net outstanding', fmt.inr(d.outstanding), 'receivables - payables') + '</div>' +
      '<div class="section-title">Year to date (' + esc(d.fy) + ')</div><div class="kpis">' +
      UI.kpi('Revenue', fmt.inr(d.ytd.revenue), d.ytd.salesBills + ' invoices') + UI.kpi('Gross profit', fmt.inr(d.ytd.grossProfit), fmt.pct(d.ytd.grossMargin) + ' margin') +
      UI.kpi('Net profit', fmt.inr(d.ytd.netProfit), '', d.ytd.netProfit < 0 ? 'bad' : 'good') + UI.kpi('Month-to-date sales', fmt.inr(d.mtd.sales), d.mtd.salesBills + ' invoices') +
      d.salesBySource.map(function (s) { return UI.kpi((s.key === 'OFFLINE' ? 'Offline' : s.key === 'TALLY' ? 'Tally' : s.key) + ' sales (YTD)', fmt.inr(s.amount), s.count + ' invoices'); }).join('') + '</div>' +
      '<div class="grid g-2-1 mt">' + UI.card('Sales vs collections - last 30 days', '<div class="chart-box" id="c1"></div>', { sub: 'Daily invoice value and money received' }) +
      UI.card('Receivable ageing', '<div class="chart-box" id="c2"></div>', { sub: 'Outstanding by ' + 'days past due' }) + '</div>' +
      '<div class="grid g2 mt">' + UI.card('Monthly revenue & net profit (' + d.fy + ')', '<div class="chart-box" id="c3"></div>') +
      UI.card('Top customers (YTD)', UI.staticTable([{ key: 'key', label: 'Customer' }, { key: 'count', label: 'Invoices', type: 'num' }, { key: 'amount', label: 'Sales', type: 'inr' }, { key: 'share', label: 'Share', type: 'pct' }], d.topCustomers), { flush: true }) + '</div>' +
      '<div class="mt">' + UI.card('Overdue invoices', UI.staticTable([{ key: 'party', label: 'Customer' }, { key: 'bill_name', label: 'Invoice' }, { key: 'due_date', label: 'Due', type: 'date' }, { key: 'days_overdue', label: 'Days overdue', type: 'num' }, { key: 'outstanding', label: 'Outstanding', type: 'inr' }], d.topOverdue, { emptyText: 'No overdue invoices.' }), { flush: true, actions: '<a class="btn sm" href="#/receivables">All receivables</a>' }) + '</div>' +
      (d.warnings && d.warnings.length ? '<div class="note mt">' + d.warnings.map(function (w) { return esc(w.message); }).join('<br>') + '</div>' : '');
    UI.chart(UI.$('#c1'), { type: 'line', labels: d.trend.map(function (x) { return x.date.slice(8) + '/' + x.date.slice(5, 7); }), datasets: [{ label: 'Sales', data: d.trend.map(function (x) { return x.sales; }) }, { label: 'Receipts', data: d.trend.map(function (x) { return x.receipts; }) }] });
    var labels = d.bucketLabels;
    UI.chart(UI.$('#c2'), { labels: labels, datasets: [{ label: 'Outstanding', data: labels.map(function (l) { return d.receivableBuckets[l] || 0; }), colors: UI.seqColors(labels.length) }] });
    UI.chart(UI.$('#c3'), { labels: d.monthly.map(function (m) { return fmt.month(m.month); }), datasets: [{ label: 'Revenue', data: d.monthly.map(function (m) { return m.revenue; }) }, { label: 'Net profit', data: d.monthly.map(function (m) { return m.netProfit; }) }] });
  }, function (e) { root.innerHTML = UI.errorBox(e); });
} };

// =============================================================================
// Management MIS - the 15 management questions
// =============================================================================
Pages.mis = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  Api.call('getManagementDashboard', {}).then(function (m) {
    function q(n, question, answer, extra) { return '<div class="card"><div class="card-body"><div class="small muted">Q' + n + '. ' + esc(question) + '</div><div style="font-size:19px;font-weight:600;margin-top:4px">' + answer + '</div>' + (extra || '') + '</div></div>'; }
    function dir(x) { return x === 'increasing' ? UI.badge('Increasing', 'warn') : x === 'decreasing' ? UI.badge('Decreasing', 'good') : UI.badge('Flat', 'info'); }
    root.innerHTML = Shared.head('Management MIS', 'Answers to the questions management asks every day · ' + fmt.date(m.date), '<button class="btn" data-print>' + UI.icon('print') + 'Print</button>') +
      '<div class="grid g4">' +
      q(1, 'How much did we sell today?', fmt.inr(m.q1_salesToday.amount), '<div class="small muted">' + m.q1_salesToday.bills + ' bills</div>') +
      q(2, 'How much did we purchase?', fmt.inr(m.q2_purchaseToday.amount), '<div class="small muted">' + m.q2_purchaseToday.bills + ' bills</div>') +
      q(3, 'How much cash came in?', fmt.inr(m.q3_cashIn)) + q(4, 'How much cash went out?', fmt.inr(m.q4_cashOut)) +
      q(5, 'How much do customers owe us?', fmt.inr(m.q5_customersOwe)) + q(6, 'How much do we owe vendors?', fmt.inr(m.q6_weOweVendors)) +
      q(10, 'What is the current profit (YTD)?', '<span class="' + (m.q10_currentProfit.netProfit < 0 ? 'neg' : 'pos') + '">' + fmt.inr(m.q10_currentProfit.netProfit) + '</span>', '<div class="small muted">Revenue ' + fmt.inr(m.q10_currentProfit.revenue) + ' · margin ' + fmt.pct(m.q10_currentProfit.netMargin) + '</div>') +
      q(14, 'Are receivables increasing?', dir(m.q14_receivablesTrend.direction), '<div class="small muted">Payables: ' + m.q15_payablesTrend.direction + ' (Q15)</div>') + '</div>' +
      '<div class="grid g2 mt">' + UI.card('Q11. How is revenue trending?', '<div class="chart-box" id="m1"></div>') + UI.card('Q12. How is cash flow trending?', '<div class="chart-box" id="m2"></div>') + '</div>' +
      '<div class="grid g2 mt">' + UI.card('Q14 / Q15. Receivables and payables (month-end)', '<div class="chart-box" id="m3"></div>') + UI.card('Q13. What are the major expenses? (YTD)', '<div class="chart-box" id="m4"></div>') + '</div>' +
      '<div class="grid g2 mt">' + UI.card('Q7. Which invoices are overdue?', UI.staticTable([{ key: 'party', label: 'Customer' }, { key: 'bill_name', label: 'Invoice' }, { key: 'days_overdue', label: 'Days', type: 'num' }, { key: 'outstanding', label: 'Outstanding', type: 'inr' }], m.q7_overdueInvoices, { emptyText: 'Nothing overdue.' }), { flush: true }) +
      UI.card('Q8. Which customers contribute most revenue?', UI.staticTable([{ key: 'key', label: 'Customer' }, { key: 'amount', label: 'Sales', type: 'inr' }, { key: 'share', label: 'Share', type: 'pct' }], m.q8_topCustomers), { flush: true }) + '</div>' +
      '<div class="mt">' + UI.card('Q9. Which vendors have the highest outstanding?', UI.staticTable([{ key: 'party', label: 'Vendor' }, { key: 'balance', label: 'Outstanding', type: 'inr' }, { key: 'overdue_amount', label: 'Overdue', type: 'inr' }, { key: 'overdue_bills', label: 'Overdue bills', type: 'num' }, { key: 'max_days_overdue', label: 'Max days overdue', type: 'num' }], m.q9_topVendorOutstanding), { flush: true }) + '</div>';
    UI.chart(UI.$('#m1'), { labels: m.q11_revenueTrend.map(function (x) { return fmt.month(x.month); }), datasets: [{ label: 'Revenue', data: m.q11_revenueTrend.map(function (x) { return x.revenue; }) }] });
    UI.chart(UI.$('#m2'), { labels: m.q12_cashFlowTrend.map(function (x) { return fmt.month(x.month); }), datasets: [{ label: 'Inflow', data: m.q12_cashFlowTrend.map(function (x) { return x.inflow; }), slot: 0 }, { label: 'Outflow', data: m.q12_cashFlowTrend.map(function (x) { return x.outflow; }), slot: 1 }] });
    UI.chart(UI.$('#m3'), { type: 'line', labels: m.q14_receivablesTrend.series.map(function (x) { return fmt.month(x.month); }), datasets: [{ label: 'Receivables', data: m.q14_receivablesTrend.series.map(function (x) { return x.value; }) }, { label: 'Payables', data: m.q15_payablesTrend.series.map(function (x) { return x.value; }) }] });
    UI.chart(UI.$('#m4'), { horizontal: true, labels: m.q13_majorExpenses.map(function (x) { return x.ledger; }), datasets: [{ label: 'Expense', data: m.q13_majorExpenses.map(function (x) { return x.amount; }) }] });
  }, function (e) { root.innerHTML = UI.errorBox(e); });
} };

// =============================================================================
// Alert center
// =============================================================================
Pages.alerts = { render: function (root) {
  var esc = UI.esc;
  var SEV_ICON = { CRITICAL: 'alert', WARNING: 'clock', INFO: 'info' };
  var CAT = { OVERDUE_RECEIVABLE: 'Overdue receivable', OVERDUE_PAYABLE: 'Overdue payable', UPCOMING_PAYMENT: 'Upcoming payment', UPCOMING_COLLECTION: 'Upcoming collection', CASH_SHORTAGE: 'Cash shortage', HIGH_EXPENSE: 'High expenses', SYNC_FAILED: 'Tally sync', UNRECONCILED_BANK: 'Unreconciled bank', DUPLICATE_VOUCHER: 'Duplicate voucher', MSME_DUE: 'MSME 45-day limit', UNBALANCED_VOUCHER: 'Unbalanced voucher' };
  var filter = '';
  function load() {
    Api.call('getAlerts', {}).then(function (a) {
      var cats = {}; a.alerts.forEach(function (x) { cats[x.category] = (cats[x.category] || 0) + 1; });
      var list = a.alerts.filter(function (x) { return !filter || x.category === filter; });
      root.innerHTML = Shared.head('Alert Center', a.counts.critical + ' critical · ' + a.counts.warning + ' warnings') +
        '<div class="seg mt" id="catSeg"><button data-c="" class="' + (!filter ? 'on' : '') + '">All (' + a.alerts.length + ')</button>' + Object.keys(cats).map(function (c) { return '<button data-c="' + c + '" class="' + (filter === c ? 'on' : '') + '">' + esc(CAT[c] || c) + ' (' + cats[c] + ')</button>'; }).join('') + '</div>' +
        '<div class="card mt">' + (list.length ? list.map(function (x, i) {
          return '<div class="alert-item"><div class="sev ' + x.severity + '" title="' + x.severity + '">' + UI.icon(SEV_ICON[x.severity]) + '</div><div style="flex:1;min-width:0"><div><b>' + esc(x.title) + '</b> <span class="badge">' + esc(CAT[x.category] || x.category) + '</span> <span class="small muted">' + esc(x.severity) + '</span></div><div class="muted">' + esc(x.message) + '</div></div>' +
            (Api.can('resolve.alerts') ? '<button class="btn sm" data-r="' + i + '">Resolve</button>' : '') + '</div>';
        }).join('') : UI.empty('No open alerts.')) + '</div>';
      UI.$$('#catSeg button', root).forEach(function (b) { b.addEventListener('click', function () { filter = b.dataset.c; load(); }); });
      UI.$$('[data-r]', root).forEach(function (b) { b.addEventListener('click', function () { var x = list[+b.dataset.r]; Api.call('resolveNotification', { dedupe_key: x.dedupe_key, severity: x.severity, category: x.category, title: x.title, message: x.message }).then(function () { UI.toast('Alert resolved.'); App.refreshIndicators(); load(); }, function (e) { UI.toast(e.message, 'bad'); }); }); });
    }, function (e) { root.innerHTML = UI.errorBox(e); });
  }
  load();
} };

// =============================================================================
// Sales
// =============================================================================
function salesColumns(kind) {
  var fmt = UI.fmt, esc = UI.esc;
  return [
    { key: 'invoice_date', label: 'Date', type: 'date' },
    { key: 'invoice_no', label: kind === 'sales' ? 'Invoice' : 'Voucher', render: function (v, r) { return '<a role="button" tabindex="0" data-v="' + esc(r.voucher_id) + '">' + esc(v) + '</a>'; } },
    { key: 'party', label: kind === 'sales' ? 'Customer' : 'Vendor' },
    kind === 'sales' ? { key: 'salesperson', label: 'Salesperson' } : { key: 'reference', label: 'Vendor invoice' },
    { key: 'products', label: 'Products', render: function (v) { return '<span class="small">' + esc(String(v || '').slice(0, 60)) + '</span>'; } },
    { key: 'taxable', label: 'Taxable', type: 'inr' }, { key: 'tax', label: 'GST', type: 'inr' },
    { key: 'amount', label: 'Amount', type: 'inr' }, { key: 'paid', label: 'Paid', type: 'inr' }, { key: 'outstanding', label: 'Outstanding', type: 'inr' },
    { key: 'due_date', label: 'Due', type: 'date' }, { key: 'status', label: 'Status', type: 'badge' },
    { key: 'source', label: 'Source', render: function (v) { return UI.badge(v === 'OFFLINE' ? 'Offline' : v === 'TALLY' ? 'Tally' : v, v === 'OFFLINE' ? 'warn' : 'info'); } }
  ];
}
function registerWithReports(root, kind, q) {
  var fmt = UI.fmt, esc = UI.esc;
  var tab = q.tab || 'register';
  var title = kind === 'sales' ? 'Sales' : 'Purchases';
  var groups = kind === 'sales'
    ? [['day', 'Daily'], ['week', 'Weekly'], ['month', 'Monthly'], ['customer', 'Customer-wise'], ['product', 'Product-wise'], ['salesperson', 'Salesperson-wise'], ['gst_rate', 'GST-wise'], ['state', 'State-wise'], ['source', 'Tally vs Offline'], ['channel', 'Channel / cost centre']]
    : [['month', 'Monthly'], ['vendor', 'Vendor-wise'], ['product', 'Category / item-wise'], ['gst_rate', 'GST-wise'], ['week', 'Weekly']];
  var action = kind === 'sales' ? '<a class="btn primary" href="#/offline-sales">' + UI.icon('plus') + 'New offline sale</a>' : '';
  function tabs() { return '<div class="tabs no-print"><button data-t="register" class="' + (tab === 'register' ? 'on' : '') + '">Register</button><button data-t="reports" class="' + (tab === 'reports' ? 'on' : '') + '">Reports</button></div>'; }
  if (tab === 'register') {
    Shared.lookups().catch(function () { return {}; }).then(function (lk) {
      var filters = UI.field('Status', UI.select('status', ['', 'Paid', 'Partially Paid', 'Outstanding', 'Overdue'], '')) + UI.field('Source', UI.select('source', [{ value: '', label: 'All' }, { value: 'TALLY', label: 'Tally' }, { value: 'OFFLINE', label: 'Offline' }], '')) +
        (kind === 'sales' ? UI.field('Customer', '<input class="input" name="customer" list="dlCust" placeholder="All">' + UI.datalist('dlCust', lk.customers || [])) + UI.field('Salesperson', UI.select('salesperson', [''].concat(lk.salespersons || []), '')) : UI.field('Vendor', '<input class="input" name="vendor" list="dlVend" placeholder="All">' + UI.datalist('dlVend', lk.vendors || [])));
      Shared.registerPage(root, {
        title: title, sub: kind === 'sales' ? 'Tally + offline invoices with live payment status' : 'Purchase bills with payment status', actions: action, action: kind === 'sales' ? 'getSales' : 'getPurchases',
        above: tabs(), filters: filters, columns: salesColumns(kind), sort: 'invoice_date',
        kpis: function (r) { var t = r.totals; return UI.kpi(kind === 'sales' ? 'Invoices' : 'Bills', fmt.num(t.count, 0), Shared.periodLabel(r), 'accent') + UI.kpi('Taxable value', fmt.inr(t.taxable)) + UI.kpi('GST', fmt.inr(t.tax)) + UI.kpi('Total', fmt.inr(t.amount), '', 'accent') + UI.kpi(kind === 'sales' ? 'Collected' : 'Paid', fmt.inr(t.paid)) + UI.kpi('Outstanding', fmt.inr(t.outstanding), '', t.outstanding > 0 ? 'bad' : 'good') + t.bySource.map(function (s) { return UI.kpi(s.key === 'OFFLINE' ? 'Offline' : 'Tally', fmt.inr(s.amount), s.count + ' invoices'); }).join(''); },
        footer: function (r) { return { invoice_date: 'Total (all pages)', taxable: r.totals.taxable, tax: r.totals.tax, amount: r.totals.amount, paid: r.totals.paid, outstanding: r.totals.outstanding }; },
        after: function (r, rt) { UI.$$('[data-v]', rt).forEach(function (a) { a.onclick = function () { Shared.openVoucher(a.dataset.v); }; }); }
      });
      bindTabs();
    });
  } else {
    var st = { preset: 'current_fy', groupBy: q.groupBy || 'month' };
    root.innerHTML = Shared.head(title + ' reports', 'Grouped analysis with totals and share', action) + tabs() +
      '<form class="filters">' + UI.periodFields(st) + UI.field('Group by', UI.select('groupBy', groups.map(function (g) { return { value: g[0], label: g[1] }; }), st.groupBy)) + '</form><div id="repBody"></div>';
    bindTabs();
    var cols;
    var load = function (v) {
      Object.assign(st, v);
      var body = UI.$('#repBody', root); body.innerHTML = UI.loading();
      var p = { groupBy: st.groupBy, preset: st.preset }; if (st.preset === 'custom') { p.from = st.from; p.to = st.to; }
      Api.call(kind === 'sales' ? 'getSalesReport' : 'getPurchaseReport', p).then(function (r) {
        UI.destroyCharts();
        var isProd = r.groupBy === 'product' || r.groupBy === 'gst_rate';
        cols = [{ key: 'key', label: (groups.filter(function (g) { return g[0] === r.groupBy; })[0] || ['', 'Group'])[1].replace('-wise', '') }, { key: 'count', label: isProd ? 'Lines' : 'Invoices', type: 'num' }].concat(isProd ? [{ key: 'quantity', label: 'Qty', type: 'num' }, { key: 'avg_price', label: 'Avg price', type: 'inr' }] : []).concat([{ key: 'taxable', label: 'Taxable', type: 'inr' }, { key: 'tax', label: 'GST', type: 'inr' }, { key: 'amount', label: 'Amount', type: 'inr' }, { key: 'share', label: 'Share', type: 'pct' }]);
        var top = r.rows.slice(0, 15);
        body.innerHTML = UI.card('By ' + r.groupBy.replace('_', ' '), '<div class="chart-box tall" id="rc"></div>', { sub: Shared.periodLabel(r) }) +
          '<div class="card mt"><div class="card-head"><h3>' + r.count + ' invoices · ' + fmt.inr(r.total) + '</h3>' + UI.exportButtons(title + ' by ' + r.groupBy, function () { return cols; }, function () { return r.rows; }) + '</div>' + UI.staticTable(cols, r.rows, { foot: { key: 'Total', amount: r.total } }) + '</div>';
        var timeSeries = ['day', 'week', 'month', 'quarter', 'year'].indexOf(r.groupBy) >= 0;
        UI.chart(UI.$('#rc', body), { type: timeSeries && r.rows.length > 20 ? 'line' : 'bar', horizontal: !timeSeries, labels: (timeSeries ? r.rows : top).map(function (x) { return r.groupBy === 'month' ? fmt.month(x.key) : x.key; }), datasets: [{ label: 'Amount', data: (timeSeries ? r.rows : top).map(function (x) { return x.amount; }) }] });
      }, function (e) { body.innerHTML = UI.errorBox(e); });
    };
    UI.bindFilters(UI.$('.filters', root), load);
    load({});
  }
  function bindTabs() { UI.$$('.tabs [data-t]', root).forEach(function (b) { b.onclick = function () { location.hash = '#/' + (kind === 'sales' ? 'sales' : 'purchases') + '?tab=' + b.dataset.t; }; }); }
}
Pages.sales = { render: function (root, q) { registerWithReports(root, 'sales', q); } };
Pages.purchases = { render: function (root, q) { registerWithReports(root, 'purchase', q); } };

// =============================================================================
// Offline sales entry
// =============================================================================
Pages['offline-sales'] = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc, $ = UI.$;
  Shared.lookups().then(function (lk) {
    var today = Engine.util.D(new Date());
    var rates = [0, 5, 12, 18, 28];
    function itemRow() {
      return '<tr><td><input class="input" name="product" list="dlProd" placeholder="Product"></td><td><input class="input" name="hsn_sac" placeholder="HSN"></td><td><input class="input num" name="qty" type="number" min="0" step="any" value="1"></td>' +
        '<td><input class="input num" name="rate" type="number" min="0" step="any"></td><td><input class="input num" name="discount_pct" type="number" min="0" max="100" step="any" value="0"></td><td>' + UI.select('tax_rate', rates.map(String), '18') + '</td><td class="num line-total">-</td><td><button type="button" class="icon-btn" data-del aria-label="Remove line">' + UI.icon('x') + '</button></td></tr>';
    }
    root.innerHTML = Shared.head('Offline Sales Entry', 'Posts a GST sales voucher (and a receipt for any amount paid) into the same books as Tally') +
      '<form id="ofs" autocomplete="off"><div class="grid g-2-1"><div class="card"><div class="card-head"><h3>Invoice</h3><span class="small muted">Leave invoice number blank to auto-number</span></div><div class="card-body"><div class="form-grid g3">' +
      UI.field('Invoice number', UI.input('invoice_no', '', 'placeholder="Auto"')) + UI.field('Invoice date', '<input class="input" type="date" name="invoice_date" value="' + today + '" max="' + today + '">') + UI.field('Salesperson', '<input class="input" name="salesperson" list="dlSp">' + UI.datalist('dlSp', lk.salespersons || [])) +
      UI.field('Customer', '<input class="input" name="customer_name" list="dlCust" placeholder="Walk-in if blank">' + UI.datalist('dlCust', lk.customers || []), 'New names create a customer ledger automatically') + UI.field('Customer GSTIN', UI.input('customer_gstin', '', 'maxlength="15" style="text-transform:uppercase"')) + UI.field('Mobile', UI.input('mobile', '', 'inputmode="tel" maxlength="13"')) +
      UI.field('State (place of supply)', UI.input('state', lk.companyState || 'Delhi', 'list="dlStates"') + UI.datalist('dlStates', ['Delhi', 'Haryana', 'Uttar Pradesh', 'Rajasthan', 'Punjab', 'Maharashtra', 'Karnataka', 'Gujarat', 'Tamil Nadu', 'West Bengal', 'Telangana', 'Madhya Pradesh', 'Uttarakhand', 'Himachal Pradesh', 'Chandigarh', 'Jammu and Kashmir', 'Bihar', 'Kerala'])) + UI.field('Address', UI.input('address', ''), '', 'full') +
      '</div></div></div>' +
      '<div class="card"><div class="card-head"><h3>Payment</h3></div><div class="card-body"><div class="form-grid">' +
      UI.field('Payment mode', UI.select('payment_mode', ['Credit', 'Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Other'], 'Credit')) + UI.field('Paid amount', '<input class="input num" type="number" name="paid_amount" min="0" step="any" value="0">') +
      UI.field('Credit days', '<input class="input num" type="number" name="credit_days" min="0" value="30">') + UI.field('Instrument / UTR', UI.input('instrument_no', '')) +
      UI.field('Remarks', '<textarea class="input" name="remarks" rows="2"></textarea>', '', 'full') + '</div></div></div></div>' +
      '<div class="card mt"><div class="card-head"><h3>Items</h3><button type="button" class="btn sm" id="addLine">' + UI.icon('plus') + 'Add line</button></div><div class="card-body"><div class="table-wrap"><table class="data items-table"><thead><tr><th style="min-width:200px">Product</th><th>HSN/SAC</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Disc %</th><th>GST %</th><th class="num">Line total</th><th></th></tr></thead><tbody id="lines">' + itemRow() + '</tbody></table></div>' +
      UI.datalist('dlProd', (lk.products || []).map(function (p) { return p.name; })) +
      '<div class="grid g2 mt"><div id="calcErr"></div><div class="totals-box" id="totals"></div></div></div>' +
      '<div class="modal-foot"><button type="reset" class="btn">Clear</button><button type="submit" class="btn primary">' + UI.icon('check') + 'Post offline sale</button></div></div></form>' +
      '<div class="mt" id="ofsList"></div>';
    var form = $('#ofs', root), tbody = $('#lines', root);
    function collect() {
      var f = UI.formData(form);
      var items = UI.$$('#lines tr', root).map(function (tr) { return UI.formData(tr); }).filter(function (i) { return i.product || i.rate; });
      delete f.product; delete f.hsn_sac; delete f.qty; delete f.rate; delete f.discount_pct; delete f.tax_rate;
      f.items = items; f.invoice_no = f.invoice_no || 'PREVIEW'; return f;
    }
    function recalc() {
      var f = collect();
      var modes = lk.paymentModeLedgers || {};
      var b = Engine.buildOfflineSale(f, { COMPANY_STATE: lk.companyState || 'Delhi', PAYMENT_MODE_LEDGERS: JSON.stringify(modes) }, []);
      UI.$$('#lines tr', root).forEach(function (tr) { var i = UI.formData(tr); var tv = (+i.qty || 0) * (+i.rate || 0) * (1 - (+i.discount_pct || 0) / 100); $('.line-total', tr).textContent = i.rate ? fmt.inr2(tv * (1 + (+i.tax_rate || 0) / 100)) : '-'; });
      if (!b.valid) { $('#calcErr', root).innerHTML = f.items.length ? '<div class="note">' + b.errors.map(esc).join('<br>') + '</div>' : ''; $('#totals', root).innerHTML = ''; return; }
      var t = b.totals;
      $('#calcErr', root).innerHTML = '<div class="note">' + (t.intraState ? 'Intra-state supply: CGST + SGST' : 'Inter-state supply: IGST') + '. Posting: Dr ' + esc(f.customer_name || 'Walk-in Customers') + ' / Cr Sales - Offline + output GST' + (t.paid ? '; receipt Dr ' + esc(modes[f.payment_mode] || f.payment_mode) + ' / Cr customer.' : '.') + '</div>';
      $('#totals', root).innerHTML = [['Taxable value', t.taxable], ['Discount', t.discount], ['CGST', t.cgst], ['SGST', t.sgst], ['IGST', t.igst], ['Round off', t.roundOff]].filter(function (x) { return x[1]; }).map(function (x) { return '<div class="stat-line"><span class="muted">' + x[0] + '</span><b>' + fmt.inr2(x[1]) + '</b></div>'; }).join('') +
        '<div class="stat-line"><span><b>Invoice total</b></span><b style="font-size:17px">' + fmt.inr2(t.total) + '</b></div><div class="stat-line"><span class="muted">Paid</span><b>' + fmt.inr2(t.paid) + '</b></div><div class="stat-line"><span class="muted">Outstanding</span><b class="' + (t.outstanding > 0 ? 'neg' : '') + '">' + fmt.inr2(t.outstanding) + '</b></div>';
    }
    tbody.addEventListener('change', function (e) {
      if (e.target.name === 'product') { var p = (lk.products || []).filter(function (x) { return x.name === e.target.value; })[0]; var tr = e.target.closest('tr'); if (p) { $('[name=rate]', tr).value = p.rate || ''; $('[name=hsn_sac]', tr).value = p.hsn || ''; if (p.gst) $('[name=tax_rate]', tr).value = String(p.gst); } }
      recalc();
    });
    form.addEventListener('input', recalc);
    form.addEventListener('change', recalc);
    tbody.addEventListener('click', function (e) { if (e.target.closest('[data-del]') && tbody.children.length > 1) { e.target.closest('tr').remove(); recalc(); } });
    $('#addLine', root).addEventListener('click', function () { tbody.insertAdjacentHTML('beforeend', itemRow()); });
    form.addEventListener('reset', function () { setTimeout(function () { tbody.innerHTML = itemRow(); recalc(); }); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var f = collect(); if (f.invoice_no === 'PREVIEW') f.invoice_no = '';
      f.customer_gstin = String(f.customer_gstin || '').toUpperCase();
      var btn = $('button[type=submit]', form); btn.disabled = true;
      Api.call('saveOfflineSale', f).then(function (r) {
        UI.toast('Posted ' + r.invoice_no + ' for ' + fmt.inr(r.totals.total) + (r.ledgersCreated.length ? ' · created ledger(s): ' + r.ledgersCreated.join(', ') : ''), 'good');
        form.reset(); Shared.invalidate(); listRecent();
      }, function (err) {
        $('#calcErr', root).innerHTML = '<div class="errors"><b>' + esc(err.message) + '</b>' + (err.details ? '<ul>' + err.details.map(function (d) { return '<li>' + esc(d) + '</li>'; }).join('') + '</ul>' : '') + '</div>';
      }).then(function () { btn.disabled = false; });
    });
    recalc();
    function listRecent() {
      if (!Api.can('view.accounts')) { $('#ofsList', root).innerHTML = ''; return; }
      $('#ofsList', root).innerHTML = '<div class="card"><div class="card-head"><h3>Offline invoices this month</h3><a class="btn sm" href="#/sales?tab=register">Open sales register</a></div><div id="ofsT"></div></div>';
      UI.table($('#ofsT', root), { columns: salesColumns('sales').filter(function (c) { return c.key !== 'source'; }), pageSize: 10, sort: 'invoice_date', load: function (p) { return Api.call('getSales', Object.assign({ source: 'OFFLINE', preset: 'this_month' }, p)); }, afterRender: function (c) { UI.$$('[data-v]', c).forEach(function (a) { a.onclick = function () { Shared.openVoucher(a.dataset.v); }; }); } });
    }
    listRecent();
  }, function (e) { root.innerHTML = UI.errorBox(e); });
} };

// =============================================================================
// Receipts / Payments
// =============================================================================
function cashPage(root, kind) {
  var fmt = UI.fmt, esc = UI.esc;
  var isR = kind === 'receipt';
  var canWrite = Api.can('write.transactions');
  Shared.registerPage(root, {
    title: isR ? 'Receipts' : 'Payments', sub: isR ? 'Money received from customers and others' : 'Money paid to vendors and others',
    actions: canWrite ? '<button class="btn primary" id="newCash">' + UI.icon('plus') + (isR ? 'New receipt' : 'New payment') + '</button>' : '',
    action: isR ? 'getReceipts' : 'getPayments', sort: 'date',
    columns: [{ key: 'date', label: 'Date', type: 'date' }, { key: 'number', label: 'Voucher', render: function (v, r) { return '<a role="button" tabindex="0" data-v="' + esc(r.voucher_id) + '">' + esc(v) + '</a>'; } }, { key: 'party', label: isR ? 'Received from' : 'Paid to' }, { key: 'account', label: isR ? 'Deposited in' : 'Paid from' }, { key: 'against', label: 'Against bill' }, { key: 'reference', label: 'Reference' }, { key: 'amount', label: 'Amount', type: 'inr' }, { key: 'source', label: 'Source', type: 'badge' }],
    kpis: function (r) { return UI.kpi(isR ? 'Total received' : 'Total paid', fmt.inr(r.total_amount), r.total + ' vouchers', 'accent'); },
    after: function (r, rt) { UI.$$('[data-v]', rt).forEach(function (a) { a.onclick = function () { Shared.openVoucher(a.dataset.v); }; }); }
  });
  var btn = UI.$('#newCash', root);
  if (btn) btn.addEventListener('click', function () { cashModal(kind); });
}
function cashModal(kind, preset) {
  var isR = kind === 'receipt';
  preset = preset || {};
  Shared.lookups().then(function (lk) {
    var parties = isR ? lk.customers : lk.vendors.concat(lk.allLedgers.filter(function (l) { return lk.vendors.indexOf(l) < 0; }));
    UI.modal({
      title: isR ? 'New receipt' : 'New payment', okText: 'Post ' + (isR ? 'receipt' : 'payment'),
      body: '<div class="form-grid">' + UI.field('Date', '<input class="input" type="date" name="date" value="' + Engine.util.D(new Date()) + '">') + UI.field('Voucher number', UI.input('number', '', 'placeholder="Auto"')) +
        UI.field(isR ? 'Received from (ledger)' : 'Paid to (ledger)', '<input class="input" name="party_ledger" list="dlParty" value="' + UI.esc(preset.party || '') + '">' + UI.datalist('dlParty', parties)) +
        UI.field(isR ? 'Deposited in' : 'Paid from', UI.select('bank_ledger', lk.cashBank, lk.cashBank[0])) +
        UI.field('Amount', '<input class="input num" type="number" name="amount" min="0" step="any" value="' + (preset.amount || '') + '">') + UI.field(isR ? 'TDS deducted by customer' : 'TDS deducted', '<input class="input num" type="number" name="tds_amount" min="0" step="any" value="0">') +
        UI.field('Mode', UI.select('mode', ['Bank Transfer', 'UPI', 'Cheque', 'Cash', 'Other'], 'Bank Transfer')) + UI.field('Against bill', UI.input('against_bill', preset.bill || ''), 'Blank = on account (auto-applied FIFO)') +
        UI.field('Instrument / UTR', UI.input('instrument_no', '')) + UI.field('Narration', UI.input('narration', ''), '', 'full') + '</div>',
      onOk: function (m) { return Api.call(isR ? 'saveReceipt' : 'savePayment', UI.formData(m)).then(function (r) { UI.toast('Posted ' + r.number, 'good'); Shared.invalidate(); App.route(); }); }
    });
  }, function (e) { UI.toast(e.message, 'bad'); });
}
Pages.receipts = { render: function (root) { cashPage(root, 'receipt'); } };
Pages.payments = { render: function (root) { cashPage(root, 'payment'); } };

// =============================================================================
// Expenses (entry, maker-checker approval, analysis)
// =============================================================================
Pages.expenses = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  var canApprove = Api.can('approve.expenses'), canView = Api.can('view.accounts');
  var page = Shared.registerPage(root, {
    title: 'Expenses', sub: 'Entry → approval (maker-checker) → posting', defaultPreset: 'current_fy',
    actions: Api.can('submit.expenses') ? '<button class="btn primary" id="newExp">' + UI.icon('plus') + 'New expense</button>' : '',
    action: 'getExpenses', sort: 'expense_date',
    filters: UI.field('Status', UI.select('status', ['', 'Pending', 'Approved', 'Rejected'], '')) + UI.field('Category', UI.select('category', ['', 'Salary', 'Rent', 'Electricity', 'Internet', 'Transportation', 'Office Expenses', 'Repairs', 'Maintenance', 'Marketing', 'Travel', 'Professional Fees', 'Miscellaneous'], '')),
    columns: [{ key: 'expense_date', label: 'Date', type: 'date' }, { key: 'expense_id', label: 'ID' }, { key: 'category', label: 'Category' }, { key: 'description', label: 'Description' }, { key: 'expense_ledger', label: 'Ledger' }, { key: 'payment_mode', label: 'Mode' }, { key: 'amount', label: 'Amount', type: 'inr' }, { key: 'gst_amount', label: 'GST', type: 'inr' }, { key: 'total_amount', label: 'Total', type: 'inr' }, { key: 'approval_status', label: 'Status', type: 'badge' }, { key: 'created_by', label: 'Entered by' },
      { key: '_act', label: '', sortable: false, render: function (v, r) { return r.approval_status === 'Pending' && canApprove ? '<button class="btn sm" data-ap="' + esc(r.expense_id) + '">Approve</button> <button class="btn sm danger" data-rj="' + esc(r.expense_id) + '">Reject</button>' : r.voucher_id ? '<a role="button" tabindex="0" data-v="' + esc(r.voucher_id) + '">Voucher</a>' : ''; } }],
    kpis: function (r) { return UI.kpi('Pending approval', r.pending, '', r.pending ? 'bad' : '') + (r.byCategory || []).slice(0, 5).map(function (c) { return UI.kpi(c.category, fmt.inr(c.amount), 'posted, period'); }).join(''); },
    below: canView ? '<div class="grid g2 mt">' + UI.card('Monthly expense analysis (posted)', '<div class="chart-box" id="ex1"></div>') + UI.card('By expense ledger (posted)', '<div class="chart-box" id="ex2"></div>') + '</div>' : '',
    after: function (r, rt) {
      UI.$$('[data-v]', rt).forEach(function (a) { a.onclick = function () { Shared.openVoucher(a.dataset.v); }; });
      UI.$$('[data-ap]', rt).forEach(function (b) { b.onclick = function () { Api.call('approveExpense', { expense_id: b.dataset.ap }).then(function (x) { UI.toast('Approved and posted as ' + x.voucher_id, 'good'); Shared.invalidate(); page.reload(); }, function (e) { UI.toast(e.message, 'bad'); }); }; });
      UI.$$('[data-rj]', rt).forEach(function (b) { b.onclick = function () { UI.modal({ title: 'Reject expense ' + b.dataset.rj, okText: 'Reject', body: UI.field('Reason', '<textarea class="input" name="reason" rows="3"></textarea>'), onOk: function (m) { return Api.call('rejectExpense', { expense_id: b.dataset.rj, reason: UI.formData(m).reason }).then(function () { UI.toast('Expense rejected.'); page.reload(); }); } }); }; });
      if (canView && UI.$('#ex1', root)) {
        UI.destroyCharts();
        UI.chart(UI.$('#ex1', root), { labels: (r.byMonth || []).map(function (m) { return fmt.month(m.month); }), datasets: [{ label: 'Expenses', data: (r.byMonth || []).map(function (m) { return m.amount; }) }] });
        UI.chart(UI.$('#ex2', root), { horizontal: true, labels: (r.byCategory || []).slice(0, 10).map(function (c) { return c.category; }), datasets: [{ label: 'Amount', data: (r.byCategory || []).slice(0, 10).map(function (c) { return c.amount; }) }] });
      }
    }
  });
  var nb = UI.$('#newExp', root);
  if (nb) nb.addEventListener('click', function () {
    Shared.lookups().then(function (lk) {
      UI.modal({
        title: 'New expense', okText: 'Submit for approval',
        body: '<div class="form-grid">' + UI.field('Date', '<input class="input" type="date" name="expense_date" value="' + Engine.util.D(new Date()) + '">') + UI.field('Category', UI.select('category', lk.expenseCategories, 'Office Expenses')) +
          UI.field('Expense ledger', '<input class="input" name="expense_ledger" list="dlExp">' + UI.datalist('dlExp', lk.expenseLedgers)) + UI.field('Vendor (for credit)', '<input class="input" name="vendor_ledger" list="dlVen">' + UI.datalist('dlVen', lk.vendors)) +
          UI.field('Amount (before GST)', '<input class="input num" type="number" name="amount" min="0" step="any">') + UI.field('GST rate %', UI.select('gst_rate', ['0', '5', '12', '18', '28'], '0')) +
          UI.field('Payment mode', UI.select('payment_mode', ['Bank Transfer', 'Cash', 'UPI', 'Cheque', 'Credit', 'Other'], 'Bank Transfer')) + UI.field('Paid from', UI.select('paid_from_ledger', lk.cashBank, lk.cashBank[0])) +
          UI.field('Cost centre', UI.select('cost_centre', [''].concat(lk.costCentres || []), '')) + UI.field('Receipt link (https)', UI.input('receipt_url', '', 'placeholder="https://drive.google.com/…"')) +
          UI.field('Description', UI.input('description', ''), '', 'full') + '</div>',
        onOk: function (m) { return Api.call('saveExpense', UI.formData(m)).then(function (r) { UI.toast('Submitted ' + r.expense_id + ' for approval.', 'good'); page.reload(); }); }
      });
    });
  });
} };
