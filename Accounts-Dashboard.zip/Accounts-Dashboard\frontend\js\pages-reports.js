/* Pages: P&L, balance sheet, cash flow, GST, analytics, financial health. */
var Pages = window.Pages = window.Pages || {};

function periodReport(root, cfg) {
  var st = { preset: cfg.preset || 'current_fy' };
  root.innerHTML = Shared.head(cfg.title, cfg.sub) + '<form class="filters">' + (cfg.asOf ? UI.field('As of', '<input class="input" type="date" name="asOf">') : UI.periodFields(st)) + (cfg.extra || '') + '</form><div id="prBody"></div>';
  function load(v) {
    Object.assign(st, v);
    var body = UI.$('#prBody', root); body.innerHTML = UI.loading(); UI.destroyCharts();
    var p = Object.assign({}, st); if (p.preset !== 'custom') { delete p.from; delete p.to; }
    if (cfg.asOf) { p = { asOf: st.asOf || '' }; }
    Object.assign(p, cfg.params ? cfg.params(st) : {});
    Api.call(cfg.action, p).then(function (d) { cfg.render(body, d, st); }, function (e) { body.innerHTML = UI.errorBox(e); });
  }
  UI.bindFilters(UI.$('.filters', root), load);
  load({});
}

// =============================================================================
// Profit & Loss
// =============================================================================
Pages['profit-loss'] = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  periodReport(root, {
    title: 'Profit & Loss', sub: 'Derived from ledger postings. Revenue, COGS, gross profit, EBITDA, PBT, tax and net profit.', action: 'getProfitLoss',
    params: function () { return { comparative: true }; },
    render: function (body, pl) {
      var rows = [];
      pl.lines.forEach(function (l) {
        rows.push({ label: l.label, amount: l.amount, pct: pl.revenue ? l.amount / pl.revenue * 100 : null, _cls: l.strong ? 'strong-row' : l.total ? 'total-row' : '' });
        (l.detail || []).forEach(function (d) { rows.push({ label: d.ledger, amount: d.amount, pct: pl.revenue ? d.amount / pl.revenue * 100 : null, _indent: true, _ledger: d.ledger }); });
      });
      var cols = [{ key: 'label', label: 'Particulars', indent: true, render: function (v, r) { return r._ledger ? '<a role="button" tabindex="0" data-l="' + esc(v) + '">' + esc(v) + '</a>' : esc(v); } }, { key: 'amount', label: 'Amount', type: 'signed' }, { key: 'pct', label: '% of revenue', type: 'pct' }];
      var c = pl.comparative;
      var compCols = [{ key: 'm', label: 'Metric' }, { key: 'cm', label: 'Current month', type: 'signed' }, { key: 'pm', label: 'Previous month', type: 'signed' }, { key: 'ytd', label: 'Current FY (YTD)', type: 'signed' }, { key: 'pytd', label: 'Previous FY same period', type: 'signed' }, { key: 'pfy', label: 'Previous FY (full)', type: 'signed' }];
      var compRows = [['Revenue', 'revenue'], ['Gross profit', 'grossProfit'], ['Operating expenses', 'operating'], ['EBITDA', 'ebitda'], ['Profit before tax', 'pbt'], ['Net profit', 'netProfit']].map(function (x) { return { m: x[0], cm: c.currentMonth[x[1]], pm: c.previousMonth[x[1]], ytd: c.ytd[x[1]], pytd: c.previousYtd[x[1]], pfy: c.previousFy[x[1]] }; });
      body.innerHTML = '<div class="kpis">' + UI.kpi('Revenue', fmt.inr(pl.revenue), '', 'accent') + UI.kpi('Gross profit', fmt.inr(pl.grossProfit), fmt.pct(pl.grossMargin) + ' margin') + UI.kpi('EBITDA', fmt.inr(pl.ebitda)) + UI.kpi('Net profit', fmt.inr(pl.netProfit), fmt.pct(pl.netMargin) + ' margin', pl.netProfit < 0 ? 'bad' : 'good') + '</div>' +
        '<div class="grid g-2-1 mt"><div class="card statement"><div class="card-head"><h3>' + esc(fmt.date(pl.from) + ' to ' + fmt.date(pl.to)) + '</h3>' + UI.exportButtons('Profit and Loss', function () { return cols; }, function () { return rows; }) + '</div>' + UI.staticTable(cols, rows) + '</div>' +
        '<div>' + UI.card('Monthly trend (current FY)', '<div class="chart-box tall" id="plC"></div>') + '<div class="note mt">' + pl.notes.map(esc).join('<br>') + '</div></div></div>' +
        '<div class="card mt"><div class="card-head"><h3>Comparison</h3></div>' + UI.staticTable(compCols, compRows) + '</div>';
      UI.$$('[data-l]', body).forEach(function (a) { a.onclick = function () { Shared.openLedger(a.dataset.l, { from: pl.from, to: pl.to }); }; });
      UI.chart(UI.$('#plC', body), { labels: c.trend.map(function (m) { return fmt.month(m.month); }), datasets: [{ label: 'Revenue', data: c.trend.map(function (m) { return m.revenue; }) }, { label: 'Gross profit', data: c.trend.map(function (m) { return m.grossProfit; }) }, { label: 'Net profit', data: c.trend.map(function (m) { return m.netProfit; }) }] });
    }
  });
} };

// =============================================================================
// Balance sheet
// =============================================================================
Pages['balance-sheet'] = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  periodReport(root, {
    title: 'Balance Sheet', sub: 'Assets = Liabilities + Equity. Current-period profit and closing stock are included automatically.', action: 'getBalanceSheet', asOf: true,
    render: function (body, bs) {
      function side(list) {
        var rows = [];
        list.forEach(function (s) { rows.push({ label: s.section, amount: s.amount, _cls: 'group-row' }); s.groups.forEach(function (g) { rows.push({ label: g.name, amount: g.amount, _indent: true }); }); });
        return rows;
      }
      var cols = [{ key: 'label', label: 'Particulars', indent: true }, { key: 'amount', label: 'Amount', type: 'signed' }];
      var liab = side(bs.liabilities), assets = side(bs.assets);
      body.innerHTML = '<div class="check ' + (bs.balanced ? 'ok' : 'bad') + '">' + UI.icon(bs.balanced ? 'check' : 'alert') + (bs.balanced ? 'Balanced as of ' + fmt.date(bs.asOf) + ': total ' + fmt.inr2(bs.totalAssets) : 'Difference of ' + fmt.inr2(bs.difference) + ' - review opening balances and unbalanced vouchers in the trial balance.') + '</div>' +
        '<div class="kpis mt">' + UI.kpi('Total assets', fmt.inr(bs.totalAssets), '', 'accent') + UI.kpi('Equity', fmt.inr(bs.equity)) + UI.kpi('Profit for the period', fmt.inr(bs.currentProfit), '', bs.currentProfit < 0 ? 'bad' : 'good') + UI.kpi('Closing stock', fmt.inr(bs.closingStock)) + '</div>' +
        '<div class="actions mt">' + UI.exportButtons('Balance Sheet', function () { return [{ key: 'side', label: 'Side' }].concat(cols); }, function () { return liab.map(function (r) { return Object.assign({ side: 'Liabilities & Equity' }, r); }).concat(assets.map(function (r) { return Object.assign({ side: 'Assets' }, r); })); }) + '</div>' +
        '<div class="bs-grid mt"><div class="card statement"><div class="card-head"><h3>Liabilities & Equity</h3></div>' + UI.staticTable(cols, liab, { foot: { label: 'Total', amount: bs.totalLiabilities } }) + '</div>' +
        '<div class="card statement"><div class="card-head"><h3>Assets</h3></div>' + UI.staticTable(cols, assets, { foot: { label: 'Total', amount: bs.totalAssets } }) + '</div></div>';
    }
  });
} };

// =============================================================================
// Cash flow
// =============================================================================
Pages['cash-flow'] = { render: function (root) {
  var fmt = UI.fmt;
  periodReport(root, {
    title: 'Cash Flow', sub: 'Direct method from cash & bank postings: operating, investing and financing activities', action: 'getCashFlow', preset: 'this_month',
    render: function (body, cf) {
      var rows = [];
      cf.sections.forEach(function (s) {
        rows.push({ label: s.activity + ' activities', inflow: s.inflow, outflow: s.outflow, net: s.net, _cls: 'group-row' });
        s.lines.forEach(function (l) { rows.push({ label: l.label, inflow: l.inflow, outflow: l.outflow, net: l.net, _indent: true }); });
      });
      var cols = [{ key: 'label', label: 'Particulars', indent: true }, { key: 'inflow', label: 'Inflow', type: 'inr' }, { key: 'outflow', label: 'Outflow', type: 'inr' }, { key: 'net', label: 'Net', type: 'signed' }];
      body.innerHTML = '<div class="kpis">' + UI.kpi('Opening cash & bank', fmt.inr(cf.opening)) + UI.kpi('Cash inflow', fmt.inr(cf.inflow)) + UI.kpi('Cash outflow', fmt.inr(cf.outflow)) + UI.kpi('Net cash flow', fmt.inr(cf.net), '', cf.net < 0 ? 'bad' : 'good') + UI.kpi('Closing cash & bank', fmt.inr(cf.closing), '', 'accent') + '</div>' +
        '<div class="check mt ' + (cf.reconciles ? 'ok' : 'bad') + '">' + UI.icon(cf.reconciles ? 'check' : 'alert') + (cf.reconciles ? 'Opening + net cash flow = closing balance.' : 'Does not reconcile by ' + fmt.inr2(cf.difference) + ' (vouchers with unclassifiable cash lines).') + '</div>' +
        '<div class="grid g-2-1 mt"><div class="card statement"><div class="card-head"><h3>' + fmt.date(cf.from) + ' to ' + fmt.date(cf.to) + '</h3>' + UI.exportButtons('Cash Flow', function () { return cols; }, function () { return rows; }) + '</div>' + UI.staticTable(cols, rows, { foot: { label: 'Net change in cash', inflow: cf.inflow, outflow: cf.outflow, net: cf.net } }) + '</div>' +
        UI.card('Net by activity', '<div class="chart-box" id="cfC"></div>') + '</div>';
      UI.chart(UI.$('#cfC', body), { labels: cf.sections.map(function (s) { return s.activity; }), datasets: [{ label: 'Inflow', data: cf.sections.map(function (s) { return s.inflow; }), slot: 0 }, { label: 'Outflow', data: cf.sections.map(function (s) { return s.outflow; }), slot: 1 }] });
    }
  });
} };

// =============================================================================
// GST
// =============================================================================
Pages.gst = { render: function (root, q) {
  var fmt = UI.fmt, esc = UI.esc;
  var tab = q.tab || 'summary';
  periodReport(root, {
    title: 'GST', sub: 'Output tax, input tax credit and net liability by head - derived from posted vouchers', action: 'getGSTSummary', preset: 'this_month',
    params: function () { return { pageSize: 200 }; },
    render: function (body, g) {
      var heads = ['cgst', 'sgst', 'igst', 'cess'];
      var tabs = [['summary', 'Summary'], ['customers', 'Customer GST'], ['vendors', 'Vendor GST'], ['hsn', 'HSN/SAC'], ['states', 'State-wise'], ['tx', 'Transactions']];
      var partyCols = function (lbl) { return [{ key: 'key', label: lbl }, { key: 'gstin', label: 'GSTIN' }, { key: 'count', label: 'Vouchers', type: 'num' }, { key: 'taxable_value', label: 'Taxable', type: 'inr' }, { key: 'cgst', label: 'CGST', type: 'inr' }, { key: 'sgst', label: 'SGST', type: 'inr' }, { key: 'igst', label: 'IGST', type: 'inr' }, { key: 'total_tax', label: 'Total tax', type: 'inr' }]; };
      var hsnCols = [{ key: 'hsn_sac', label: 'HSN/SAC' }, { key: 'quantity', label: 'Qty', type: 'num' }, { key: 'taxable_value', label: 'Taxable', type: 'inr' }, { key: 'cgst', label: 'CGST', type: 'inr' }, { key: 'sgst', label: 'SGST', type: 'inr' }, { key: 'igst', label: 'IGST', type: 'inr' }];
      var content = {
        summary: function () { return '<div class="grid g-2-1"><div class="card">' + UI.staticTable([{ key: 'h', label: 'Head' }, { key: 'o', label: 'Output tax', type: 'inr' }, { key: 'i', label: 'Input tax credit', type: 'inr' }, { key: 'n', label: 'Net liability', type: 'signed' }], heads.map(function (h) { return { h: h.toUpperCase(), o: g.output[h], i: g.input[h], n: g.net[h] }; }), { foot: { h: 'Total', o: g.output.total_tax, i: g.input.total_tax, n: g.net.total } }) + '</div>' + UI.card('Monthly output vs input', '<div class="chart-box" id="gC"></div>') + '</div>'; },
        customers: function () { return '<div class="card">' + UI.staticTable(partyCols('Customer'), g.customers) + '</div>'; },
        vendors: function () { return '<div class="card">' + UI.staticTable(partyCols('Vendor'), g.vendors) + '</div>'; },
        hsn: function () { return '<div class="grid g2"><div class="card"><div class="card-head"><h3>Outward (sales)</h3></div>' + UI.staticTable(hsnCols, g.hsnOutward) + '</div><div class="card"><div class="card-head"><h3>Inward (purchases)</h3></div>' + UI.staticTable(hsnCols, g.hsnInward) + '</div></div>'; },
        states: function () { return '<div class="card">' + UI.staticTable(partyCols('Place of supply').filter(function (c) { return c.key !== 'gstin'; }), g.states) + '</div>'; },
        tx: function () { return '<div class="card">' + UI.staticTable([{ key: 'voucher_date', label: 'Date', type: 'date' }, { key: 'voucher_number', label: 'Voucher' }, { key: 'direction', label: 'Direction', type: 'badge' }, { key: 'party_ledger', label: 'Party' }, { key: 'party_gstin', label: 'GSTIN' }, { key: 'supply_type', label: 'Supply' }, { key: 'taxable_value', label: 'Taxable', type: 'inr' }, { key: 'total_tax', label: 'Tax', type: 'inr' }], g.transactions.rows) + '<div class="table-foot">' + g.transactions.total + ' GST vouchers' + (g.transactions.total > g.transactions.rows.length ? ' (first ' + g.transactions.rows.length + ' shown; export for all)' : '') + '</div></div>'; }
      };
      body.innerHTML = '<div class="kpis">' + UI.kpi('Output tax', fmt.inr(g.output.total_tax), 'on ' + fmt.inr(g.output.taxable_value) + ' taxable') + UI.kpi('Input tax credit', fmt.inr(g.input.total_tax), 'on ' + fmt.inr(g.input.taxable_value) + ' taxable') + UI.kpi('Net GST liability', fmt.inr(g.net.total), 'before set-off rules', 'accent') + UI.kpi('GST paid / set-off', fmt.inr(g.settled.total_tax)) + '</div>' +
        '<div class="note mt">' + esc(g.disclaimer) + '</div>' +
        '<div class="tabs mt no-print">' + tabs.map(function (t) { return '<button data-g="' + t[0] + '" class="' + (tab === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; }).join('') + '</div><div id="gBody"></div>';
      function show() {
        UI.destroyCharts();
        UI.$('#gBody', body).innerHTML = content[tab]();
        UI.$$('[data-g]', body).forEach(function (b) { b.classList.toggle('on', b.dataset.g === tab); });
        if (tab === 'summary') UI.chart(UI.$('#gC', body), { labels: g.monthly.map(function (m) { return fmt.month(m.period); }), datasets: [{ label: 'Output', data: g.monthly.map(function (m) { return m.output; }), slot: 0 }, { label: 'Input', data: g.monthly.map(function (m) { return m.input; }), slot: 1 }] });
      }
      UI.$$('[data-g]', body).forEach(function (b) { b.onclick = function () { tab = b.dataset.g; show(); }; });
      show();
    }
  });
} };

// =============================================================================
// Analytics
// =============================================================================
Pages.analytics = { render: function (root) {
  var fmt = UI.fmt;
  periodReport(root, {
    title: 'Analytics', sub: 'Revenue, customer, vendor and product analytics', action: 'getAnalytics',
    render: function (body, a) {
      var gran = 'monthly';
      body.innerHTML = '<div class="card"><div class="card-head"><h3>Revenue</h3><div class="seg" id="gran">' + ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'].map(function (g) { return '<button data-g="' + g + '" class="' + (g === gran ? 'on' : '') + '">' + g[0].toUpperCase() + g.slice(1) + '</button>'; }).join('') + '</div></div><div class="card-body"><div class="chart-box tall" id="aR"></div></div></div>' +
        '<div class="kpis mt">' + UI.kpi('Active customers', a.customers.top.length) + UI.kpi('New customers', a.customers.newCount) + UI.kpi('Repeat customers', a.customers.repeatCount) + UI.kpi('Inactive customers', a.customers.inactive.length, 'no sale in the configured window') + '</div>' +
        '<div class="grid g2 mt">' + UI.card('Top customers', UI.staticTable([{ key: 'customer', label: 'Customer' }, { key: 'type', label: 'Type', type: 'badge' }, { key: 'invoices', label: 'Invoices', type: 'num' }, { key: 'amount', label: 'Revenue', type: 'inr' }, { key: 'share', label: 'Share', type: 'pct' }, { key: 'outstanding', label: 'Outstanding', type: 'inr' }], a.customers.top), { flush: true }) +
        UI.card('Top vendors', UI.staticTable([{ key: 'vendor', label: 'Vendor' }, { key: 'bills', label: 'Bills', type: 'num' }, { key: 'amount', label: 'Purchases', type: 'inr' }, { key: 'share', label: 'Share', type: 'pct' }, { key: 'outstanding', label: 'Outstanding', type: 'inr' }, { key: 'risk', label: 'Overdue %', type: 'pct' }], a.vendors), { flush: true }) + '</div>' +
        '<div class="grid g2 mt">' + UI.card('Products', UI.staticTable([{ key: 'product', label: 'Product' }, { key: 'quantity', label: 'Qty', type: 'num' }, { key: 'revenue', label: 'Revenue', type: 'inr' }, { key: 'avg_price', label: 'Avg price', type: 'inr' }, { key: 'est_margin_pct', label: 'Est. margin', type: 'pct' }], a.products), { flush: true, sub: a.notes[0] }) +
        UI.card('Inactive customers', UI.staticTable([{ key: 'customer', label: 'Customer' }, { key: 'last_sale', label: 'Last sale', type: 'date' }, { key: 'days_since', label: 'Days since', type: 'num' }], a.customers.inactive, { emptyText: 'Every customer bought recently.' }), { flush: true }) + '</div>';
      function draw() {
        UI.destroyCharts();
        var rows = a.revenue[gran];
        UI.chart(UI.$('#aR', body), { type: rows.length > 24 ? 'line' : 'bar', labels: rows.map(function (r) { return gran === 'monthly' ? fmt.month(r.key) : gran === 'daily' || gran === 'weekly' ? fmt.date(r.key).slice(0, 6) : r.key; }), datasets: [{ label: 'Revenue', data: rows.map(function (r) { return r.amount; }) }] });
      }
      UI.$$('#gran button', body).forEach(function (b) { b.onclick = function () { gran = b.dataset.g; UI.$$('#gran button', body).forEach(function (x) { x.classList.toggle('on', x === b); }); draw(); }; });
      draw();
    }
  });
} };

// =============================================================================
// Financial health - every metric shows its formula and source figures
// =============================================================================
Pages.health = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  periodReport(root, {
    title: 'Financial Health', sub: 'Ratios with the formula and the exact figures used', action: 'getFinancialHealth',
    render: function (body, h) {
      function val(m) { if (m.value === null) return 'n/a'; return m.unit === '₹' ? fmt.inr(m.value) : m.unit === '%' ? fmt.pct(m.value) : m.unit === 'x' ? m.value.toFixed(2) + 'x' : fmt.num(m.value, 1) + ' ' + m.unit; }
      var tone = { good: 'good', bad: 'bad', warn: 'warn' };
      body.innerHTML = '<div class="grid g3">' + h.metrics.map(function (m) {
        return '<div class="card"><div class="card-body"><div style="display:flex;justify-content:space-between;gap:8px"><span class="small muted">' + esc(m.label) + '</span>' + (tone[m.status] ? UI.badge(m.status === 'good' ? 'Healthy' : m.status === 'bad' ? 'Attention' : 'Watch', tone[m.status]) : '') + '</div>' +
          '<div style="font-size:22px;font-weight:600;margin:4px 0 8px">' + esc(val(m)) + '</div><div class="formula">' + esc(m.formula) + '</div>' +
          '<details class="mt"><summary class="small muted" style="cursor:pointer">Source figures</summary>' + Object.keys(m.inputs).map(function (k) { var v = m.inputs[k]; return '<div class="stat-line small"><span class="muted">' + esc(k) + '</span><span>' + (v === null || v === undefined ? 'n/a' : typeof v === 'number' && Math.abs(v) >= 1000 ? fmt.inr(v) : esc(v)) + '</span></div>'; }).join('') + '</details></div></div>';
      }).join('') + '</div><div class="note mt">Period ' + fmt.date(h.from) + ' to ' + fmt.date(h.to) + ' (' + h.days + ' days). Growth metrics compare with ' + fmt.date(h.previous.from) + ' to ' + fmt.date(h.previous.to) + '. Thresholds are indicative for a manufacturing SME.</div>';
    }
  });
} };
