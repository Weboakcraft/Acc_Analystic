"""Client for the Accounts Dashboard Google Apps Script web app.

Protocol: ``POST <APPS_SCRIPT_URL>`` with ``Content-Type:
text/plain;charset=utf-8`` (a "simple" request, so no CORS preflight) and a
JSON body ``{"action", "api_key", "params"}``. Apps Script answers with a 302
redirect to ``script.googleusercontent.com`` which urllib follows with a GET;
the final body is ``{"ok": true, "data": ...}`` or ``{"ok": false, "error":
{"code", "message"}}``.
"""

from __future__ import annotations

import http.client
import json
import logging
import random
import re
import time
import urllib.error
import urllib.request
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Callable, Dict, Optional

from . import __version__

log = logging.getLogger("tally_connector.api")

# Server error codes that are safe to retry (the server de-duplicates by unique_key).
RETRYABLE_SERVER_CODES = {"LOCK_TIMEOUT", "BUSY", "RATE_LIMITED", "TIMEOUT", "INTERNAL", "SERVICE_UNAVAILABLE"}
_RETRYABLE_HTML_RE = re.compile(r"too many times|try again|temporar|timed out|service unavailable|rate limit", re.I)


class ApiError(Exception):
    """The Apps Script call failed (network, HTTP, non-JSON or ``ok: false``)."""

    def __init__(self, code: str, message: str, http_status: Optional[int] = None,
                 retryable: bool = False, retry_after: Optional[float] = None) -> None:
        super().__init__("%s: %s" % (code, message))
        self.code = code
        self.message = message
        self.http_status = http_status
        self.retryable = retryable
        self.retry_after = retry_after


def _json_default(value: Any) -> Any:
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, set):
        return sorted(value)
    raise TypeError("Object of type %s is not JSON serializable" % type(value).__name__)


def _html_title(text: str) -> str:
    match = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
    return " ".join(match.group(1).split()) if match else ""


class AppsScriptClient:
    """Calls connector actions on the Apps Script web app with retries."""

    def __init__(
        self,
        url: str,
        api_key: str,
        timeout: float = 300.0,
        retries: int = 4,
        backoff: float = 2.0,
        max_backoff: float = 60.0,
        opener=None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if not url:
            raise ValueError("Apps Script URL is required")
        if not api_key:
            raise ValueError("Connector API key is required")
        self.url = url.strip()
        self._api_key = api_key
        self.timeout = float(timeout)
        self.retries = max(0, int(retries))
        self.backoff = float(backoff)
        self.max_backoff = float(max_backoff)
        self._opener = opener or urllib.request.build_opener()
        self._sleep = sleep

    def __repr__(self) -> str:  # never leak the key
        return "AppsScriptClient(url=%r)" % self.url

    def call(self, action: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Invoke ``action`` and return its ``data``; raises :class:`ApiError`."""
        body = json.dumps(
            {"action": action, "api_key": self._api_key, "params": params or {}},
            ensure_ascii=False, default=_json_default, allow_nan=False,
        ).encode("utf-8")
        attempt = 0
        while True:
            started = time.monotonic()
            try:
                data = self._call_once(body)
                log.debug("%s ok in %.1fs", action, time.monotonic() - started)
                return data
            except ApiError as exc:
                if not exc.retryable or attempt >= self.retries:
                    raise
                delay = min(self.max_backoff, self.backoff * (2 ** attempt)) * (0.75 + random.random() * 0.5)
                if exc.retry_after:
                    delay = max(delay, float(exc.retry_after))
                attempt += 1
                log.warning("%s failed (%s); retry %d/%d in %.1fs", action, exc, attempt, self.retries, delay)
                self._sleep(delay)

    # -- internals ----------------------------------------------------------
    def _call_once(self, body: bytes) -> Any:
        request = urllib.request.Request(
            self.url, data=body, method="POST",
            headers={
                "Content-Type": "text/plain;charset=utf-8",
                "Accept": "application/json",
                "User-Agent": "Accounts DashboardTallyConnector/%s" % __version__,
            },
        )
        try:
            with self._opener.open(request, timeout=self.timeout) as response:
                status = int(getattr(response, "status", None) or response.getcode() or 200)
                content_type = response.headers.get("Content-Type", "") if response.headers else ""
                raw = response.read()
        except urllib.error.HTTPError as exc:
            try:
                raw = exc.read() or b""
            except Exception:  # noqa: BLE001
                raw = b""
            status = exc.code
            retry_after = None
            header = exc.headers.get("Retry-After") if exc.headers else None
            if header and str(header).strip().isdigit():
                retry_after = float(str(header).strip())
            text = raw.decode("utf-8", errors="replace")
            detail = _html_title(text) or text.strip()[:200]
            hint = ""
            if status in (401, 403):
                hint = (" Check the web app deployment: 'Execute as: Me' and 'Who has access: Anyone', "
                        "and that the URL is the /exec URL of the current deployment.")
            elif status == 404:
                hint = " The Apps Script URL looks wrong or the deployment was removed."
            raise ApiError("HTTP_%d" % status, "Apps Script returned HTTP %d%s.%s"
                           % (status, (": " + detail) if detail else "", hint),
                           http_status=status,
                           retryable=status in (408, 429) or status >= 500,
                           retry_after=retry_after) from exc
        except (OSError, http.client.HTTPException) as exc:
            reason = getattr(exc, "reason", None) or exc
            raise ApiError("NETWORK_ERROR", "Could not reach Apps Script (%s)." % reason,
                           retryable=True) from exc
        return self._parse(status, content_type, raw)

    @staticmethod
    def _parse(status: int, content_type: str, raw: bytes) -> Any:
        text = raw.decode("utf-8", errors="replace").lstrip("﻿").strip()
        if not text:
            raise ApiError("EMPTY_RESPONSE", "Apps Script returned an empty response.",
                           http_status=status, retryable=True)
        if text.startswith("<") or "text/html" in (content_type or "").lower():
            title = _html_title(text)
            retryable = bool(_RETRYABLE_HTML_RE.search(text[:5000]))
            raise ApiError(
                "NON_JSON_RESPONSE",
                "Apps Script returned an HTML page instead of JSON%s. This usually means the web app "
                "deployment is not accessible: deploy it with 'Execute as: Me' and 'Who has access: "
                "Anyone', use the /exec URL (not /dev), and re-deploy after code changes."
                % ((" (" + title + ")") if title else ""),
                http_status=status, retryable=retryable)
        try:
            payload = json.loads(text)
        except ValueError:
            raise ApiError("INVALID_JSON", "Apps Script returned invalid JSON: %r" % text[:200],
                           http_status=status) from None
        if not isinstance(payload, dict) or "ok" not in payload:
            raise ApiError("INVALID_RESPONSE", "Unexpected response shape: %r" % text[:200], http_status=status)
        if payload.get("ok") is True:
            data = payload.get("data")
            return data if data is not None else {}
        error = payload.get("error") or {}
        if not isinstance(error, dict):
            error = {"message": str(error)}
        code = str(error.get("code") or "SERVER_ERROR")
        message = str(error.get("message") or "Unknown server error")
        raise ApiError(code, message, http_status=status, retryable=code in RETRYABLE_SERVER_CODES)


__all__ = ["AppsScriptClient", "ApiError", "RETRYABLE_SERVER_CODES"]
