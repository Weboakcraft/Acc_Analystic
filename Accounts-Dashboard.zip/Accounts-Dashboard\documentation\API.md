# API reference

Base URL: the Apps Script web-app URL (`https://script.google.com/macros/s/<id>/exec`).

Apps Script web apps accept only GET and POST, so every call is routed by `action`:

```http
POST /exec
Content-Type: text/plain;charset=utf-8        (text/plain avoids a CORS pre-flight)

{ "action": "getSales", "token": "<session token>", "params": { "preset": "this_month", "page": 1, "pageSize": 25 } }
```

- `GET /exec?action=health` is public. Reads can also use `GET ?action=<name>&token=…&params=<url-encoded JSON>`, but prefer POST so the token stays out of URLs and logs.
- Updates and deletes (PUT/PATCH/DELETE) are expressed as actions (`updateSetting`, `cancelVoucher`, …). Financial records are never hard-deleted: cancelling is a soft delete with a reason in the audit log.
- Success: `{ "ok": true, "data": …, "meta": { "action", "ms", "version" } }`
- Error: `{ "ok": false, "error": { "code", "message", "details"? } }`. Codes include `UNAUTHENTICATED`, `FORBIDDEN`, `VALIDATION`, `INVALID_INVOICE`, `DUPLICATE_VOUCHER`, `UNBALANCED`, `NOT_FOUND`, `LOCK_TIMEOUT`, `SHEETS_ERROR`, `CONFIG`, `INTERNAL`.

**Common params.** Period: `preset` (today, yesterday, this_week, this_month, previous_month, this_quarter, current_fy, previous_fy, custom) or `from`/`to` (YYYY-MM-DD). Paging: `page`, `pageSize` (≤1000), `sort`, `dir` (asc/desc), `q` (text filter). Paged responses: `{ rows, total, page, pageSize, pages }`.

## Auth
| Action | Perm | Params | Returns |
|---|---|---|---|
| `health` | public | - | status, versions |
| `login` | public | email, password | token, user {email, name, role, permissions}, expiresIn |
| `logout` / `me` | session | - | - / user |

## Dashboards & insight
| Action | Perm | Params | Returns |
|---|---|---|---|
| `getDashboard` | view.dashboard | date? | today (sales bills/amount, offline split, purchases, receipts, payments, net cash flow, expenses), cash/bank, receivables/payables, overdue, MTD/YTD, 30-day trend, monthly trend, ageing buckets, top overdue, top customers, last sync |
| `getManagementDashboard` | view.reports | date? | q1…q15 answers |
| `getFinancialHealth` | view.reports | period | metrics[] {key, label, value, unit, formula, inputs, status} |
| `getAnalytics` | view.reports | period | revenue daily/weekly/monthly/quarterly/yearly, customers (top/new/repeat/inactive), vendors, products |
| `getAlerts` | view.dashboard | date? | alerts[], counts |
| `searchTransactions` | view.accounts | q | results[] (voucher / ledger / customer / vendor) by invoice, voucher no., party, GSTIN, mobile, reference, ID |
| `getLookups` | view.lookup | - | ledger lists, groups, products, salespersons, cost centres, bank accounts, payment-mode map |

## Registers & parties
| Action | Perm | Params | Returns |
|---|---|---|---|
| `getSales` | view.accounts | period, customer, status, source, salesperson + paging | rows (invoice, party, taxable, GST split, amount, paid, outstanding, due, status, source), totals incl. bySource |
| `getSalesReport` | view.accounts | period, groupBy = day/week/month/quarter/year/customer/product/salesperson/gst_rate/state/source/channel | rows {key, count, taxable, tax, amount, share} |
| `getPurchases` / `getPurchaseReport` | view.accounts | as above (vendor) | as above |
| `getCustomers` / `getVendors` | view.accounts | period + paging | party ledgers: opening, invoices, notes, settlements, adjustments, closing, open/overdue bills, profile |
| `getReceivables` / `getPayables` | view.accounts | asOf, party, status, bucket + paging | total, current, overdue, 30/60/90/180/365+ overdue, bucketTotals, parties[], bills (paged) |
| `getAgeing` | view.accounts | kind = receivable/payable | same as above |
| `getPartyAccounts` | view.accounts | kind, period | unpaged party summary |
| `getReceipts` / `getPayments` | view.accounts | period, party + paging | rows, total_amount |
| `getExpenses` | submit.expenses \| view.accounts | period, status, category + paging | rows, byCategory, byMonth, pending |
| `getVoucher` | view.accounts | voucher_id | header, lines, bills, items, totals, balanced |

## Ledgers, cash & bank, statements
| Action | Perm | Params | Returns |
|---|---|---|---|
| `getLedgers` | view.accounts | period, group + paging | ledger, group, opening, debit, credit, closing |
| `getLedgerStatement` | view.accounts | ledger, period, voucherType? | opening, rows (date, voucher, particulars, Dr, Cr, running balance, reference, narration), closing |
| `getCashBook` | view.accounts | period, ledger? | accounts (opening/in/out/closing), rows (paged), cash, bank |
| `getBankTransactions` | view.accounts | bank_account_id, status | statement lines, accounts, reconciliation summary |
| `getTrialBalance` | view.reports | period | rows (opening/period/closing Dr & Cr), totals, balanced, difference, openingDifference, unbalancedVouchers |
| `getProfitLoss` | view.reports | period, comparative? | lines (revenue → net profit with ledger detail), margins, trend / comparative (current & previous month, YTD, previous FY) |
| `getBalanceSheet` | view.reports | asOf | assets[], liabilities[] (sections → groups), totals, balanced, difference |
| `getCashFlow` | view.reports | period | opening, sections (Operating/Investing/Financing lines), inflow, outflow, net, closing, reconciles |
| `getGSTSummary` | view.reports | period + paging | output/input/settled/net per head, monthly, customers, vendors, states, HSN outward/inward, transactions (paged), disclaimer |
| `getInventory` | view.accounts | asOf | stockValue, valuations, products |

## Writes
All writes run under the script lock, check the voucher balances, and write an audit entry.

| Action | Perm | Params |
|---|---|---|
| `saveOfflineSale` | write.offline_sales | invoice_no? (auto OFF/2627/0001), invoice_date, customer_name, customer_gstin, mobile, address, state, items[{product, hsn_sac, qty, uom, rate, discount_pct, tax_rate}], payment_mode (Cash/UPI/Bank Transfer/Cheque/Credit/Other), paid_amount, credit_days, salesperson, remarks, instrument_no |
| `saveReceipt` / `savePayment` | write.transactions | date, number?, party_ledger, bank_ledger, amount, tds_amount, mode, against_bill (blank = on account), instrument_no, narration |
| `saveJournal` | write.transactions | date, number?, journal_type, narration, lines[{ledger_name, debit, credit, cost_centre}] |
| `cancelVoucher` | write.transactions | voucher_id, reason (non-Tally vouchers only) |
| `saveExpense` | submit.expenses | expense_date, category, expense_ledger, vendor_ledger, amount, gst_rate/gst_amount, payment_mode, paid_from_ledger, cost_centre, receipt_url (https), description |
| `approveExpense` / `rejectExpense` | approve.expenses | expense_id (+ reason for reject; approver ≠ creator) |
| `createLedger` | write.masters | ledger_name, parent_group, opening_balance, opening_dr_cr, mis_category, tax_type, gstin, state, credit_days |
| `createCustomer` / `createVendor` | write.masters | name, gstin, mobile, email, state, credit_days, opening, credit_limit / msme_registered |
| `importBankStatement` | reconcile.bank | bank_account_id, rows[{date, description, reference, debit, credit, balance}] |
| `autoReconcile` / `setBankMatch` | reconcile.bank | bank_account_id / bank_txn_id, voucher_id ('' = unmatch), remarks |
| `resolveNotification` | resolve.alerts | dedupe_key |

## Tally
| Action | Auth | Params | Returns |
|---|---|---|---|
| `getTallyStatus` | view.tally | - | lastSuccess, connectorLastSeen, pending, unresolvedErrors, voucherCounts, config, recent |
| `getSyncLog` / `getTallyErrors` | view.tally | paging | rows |
| `getTallyData` | view.tally | voucher_id or unique_key | original XML (all chunks joined) |
| `requestTallySync` | run.sync | mode, from_date, to_date, voucher_type, voucher_number, ledger | queued sync_id |
| `resolveTallyError` | run.sync | error_id | - |
| `tallyConfig` | api_key | company | last_alter_id, last_success_at, config, pending_requests |
| `tallySyncStart` | api_key | company, mode, from_date, to_date, from_alter_id, request_sync_id?, connector_host, connector_version | sync_id |
| `tallyIngestMasters` | api_key | sync_id, company, groups[], ledgers[], voucher_types[], stock_items[], cost_centres[] | added/updated/skipped per type, profiles created |
| `syncTallyData` | api_key | sync_id, company, vouchers[≤500 normalized], reconcile? {from_date, to_date, unique_keys[]} | added, updated, skipped, failed, deleted, errors[] |
| `tallySyncFinish` | api_key | sync_id, status (SUCCESS/PARTIAL/FAILED), records_fetched, to_alter_id, error | - |

Normalized voucher: `{ header: {unique_key, voucher_date, voucher_type, base_voucher_type, voucher_number, reference_no, reference_date, party_ledger, party_gstin, place_of_supply, amount, narration, salesperson, cost_centre, status, tally_guid, tally_master_id, tally_alter_id}, lines: [{line_no, ledger_name, debit, credit, is_party_line, cost_centre}], bills: [{party_ledger, bill_name, bill_type, bill_date, due_date, credit_days, amount, dr_cr}], items: [...], gst: {taxable, cgst, sgst, igst, cess}, raw_xml }`.

## Admin
| Action | Perm | Params |
|---|---|---|
| `getSettings` / `updateSetting` | admin.settings | key, value (validated against engine defaults) |
| `updateConfig` | admin.settings | key, value, category (secret-looking keys refused) |
| `getUsers` / `createUser` / `updateUser` | admin.users | email, full_name, role, password (≥10, letters + digits), status |
| `getAuditLog` | view.audit | period, action_type, entity, user, record_id + paging |
| `rebuildReportSnapshots` / `runAlertScan` | admin.settings | - |

## Roles
| Role | Permissions |
|---|---|
| ADMIN | everything |
| ACCOUNTANT | view dashboard/accounts/reports/tally; post transactions, offline sales, masters; submit expenses; run sync; reconcile bank |
| FINANCE_MANAGER | view all incl. audit; approve expenses; run sync; reconcile; resolve alerts |
| MANAGEMENT | dashboards, accounts and reports (read-only) |
| DATA_ENTRY | offline sales, receipts/payments entry, expense submission only |
| AUDITOR | read-only everything + audit trail |
