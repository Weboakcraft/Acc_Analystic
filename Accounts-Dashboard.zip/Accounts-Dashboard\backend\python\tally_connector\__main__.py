"""Command line interface.

    python -m tally_connector sync --mode incremental|full|date|voucher|ledger|masters
                              [--from YYYY-MM-DD] [--to YYYY-MM-DD] [--voucher-type NAME]
                              [--voucher-number NO] [--ledger NAME] [--dry-run]
    python -m tally_connector watch [--once]
    python -m tally_connector test-connection
    python -m tally_connector export --out FILE.json [--from ..] [--to ..]
                              [--tally-xml FILE.xml [--masters-xml FILE.xml]] [--no-raw]

Exit codes: 0 success, 1 failed, 2 configuration/usage error, 3 partial
(some vouchers failed), 130 interrupted.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from datetime import datetime
from typing import Any, Dict, Optional

from . import __version__
from .api_client import ApiError, AppsScriptClient
from .config import AppConfig, ConfigError, load_config
from .logging_setup import setup_logging
from .normalizer import NormalizerContext, normalize_masters, strip_private, to_flat_transactions
from .sync_engine import SyncEngine, SyncRequest, fy_end, fy_start, process_voucher_elements
from .tally_client import TallyClient, TallyError
from .validators import clean_masters
from .xml_parser import TallyParseError, extract_masters, extract_vouchers, parse_tally_date, parse_xml

CLI_MODES = {
    "incremental": "INCREMENTAL",
    "full": "FULL",
    "date": "DATE_RANGE",
    "voucher": "VOUCHER",
    "ledger": "LEDGER",
    "masters": "MASTERS",
}
EXIT_OK, EXIT_FAILED, EXIT_USAGE, EXIT_PARTIAL, EXIT_INTERRUPTED = 0, 1, 2, 3, 130

log = logging.getLogger("tally_connector.cli")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m tally_connector",
        description="Accounts Dashboard on-premise Tally connector.")
    parser.add_argument("--config", "-c", help="path to config.ini (default: ./config.ini or $ACCOUNTS_CONNECTOR_CONFIG)")
    parser.add_argument("--company", help="override [tally] company")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], help="override [sync] log_level")
    parser.add_argument("--version", action="version", version="%(prog)s " + __version__)
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    sync = sub.add_parser("sync", help="run one sync now")
    sync.add_argument("--mode", choices=sorted(CLI_MODES), default="incremental")
    sync.add_argument("--from", dest="from_date", help="start date YYYY-MM-DD")
    sync.add_argument("--to", dest="to_date", help="end date YYYY-MM-DD")
    sync.add_argument("--voucher-type", help="voucher type name (mode voucher)")
    sync.add_argument("--voucher-number", help="voucher number (mode voucher)")
    sync.add_argument("--ledger", help="ledger name (mode ledger)")
    sync.add_argument("--dry-run", action="store_true",
                      help="fetch, normalize and validate only; send nothing to the server")

    watch = sub.add_parser("watch", help="run continuously: UI sync requests + incremental every interval")
    watch.add_argument("--once", action="store_true", help="run a single poll cycle and exit")

    sub.add_parser("test-connection", help="check Tally and the Apps Script web app")

    export = sub.add_parser("export", help="write normalized data to a JSON file for offline inspection")
    export.add_argument("--out", required=True, help="output JSON file")
    export.add_argument("--from", dest="from_date", help="start date YYYY-MM-DD (live Tally only)")
    export.add_argument("--to", dest="to_date", help="end date YYYY-MM-DD (live Tally only)")
    export.add_argument("--tally-xml", help="parse a saved Tally XML export instead of calling Tally")
    export.add_argument("--masters-xml", help="saved masters XML to use with --tally-xml")
    export.add_argument("--no-raw", action="store_true", help="omit raw_xml from vouchers")
    return parser


def _make_tally(cfg: AppConfig) -> TallyClient:
    t = cfg.tally
    return TallyClient(t.url, t.company, timeout=t.timeout, retries=t.retries, export_mode=t.export_mode,
                       request_encoding=t.request_encoding, chunk_days=t.chunk_days)


def _make_api(cfg: AppConfig) -> Optional[AppsScriptClient]:
    if not cfg.api.configured:
        return None
    return AppsScriptClient(cfg.api.apps_script_url, cfg.api.api_key, timeout=cfg.api.timeout,
                            retries=cfg.api.retries)


def _print_report(report: Dict[str, Any]) -> None:
    c = report["counts"]
    print("Sync %s: %s%s" % (report.get("sync_id") or "-", report["status"], " (dry run)" if report.get("dry_run") else ""))
    print("  mode %s  range %s..%s  AlterID %s -> %s" % (report["mode"], report.get("from_date") or "-",
                                                         report.get("to_date") or "-", report.get("from_alter_id"),
                                                         report.get("to_alter_id")))
    print("  fetched %d  unique %d  duplicates %d  valid %d  invalid %d  non-accounting %d  sent %d"
          % (c["fetched"], c["unique"], c["duplicates"], c["valid"], c["invalid"], c["non_accounting_skipped"], c["sent"]))
    print("  server: added %d  updated %d  skipped %d  failed %d" % (c["added"], c["updated"], c["skipped"], c["failed"]))
    masters = report.get("masters") or {}
    if masters.get("fetched"):
        print("  masters: %s%s" % (", ".join("%s=%d" % kv for kv in masters["fetched"].items()),
                                   " (ingested)" if masters.get("ingested") else ""))
    for item in (report.get("invalid_vouchers") or [])[:20]:
        print("  INVALID %s %s: %s" % (item.get("voucher_number") or "?", item.get("voucher_date") or "",
                                        "; ".join(e.get("message", "") for e in item.get("errors") or [])))
    if report.get("error"):
        print("  error: %s" % report["error"])
    if report.get("report_path"):
        print("  report: %s" % report["report_path"])


def cmd_sync(cfg: AppConfig, args: argparse.Namespace) -> int:
    request = SyncRequest(mode=CLI_MODES[args.mode], from_date=args.from_date or "", to_date=args.to_date or "",
                          voucher_type=args.voucher_type or "", voucher_number=args.voucher_number or "",
                          ledger=args.ledger or "")
    try:
        request.normalized()
    except ValueError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return EXIT_USAGE
    engine = SyncEngine(cfg, _make_tally(cfg), _make_api(cfg))
    report = engine.run(request, dry_run=args.dry_run)
    _print_report(report)
    return {"SUCCESS": EXIT_OK, "PARTIAL": EXIT_PARTIAL}.get(report["status"], EXIT_FAILED)


def cmd_watch(cfg: AppConfig, args: argparse.Namespace) -> int:
    engine = SyncEngine(cfg, _make_tally(cfg), _make_api(cfg))
    engine.watch(max_cycles=1 if args.once else None)
    return EXIT_OK


def cmd_test_connection(cfg: AppConfig, args: argparse.Namespace) -> int:
    ok = True
    tally = _make_tally(cfg)
    print("Tally XML server %s" % cfg.tally.url)
    try:
        info = tally.ping()
        print("  reachable: yes")
        print("  open companies: %s" % (", ".join(info["companies"]) or "(none)"))
        if info["company_open"]:
            print("  company '%s': OPEN" % cfg.tally.company)
            masters = tally.fetch_masters()
            print("  masters readable: %s" % ", ".join("%s=%d" % (k, len(v)) for k, v in masters.items()))
        else:
            ok = False
            print("  company '%s': NOT OPEN - open it in Tally (or fix [tally] company)" % cfg.tally.company)
    except (TallyError, TallyParseError) as exc:
        ok = False
        print("  ERROR: %s" % exc)

    api = _make_api(cfg)
    print("Apps Script web app %s" % (cfg.api.apps_script_url or "(not configured)"))
    if api is None:
        missing = []
        if not cfg.api.apps_script_url:
            missing.append("[api] apps_script_url")
        if not cfg.api.api_key:
            missing.append("environment variable %s" % cfg.api.api_key_env)
        print("  SKIPPED: set %s" % " and ".join(missing))
    else:
        try:
            data = api.call("tallyConfig", {"company": cfg.tally.company}) or {}
            print("  reachable: yes (API key accepted)")
            print("  last_alter_id: %s  last_success_at: %s  pending requests: %d"
                  % (data.get("last_alter_id"), data.get("last_success_at") or "-",
                     len(data.get("pending_requests") or [])))
        except ApiError as exc:
            ok = False
            print("  ERROR: %s" % exc)
    print("RESULT: %s" % ("OK" if ok else "PROBLEMS FOUND"))
    return EXIT_OK if ok else EXIT_FAILED


def cmd_export(cfg: AppConfig, args: argparse.Namespace) -> int:
    company = cfg.tally.company
    from_d = to_d = ""
    if args.tally_xml:
        with open(args.tally_xml, "rb") as fh:
            root = parse_xml(fh.read())
        elements = extract_vouchers(root)
        if args.masters_xml:
            with open(args.masters_xml, "rb") as fh:
                masters_raw = extract_masters(parse_xml(fh.read()))
        else:
            masters_raw = extract_masters(root)
        source = os.path.abspath(args.tally_xml)
    else:
        today = datetime.now().date()
        from_d = parse_tally_date(args.from_date or cfg.sync.from_date) or fy_start(today).isoformat()
        to_d = parse_tally_date(args.to_date) or fy_end(today).isoformat()
        if (args.from_date and not parse_tally_date(args.from_date)) or (args.to_date and not parse_tally_date(args.to_date)):
            print("error: dates must look like 2026-04-01", file=sys.stderr)
            return EXIT_USAGE
        tally = _make_tally(cfg)
        masters_raw = tally.fetch_masters()
        elements = tally.fetch_vouchers(from_d, to_d)
        source = cfg.tally.url

    masters, problems = clean_masters(normalize_masters(masters_raw))
    context = NormalizerContext.from_masters(masters)
    processed = process_voucher_elements(elements, company, context)
    timestamp = datetime.now().replace(microsecond=0).isoformat()
    transactions = []
    for voucher in processed.valid:
        transactions.extend(to_flat_transactions(voucher, timestamp))
    vouchers = [strip_private(v) for v in processed.valid]
    if args.no_raw:
        for voucher in vouchers:
            voucher.pop("raw_xml", None)
    output = {
        "company": company,
        "exported_at": timestamp,
        "connector_version": __version__,
        "source": source,
        "from_date": from_d,
        "to_date": to_d,
        "counts": {
            "fetched": processed.fetched, "unique": processed.unique, "duplicates": processed.duplicates,
            "valid": len(processed.valid), "invalid": len(processed.invalid),
            "non_accounting": len(processed.non_accounting), "transactions": len(transactions),
            "masters": {k: len(v) for k, v in masters.items()},
        },
        "masters": masters,
        "master_problems": problems,
        "vouchers": vouchers,
        "invalid_vouchers": processed.invalid,
        "non_accounting_vouchers": processed.non_accounting,
        "warnings": processed.warnings,
        "transactions": transactions,
    }
    out_dir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(out_dir, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(output, fh, indent=2, ensure_ascii=False)
    print("Wrote %s: %d valid voucher(s), %d invalid, %d transaction row(s), masters %s"
          % (args.out, len(processed.valid), len(processed.invalid), len(transactions),
             ", ".join("%s=%d" % (k, len(v)) for k, v in masters.items())))
    for item in processed.invalid[:20]:
        print("  INVALID %s: %s" % (item.get("voucher_number") or item.get("unique_key"),
                                    "; ".join(e.get("message", "") for e in item.get("errors") or [])))
    return EXIT_OK


COMMANDS = {
    "sync": cmd_sync,
    "watch": cmd_watch,
    "test-connection": cmd_test_connection,
    "export": cmd_export,
}


def main(argv: Optional[list] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    env = dict(os.environ)
    if args.company:
        env["ACCOUNTS_TALLY_COMPANY"] = args.company
    require_api = args.command == "watch" or (args.command == "sync" and not args.dry_run)
    try:
        cfg = load_config(args.config, env=env, require_api=require_api)
    except ConfigError as exc:
        print(str(exc), file=sys.stderr)
        return EXIT_USAGE
    setup_logging(cfg.sync.log_dir, args.log_level or cfg.sync.log_level, console=True,
                  secrets=[cfg.api.api_key])
    try:
        return COMMANDS[args.command](cfg, args)
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return EXIT_INTERRUPTED
    except (TallyError, TallyParseError, ApiError) as exc:
        log.error("%s", exc)
        return EXIT_FAILED
    except OSError as exc:
        log.error("File/network error: %s", exc)
        return EXIT_FAILED


if __name__ == "__main__":
    sys.exit(main())
