/**
 * Tally integration - server side.
 *
 * Tally (LAN) -> Python connector (on-prem) -> [this file] -> Google Sheets -> frontend
 *
 * The connector fetches, validates and normalizes Tally XML, then calls:
 *   tallyConfig -> tallySyncStart -> tallyIngestMasters -> syncTallyData (batches) -> tallySyncFinish
 *
 * Guarantees
 *   - Idempotent: the same voucher is never imported twice (unique_key = GUID, else company|type|number|date).
 *   - Alterations: a higher Tally ALTERID creates a new revision; old lines stay for history but stop counting.
 *   - Atomic per voucher: a voucher that fails validation is logged to TALLY_ERRORS and nothing of it is posted.
 *   - Deletions: a FULL/DATE_RANGE sync sends every key Tally returned; missing ones become DELETED_IN_TALLY.
 *   - Raw XML is preserved in TALLY_RAW_DATA.
 */
var RAW_CHUNK = 45000;

var Tally = {
  companyByName_: function (name) {
    var n = String(name || '').toLowerCase();
    var c = Db.read('COMPANIES').filter(function (x) { return String(x.tally_company_name || x.company_name).toLowerCase() === n || String(x.company_name).toLowerCase() === n; })[0];
    if (!c) throw new AppError('CONFIG', 'Company "' + name + '" is not in COMPANIES. Add it (tally_company_name must match Tally exactly).');
    return c;
  },

  // ---- connector: configuration & watermark ------------------------------------
  config: function (p) {
    var c = Tally.companyByName_(p.company);
    var maxAlter = 0;
    Db.read('VOUCHERS').forEach(function (v) { if (v.company_id === c.company_id && v.source === 'TALLY') maxAlter = Math.max(maxAlter, Number(v.tally_alter_id) || 0); });
    var logs = Db.read('TALLY_SYNC_LOG').filter(function (l) { return String(l.company).toLowerCase() === String(p.company).toLowerCase(); });
    var lastOk = logs.filter(function (l) { return l.status === 'SUCCESS'; }).sort(function (a, b) { return b.end_time - a.end_time; })[0];
    var cfg = {};
    Db.read('CONFIG').forEach(function (r) { if (r.category === 'TALLY' || r.category === 'SYNC') cfg[r.config_key] = String(r.config_value); });
    var pending = plain_(logs.filter(function (l) { return l.status === 'REQUESTED'; })).map(function (l) {
      var extra = {}; try { extra = JSON.parse(l.error || '{}'); } catch (e) { extra = {}; }
      return { sync_id: l.sync_id, mode: l.mode, from_date: l.from_date, to_date: l.to_date, voucher_type: extra.voucher_type || '', ledger: extra.ledger || '', voucher_number: extra.voucher_number || '' };
    });
    return { company: c.tally_company_name || c.company_name, last_alter_id: maxAlter, last_success_at: lastOk ? plain_([lastOk])[0].end_time : null, books_begin_date: Engine.util.D(c.books_begin_date), config: cfg, pending_requests: pending };
  },

  syncStart: function (p, session) {
    Validate.required(p, ['company', 'mode']);
    Validate.oneOf(p.mode, ['FULL', 'INCREMENTAL', 'DATE_RANGE', 'VOUCHER', 'LEDGER', 'MASTERS'], 'Mode');
    var fields = { company: p.company, mode: p.mode, start_time: new Date(), from_date: p.from_date || '', to_date: p.to_date || '', from_alter_id: p.from_alter_id || 0, status: 'RUNNING', error: '', connector_host: String(p.connector_host || '') + (p.connector_version ? ' v' + p.connector_version : ''), records_fetched: 0, records_added: 0, records_updated: 0, records_skipped: 0, records_failed: 0 };
    if (p.request_sync_id) {
      Db.update('TALLY_SYNC_LOG', 'sync_id', p.request_sync_id, fields);
      return { sync_id: p.request_sync_id };
    }
    fields.requested_by = 'scheduler';
    fields.requested_at = new Date();
    var row = Db.insert('TALLY_SYNC_LOG', [fields])[0];
    return { sync_id: row.sync_id };
  },

  syncFinish: function (p, session) {
    Validate.required(p, ['sync_id', 'status']);
    Validate.oneOf(p.status, ['SUCCESS', 'PARTIAL', 'FAILED'], 'Status');
    var res = Db.update('TALLY_SYNC_LOG', 'sync_id', p.sync_id, { end_time: new Date(), status: p.status, records_fetched: Number(p.records_fetched) || 0, to_alter_id: Number(p.to_alter_id) || '', error: Validate.text(p.error, 2000) });
    var r = res.row;
    Audit.log({ action: 'SYNC', entity: 'TALLY_SYNC_LOG', record_id: p.sync_id, new_value: { status: p.status, fetched: r.records_fetched, added: r.records_added, updated: r.records_updated, skipped: r.records_skipped, failed: r.records_failed } }, session);
    if (p.status === 'FAILED') {
      Notify.raise('CRITICAL', 'SYNC_FAILED', 'Tally sync failed', (p.error || 'Unable to synchronize vouchers.').slice(0, 300), p.sync_id, 'SYNC_FAILED|' + p.sync_id, 'ACCOUNTANT');
    } else if (Number(r.records_failed) > 0) {
      Notify.raise('WARNING', 'SYNC_FAILED', 'Tally sync finished with ' + r.records_failed + ' rejected vouchers', 'See Tally Integration > Errors', p.sync_id, 'SYNC_PARTIAL|' + p.sync_id, 'ACCOUNTANT');
    }
    return { sync_id: p.sync_id, status: p.status };
  },

  bumpLog_: function (syncId, c) {
    if (!syncId) return;
    var row = Db.read('TALLY_SYNC_LOG').filter(function (l) { return l.sync_id === syncId; })[0];
    if (!row) return;
    Db.update('TALLY_SYNC_LOG', 'sync_id', syncId, {
      records_added: (Number(row.records_added) || 0) + (c.added || 0), records_updated: (Number(row.records_updated) || 0) + (c.updated || 0),
      records_skipped: (Number(row.records_skipped) || 0) + (c.skipped || 0), records_failed: (Number(row.records_failed) || 0) + (c.failed || 0)
    });
  },

  // ---- web UI: request a sync (picked up by the connector's watch loop) -------------
  requestSync: function (p, session) {
    var mode = Validate.oneOf(p.mode || 'INCREMENTAL', ['FULL', 'INCREMENTAL', 'DATE_RANGE', 'VOUCHER', 'LEDGER', 'MASTERS'], 'Mode');
    var company = Ctx.company(p);
    var name = company.tally_company_name || company.company_name;
    var open = Db.read('TALLY_SYNC_LOG').filter(function (l) { return l.status === 'REQUESTED' && String(l.company) === name; })[0];
    if (open) return { sync_id: open.sync_id, status: 'REQUESTED', message: 'A sync request is already queued.' };
    if ((mode === 'DATE_RANGE' || mode === 'LEDGER' || mode === 'VOUCHER') && !(p.from_date && p.to_date)) throw new AppError('VALIDATION', 'From and to dates are required for this sync mode.');
    var extra = { voucher_type: p.voucher_type || '', ledger: p.ledger || '', voucher_number: p.voucher_number || '' };
    var row = Db.insert('TALLY_SYNC_LOG', [{ company: name, mode: mode, requested_by: session.email, requested_at: new Date(), from_date: p.from_date || '', to_date: p.to_date || '', status: 'REQUESTED', error: JSON.stringify(extra) }])[0];
    Audit.log({ action: 'SYNC', entity: 'TALLY_SYNC_LOG', record_id: row.sync_id, new_value: { requested: mode } }, session);
    return { sync_id: row.sync_id, status: 'REQUESTED', message: 'Sync queued. The Tally connector will pick it up on its next poll.' };
  },

  status: function () {
    var logs = plain_(Db.read('TALLY_SYNC_LOG')).sort(function (a, b) { return String(b.requested_at || b.start_time) < String(a.requested_at || a.start_time) ? -1 : 1; });
    var lastOk = logs.filter(function (l) { return l.status === 'SUCCESS' || l.status === 'PARTIAL'; }).sort(function (a, b) { return String(b.end_time) < String(a.end_time) ? -1 : 1; })[0];
    var lastSeen = logs.filter(function (l) { return l.start_time; }).sort(function (a, b) { return String(b.start_time) < String(a.start_time) ? -1 : 1; })[0];
    var counts = {};
    Db.read('VOUCHERS').forEach(function (v) { var k = v.source + '|' + v.status; counts[k] = (counts[k] || 0) + 1; });
    var cfg = {};
    Db.read('CONFIG').forEach(function (r) { if (r.category === 'TALLY' || r.category === 'SYNC') cfg[r.config_key] = String(r.config_value); });
    return {
      lastSuccess: lastOk || null, connectorLastSeen: lastSeen ? lastSeen.start_time : null,
      pending: logs.filter(function (l) { return l.status === 'REQUESTED'; }).length,
      running: logs.filter(function (l) { return l.status === 'RUNNING'; }).length,
      unresolvedErrors: Db.read('TALLY_ERRORS').filter(function (e) { return e.resolved !== true; }).length,
      voucherCounts: counts, config: cfg, recent: logs.slice(0, 25)
    };
  },
  syncLog: function (p) { return Paging.apply(plain_(Db.read('TALLY_SYNC_LOG')).reverse(), p); },
  errors: function (p) {
    var rows = plain_(Db.read('TALLY_ERRORS')).filter(function (e) { return p.all ? true : e.resolved !== true; }).reverse();
    return Paging.apply(rows, p);
  },
  resolveError: function (p, session) {
    Validate.required(p, ['error_id']);
    Db.update('TALLY_ERRORS', 'error_id', p.error_id, { resolved: true });
    Audit.log({ action: 'UPDATE', entity: 'TALLY_ERRORS', record_id: p.error_id, new_value: { resolved: true } }, session);
    return { resolved: true };
  },
  /** getTallyData: raw XML for a voucher (by unique_key or voucher_id) or the latest raw records. */
  rawData: function (p) {
    var key = p.unique_key;
    if (!key && p.voucher_id) { var v = Db.read('VOUCHERS').filter(function (x) { return x.voucher_id === p.voucher_id; })[0]; key = v && v.unique_key; }
    var rows = Db.read('TALLY_RAW_DATA');
    if (key) {
      var chunks = rows.filter(function (r) { return r.unique_key === key; });
      var latestAlter = chunks.reduce(function (m, r) { return Math.max(m, Number(r.alter_id) || 0); }, 0);
      chunks = chunks.filter(function (r) { return (Number(r.alter_id) || 0) === latestAlter; }).sort(function (a, b) { return a.chunk_no - b.chunk_no; });
      return { unique_key: key, alter_id: latestAlter, xml: chunks.map(function (c) { return String(c.payload).replace(/^'/, ''); }).join(''), revisions: rows.filter(function (r) { return r.unique_key === key && r.chunk_no === 1; }).length };
    }
    return Paging.apply(plain_(rows.filter(function (r) { return r.chunk_no === 1; })).reverse().map(function (r) { r.payload = String(r.payload).slice(0, 300); return r; }), p);
  },

  // ---- connector: masters --------------------------------------------------------
  ingestMasters: function (p, session) {
    var company = Tally.companyByName_(p.company);
    var out = { groups: Tally.upsert_('GROUPS', 'group_name', (p.groups || []).filter(function (g) { return !Engine.RESERVED_GROUPS[g.group_name]; }), function (g) {
      return { group_name: g.group_name, parent_group: g.parent_group || '', nature: g.nature || '', affects_gross_profit: !!g.affects_gross_profit, is_tally_reserved: false, source: 'TALLY', tally_guid: g.tally_guid || '', alter_id: g.alter_id || '' };
    }, session) };
    out.voucher_types = Tally.upsert_('VOUCHER_TYPES', 'voucher_type', p.voucher_types || [], function (t) {
      return { voucher_type: t.voucher_type, base_voucher_type: t.base_voucher_type || 'Other', source: 'TALLY' };
    }, session);
    out.ledgers = Tally.upsert_('LEDGERS', 'ledger_name', p.ledgers || [], function (l) {
      return { company_id: company.company_id, ledger_name: l.ledger_name, parent_group: l.parent_group, ledger_type: Tally.guessType_(l), opening_balance: Math.abs(Number(l.opening_balance) || 0), opening_dr_cr: l.opening_dr_cr === 'Cr' ? 'Cr' : 'Dr', gstin: l.gstin || '', state: l.state || '', tax_type: l.tax_type || '', gst_rate: l.gst_rate || '', credit_days: l.credit_days || '', is_active: true, needs_review: false, source: 'TALLY', tally_guid: l.tally_guid || '', alter_id: l.alter_id || '' };
    }, session);
    out.products = Tally.upsert_('PRODUCTS', 'product_name', p.stock_items || [], function (s) {
      return { product_name: s.product_name, stock_group: s.stock_group || '', hsn_sac: s.hsn_sac || '', uom: s.uom || '', gst_rate: s.gst_rate || '', opening_qty: s.opening_qty || 0, opening_value: s.opening_value || 0, is_active: true, source: 'TALLY', tally_guid: s.tally_guid || '' };
    }, session);
    out.cost_centres = Tally.upsert_('COST_CENTRES', 'cost_centre_name', p.cost_centres || [], function (c) {
      return { cost_centre_name: c.cost_centre_name, category: c.category || '', parent: c.parent || '', is_active: true, source: 'TALLY' };
    }, session);
    out.profilesCreated = Tally.ensurePartyProfiles_(session);
    var tot = { added: 0, updated: 0, skipped: 0 };
    Object.keys(out).forEach(function (k) { if (out[k] && typeof out[k] === 'object') { tot.added += out[k].added; tot.updated += out[k].updated; tot.skipped += out[k].skipped; } });
    Tally.bumpLog_(p.sync_id, tot);
    Audit.log({ action: 'SYNC', entity: 'MASTERS', record_id: p.sync_id || '', new_value: out }, session);
    out.added = tot.added; out.updated = tot.updated; out.skipped = tot.skipped;
    return out;
  },

  guessType_: function (l) {
    var g = String(l.parent_group || '');
    var map = { 'Sundry Debtors': 'Customer', 'Sundry Creditors': 'Vendor', 'Bank Accounts': 'Bank', 'Bank OD A/c': 'Bank', 'Cash-in-Hand': 'Cash', 'Duties & Taxes': 'Tax', 'Sales Accounts': 'Sales', 'Purchase Accounts': 'Purchase', 'Direct Expenses': 'Expense', 'Indirect Expenses': 'Expense', 'Direct Incomes': 'Income', 'Indirect Incomes': 'Income', 'Fixed Assets': 'Asset', 'Capital Account': 'Capital', 'Stock-in-Hand': 'Stock' };
    return map[g] || 'Other';
  },

  /** Insert-or-update by natural key. Unchanged alter_id => skipped. */
  upsert_: function (table, keyField, items, mapFn, session) {
    var res = { added: 0, updated: 0, skipped: 0 };
    if (!items.length) return res;
    var existing = {};
    Db.read(table).forEach(function (r) { existing[String(r[keyField]).toLowerCase()] = r; });
    var inserts = [], patches = {};
    items.forEach(function (it) {
      var row = mapFn(it);
      if (!row[keyField]) return;
      var k = String(row[keyField]).toLowerCase();
      var ex = existing[k];
      if (!ex) { inserts.push(row); existing[k] = row; res.added++; return; }
      if (row.alter_id && ex.alter_id && Number(row.alter_id) <= Number(ex.alter_id)) { res.skipped++; return; }
      patches[k] = row; res.updated++;
    });
    if (table === 'LEDGERS') Post.ledgers(inserts, session, inserts.length ? inserts[0].company_id : '');
    else Db.insert(table, inserts, session);
    if (Object.keys(patches).length) {
      Db.updateWhere(table, function (r) { return !!patches[String(r[keyField]).toLowerCase()]; }, function (r) {
        var pch = patches[String(r[keyField]).toLowerCase()];
        Object.keys(pch).forEach(function (f) { if (f !== 'ledger_type' || !r.ledger_type || r.ledger_type === 'Other') r[f] = pch[f]; });
      });
    }
    return res;
  },

  /** Every debtor/creditor ledger (including ones under custom sub-groups) gets a customer/vendor profile. */
  ensurePartyProfiles_: function (session) {
    var ctx = Engine.createContext({ groups: Db.read('GROUPS'), ledgers: Db.read('LEDGERS') }, Settings.all());
    var cust = {}, vend = {};
    Db.read('CUSTOMERS').forEach(function (c) { cust[String(c.customer_name).toLowerCase()] = true; });
    Db.read('VENDORS').forEach(function (v) { vend[String(v.vendor_name).toLowerCase()] = true; });
    var newC = [], newV = [];
    Db.read('LEDGERS').forEach(function (l) {
      var info = ctx.ledgerInfo(l.ledger_name), k = String(l.ledger_name).toLowerCase();
      if (info.isDebtor && !cust[k]) newC.push({ ledger_id: l.ledger_id, customer_name: l.ledger_name, gstin: l.gstin, state: l.state, credit_days: l.credit_days, status: 'ACTIVE', source: 'TALLY' });
      if (info.isCreditor && !vend[k]) newV.push({ ledger_id: l.ledger_id, vendor_name: l.ledger_name, gstin: l.gstin, state: l.state, credit_days: l.credit_days, status: 'ACTIVE', source: 'TALLY', msme_registered: false });
    });
    Db.insert('CUSTOMERS', newC, session);
    Db.insert('VENDORS', newV, session);
    return { customers: newC.length, vendors: newV.length };
  },

  // ---- connector: vouchers ---------------------------------------------------------
  ingestVouchers: function (p, session) {
    Validate.required(p, ['sync_id', 'company']);
    var company = Tally.companyByName_(p.company);
    var list = p.vouchers || [];
    if (list.length > 500) throw new AppError('VALIDATION', 'Send at most 500 vouchers per batch.');
    var index = {};
    Db.read('VOUCHERS').forEach(function (v) { index[String(v.unique_key)] = v; });
    var knownLedgers = {};
    Db.read('LEDGERS').forEach(function (l) { knownLedgers[String(l.ledger_name).toLowerCase()] = true; });

    var c = { added: 0, updated: 0, skipped: 0, failed: 0, deleted: 0, errors: [] };
    var newHeaders = [], lines = [], bills = [], salesItems = [], purchaseItems = [], raws = [], errs = [], autoLedgers = [], audits = [];
    var regInserts = { SALES: [], PURCHASES: [], RECEIPTS: [], PAYMENTS: [], JOURNALS: [] };
    var headerPatches = {}, regPatches = {};
    var seen = {};
    var pendingIds = [];

    list.forEach(function (v) {
      var h = v.header || {};
      try {
        if (!h.unique_key) throw { code: 'NO_KEY', message: 'Voucher has no unique key.' };
        if (seen[h.unique_key]) { c.skipped++; return; }
        seen[h.unique_key] = true;
        h.voucher_date = Engine.util.D(h.voucher_date);
        if (!h.voucher_date) throw { code: 'BAD_DATE', message: 'Voucher date is missing or invalid.' };
        var status = ['ACTIVE', 'CANCELLED', 'OPTIONAL'].indexOf(h.status) >= 0 ? h.status : 'ACTIVE';
        var vLines = (v.lines || []).map(function (l, i) { return { line_no: l.line_no || i + 1, ledger_name: String(l.ledger_name || '').trim(), debit: Number(l.debit) || 0, credit: Number(l.credit) || 0, is_party_line: !!l.is_party_line, cost_centre: l.cost_centre || '' }; });
        if (status === 'ACTIVE') {
          var check = Engine.validateVoucher(h, vLines);
          if (!check.valid) throw { code: 'UNBALANCED', message: check.errors.join(' ') };
        }
        var ex = index[h.unique_key];
        var revision = 1, voucherId;
        if (ex) {
          var sameAlter = Number(h.tally_alter_id || 0) <= Number(ex.tally_alter_id || 0);
          if (sameAlter && ex.status === status) { c.skipped++; return; }
          revision = (Number(ex.revision) || 1) + 1;
          voucherId = ex.voucher_id;
          headerPatches[voucherId] = Tally.headerFields_(h, status, company, p.sync_id, revision);
          audits.push({ action: 'UPDATE', entity: 'VOUCHERS', record_id: voucherId, old_value: { alter_id: ex.tally_alter_id, amount: ex.amount, status: ex.status, revision: ex.revision }, new_value: { alter_id: h.tally_alter_id, amount: h.amount, status: status, revision: revision }, source: 'TALLY' });
          c.updated++;
        } else {
          var nh = Tally.headerFields_(h, status, company, p.sync_id, 1);
          nh.unique_key = h.unique_key; nh.source = 'TALLY'; nh.created_by = 'tally-connector';
          newHeaders.push(nh);
          pendingIds.push(nh);
          voucherId = null;
          c.added++;
        }
        var target = voucherId ? { voucher_id: voucherId } : newHeaders[newHeaders.length - 1];
        // unknown ledgers -> auto-create under a best-guess group, flagged for review
        vLines.forEach(function (l) {
          var k = l.ledger_name.toLowerCase();
          if (!l.ledger_name || knownLedgers[k]) return;
          knownLedgers[k] = true;
          var b = h.base_voucher_type;
          var group = l.is_party_line ? (['Sales', 'Receipt', 'Credit Note'].indexOf(b) >= 0 ? 'Sundry Debtors' : ['Purchase', 'Payment', 'Debit Note'].indexOf(b) >= 0 ? 'Sundry Creditors' : 'Suspense A/c') : 'Suspense A/c';
          autoLedgers.push({ ledger_name: l.ledger_name, parent_group: group, ledger_type: group === 'Sundry Debtors' ? 'Customer' : group === 'Sundry Creditors' ? 'Vendor' : 'Other', opening_balance: 0, opening_dr_cr: 'Dr', is_active: true, needs_review: true, source: 'AUTO' });
          errs.push({ sync_id: p.sync_id, entity_type: 'LEDGER', unique_key: h.unique_key, voucher_number: h.voucher_number, severity: 'WARNING', error_code: 'UNKNOWN_LEDGER', message: 'Ledger "' + l.ledger_name + '" was not in masters; created under ' + group + ' for review. Run a MASTERS sync.', resolved: false });
        });
        vLines.forEach(function (l) { l._target = target; l.revision = revision; lines.push(l); });
        (v.bills || []).forEach(function (b) {
          bills.push({ _target: target, revision: revision, party_ledger: b.party_ledger, bill_name: String(b.bill_name || ''), bill_type: b.bill_type || 'New Ref', bill_date: Engine.util.D(b.bill_date) || h.voucher_date, due_date: Engine.util.D(b.due_date), credit_days: b.credit_days === undefined ? '' : b.credit_days, amount: Math.abs(Number(b.amount) || 0), dr_cr: b.dr_cr === 'Cr' ? 'Cr' : 'Dr' });
        });
        var itemsTarget = h.base_voucher_type === 'Purchase' || h.base_voucher_type === 'Debit Note' ? purchaseItems : salesItems;
        (v.items || []).forEach(function (it, i) {
          var row = { _target: target, revision: revision, line_no: it.line_no || i + 1, product_name: it.product_name, hsn_sac: it.hsn_sac || '', qty: Number(it.qty) || 0, uom: it.uom || '', rate: Number(it.rate) || 0, discount_amount: Number(it.discount_amount) || 0, taxable_amount: Number(it.taxable_amount) || 0, gst_rate: Number(it.gst_rate) || 0, cgst: Number(it.cgst) || 0, sgst: Number(it.sgst) || 0, igst: Number(it.igst) || 0, cess: Number(it.cess) || 0, line_total: Number(it.line_total) || 0, godown: it.godown || '' };
          if (itemsTarget === salesItems) { row.discount_pct = Number(it.discount_pct) || 0; row.sales_ledger = it.ledger || ''; } else { row.purchase_ledger = it.ledger || ''; }
          itemsTarget.push(row);
        });
        // registers
        var reg = Tally.registerRow_(h, v, vLines, status);
        if (reg) {
          if (voucherId) { regPatches[reg.table] = regPatches[reg.table] || {}; regPatches[reg.table][voucherId] = reg.row; }
          else { reg.row._target = target; regInserts[reg.table].push(reg.row); }
        }
        // raw payload, chunked
        var xml = String(v.raw_xml || '');
        var n = Math.max(1, Math.ceil(xml.length / RAW_CHUNK));
        for (var i = 0; i < n; i++) raws.push({ sync_id: p.sync_id, entity_type: 'VOUCHER', unique_key: h.unique_key, tally_guid: h.tally_guid || '', alter_id: h.tally_alter_id || '', chunk_no: i + 1, chunk_count: n, payload: xml.slice(i * RAW_CHUNK, (i + 1) * RAW_CHUNK), received_at: new Date() });
      } catch (e) {
        c.failed++;
        var code = e.code || 'INGEST_ERROR', msg = e.message || String(e);
        c.errors.push({ unique_key: h.unique_key || '', voucher_number: h.voucher_number || '', code: code, message: msg });
        errs.push({ sync_id: p.sync_id, entity_type: 'VOUCHER', unique_key: h.unique_key || '', voucher_number: h.voucher_number || '', severity: 'ERROR', error_code: code, message: msg, resolved: false });
      }
    });

    // Persist: ledgers first, then headers (to get IDs), then children.
    if (autoLedgers.length) Post.ledgers(autoLedgers, session, company.company_id);
    if (newHeaders.length) {
      var ids = Db.nextIds('VOUCHERS', newHeaders.length);
      newHeaders.forEach(function (nh, i) { nh.voucher_id = ids[i]; });
      Db.insert('VOUCHERS', newHeaders, session);
    }
    function resolve(rows) { rows.forEach(function (r) { r.voucher_id = r._target.voucher_id; delete r._target; }); return rows; }
    Db.insert('VOUCHER_ENTRIES', resolve(lines), session);
    Db.insert('BILL_REFERENCES', resolve(bills), session);
    Db.insert('SALES_ITEMS', resolve(salesItems), session);
    Db.insert('PURCHASE_ITEMS', resolve(purchaseItems), session);
    Object.keys(regInserts).forEach(function (t) { Db.insert(t, resolve(regInserts[t]), session); });
    if (Object.keys(headerPatches).length) {
      Db.updateWhere('VOUCHERS', function (r) { return !!headerPatches[r.voucher_id]; }, function (r) { var pch = headerPatches[r.voucher_id]; Object.keys(pch).forEach(function (k) { r[k] = pch[k]; }); });
    }
    Object.keys(regPatches).forEach(function (t) {
      var m = regPatches[t];
      Db.updateWhere(t, function (r) { return !!m[r.voucher_id]; }, function (r) { var pch = m[r.voucher_id]; Object.keys(pch).forEach(function (k) { r[k] = pch[k]; }); });
      var have = {}; Db.read(t).forEach(function (r) { have[r.voucher_id] = true; });
      var missing = Object.keys(m).filter(function (id) { return !have[id]; }).map(function (id) { var row = m[id]; row.voucher_id = id; return row; });
      Db.insert(t, missing, session);
    });
    Db.insert('TALLY_RAW_DATA', raws);
    Db.insert('TALLY_ERRORS', errs);
    if (p.reconcile) c.deleted = Tally.reconcileDeletions_(company, p.reconcile, audits);
    audits.push({ action: 'SYNC', entity: 'VOUCHERS', record_id: p.sync_id, new_value: { added: c.added, updated: c.updated, skipped: c.skipped, failed: c.failed, deleted: c.deleted }, source: 'TALLY' });
    Audit.logMany(audits, session);
    Tally.bumpLog_(p.sync_id, c);
    return c;
  },

  headerFields_: function (h, status, company, syncId, revision) {
    return {
      company_id: company.company_id, voucher_date: h.voucher_date, voucher_type: h.voucher_type, base_voucher_type: Engine.BASE_TYPES.indexOf(h.base_voucher_type) >= 0 ? h.base_voucher_type : 'Other',
      voucher_number: String(h.voucher_number || ''), reference_no: String(h.reference_no || ''), reference_date: Engine.util.D(h.reference_date),
      party_ledger: h.party_ledger || '', party_gstin: h.party_gstin || '', place_of_supply: h.place_of_supply || '', amount: Math.abs(Number(h.amount) || 0),
      narration: String(h.narration || ''), salesperson: h.salesperson || '', cost_centre: h.cost_centre || '', status: status, revision: revision,
      tally_guid: h.tally_guid || '', tally_master_id: h.tally_master_id || '', tally_alter_id: h.tally_alter_id || '', sync_id: syncId, updated_by: 'tally-connector'
    };
  },

  registerRow_: function (h, v, lines, status) {
    var g = v.gst || {}, st = status === 'CANCELLED' ? 'CANCELLED' : 'ACTIVE';
    var newRef = (v.bills || []).filter(function (b) { return b.bill_type !== 'Agst Ref'; })[0];
    var agst = (v.bills || []).filter(function (b) { return b.bill_type === 'Agst Ref'; }).map(function (b) { return b.bill_name; }).join(', ');
    var other = lines.filter(function (l) { return !l.is_party_line; });
    var taxes = (Number(g.cgst) || 0) + (Number(g.sgst) || 0) + (Number(g.igst) || 0) + (Number(g.cess) || 0);
    var amt = Math.abs(Number(h.amount) || 0);
    switch (h.base_voucher_type) {
      case 'Sales':
        return { table: 'SALES', row: { invoice_no: h.voucher_number, invoice_date: h.voucher_date, customer_ledger: h.party_ledger, customer_gstin: h.party_gstin || '', customer_state: h.place_of_supply || '', place_of_supply: h.place_of_supply || '', salesperson: h.salesperson || '', taxable_amount: Number(g.taxable) || 0, discount_amount: (v.items || []).reduce(function (s, i) { return s + (Number(i.discount_amount) || 0); }, 0), cgst: Number(g.cgst) || 0, sgst: Number(g.sgst) || 0, igst: Number(g.igst) || 0, cess: Number(g.cess) || 0, round_off: Engine.util.r2(amt - (Number(g.taxable) || 0) - taxes), invoice_amount: amt, due_date: newRef ? Engine.util.D(newRef.due_date) : '', source: 'TALLY', status: st } };
      case 'Purchase':
        return { table: 'PURCHASES', row: { purchase_invoice_no: h.reference_no || h.voucher_number, invoice_date: Engine.util.D(h.reference_date) || h.voucher_date, vendor_ledger: h.party_ledger, vendor_gstin: h.party_gstin || '', due_date: newRef ? Engine.util.D(newRef.due_date) : '', purchase_type: (v.items || []).length ? 'Goods' : 'Services', taxable_amount: Number(g.taxable) || 0, cgst: Number(g.cgst) || 0, sgst: Number(g.sgst) || 0, igst: Number(g.igst) || 0, cess: Number(g.cess) || 0, total_amount: amt, bill_reference: newRef ? newRef.bill_name : '', tally_voucher_number: h.voucher_number, source: 'TALLY', status: st } };
      case 'Receipt':
        var dr = other.filter(function (l) { return l.debit > 0; })[0];
        return { table: 'RECEIPTS', row: { receipt_no: h.voucher_number, receipt_date: h.voucher_date, party_ledger: h.party_ledger, amount: amt, mode: /cash/i.test(dr ? dr.ledger_name : '') ? 'Cash' : 'Bank Transfer', bank_ledger: dr ? dr.ledger_name : '', instrument_no: h.reference_no || '', against_bill: agst, source: 'TALLY', status: st, created_by: 'tally-connector' } };
      case 'Payment':
        var cr = other.filter(function (l) { return l.credit > 0; })[0];
        return { table: 'PAYMENTS', row: { payment_no: h.voucher_number, payment_date: h.voucher_date, party_ledger: h.party_ledger, amount: amt, mode: /cash/i.test(cr ? cr.ledger_name : '') ? 'Cash' : 'Bank Transfer', bank_ledger: cr ? cr.ledger_name : '', instrument_no: h.reference_no || '', against_bill: agst, source: 'TALLY', status: st, created_by: 'tally-connector' } };
      case 'Journal':
        var td = lines.reduce(function (s, l) { return s + l.debit; }, 0), tc = lines.reduce(function (s, l) { return s + l.credit; }, 0);
        return { table: 'JOURNALS', row: { journal_no: h.voucher_number, journal_date: h.voucher_date, journal_type: 'Other', total_debit: Engine.util.r2(td), total_credit: Engine.util.r2(tc), narration: h.narration || '', source: 'TALLY', status: st } };
      default:
        return null;
    }
  },

  reconcileDeletions_: function (company, rc, audits) {
    var from = Engine.util.D(rc.from_date), to = Engine.util.D(rc.to_date);
    if (!from || !to || !Array.isArray(rc.unique_keys)) return 0;
    var keys = {}; rc.unique_keys.forEach(function (k) { keys[k] = true; });
    var gone = [];
    var n = Db.updateWhere('VOUCHERS', function (v) {
      var d = Engine.util.D(v.voucher_date);
      var hit = v.company_id === company.company_id && v.source === 'TALLY' && v.status !== 'DELETED_IN_TALLY' && d >= from && d <= to && !keys[v.unique_key];
      if (hit) gone.push(v.voucher_id);
      return hit;
    }, function (v) { v.status = 'DELETED_IN_TALLY'; });
    gone.forEach(function (id) { audits.push({ action: 'DELETE', entity: 'VOUCHERS', record_id: id, new_value: { status: 'DELETED_IN_TALLY' }, source: 'TALLY' }); });
    return n;
  }
};
