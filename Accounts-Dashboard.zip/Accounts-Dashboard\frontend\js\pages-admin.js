/* Pages: Tally integration, audit trail, settings. */
var Pages = window.Pages = window.Pages || {};

// =============================================================================
// Tally integration
// =============================================================================
Pages.tally = { render: function (root, q) {
  var fmt = UI.fmt, esc = UI.esc, $ = UI.$;
  var tab = q.tab || 'status';
  // "26 Sep, 09:56" - fits a KPI card; the full timestamp is in the tooltip
  function whenShort(s) { s = fmt.dt(s); return s === '-' ? s : fmt.date(s.slice(0, 10)).slice(0, 6) + ', ' + s.slice(11, 16); }
  Api.call('getTallyStatus', {}).then(function (t) {
    var last = t.lastSuccess;
    var counts = t.voucherCounts || {};
    var tally = Object.keys(counts).filter(function (k) { return k.indexOf('TALLY|') === 0; }).reduce(function (s, k) { return s + counts[k]; }, 0);
    var offline = Object.keys(counts).filter(function (k) { return k.indexOf('OFFLINE|') === 0; }).reduce(function (s, k) { return s + counts[k]; }, 0);
    root.innerHTML = Shared.head('Tally Integration', 'Tally → on-premise connector → validation & normalization → Apps Script API → Google Sheets',
      Api.can('run.sync') ? '<button class="btn primary" id="syncNow">' + UI.icon('sync') + 'Sync now</button><button class="btn" id="syncAdv">Advanced sync…</button>' : '') +
      '<div class="kpis">' + UI.kpi('Last successful sync', last ? whenShort(last.end_time) : 'Never', last ? last.mode + ' · ' + (last.records_added || 0) + ' added, ' + (last.records_updated || 0) + ' updated' : '', last ? 'good' : 'bad', last ? fmt.dt(last.end_time) : '') +
      UI.kpi('Connector last seen', t.connectorLastSeen ? whenShort(t.connectorLastSeen) : 'Never', '', '', t.connectorLastSeen ? fmt.dt(t.connectorLastSeen) : '') + UI.kpi('Queued requests', t.pending) + UI.kpi('Unresolved errors', t.unresolvedErrors, '', t.unresolvedErrors ? 'bad' : 'good') +
      UI.kpi('Tally vouchers', fmt.num(tally, 0)) + UI.kpi('Offline vouchers', fmt.num(offline, 0)) + '</div>' +
      '<div class="tabs mt no-print">' + [['status', 'Sync history'], ['errors', 'Errors'], ['config', 'Configuration'], ['raw', 'Raw data']].map(function (x) { return '<button data-t="' + x[0] + '" class="' + (tab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div><div id="tBody"></div>';
    UI.$$('.tabs [data-t]', root).forEach(function (b) { b.onclick = function () { location.hash = '#/tally?tab=' + b.dataset.t; }; });
    var body = $('#tBody', root);
    function request(p) { return Api.call('requestTallySync', p).then(function (r) { UI.toast(r.message, 'good'); App.route(); }); }
    var sn = $('#syncNow', root);
    if (sn) sn.onclick = function () { sn.disabled = true; request({ mode: 'INCREMENTAL' }).catch(function (e) { UI.toast(e.message, 'bad'); sn.disabled = false; }); };
    var sa = $('#syncAdv', root);
    if (sa) sa.onclick = function () {
      UI.modal({ title: 'Request a Tally sync', okText: 'Queue sync',
        body: '<div class="note" style="margin-bottom:12px">The request is queued; the connector on the Tally PC picks it up on its next poll. Duplicates are never imported - vouchers are keyed by Tally GUID (or company + type + number + date).</div><div class="form-grid">' +
          UI.field('Mode', UI.select('mode', [{ value: 'INCREMENTAL', label: 'Incremental (changes since last AlterID)' }, { value: 'FULL', label: 'Full (also detects deletions)' }, { value: 'DATE_RANGE', label: 'Date range' }, { value: 'VOUCHER', label: 'Voucher type / number' }, { value: 'LEDGER', label: 'Ledger-wise' }, { value: 'MASTERS', label: 'Masters only' }], 'INCREMENTAL'), '', 'full') +
          UI.field('From', '<input class="input" type="date" name="from_date">') + UI.field('To', '<input class="input" type="date" name="to_date">') +
          UI.field('Voucher type', UI.input('voucher_type', '', 'placeholder="e.g. Sales"')) + UI.field('Voucher number', UI.input('voucher_number', '')) + UI.field('Ledger', UI.input('ledger', ''), '', 'full') + '</div>',
        onOk: function (m) { return request(UI.formData(m)); } });
    };
    if (tab === 'status') {
      body.innerHTML = '<div class="card">' + UI.staticTable([{ key: 'sync_id', label: 'Sync' }, { key: 'mode', label: 'Mode' }, { key: 'requested_by', label: 'Requested by' }, { key: 'start_time', label: 'Started', render: function (v) { return esc(fmt.dt(v)); } }, { key: 'end_time', label: 'Finished', render: function (v) { return esc(fmt.dt(v)); } }, { key: 'records_fetched', label: 'Fetched', type: 'num' }, { key: 'records_added', label: 'Added', type: 'num' }, { key: 'records_updated', label: 'Updated', type: 'num' }, { key: 'records_skipped', label: 'Skipped (dup)', type: 'num' }, { key: 'records_failed', label: 'Failed', type: 'num' }, { key: 'status', label: 'Status', type: 'badge' }, { key: 'connector_host', label: 'Connector' }], t.recent, { emptyText: 'No syncs yet. Start the connector on the Tally PC.' }) + '</div>';
    } else if (tab === 'errors') {
      var cols = [{ key: 'created_at', label: 'When', render: function (v) { return esc(fmt.dt(v)); } }, { key: 'sync_id', label: 'Sync' }, { key: 'voucher_number', label: 'Voucher' }, { key: 'severity', label: 'Severity', type: 'badge' }, { key: 'error_code', label: 'Code' }, { key: 'message', label: 'Message' }, { key: '_r', label: '', sortable: false, render: function (v, r) { return Api.can('run.sync') && !r.resolved ? '<button class="btn sm" data-res="' + esc(r.error_id) + '">Mark resolved</button>' : ''; } }];
      body.innerHTML = '<div class="note">Rejected vouchers are never half-posted. Fix the voucher in Tally (for example, an unbalanced journal) and the next sync imports it.</div><div class="card mt" id="teT"></div>';
      var tbl = UI.table($('#teT', body), { columns: cols, load: function (p) { return Api.call('getTallyErrors', p); }, afterRender: function (c) { UI.$$('[data-res]', c).forEach(function (b) { b.onclick = function () { Api.call('resolveTallyError', { error_id: b.dataset.res }).then(function () { tbl.reload(); App.refreshIndicators(); }); }; }); } });
    } else if (tab === 'config') {
      var cfg = t.config || {};
      body.innerHTML = '<div class="grid g2"><div class="card"><div class="card-head"><h3>Connection (non-secret)</h3>' + (Api.can('admin.settings') ? '<a class="btn sm" href="#/settings">Edit in Settings</a>' : '') + '</div><div class="card-body">' +
        (Object.keys(cfg).length ? Object.keys(cfg).map(function (k) { return '<div class="stat-line"><span class="muted">' + esc(k) + '</span><b>' + esc(cfg[k]) + '</b></div>'; }).join('') : UI.empty('No TALLY/SYNC keys in CONFIG yet.')) +
        '</div></div><div class="card"><div class="card-head"><h3>How it connects</h3></div><div class="card-body small">' +
        '<ol style="padding-left:18px;margin:0;line-height:1.8"><li>In Tally: F1 Help → Settings → Connectivity → enable the XML server on port 9000 and keep the company open.</li><li>On the Tally PC install Python 3.9+ and copy <code>backend/python</code>.</li><li>In the Sheet: Accounts Dashboard menu → Generate connector API key; set it as the <code>ACCOUNTS_CONNECTOR_API_KEY</code> environment variable on the Tally PC.</li><li>Configure <code>config.ini</code> (Tally URL, company, Apps Script URL) and run <code>python -m tally_connector test-connection</code>.</li><li>Schedule <code>python -m tally_connector watch</code> (Task Scheduler) for automatic incremental sync and to pick up "Sync now" requests.</li></ol>' +
        '<p class="muted">Credentials and the API key never reach this web app.</p></div></div></div>';
    } else {
      body.innerHTML = '<form class="filters" id="rawF">' + UI.field('Voucher ID', UI.input('voucher_id', '', 'placeholder="VCH-000123"')) + '<div class="field"><label>&nbsp;</label><button class="btn primary" type="submit">Show payload</button></div></form><div id="rawOut" class="card"><div class="empty">Enter a voucher ID (open any voucher to see it) to view the original Tally XML preserved in TALLY_RAW_DATA.</div></div>';
      $('#rawF', body).addEventListener('submit', function (e) {
        e.preventDefault();
        Api.call('getTallyData', UI.formData(e.target)).then(function (r) {
          $('#rawOut', body).innerHTML = r.xml ? '<div class="card-body">' + (r.note ? '<div class="note">' + esc(r.note) + '</div>' : '') + '<div class="small muted">Key ' + esc(r.unique_key) + ' · AlterID ' + esc(r.alter_id) + ' · revisions ' + esc(r.revisions) + '</div><pre style="white-space:pre-wrap;font-size:12px">' + esc(r.xml) + '</pre></div>' : UI.empty('No raw payload for that voucher.');
        }, function (e2) { $('#rawOut', body).innerHTML = UI.errorBox(e2); });
      });
    }
  }, function (e) { root.innerHTML = UI.errorBox(e); });
} };

// =============================================================================
// Audit trail
// =============================================================================
Pages.audit = { render: function (root) {
  var esc = UI.esc;
  Shared.registerPage(root, {
    title: 'Audit Trail', sub: 'Append-only record of every create, update, delete, sync, import, reconciliation and approval', action: 'getAuditLog', defaultPreset: 'this_month', pageSize: 50,
    filters: UI.field('Action', UI.select('action_type', ['', 'CREATE', 'UPDATE', 'DELETE', 'SYNC', 'IMPORT', 'RECONCILE', 'APPROVE', 'REJECT', 'LOGIN', 'LOGIN_FAILED', 'CONFIG'], '')) + UI.field('Entity', UI.select('entity', ['', 'VOUCHERS', 'OFFLINE_SALES', 'RECEIPTS', 'PAYMENTS', 'JOURNALS', 'EXPENSES', 'LEDGERS', 'BANK_TRANSACTIONS', 'BANK_RECONCILIATION', 'TALLY_SYNC_LOG', 'SETTINGS', 'CONFIG', 'USERS'], '')),
    columns: [{ key: 'timestamp', label: 'When', render: function (v) { return esc(UI.fmt.dt(v)); } }, { key: 'user', label: 'User' }, { key: 'role', label: 'Role' }, { key: 'action', label: 'Action', type: 'badge' }, { key: 'entity', label: 'Entity' }, { key: 'record_id', label: 'Record' },
      { key: 'old_value', label: 'Old value', render: function (v) { return '<span class="small">' + esc(String(v || '').slice(0, 120)) + '</span>'; } }, { key: 'new_value', label: 'New value', render: function (v) { return '<span class="small">' + esc(String(v || '').slice(0, 160)) + '</span>'; } }, { key: 'source', label: 'Source' }],
    emptyText: 'No audit events in this period. Post a transaction and it appears here.'
  });
} };

// =============================================================================
// Settings: accounting rules, configuration, users & roles
// =============================================================================
Pages.settings = { render: function (root, q) {
  var esc = UI.esc, $ = UI.$;
  var tab = q.tab || 'rules';
  var DESCRIPTIONS = {
    FY_START_MONTH: 'Financial year start month (4 = April, Indian FY).', AGEING_BASIS: 'DUE_DATE or BILL_DATE.', AGEING_BUCKETS: 'Upper bounds of ageing buckets in days.',
    DEFAULT_CREDIT_DAYS: 'Credit period when neither bill nor ledger defines one.', BILL_ALLOCATION_FALLBACK: 'FIFO applies receipts/payments without bill references to the oldest bills; NONE leaves them on account.',
    STOCK_VALUATION_SOURCE: 'INVENTORY (valuations sheet, falls back to stock ledgers), LEDGER or NONE.', INCLUDE_OPTIONAL_VOUCHERS: 'Include Tally optional (memorandum) vouchers.',
    BANK_OD_AS_CASH_EQUIVALENT: 'Treat Bank OD as cash in cash-flow.', INTEREST_PAID_ACTIVITY: 'Financing or Operating (Ind AS 7 permits either).', EBITDA_INCLUDES_OTHER_INCOME: 'Include other income in EBITDA.',
    DSO_USE_GROSS_SALES: 'Use GST-inclusive sales for receivable days.', ROUND_INVOICE_TOTAL: 'Round offline invoice totals to the rupee.', PAYMENT_MODE_LEDGERS: 'JSON map of payment mode → cash/bank ledger for offline sales.',
    COMPANY_STATE: 'Decides CGST+SGST vs IGST.', MSME_MAX_PAYMENT_DAYS: 'MSME payment limit (Sec. 43B(h)).', CASH_SHORTAGE_THRESHOLD: 'Alert when cash & bank fall below this.', HIGH_EXPENSE_INCREASE_PCT: 'Alert when month-to-date expenses rise more than this % over last month.'
  };
  root.innerHTML = Shared.head('Settings', 'Accounting rules, connection configuration, users and roles') +
    '<div class="tabs no-print">' + [['rules', 'Accounting rules'], ['config', 'Configuration'], ['users', 'Users & roles']].map(function (x) { return '<button data-t="' + x[0] + '" class="' + (tab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div><div id="sBody">' + UI.loading() + '</div>';
  UI.$$('.tabs [data-t]', root).forEach(function (b) { b.onclick = function () { location.hash = '#/settings?tab=' + b.dataset.t; }; });
  var body = $('#sBody', root);
  if (tab === 'users') {
    Api.call('getUsers', {}).then(function (users) {
      var roles = Object.keys(App.ROLE_LABELS);
      var matrix = [['View dashboards', 'view.dashboard'], ['View accounts & registers', 'view.accounts'], ['View financial reports', 'view.reports'], ['Post transactions', 'write.transactions'], ['Offline sales entry', 'write.offline_sales'], ['Create ledgers', 'write.masters'], ['Submit expenses', 'submit.expenses'], ['Approve expenses', 'approve.expenses'], ['Run Tally sync', 'run.sync'], ['Bank reconciliation', 'reconcile.bank'], ['Audit trail', 'view.audit'], ['Settings & users', 'admin.settings']];
      var P = { ADMIN: ['*'], ACCOUNTANT: ['view.dashboard', 'view.accounts', 'view.reports', 'write.transactions', 'write.masters', 'write.offline_sales', 'submit.expenses', 'run.sync', 'reconcile.bank'], FINANCE_MANAGER: ['view.dashboard', 'view.accounts', 'view.reports', 'view.audit', 'approve.expenses', 'submit.expenses', 'run.sync', 'reconcile.bank'], MANAGEMENT: ['view.dashboard', 'view.accounts', 'view.reports'], DATA_ENTRY: ['write.offline_sales', 'write.transactions', 'submit.expenses'], AUDITOR: ['view.dashboard', 'view.accounts', 'view.reports', 'view.audit'] };
      body.innerHTML = '<div class="card"><div class="card-head"><h3>Users</h3>' + (Api.can('admin.users') ? '<button class="btn primary sm" id="addU">' + UI.icon('plus') + 'Add user</button>' : '') + '</div>' +
        UI.staticTable([{ key: 'full_name', label: 'Name' }, { key: 'email', label: 'Email' }, { key: 'role', label: 'Role', render: function (v) { return esc(App.ROLE_LABELS[v] || v); } }, { key: 'status', label: 'Status', type: 'badge' }, { key: 'last_login', label: 'Last login' }], users) + '</div>' +
        '<div class="card mt"><div class="card-head"><h3>Role permissions</h3><span class="sub">Enforced by the API; navigation hides what a role cannot use</span></div>' +
        UI.staticTable([{ key: 'l', label: 'Permission' }].concat(roles.map(function (r) { return { key: r, label: App.ROLE_LABELS[r], render: function (v) { return v ? UI.icon('check') : ''; } }; })), matrix.map(function (m) { var o = { l: m[0] }; roles.forEach(function (r) { o[r] = P[r].indexOf('*') >= 0 || P[r].indexOf(m[1]) >= 0; }); return o; })) + '</div>';
      var au = $('#addU', body);
      if (au) au.onclick = function () {
        UI.modal({ title: 'Add user', okText: 'Create user', body: '<div class="form-grid">' + UI.field('Full name', UI.input('full_name', '')) + UI.field('Email', UI.input('email', '', 'type="email"')) + UI.field('Role', UI.select('role', roles.map(function (r) { return { value: r, label: App.ROLE_LABELS[r] }; }), 'ACCOUNTANT')) + UI.field('Initial password', '<input class="input" type="password" name="password" autocomplete="new-password">', 'Min 10 characters with letters and digits') + '</div>',
          onOk: function (m) { return Api.call('createUser', UI.formData(m)).then(function () { UI.toast('User created.', 'good'); App.route(); }); } });
      };
    }, function (e) { body.innerHTML = UI.errorBox(e); });
    return;
  }
  Api.call('getSettings', {}).then(function (s) {
    if (tab === 'rules') {
      body.innerHTML = '<div class="note">Every accounting ambiguity the engine resolves is a named rule. Changes apply immediately to all reports and are recorded in the audit trail.</div><div class="card mt">' +
        UI.staticTable([{ key: 'key', label: 'Rule', render: function (v) { return '<b>' + esc(v) + '</b><div class="small muted">' + esc(DESCRIPTIONS[v] || '') + '</div>'; } }, { key: 'value', label: 'Current value', render: function (v) { return '<code>' + esc(typeof v === 'object' ? JSON.stringify(v) : v) + '</code>'; } }, { key: 'overridden', label: '', render: function (v) { return v ? UI.badge('Custom', 'info') : '<span class="small muted">default</span>'; } }, { key: '_e', label: '', render: function (v, r) { return '<button class="btn sm" data-k="' + esc(r.key) + '">Edit</button>'; } }], s.settings) + '</div>';
      UI.$$('[data-k]', body).forEach(function (b) { b.onclick = function () {
        var st = s.settings.filter(function (x) { return x.key === b.dataset.k; })[0];
        UI.modal({ title: 'Edit ' + st.key, body: '<div class="note" style="margin-bottom:10px">' + esc(DESCRIPTIONS[st.key] || '') + ' Default: <code>' + esc(st.default) + '</code></div>' + UI.field('Value', '<textarea class="input" name="value" rows="' + (st.key === 'PAYMENT_MODE_LEDGERS' ? 5 : 1) + '">' + esc(st.value) + '</textarea>'),
          onOk: function (m) { return Api.call('updateSetting', { key: st.key, value: UI.formData(m).value }).then(function () { UI.toast('Saved ' + st.key, 'good'); Shared.invalidate(); App.route(); }); } });
      }; });
    } else {
      body.innerHTML = '<div class="note">Non-secret configuration. API keys and passwords are kept in Apps Script Script Properties and are never shown here.' + (s.connectorKeyConfigured === false ? ' <b>Connector API key: not configured.</b>' : ' Connector API key: configured.') + '</div><div class="card mt"><div class="card-head"><h3>CONFIG</h3><button class="btn sm primary" id="addC">' + UI.icon('plus') + 'Add key</button></div>' +
        UI.staticTable([{ key: 'config_key', label: 'Key' }, { key: 'config_value', label: 'Value' }, { key: 'category', label: 'Category' }, { key: '_e', label: '', render: function (v, r) { return '<button class="btn sm" data-c="' + esc(r.config_key) + '">Edit</button>'; } }], s.config) + '</div>' +
        '<div class="card mt"><div class="card-body small muted">Useful keys: TALLY_SERVER_URL, TALLY_COMPANY, SYNC_INTERVAL_SECONDS, SYNC_BATCH_SIZE, SYNC_FROM_DATE, SYNC_STALE_HOURS, REPORT_RECIPIENTS, OFFLINE_INVOICE_SERIES, SEND_CUSTOMER_REMINDERS.</div></div>';
      function edit(key, value, category) {
        UI.modal({ title: key ? 'Edit ' + key : 'Add configuration key', body: '<div class="form-grid">' + UI.field('Key', UI.input('key', key || '', key ? 'readonly' : '')) + UI.field('Category', UI.select('category', ['TALLY', 'SYNC', 'EMAIL', 'APP', 'SECURITY'], category || 'APP')) + UI.field('Value', UI.input('value', value || ''), '', 'full') + '</div>',
          onOk: function (m) { return Api.call('updateConfig', UI.formData(m)).then(function () { UI.toast('Saved.', 'good'); App.route(); }); } });
      }
      $('#addC', body).onclick = function () { edit(); };
      UI.$$('[data-c]', body).forEach(function (b) { b.onclick = function () { var c = s.config.filter(function (x) { return x.config_key === b.dataset.c; })[0]; edit(c.config_key, c.config_value, c.category); }; });
    }
  }, function (e) { body.innerHTML = UI.errorBox(e); });
} };
