"""Validation of normalized vouchers and masters before they are sent.

Invalid vouchers are never sent to the server; the sync engine records them
in the local run report and counts them as failed.
"""

from __future__ import annotations

import re
from datetime import date
from decimal import Decimal
from typing import Any, Dict, List, Tuple

BALANCE_TOLERANCE = Decimal("0.01")
_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

MASTER_NAME_FIELDS = {
    "groups": "group_name",
    "ledgers": "ledger_name",
    "voucher_types": "voucher_type",
    "stock_items": "product_name",
    "cost_centres": "cost_centre_name",
}


def is_valid_iso_date(value: Any) -> bool:
    s = str(value or "")
    if not _ISO_DATE_RE.match(s):
        return False
    try:
        date.fromisoformat(s)
    except ValueError:
        return False
    return True


def _dec(value: Any) -> Decimal:
    try:
        return Decimal(str(value if value is not None else 0))
    except Exception:  # noqa: BLE001 - any junk counts as invalid
        return Decimal("NaN")


def validate_voucher(voucher: Dict[str, Any]) -> List[Dict[str, str]]:
    """Return a list of ``{code, message}`` problems (empty when valid).

    Rules: non-empty voucher type, valid voucher date, a unique key, every
    line has a ledger and non-negative amounts, and - unless the voucher is
    cancelled (Tally strips a cancelled voucher's entries) - at least two
    lines with total debit equal to total credit within 0.01.
    """
    problems: List[Dict[str, str]] = [dict(e) for e in voucher.get("_errors") or []]
    header = voucher.get("header") or {}
    lines = voucher.get("lines") or []

    if not str(header.get("voucher_type") or "").strip():
        problems.append({"code": "MISSING_VOUCHER_TYPE", "message": "Voucher type is empty."})
    if not is_valid_iso_date(header.get("voucher_date")):
        problems.append({"code": "INVALID_DATE",
                         "message": "Voucher date %r is missing or invalid." % (header.get("voucher_date"),)})
    if not str(header.get("unique_key") or "").strip():
        problems.append({"code": "MISSING_UNIQUE_KEY", "message": "Voucher has no unique key."})

    total_debit = total_credit = Decimal("0")
    for line in lines:
        debit, credit = _dec(line.get("debit")), _dec(line.get("credit"))
        if not str(line.get("ledger_name") or "").strip():
            problems.append({"code": "MISSING_LEDGER",
                             "message": "Line %s has no ledger name." % line.get("line_no")})
        if not debit.is_finite() or not credit.is_finite() or debit < 0 or credit < 0:
            problems.append({"code": "INVALID_LINE_AMOUNT",
                             "message": "Line %s has an invalid debit/credit (%r / %r)."
                                        % (line.get("line_no"), line.get("debit"), line.get("credit"))})
            continue
        total_debit += debit
        total_credit += credit

    if header.get("status") != "CANCELLED":
        if len(lines) < 2:
            problems.append({"code": "TOO_FEW_LINES",
                             "message": "Voucher has %d ledger line(s); at least 2 are required." % len(lines)})
        difference = total_debit - total_credit
        if abs(difference) > BALANCE_TOLERANCE:
            problems.append({"code": "UNBALANCED",
                             "message": "Debit %.2f does not equal credit %.2f (difference %.2f)."
                                        % (total_debit, total_credit, difference)})
    return problems


def is_non_accounting(voucher: Dict[str, Any]) -> bool:
    """True for inventory/order vouchers (base type Other) that carry no ledger lines.

    Such vouchers (Delivery Note, Sales Order, Stock Journal...) have nothing
    to post in the ledger and are skipped rather than failed.
    """
    header = voucher.get("header") or {}
    return (header.get("base_voucher_type") == "Other"
            and not voucher.get("lines")
            and header.get("status") != "CANCELLED")


def clean_masters(masters: Dict[str, List[Dict[str, Any]]]) -> Tuple[Dict[str, List[Dict[str, Any]]], List[str]]:
    """Drop master rows without a name and de-duplicate by name (last wins)."""
    cleaned: Dict[str, List[Dict[str, Any]]] = {}
    problems: List[str] = []
    for kind, name_field in MASTER_NAME_FIELDS.items():
        seen: Dict[str, int] = {}
        rows: List[Dict[str, Any]] = []
        for row in masters.get(kind) or []:
            name = str(row.get(name_field) or "").strip()
            if not name:
                problems.append("%s: row without %s skipped" % (kind, name_field))
                continue
            key = " ".join(name.split()).lower()
            if key in seen:
                problems.append("%s: duplicate '%s' (last one kept)" % (kind, name))
                rows[seen[key]] = row
            else:
                seen[key] = len(rows)
                rows.append(row)
        cleaned[kind] = rows
    return cleaned, problems


__all__ = ["validate_voucher", "is_non_accounting", "clean_masters", "is_valid_iso_date", "BALANCE_TOLERANCE"]
