# Builds dist\Accounts Dashboard.html - one self-contained file (CSS, JS, Chart.js inlined) that runs
# the full app in demo mode by double-clicking it. No server, no internet needed (fonts fall back to
# the system font offline; Excel export loads its library from the CDN when online).
# Usage (from repo root): powershell -ExecutionPolicy Bypass -File tools\build-single.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$fe = Join-Path $root 'frontend'
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Read-Text($p) { [IO.File]::ReadAllText($p, $utf8) }
function Safe-Js($s) { $s.Replace('</script', '<\/script') }

$html = Read-Text (Join-Path $fe 'index.html')
# Inline scripts need to be allowed, so the preview drops the strict CSP used on GitHub Pages.
$html = [regex]::Replace($html, '\s*<meta http-equiv="Content-Security-Policy"[^>]*>', '')
$html = $html.Replace('<link rel="stylesheet" href="css/app.css">', "<style>`n" + (Read-Text (Join-Path $fe 'css\app.css')) + "`n</style>")

$chart = Join-Path $root 'tools\vendor\chart.umd.min.js'
if (Test-Path $chart) {
  $html = [regex]::Replace($html, '<script src="https://cdn\.jsdelivr\.net/npm/chart\.js[^"]*"></script>', { param($m) "<script>`n" + (Safe-Js (Read-Text $chart)) + "`n</script>" })
}
$html = [regex]::Replace($html, '<script src="(js/[^"]+)"></script>', {
  param($m)
  $js = Read-Text (Join-Path $fe ($m.Groups[1].Value -replace '/', '\'))
  "<script>/* " + $m.Groups[1].Value + " */`n" + (Safe-Js $js) + "`n</script>"
})
$html = $html.Replace('<title>Accounts Dashboard</title>', '<title>Accounts Dashboard (Preview)</title>')

$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Force $dist | Out-Null
$out = Join-Path $dist 'Accounts Dashboard.html'
[IO.File]::WriteAllText($out, $html, $utf8)
Write-Host ("Built {0} ({1:N0} KB)" -f $out, ((Get-Item $out).Length / 1KB))
