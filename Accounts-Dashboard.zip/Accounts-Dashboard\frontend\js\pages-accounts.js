/* Pages: parties, receivables/payables & ageing, ledgers, cash & bank, trial balance, inventory. */
var Pages = window.Pages = window.Pages || {};

// =============================================================================
// Customers / Vendors - auto-maintained party ledgers
// =============================================================================
function partyPage(root, kind) {
  var fmt = UI.fmt, esc = UI.esc, isC = kind === 'customer';
  var canWrite = Api.can('write.masters');
  var page = Shared.registerPage(root, {
    title: isC ? 'Customers' : 'Vendors',
    sub: isC ? 'Customer ledgers: opening, sales, credit notes, receipts, adjustments and closing - computed from vouchers' : 'Vendor payment ledgers: opening, purchases, debit notes, payments, adjustments and closing - computed from vouchers',
    actions: canWrite ? '<button class="btn primary" id="newParty">' + UI.icon('plus') + (isC ? 'New customer' : 'New vendor') + '</button>' : '',
    action: isC ? 'getCustomers' : 'getVendors', sort: 'closing',
    columns: [{ key: 'party', label: isC ? 'Customer' : 'Vendor', render: function (v) { return '<a role="button" tabindex="0" data-l="' + esc(v) + '">' + esc(v) + '</a>'; } }, { key: 'gstin', label: 'GSTIN' },
      { key: 'opening', label: 'Opening', type: 'inr' }, { key: 'invoices', label: isC ? 'Sales' : 'Purchases', type: 'inr' }, { key: 'notes', label: isC ? 'Credit notes' : 'Debit notes', type: 'inr' },
      { key: 'settlements', label: isC ? 'Receipts' : 'Payments', type: 'inr' }, { key: 'adjustments', label: 'Adjustments', type: 'inr' }, { key: 'closing', label: 'Closing', type: 'signed' },
      { key: 'outstanding_bills', label: 'Open bills', type: 'num' }, { key: 'overdue_amount', label: 'Overdue', type: 'inr' }, { key: 'max_days_overdue', label: 'Max days', type: 'num' },
      isC ? { key: 'over_limit', label: 'Credit limit', render: function (v, r) { return r.credit_limit ? (v ? UI.badge('Exceeded', 'bad') : fmt.inr(r.credit_limit)) : ''; } } : { key: 'msme', label: 'MSME', render: function (v) { return v ? UI.badge('MSME', 'info') : ''; } }],
    footer: function (r) { var t = r.totals; return { party: 'Total', opening: t.opening, invoices: t.invoices, notes: t.notes, settlements: t.settlements, adjustments: t.adjustments, closing: t.closing, overdue_amount: t.overdue_amount }; },
    kpis: function (r) { var t = r.totals; return UI.kpi(isC ? 'Total receivable' : 'Total payable', fmt.inr(t.closing), Shared.periodLabel(r), 'accent') + UI.kpi(isC ? 'Sales in period' : 'Purchases in period', fmt.inr(t.invoices)) + UI.kpi(isC ? 'Received in period' : 'Paid in period', fmt.inr(t.settlements)) + UI.kpi('Overdue', fmt.inr(t.overdue_amount), '', t.overdue_amount > 0 ? 'bad' : 'good'); },
    after: function (r, rt) { UI.$$('[data-l]', rt).forEach(function (a) { a.onclick = function () { Shared.openLedger(a.dataset.l); }; }); }
  });
  var nb = UI.$('#newParty', root);
  if (nb) nb.addEventListener('click', function () {
    UI.modal({
      title: isC ? 'New customer' : 'New vendor', okText: 'Create ledger',
      body: '<div class="note" style="margin-bottom:12px">Creates the ' + (isC ? 'customer' : 'vendor') + ' ledger under ' + (isC ? 'Sundry Debtors' : 'Sundry Creditors') + ' and its profile. Create the same ledger in Tally to keep masters aligned; the next masters sync links them by name.</div><div class="form-grid">' +
        UI.field('Name', UI.input(isC ? 'customer_name' : 'vendor_name', '')) + UI.field('GSTIN', UI.input('gstin', '', 'maxlength="15" style="text-transform:uppercase"')) +
        UI.field('Mobile', UI.input('mobile', '')) + UI.field('Email', UI.input('email', '', 'type="email"')) + UI.field('State', UI.input('state', 'Delhi')) + UI.field('Credit days', '<input class="input num" type="number" name="credit_days" value="30">') +
        UI.field('Opening balance', '<input class="input num" type="number" name="opening_balance" value="0" step="any">') + UI.field('Opening Dr/Cr', UI.select('opening_dr_cr', isC ? ['Dr', 'Cr'] : ['Cr', 'Dr'], isC ? 'Dr' : 'Cr')) +
        (isC ? UI.field('Credit limit', '<input class="input num" type="number" name="credit_limit" step="any">') : UI.field('MSME registered', UI.select('msme_registered', [{ value: 'false', label: 'No' }, { value: 'true', label: 'Yes (45-day rule applies)' }], 'false'))) +
        UI.field('Address', UI.input('address', ''), '', 'full') + '</div>',
      onOk: function (m) { var d = UI.formData(m); d.gstin = d.gstin.toUpperCase(); return Api.call(isC ? 'createCustomer' : 'createVendor', d).then(function (r) { UI.toast('Created ledger ' + r.ledger_name, 'good'); Shared.invalidate(); page.reload(); }); }
    });
  });
}
Pages.customers = { render: function (root) { partyPage(root, 'customer'); } };
Pages.vendors = { render: function (root) { partyPage(root, 'vendor'); } };

// =============================================================================
// Receivables / Payables with ageing
// =============================================================================
function outstandingPage(root, kind, q) {
  var fmt = UI.fmt, esc = UI.esc, isR = kind === 'receivable';
  var state = { asOf: '', status: q.status || '', bucket: '', party: q.party || '' };
  var tbl, lastRes;
  root.innerHTML = Shared.head(isR ? 'Receivables' : 'Payables', isR ? 'Bill-wise customer dues with ageing. Totals always tie to ledger balances.' : 'Bill-wise vendor dues with ageing, MSME tracking and payment planning', isR ? '' : (Api.can('write.transactions') ? '<a class="btn" href="#/payments">Record payment</a>' : '')) +
    '<div class="kpis" id="osK">' + UI.loading() + '</div>' +
    '<div class="grid g-2-1 mt"><div class="card"><div class="card-head"><h3>Ageing</h3><span class="sub" id="osBasis"></span></div><div class="card-body"><div class="chart-box" id="osC"></div></div></div><div class="card"><div class="card-head"><h3>Bucket totals</h3></div><div id="osB"></div></div></div>' +
    '<div class="card mt"><div class="card-head"><h3>' + (isR ? 'Customer' : 'Vendor') + ' summary</h3></div><div id="osP"></div></div>' +
    '<form class="filters mt">' + UI.field('As of', '<input class="input" type="date" name="asOf">') + UI.field('Status', UI.select('status', ['', 'Overdue', 'Current', 'Advance'], state.status)) + UI.field('Ageing bucket', '<select class="input" name="bucket" id="bkSel"><option value="">All</option></select>') +
    UI.field(isR ? 'Customer' : 'Vendor', '<input class="input" name="party" list="dlP" value="' + esc(state.party) + '" data-live>') + '<datalist id="dlP"></datalist><div class="field grow"><label>Search</label><input class="input" type="search" name="q"></div></form>' +
    '<div class="card"><div class="card-head"><h3>Outstanding bills</h3><span id="osX"></span></div><div id="osT"></div></div>';
  var cols = [{ key: 'party', label: isR ? 'Customer' : 'Vendor', render: function (v) { return '<a role="button" tabindex="0" data-l="' + esc(v) + '">' + esc(v) + '</a>'; } }, { key: 'bill_name', label: isR ? 'Invoice' : 'Bill' }, { key: 'bill_date', label: 'Bill date', type: 'date' }, { key: 'due_date', label: 'Due date', type: 'date' },
    { key: 'bill_amount', label: 'Bill amount', type: 'inr' }, { key: 'settled_amount', label: isR ? 'Received' : 'Paid', type: 'inr' }, { key: 'outstanding', label: 'Outstanding', type: 'signed' },
    { key: 'days_outstanding', label: 'Days out', type: 'num' }, { key: 'days_overdue', label: 'Days overdue', type: 'num' }, { key: 'ageing_bucket', label: 'Bucket' }, { key: 'status', label: 'Status', type: 'badge' },
    { key: '_a', label: '', sortable: false, render: function (v, r) { return r.outstanding > 0 && Api.can('write.transactions') && !r.synthetic ? '<button class="btn sm" data-pay="' + esc(r.bill_name) + '" data-party="' + esc(r.party) + '" data-amt="' + r.outstanding + '">' + (isR ? 'Receive' : 'Pay') + '</button>' : ''; } }];
  function params(p) { var o = Object.assign({}, state, p || {}); Object.keys(o).forEach(function (k) { if (o[k] === '') delete o[k]; }); return o; }
  tbl = UI.table(UI.$('#osT', root), {
    columns: cols, pageSize: 25, sort: 'days_overdue', dir: 'desc',
    rowClass: function (r) { return r.status === 'Overdue' && r.days_overdue > 90 ? '' : ''; },
    load: function (pg) {
      return Api.call(isR ? 'getReceivables' : 'getPayables', params(pg)).then(function (o) {
        lastRes = o; summarise(o); return o.bills;
      });
    },
    afterRender: function (c) {
      UI.$$('[data-l]', c).forEach(function (a) { a.onclick = function () { Shared.openLedger(a.dataset.l); }; });
      UI.$$('[data-pay]', c).forEach(function (b) { b.onclick = function () { cashModal(isR ? 'receipt' : 'payment', { party: b.dataset.party, bill: b.dataset.pay, amount: b.dataset.amt }); }; });
    }
  });
  UI.$('#osX', root).outerHTML = UI.exportButtons(isR ? 'Receivables' : 'Payables', function () { return cols.filter(function (c) { return c.key !== '_a'; }); }, function () { return Api.call(isR ? 'getReceivables' : 'getPayables', params({ page: 1, pageSize: 5000 })).then(function (o) { return o.bills.rows; }); });
  var summarised = false;
  function summarise(o) {
    var s = o.summary;
    UI.$('#osK', root).innerHTML = UI.kpi(isR ? 'Total receivable' : 'Total payable', fmt.inr(o.total), 'as of ' + fmt.date(o.asOf), 'accent') + UI.kpi('Current', fmt.inr(o.current)) + UI.kpi('Overdue', fmt.inr(o.overdue), '', o.overdue > 0 ? 'bad' : 'good') +
      UI.kpi('30+ days overdue', fmt.inr(s.overdue30)) + UI.kpi('60+ days', fmt.inr(s.overdue60)) + UI.kpi('90+ days', fmt.inr(s.overdue90), '', s.overdue90 > 0 ? 'bad' : '') + UI.kpi('180+ days', fmt.inr(s.overdue180)) + UI.kpi('365+ days', fmt.inr(s.overdue365));
    UI.$('#osBasis', root).textContent = 'Basis: ' + (o.basis === 'BILL_DATE' ? 'days since bill date' : 'days past due date') + ' (setting AGEING_BASIS)';
    var labels = o.bucketLabels;
    UI.$('#osB', root).innerHTML = UI.staticTable([{ key: 'b', label: 'Bucket' }, { key: 'v', label: 'Outstanding', type: 'inr' }, { key: 'p', label: 'Share', type: 'pct' }], labels.concat(['Advance']).map(function (l) { return { b: l, v: o.bucketTotals[l] || 0, p: o.total ? (o.bucketTotals[l] || 0) / o.total * 100 : 0 }; }), { foot: { b: 'Total', v: o.total } });
    if (!summarised) {
      summarised = true;
      UI.destroyCharts();
      var sel = UI.$('#bkSel', root);
      sel.innerHTML = '<option value="">All</option>' + labels.concat(['Advance']).map(function (l) { return '<option' + (l === state.bucket ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('');
      UI.$('#dlP', root).innerHTML = o.parties.map(function (p) { return '<option value="' + esc(p.party) + '">'; }).join('');
      UI.chart(UI.$('#osC', root), { labels: labels, datasets: [{ label: 'Outstanding', data: labels.map(function (l) { return o.bucketTotals[l] || 0; }), colors: UI.seqColors(labels.length) }] });
      var pcols = [{ key: 'party', label: isR ? 'Customer' : 'Vendor' }, { key: 'balance', label: 'Balance', type: 'signed' }, { key: 'outstanding_bills', label: 'Open bills', type: 'num' }, { key: 'overdue_bills', label: 'Overdue bills', type: 'num' }, { key: 'overdue_amount', label: 'Overdue', type: 'inr' }, { key: 'oldest_due', label: 'Oldest due', type: 'date' }, { key: 'max_days_overdue', label: 'Max days', type: 'num' }]
        .concat(labels.map(function (l) { return { key: 'b_' + l, label: l, type: 'inr', render: function (v, r) { return r.buckets[l] ? UI.fmt.inr(r.buckets[l]) : ''; } }; }));
      UI.$('#osP', root).innerHTML = UI.staticTable(pcols, o.parties, { foot: { party: 'Total', balance: o.total, overdue_amount: o.overdue } });
    }
  }
  UI.bindFilters(UI.$('.filters', root), function (v) { if ((v.asOf || '') !== (state.asOf || '')) summarised = false; Object.assign(state, v); tbl.reload(true); });
}
Pages.receivables = { render: function (root, q) { outstandingPage(root, 'receivable', q); } };
Pages.payables = { render: function (root, q) { outstandingPage(root, 'payable', q); } };

// =============================================================================
// Ledgers
// =============================================================================
Pages.ledgers = { render: function (root, q) {
  var esc = UI.esc;
  Shared.lookups().catch(function () { return { groups: [] }; }).then(function (lk) {
    var page = Shared.registerPage(root, {
      title: 'Ledgers', sub: 'Every account with opening, period movement and closing. Click a ledger for its statement with running balance.',
      actions: Api.can('write.masters') ? '<button class="btn primary" id="newLed">' + UI.icon('plus') + 'New ledger</button>' : '',
      action: 'getLedgers', sort: 'ledger', dir: 'asc', pageSize: 50,
      filters: UI.field('Group', UI.select('group', [''].concat(lk.groups || []), q.group || '')),
      initial: { group: q.group || '' },
      columns: [{ key: 'ledger', label: 'Ledger', render: function (v) { return '<a role="button" tabindex="0" data-l="' + esc(v) + '">' + esc(v) + '</a>'; } }, { key: 'group', label: 'Group' }, { key: 'primary', label: 'Primary group' }, { key: 'nature', label: 'Nature' },
        { key: 'opening', label: 'Opening', render: function (v) { return UI.fmt.drcr(v); }, exportValue: function (v) { return v; } }, { key: 'debit', label: 'Debit', type: 'inr2' }, { key: 'credit', label: 'Credit', type: 'inr2' },
        { key: 'closing', label: 'Closing', render: function (v) { return UI.fmt.drcr(v); }, exportValue: function (v) { return v; } }, { key: 'source', label: 'Source' }, { key: 'needs_review', label: '', render: function (v) { return v ? UI.badge('Review', 'warn') : ''; } }],
      after: function (r, rt) { UI.$$('[data-l]', rt).forEach(function (a) { a.onclick = function () { Shared.openLedger(a.dataset.l); }; }); }
    });
    if (q.ledger) Shared.openLedger(q.ledger);
    var nb = UI.$('#newLed', root);
    if (nb) nb.addEventListener('click', function () {
      UI.modal({
        title: 'New ledger', okText: 'Create ledger',
        body: '<div class="form-grid">' + UI.field('Ledger name', UI.input('ledger_name', '')) + UI.field('Under group', UI.select('parent_group', lk.groups, 'Indirect Expenses')) +
          UI.field('Opening balance', '<input class="input num" type="number" name="opening_balance" value="0" step="any">') + UI.field('Dr / Cr', UI.select('opening_dr_cr', ['Dr', 'Cr'], 'Dr')) +
          UI.field('MIS category', UI.select('mis_category', ['', 'DEPRECIATION', 'INTEREST', 'INCOME_TAX', 'SALARY', 'RENT', 'UTILITIES', 'MARKETING', 'TRAVEL', 'PROFESSIONAL_FEES', 'REPAIRS', 'FREIGHT', 'OTHER'], ''), 'Drives EBITDA and cash-flow classification') +
          UI.field('GST head (tax ledgers)', UI.select('tax_type', ['', 'CGST', 'SGST', 'IGST', 'CESS', 'TDS', 'TCS'], '')) + UI.field('GSTIN', UI.input('gstin', '')) + UI.field('State', UI.input('state', '')) + '</div>',
        onOk: function (m) { return Api.call('createLedger', UI.formData(m)).then(function (r) { UI.toast('Created ' + r.ledger_name, 'good'); Shared.invalidate(); page.reload(); }); }
      });
    });
  });
} };

// =============================================================================
// Cash & Bank: balances, cash/bank book, reconciliation
// =============================================================================
Pages['cash-bank'] = { render: function (root, q) {
  var fmt = UI.fmt, esc = UI.esc, $ = UI.$;
  var tab = q.tab || 'book';
  root.innerHTML = Shared.head('Cash & Bank', 'Cash book, bank book, transfers and bank reconciliation', Api.can('write.transactions') ? '<button class="btn" id="cbR">Receipt</button><button class="btn" id="cbP">Payment</button>' : '') +
    '<div class="kpis" id="cbK">' + UI.loading() + '</div><div class="tabs mt no-print"><button data-t="book" class="' + (tab === 'book' ? 'on' : '') + '">Cash / bank book</button><button data-t="recon" class="' + (tab === 'recon' ? 'on' : '') + '">Bank reconciliation</button></div><div id="cbBody"></div>';
  UI.$$('.tabs [data-t]', root).forEach(function (b) { b.onclick = function () { location.hash = '#/cash-bank?tab=' + b.dataset.t; }; });
  var r1 = $('#cbR', root), p1 = $('#cbP', root);
  if (r1) r1.onclick = function () { cashModal('receipt'); };
  if (p1) p1.onclick = function () { cashModal('payment'); };
  var body = $('#cbBody', root);
  if (tab === 'book') {
    var st = { preset: 'this_month', ledger: '' };
    body.innerHTML = '<form class="filters">' + UI.periodFields(st) + UI.field('Account', '<select class="input" name="ledger" id="cbAcc"><option value="">All cash & bank</option></select>') + '<div class="field grow"><label>Search</label><input class="input" type="search" name="q"></div></form><div class="card"><div class="card-head"><h3 id="cbTitle">Cash & bank book</h3><span id="cbX"></span></div><div id="cbT"></div></div>';
    var accountsFilled = false;
    var cols = [{ key: 'date', label: 'Date', type: 'date' }, { key: 'voucher_number', label: 'Voucher', render: function (v, r) { return '<a role="button" tabindex="0" data-v="' + esc(r.voucher_id) + '">' + esc(v) + '</a>'; } }, { key: 'voucher_type', label: 'Type' }, { key: 'account', label: 'Account' }, { key: 'particulars', label: 'Particulars' }, { key: 'receipt', label: 'Receipt', type: 'inr2' }, { key: 'payment', label: 'Payment', type: 'inr2' }, { key: 'balance', label: 'Running balance', type: 'inr2' }, { key: 'narration', label: 'Narration' }];
    var tbl = UI.table($('#cbT', root), {
      columns: cols, pageSize: 50, sortable: false,
      load: function (pg) {
        var p = Object.assign({}, st, pg); if (p.preset !== 'custom') { delete p.from; delete p.to; }
        return Api.call('getCashBook', p).then(function (cb) {
          $('#cbK', root).innerHTML = cb.accounts.map(function (a) { return UI.kpi(a.ledger, fmt.inr(a.closing), 'in ' + fmt.inr(a.inflow) + ' · out ' + fmt.inr(a.outflow), a.closing < 0 ? 'bad' : ''); }).join('') + UI.kpi('Cash total', fmt.inr(cb.cash), '', 'accent') + UI.kpi('Bank total', fmt.inr(cb.bank), '', 'accent');
          if (!accountsFilled) { accountsFilled = true; cb.accounts.forEach(function (a) { $('#cbAcc', root).insertAdjacentHTML('beforeend', '<option>' + esc(a.ledger) + '</option>'); }); }
          $('#cbTitle', root).textContent = (st.ledger || 'Cash & bank book') + ' · opening ' + fmt.inr(cb.opening) + ' · closing ' + fmt.inr(cb.closing);
          return cb.rows;
        });
      },
      afterRender: function (c) { UI.$$('[data-v]', c).forEach(function (a) { a.onclick = function () { Shared.openVoucher(a.dataset.v); }; }); }
    });
    $('#cbX', root).outerHTML = UI.exportButtons('Cash book', function () { return cols; }, function () { return tbl.exportRows(); });
    UI.bindFilters($('.filters', body), function (v) { Object.assign(st, v); tbl.reload(true); });
  } else {
    var acct = q.account || 'BNK-0001';
    var canRec = Api.can('reconcile.bank');
    function loadRecon() {
      body.innerHTML = UI.loading();
      Api.call('getBankTransactions', { bank_account_id: acct, pageSize: 200 }).then(function (r) {
        var s = r.summary || {};
        $('#cbK', root).innerHTML = UI.kpi('Balance as per books', fmt.inr(s.balanceAsPerBooks), s.account || '', 'accent') + UI.kpi('Balance as per statement', s.balanceAsPerStatement === null || s.balanceAsPerStatement === undefined ? 'Not in file' : fmt.inr(s.balanceAsPerStatement)) +
          UI.kpi('Deposits not yet credited', fmt.inr(s.depositsNotCredited), (s.unmatchedBookEntries || 0) + ' book entries unmatched') + UI.kpi('Payments not yet debited', fmt.inr(s.chequesNotPresented)) +
          UI.kpi('Credits in bank, not in books', fmt.inr(s.creditsNotInBooks), '', s.creditsNotInBooks ? 'bad' : '') + UI.kpi('Debits in bank, not in books', fmt.inr(s.debitsNotInBooks), (s.unmatchedStatementLines || 0) + ' statement lines open', s.debitsNotInBooks ? 'bad' : '');
        body.innerHTML = '<div class="filters"><div class="field">' + '<label>Bank account</label>' + UI.select('acct', r.accounts.map(function (a) { return { value: a.bank_account_id, label: a.ledger_name + ' (' + a.account_no_masked + ')' }; }), acct, 'id="rcAcc"') + '</div>' +
          (canRec ? '<div class="actions" style="margin-left:auto"><button class="btn" id="rcImp">' + UI.icon('download') + 'Import statement (CSV)</button><button class="btn primary" id="rcAuto">' + UI.icon('sync') + 'Auto-reconcile</button></div>' : '') + '</div>' +
          '<div class="note">Matching rules: amount + reference token → Matched; amount + same date (unique) → Matched; amount within ±5 days (unique) → Partially Matched (review). Everything else stays Unmatched.</div>' +
          '<div class="card mt"><div class="card-head"><h3>Statement lines</h3></div>' + UI.staticTable([{ key: 'txn_date', label: 'Date', type: 'date' }, { key: 'description', label: 'Description' }, { key: 'reference', label: 'Reference' }, { key: 'debit', label: 'Debit', type: 'inr2' }, { key: 'credit', label: 'Credit', type: 'inr2' }, { key: 'reconciliation_status', label: 'Status', type: 'badge' }, { key: 'matched_voucher_id', label: 'Book entry', render: function (v) { return v ? '<a role="button" tabindex="0" data-v="' + esc(v) + '">' + esc(v) + '</a>' : ''; } },
            { key: '_m', label: '', render: function (v, t) { return canRec ? (t.matched_voucher_id ? '<button class="btn sm" data-un="' + esc(t.bank_txn_id) + '">Unmatch</button>' : '<button class="btn sm" data-mt="' + esc(t.bank_txn_id) + '">Match…</button>') : ''; } }], r.rows) + '</div>';
        $('#rcAcc', body).onchange = function (e) { acct = e.target.value; loadRecon(); };
        UI.$$('[data-v]', body).forEach(function (a) { a.onclick = function () { Shared.openVoucher(a.dataset.v); }; });
        UI.$$('[data-un]', body).forEach(function (b) { b.onclick = function () { Api.call('setBankMatch', { bank_txn_id: b.dataset.un, voucher_id: '' }).then(loadRecon, function (e) { UI.toast(e.message, 'bad'); }); }; });
        UI.$$('[data-mt]', body).forEach(function (b) { b.onclick = function () { UI.modal({ title: 'Match statement line', okText: 'Match', body: UI.field('Voucher ID (open the voucher from the cash book to find it)', UI.input('voucher_id', '', 'placeholder="VCH-000123"')) + UI.field('Remarks', UI.input('remarks', '')), onOk: function (m) { var d = UI.formData(m); d.bank_txn_id = b.dataset.mt; return Api.call('setBankMatch', d).then(loadRecon); } }); }; });
        var auto = $('#rcAuto', body);
        if (auto) auto.onclick = function () { auto.disabled = true; Api.call('autoReconcile', { bank_account_id: acct }).then(function (x) { UI.toast('Matched ' + x.matched + ', partial ' + x.partiallyMatched + ', unmatched ' + x.unmatched, 'good'); loadRecon(); }, function (e) { UI.toast(e.message, 'bad'); auto.disabled = false; }); };
        var imp = $('#rcImp', body);
        if (imp) imp.onclick = function () {
          UI.modal({ title: 'Import bank statement', wide: true, okText: 'Import',
            body: '<div class="note">Paste CSV with a header row: <b>date, description, reference, debit, credit, balance</b>. Dates as YYYY-MM-DD or DD-MM-YYYY. Duplicate lines are skipped automatically.</div>' + UI.field('CSV', '<textarea class="input" name="csv" rows="10" placeholder="date,description,reference,debit,credit,balance&#10;2026-09-24,NEFT CR-ABC INTERIORS,HDFCN2626,0,50000,1250000"></textarea>'),
            onOk: function (m) {
              var lines = UI.formData(m).csv.split(/\r?\n/).filter(Boolean);
              if (lines.length < 2) throw new Api.ApiError('VALIDATION', 'Paste a header row and at least one line.');
              var hdr = splitCsv(lines[0]).map(function (h) { return h.trim().toLowerCase(); });
              var rows = lines.slice(1).map(function (l) { var c = splitCsv(l), o = {}; hdr.forEach(function (h, i) { o[h] = (c[i] || '').trim(); }); o.debit = +String(o.debit || 0).replace(/,/g, '') || 0; o.credit = +String(o.credit || 0).replace(/,/g, '') || 0; return o; });
              return Api.call('importBankStatement', { bank_account_id: acct, rows: rows }).then(function (x) { UI.toast('Imported ' + x.imported + ' lines (' + x.duplicatesSkipped + ' duplicates skipped).', 'good'); loadRecon(); });
            } });
        };
      }, function (e) { body.innerHTML = UI.errorBox(e); });
    }
    loadRecon();
  }
  function splitCsv(line) { var out = [], cur = '', q2 = false; for (var i = 0; i < line.length; i++) { var ch = line[i]; if (ch === '"') { if (q2 && line[i + 1] === '"') { cur += '"'; i++; } else q2 = !q2; } else if (ch === ',' && !q2) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out; }
} };

// =============================================================================
// Trial balance
// =============================================================================
Pages['trial-balance'] = { render: function (root) {
  var fmt = UI.fmt, esc = UI.esc;
  var st = { preset: 'current_fy' };
  root.innerHTML = Shared.head('Trial Balance', 'Opening, period and closing balances for every ledger. Total debit must equal total credit.') + '<form class="filters">' + UI.periodFields(st) + '</form><div id="tbBody"></div>';
  function load(v) {
    Object.assign(st, v);
    var body = UI.$('#tbBody', root); body.innerHTML = UI.loading();
    var p = { preset: st.preset }; if (st.preset === 'custom') { p.from = st.from; p.to = st.to; }
    Api.call('getTrialBalance', p).then(function (tb) {
      var t = tb.totals;
      var rows = [], byPrimary = {};
      tb.rows.forEach(function (r) { (byPrimary[r.primary || 'Other'] = byPrimary[r.primary || 'Other'] || []).push(r); });
      Object.keys(byPrimary).forEach(function (g) {
        var rs = byPrimary[g];
        var sub = ['openingDr', 'openingCr', 'periodDr', 'periodCr', 'closingDr', 'closingCr'].reduce(function (o, k) { o[k] = rs.reduce(function (s, r) { return s + r[k]; }, 0); return o; }, {});
        rows.push(Object.assign({ ledger: g, _cls: 'group-row' }, sub));
        rs.forEach(function (r) { rows.push(Object.assign({ _indent: true }, r)); });
      });
      var cols = [{ key: 'ledger', label: 'Ledger', indent: true, render: function (v, r) { return r._cls ? esc(v) : '<a role="button" tabindex="0" data-l="' + esc(v) + '">' + esc(v) + '</a>'; } }, { key: 'group', label: 'Group' }, { key: 'openingDr', label: 'Opening Dr', type: 'inr2' }, { key: 'openingCr', label: 'Opening Cr', type: 'inr2' }, { key: 'periodDr', label: 'Period Dr', type: 'inr2' }, { key: 'periodCr', label: 'Period Cr', type: 'inr2' }, { key: 'closingDr', label: 'Closing Dr', type: 'inr2' }, { key: 'closingCr', label: 'Closing Cr', type: 'inr2' }];
      body.innerHTML = '<div class="check ' + (tb.balanced ? 'ok' : 'bad') + '">' + UI.icon(tb.balanced ? 'check' : 'alert') + (tb.balanced ? 'Balanced: total debit equals total credit (' + fmt.inr2(t.closingDr) + ').' : 'IMBALANCE: closing difference ' + fmt.inr2(tb.difference) + ', period difference ' + fmt.inr2(tb.periodDifference) + '. See unbalanced vouchers below.') + '</div>' +
        (tb.openingDifference ? '<div class="note mt">Opening balances do not agree by ' + fmt.inr2(tb.openingDifference) + ' - shown as "Difference in opening balances", exactly as Tally does. Correct the ledger opening balances to clear it.</div>' : '') +
        (tb.unbalancedVouchers.length ? '<div class="card mt"><div class="card-head"><h3>Unbalanced vouchers</h3></div>' + UI.staticTable([{ key: 'date', label: 'Date', type: 'date' }, { key: 'voucher_number', label: 'Voucher' }, { key: 'debit', label: 'Debit', type: 'inr2' }, { key: 'credit', label: 'Credit', type: 'inr2' }, { key: 'difference', label: 'Difference', type: 'inr2' }], tb.unbalancedVouchers) + '</div>' : '') +
        '<div class="card mt"><div class="card-head"><h3>' + esc(fmt.date(tb.from) + ' to ' + fmt.date(tb.to)) + '</h3>' + UI.exportButtons('Trial Balance', function () { return cols; }, function () { return tb.rows; }) + '</div>' +
        UI.staticTable(cols, rows, { foot: { ledger: 'Total', openingDr: t.openingDr, openingCr: t.openingCr, periodDr: t.periodDr, periodCr: t.periodCr, closingDr: t.closingDr, closingCr: t.closingCr } }) + '</div>';
      UI.$$('[data-l]', body).forEach(function (a) { a.onclick = function () { Shared.openLedger(a.dataset.l, { from: tb.from, to: tb.to }); }; });
    }, function (e) { body.innerHTML = UI.errorBox(e); });
  }
  UI.bindFilters(UI.$('.filters', root), load);
  load({});
} };

// =============================================================================
// Inventory
// =============================================================================
Pages.inventory = { render: function (root) {
  var fmt = UI.fmt;
  Api.call('getInventory', {}).then(function (inv) {
    var cols = [{ key: 'product', label: 'Product' }, { key: 'hsn_sac', label: 'HSN/SAC' }, { key: 'uom', label: 'UOM' }, { key: 'gst_rate', label: 'GST %', type: 'num' }, { key: 'sale_rate', label: 'List price', type: 'inr' }, { key: 'purchase_rate', label: 'Std cost', type: 'inr' }, { key: 'qty_sold', label: 'Qty sold (FY)', type: 'num' }, { key: 'revenue', label: 'Revenue (FY)', type: 'inr' }, { key: 'avg_price', label: 'Avg selling price', type: 'inr' }];
    root.innerHTML = Shared.head('Inventory', 'Stock valuation used for closing stock in P&L and balance sheet (source: ' + inv.source + ')') +
      '<div class="kpis">' + UI.kpi('Closing stock value', fmt.inr(inv.stockValue), 'as of ' + fmt.date(inv.asOf), 'accent') + UI.kpi('Stock items', inv.products.length) + '</div>' +
      '<div class="card mt"><div class="card-head"><h3>Stock items</h3>' + UI.exportButtons('Inventory', function () { return cols; }, function () { return inv.products; }) + '</div>' + UI.staticTable(cols, inv.products) + '</div>' +
      '<div class="card mt"><div class="card-head"><h3>Valuation history</h3><span class="sub">Synced from Tally stock summary or entered manually</span></div>' + UI.staticTable([{ key: 'as_of_date', label: 'As of', type: 'date' }, { key: 'product_name', label: 'Item' }, { key: 'godown', label: 'Godown' }, { key: 'closing_qty', label: 'Qty', type: 'num' }, { key: 'closing_value', label: 'Value', type: 'inr' }, { key: 'valuation_method', label: 'Method' }], inv.valuations) + '</div>';
  }, function (e) { root.innerHTML = UI.errorBox(e); });
} };
