"""Tests for SyncEngine with fake Tally and fake Apps Script clients."""

import copy
import json
import os
import shutil
import tempfile
import unittest
from datetime import datetime

from tally_connector.api_client import ApiError
from tally_connector.config import ApiSettings, AppConfig, SyncSettings, TallySettings
from tally_connector.sync_engine import SyncEngine, SyncRequest
from tally_connector.tally_client import TallyError
from tally_connector.xml_parser import extract_masters, extract_vouchers, parse_xml

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")
COMPANY = "Demo Company"


def load(name):
    with open(os.path.join(FIXTURES, name), "rb") as fh:
        return parse_xml(fh.read())


def journal(n, guid=None, alter=None, amount="1000.00", date="20260910"):
    return parse_xml(
        '<VOUCHER VCHTYPE="Journal"><DATE>%s</DATE><GUID>%s</GUID><VOUCHERTYPENAME>Journal</VOUCHERTYPENAME>'
        "<VOUCHERNUMBER>J/%d</VOUCHERNUMBER><ALTERID>%d</ALTERID><MASTERID>%d</MASTERID>"
        "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Rent</LEDGERNAME><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>"
        "<AMOUNT>-%s</AMOUNT></ALLLEDGERENTRIES.LIST>"
        "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Cash</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>"
        "<AMOUNT>%s</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>"
        % (date, guid or "guid-%04d" % n, n, alter if alter is not None else n, n, amount, amount))


class FakeTally:
    def __init__(self, vouchers=None, masters=None, error=None, company=COMPANY):
        self.company = company
        self.vouchers = list(vouchers or [])
        self.masters = masters if masters is not None else extract_masters(load("masters_sample.xml"))
        self.error = error
        self.fetch_calls = []

    def ping(self):
        return {"ok": True, "company": self.company, "companies": [self.company], "company_open": True}

    def fetch_masters(self):
        return self.masters

    def fetch_vouchers(self, from_date, to_date, min_alter_id=None, voucher_type=None, voucher_number=None):
        self.fetch_calls.append({"from_date": from_date, "to_date": to_date, "min_alter_id": min_alter_id,
                                 "voucher_type": voucher_type, "voucher_number": voucher_number})
        if self.error is not None:
            raise self.error
        return list(self.vouchers)


class FakeApi:
    def __init__(self, last_alter_id=0, pending=None, server_config=None, fail_actions=None):
        self.last_alter_id = last_alter_id
        self.pending = list(pending or [])
        self.server_config = server_config or {}
        self.fail_actions = fail_actions or {}
        self.calls = []
        self._next_id = 0

    def call(self, action, params=None):
        self.calls.append((action, copy.deepcopy(params)))
        if action in self.fail_actions:
            raise self.fail_actions[action]
        if action == "tallyConfig":
            return {"company": params["company"], "last_alter_id": self.last_alter_id, "last_success_at": "",
                    "config": dict(self.server_config), "pending_requests": copy.deepcopy(self.pending)}
        if action == "tallySyncStart":
            self._next_id += 1
            return {"sync_id": "SYN-%04d" % self._next_id}
        if action == "tallyIngestMasters":
            total = sum(len(params[k]) for k in ("groups", "ledgers", "voucher_types", "stock_items", "cost_centres"))
            return {"added": total, "updated": 0, "skipped": 0}
        if action == "syncTallyData":
            return {"added": len(params["vouchers"]), "updated": 0, "skipped": 0, "failed": 0, "errors": []}
        if action == "tallySyncFinish":
            return {}
        raise AssertionError("unexpected action %s" % action)

    def params(self, action):
        return [p for a, p in self.calls if a == action]

    def actions(self):
        return [a for a, _ in self.calls]


class SyncEngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="acctdash-test-")
        self.config = AppConfig(
            tally=TallySettings(company=COMPANY),
            api=ApiSettings(apps_script_url="https://script.google.com/macros/s/test/exec", api_key="test-key"),
            sync=SyncSettings(batch_size=2, from_date="2026-04-01",
                              state_dir=os.path.join(self.tmp, "state"), log_dir=os.path.join(self.tmp, "logs")),
        )

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def engine(self, tally, api):
        return SyncEngine(self.config, tally, api, now=lambda: datetime(2026, 9, 26, 10, 0, 0),
                          hostname="ACCOUNTS-PC-01", sleep=lambda s: None)

    def test_full_sync_batches_and_reconcile_only_on_last_batch(self):
        tally = FakeTally([journal(i) for i in range(1, 6)])
        api = FakeApi()
        report = self.engine(tally, api).run(SyncRequest(mode="FULL"))

        self.assertEqual(report["status"], "SUCCESS")
        batches = api.params("syncTallyData")
        self.assertEqual([len(b["vouchers"]) for b in batches], [2, 2, 1])
        self.assertIsNone(batches[0]["reconcile"])
        self.assertIsNone(batches[1]["reconcile"])
        reconcile = batches[2]["reconcile"]
        self.assertEqual(reconcile["from_date"], "2026-04-01")
        self.assertEqual(reconcile["to_date"], "2027-03-31")
        self.assertEqual(sorted(reconcile["unique_keys"]), ["GUID:guid-%04d" % i for i in range(1, 6)])
        for batch in batches:
            self.assertEqual(batch["sync_id"], "SYN-0001")
            self.assertEqual(batch["company"], COMPANY)
            for voucher in batch["vouchers"]:
                self.assertFalse([k for k in voucher if k.startswith("_")])

        start = api.params("tallySyncStart")[0]
        self.assertEqual(start["mode"], "FULL")
        self.assertEqual(start["connector_host"], "ACCOUNTS-PC-01")
        self.assertNotIn("request_sync_id", start)
        self.assertEqual(len(api.params("tallyIngestMasters")), 1)
        finish = api.params("tallySyncFinish")[0]
        self.assertEqual(finish, {"sync_id": "SYN-0001", "status": "SUCCESS", "records_fetched": 5,
                                  "to_alter_id": 5, "error": ""})
        self.assertEqual(api.actions()[0], "tallyConfig")
        self.assertEqual(api.actions()[-1], "tallySyncFinish")
        self.assertTrue(os.path.isfile(report["report_path"]))
        with open(report["report_path"], encoding="utf-8") as fh:
            self.assertEqual(json.load(fh)["status"], "SUCCESS")

    def test_dedupe_within_run_keeps_highest_alter_id(self):
        tally = FakeTally([journal(1, guid="dup", alter=3), journal(1, guid="dup", alter=7, amount="2000.00"),
                           journal(2)])
        api = FakeApi()
        report = self.engine(tally, api).run(SyncRequest(mode="FULL"))
        sent = [v for b in api.params("syncTallyData") for v in b["vouchers"]]
        self.assertEqual(len(sent), 2)
        dup = next(v for v in sent if v["header"]["unique_key"] == "GUID:dup")
        self.assertEqual(dup["header"]["tally_alter_id"], 7)
        self.assertEqual(dup["header"]["amount"], 2000.0)
        self.assertEqual(report["counts"]["duplicates"], 1)
        self.assertEqual(report["counts"]["unique"], 2)
        self.assertEqual(len(api.params("syncTallyData")[-1]["reconcile"]["unique_keys"]), 2)

    def test_incremental_uses_alter_id_and_never_reconciles(self):
        tally = FakeTally([journal(i, alter=100 + i) for i in range(1, 4)])
        api = FakeApi(last_alter_id=100)
        report = self.engine(tally, api).run(SyncRequest(mode="INCREMENTAL"))
        self.assertEqual(tally.fetch_calls[0]["min_alter_id"], 100)
        self.assertEqual(api.params("tallySyncStart")[0]["from_alter_id"], 100)
        for batch in api.params("syncTallyData"):
            self.assertIsNone(batch["reconcile"])
        self.assertEqual(api.params("tallySyncFinish")[0]["to_alter_id"], 103)
        self.assertEqual(report["status"], "SUCCESS")
        # Unchanged masters are not re-ingested on incremental runs once the server has data.
        api2 = FakeApi(last_alter_id=103)
        self.engine(FakeTally([]), api2).run(SyncRequest(mode="INCREMENTAL"))
        self.assertEqual(api2.params("tallyIngestMasters"), [])
        self.assertEqual(api2.params("syncTallyData"), [])

    def test_invalid_vouchers_not_sent_and_counted_failed(self):
        tally = FakeTally(extract_vouchers(load("daybook_sample.xml")))
        api = FakeApi()
        report = self.engine(tally, api).run(SyncRequest(mode="FULL"))
        sent = [v["header"]["voucher_number"] for b in api.params("syncTallyData") for v in b["vouchers"]]
        self.assertEqual(sorted(sent), ["AC/J/0007", "AC/P/0012", "AC/R/0031", "AC/S/0001"])
        self.assertEqual(report["counts"]["invalid"], 1)
        self.assertEqual(report["counts"]["failed_total"], 1)
        self.assertEqual(report["invalid_vouchers"][0]["voucher_number"], "AC/J/0008")
        self.assertEqual(report["invalid_vouchers"][0]["errors"][0]["code"], "UNBALANCED")
        self.assertEqual(report["status"], "PARTIAL")
        finish = api.params("tallySyncFinish")[0]
        self.assertEqual(finish["status"], "PARTIAL")
        self.assertIn("AC/J/0008", finish["error"])
        self.assertEqual(finish["to_alter_id"], 5011)
        keys = api.params("syncTallyData")[-1]["reconcile"]["unique_keys"]
        self.assertIn("GUID:a1b2c3d4-0000-0000-0000-000000009999", keys)  # invalid still exists in Tally
        self.assertEqual(len(keys), 5)
        with open(report["report_path"], encoding="utf-8") as fh:
            self.assertEqual(json.load(fh)["invalid_vouchers"][0]["voucher_number"], "AC/J/0008")

    def test_finish_called_with_failed_on_exception(self):
        tally = FakeTally(error=TallyError("Tally connection unavailable."))
        api = FakeApi()
        report = self.engine(tally, api).run(SyncRequest(mode="FULL"))
        self.assertEqual(report["status"], "FAILED")
        self.assertEqual(api.params("syncTallyData"), [])
        finish = api.params("tallySyncFinish")
        self.assertEqual(len(finish), 1)
        self.assertEqual(finish[0]["status"], "FAILED")
        self.assertIn("Tally connection unavailable", finish[0]["error"])
        self.assertEqual(finish[0]["to_alter_id"], 0)

    def test_api_failure_mid_sync_reports_failed(self):
        tally = FakeTally([journal(i) for i in range(1, 4)])
        api = FakeApi(fail_actions={"syncTallyData": ApiError("HTTP_500", "boom", 500, retryable=True)})
        report = self.engine(tally, api).run(SyncRequest(mode="FULL"))
        self.assertEqual(report["status"], "FAILED")
        self.assertEqual(api.params("tallySyncFinish")[0]["status"], "FAILED")

    def test_empty_full_sync_still_sends_reconcile(self):
        api = FakeApi()
        report = self.engine(FakeTally([]), api).run(SyncRequest(mode="FULL"))
        batches = api.params("syncTallyData")
        self.assertEqual(len(batches), 1)
        self.assertEqual(batches[0]["vouchers"], [])
        self.assertEqual(batches[0]["reconcile"]["unique_keys"], [])
        self.assertEqual(report["status"], "SUCCESS")

    def test_pending_request_executed_with_request_sync_id(self):
        api = FakeApi(last_alter_id=50, pending=[{
            "sync_id": "SYN-REQ-9", "mode": "DATE_RANGE", "from_date": "2026-09-01", "to_date": "2026-09-30",
            "voucher_type": "", "ledger": "", "voucher_number": ""}])
        tally = FakeTally([journal(1)])
        self.engine(tally, api).watch(max_cycles=1)
        starts = api.params("tallySyncStart")
        self.assertEqual(len(starts), 1)  # the request only; no incremental in the same cycle
        self.assertEqual(starts[0]["request_sync_id"], "SYN-REQ-9")
        self.assertEqual(starts[0]["mode"], "DATE_RANGE")
        self.assertEqual((starts[0]["from_date"], starts[0]["to_date"]), ("2026-09-01", "2026-09-30"))
        self.assertEqual(tally.fetch_calls[0]["from_date"], "2026-09-01")
        self.assertEqual(api.params("syncTallyData")[-1]["reconcile"]["from_date"], "2026-09-01")

    def test_watch_runs_incremental_when_nothing_pending(self):
        api = FakeApi(last_alter_id=0)
        self.engine(FakeTally([journal(1)]), api).watch(max_cycles=1)
        starts = api.params("tallySyncStart")
        self.assertEqual([s["mode"] for s in starts], ["INCREMENTAL"])
        self.assertNotIn("request_sync_id", starts[0])

    def test_invalid_pending_request_is_reported_failed(self):
        api = FakeApi(pending=[{"sync_id": "SYN-REQ-10", "mode": "VOUCHER"}])
        self.engine(FakeTally([]), api).watch(max_cycles=1)
        self.assertEqual(api.params("tallySyncStart")[0]["request_sync_id"], "SYN-REQ-10")
        finish = api.params("tallySyncFinish")[0]
        self.assertEqual(finish["status"], "FAILED")
        self.assertIn("VOUCHER sync needs", finish["error"])

    def test_ledger_mode_filters_client_side(self):
        tally = FakeTally(extract_vouchers(load("daybook_sample.xml")))
        api = FakeApi()
        report = self.engine(tally, api).run(SyncRequest(mode="LEDGER", ledger="hdfc bank ca 4521"))
        sent = [v["header"]["voucher_number"] for b in api.params("syncTallyData") for v in b["vouchers"]]
        self.assertEqual(sent, ["AC/R/0031"])
        self.assertIsNone(api.params("syncTallyData")[0]["reconcile"])
        self.assertEqual(report["status"], "SUCCESS")

    def test_masters_mode(self):
        api = FakeApi(last_alter_id=10)
        report = self.engine(FakeTally([]), api).run(SyncRequest(mode="MASTERS"))
        ingest = api.params("tallyIngestMasters")
        self.assertEqual(len(ingest), 1)
        self.assertEqual(len(ingest[0]["ledgers"]), 10)
        self.assertEqual(ingest[0]["voucher_types"][1]["base_voucher_type"], "Sales")
        self.assertEqual(api.params("syncTallyData"), [])
        self.assertEqual(report["counts"]["records_fetched"], 26)
        self.assertEqual(api.params("tallySyncFinish")[0]["to_alter_id"], 10)

    def test_dry_run_sends_nothing(self):
        api = FakeApi()
        report = self.engine(FakeTally([journal(1), journal(2)]), api).run(SyncRequest(mode="FULL"), dry_run=True)
        self.assertEqual(api.actions(), ["tallyConfig"])
        self.assertEqual(report["counts"]["sent"], 2)
        self.assertTrue(report["sync_id"].startswith("DRYRUN-"))
        self.assertEqual(report["status"], "SUCCESS")

    def test_server_config_overrides_batch_size(self):
        api = FakeApi(server_config={"SYNC_BATCH_SIZE": "3", "SYNC_FROM_DATE": "2026-07-01"})
        self.engine(FakeTally([journal(i) for i in range(1, 6)]), api).run(SyncRequest(mode="FULL"))
        self.assertEqual([len(b["vouchers"]) for b in api.params("syncTallyData")], [3, 2])
        self.assertEqual(api.params("tallySyncStart")[0]["from_date"], "2026-07-01")


if __name__ == "__main__":
    unittest.main()
