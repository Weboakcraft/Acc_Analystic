/**
 * API layer. Pages only ever call Api.call(action, params) - they never know whether the backend
 * is Google Apps Script, a future PostgreSQL service, or the in-browser demo.
 *
 *   RemoteAdapter - POSTs { action, token, params } to APP_CONFIG.API_URL (Apps Script web app).
 *   DemoAdapter   - runs the same accounting engine over a generated dataset (no backend needed).
 */
var Api = (function () {
  'use strict';
  var U = Engine.util;
  var SESSION_KEY = 'acctdash.session';

  function ApiError(code, message, details) { this.code = code; this.message = message; this.details = details; }
  ApiError.prototype = Object.create(Error.prototype);

  function storage(kind) { try { return window[kind]; } catch (e) { return null; } }
  function loadSession() { try { return JSON.parse((storage('sessionStorage') || {}).getItem(SESSION_KEY) || 'null'); } catch (e) { return null; } }
  function saveSession(s) { try { var st = storage('sessionStorage'); if (s) st.setItem(SESSION_KEY, JSON.stringify(s)); else st.removeItem(SESSION_KEY); } catch (e) { /* storage unavailable */ } }

  // ---------------------------------------------------------------------------
  // Remote (Apps Script)
  // ---------------------------------------------------------------------------
  var RemoteAdapter = {
    mode: 'remote',
    call: function (action, params, token) {
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, (APP_CONFIG.TIMEOUT_SECONDS || 60) * 1000) : null;
      return fetch(APP_CONFIG.API_URL, {
        method: 'POST', redirect: 'follow', signal: ctrl ? ctrl.signal : undefined,
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action: action, token: token, params: params || {} })
      }).then(function (r) {
        if (timer) clearTimeout(timer);
        return r.text().then(function (t) {
          var j;
          try { j = JSON.parse(t); } catch (e) { throw new ApiError('BAD_RESPONSE', 'The server returned an unexpected response. Check that the Apps Script deployment allows access to "Anyone".'); }
          if (!j.ok) throw new ApiError(j.error.code, j.error.message, j.error.details);
          return j.data;
        });
      }, function (err) {
        if (timer) clearTimeout(timer);
        throw new ApiError('NETWORK', err && err.name === 'AbortError' ? 'The server took too long to respond.' : 'Unable to reach the server. Check your connection.');
      });
    }
  };

  // ---------------------------------------------------------------------------
  // Demo (in-browser)
  // ---------------------------------------------------------------------------
  var ROLE_PERMISSIONS = {
    ADMIN: ['*'],
    ACCOUNTANT: ['view.dashboard', 'view.accounts', 'view.reports', 'view.tally', 'view.lookup', 'write.transactions', 'write.masters', 'write.offline_sales', 'submit.expenses', 'run.sync', 'reconcile.bank'],
    FINANCE_MANAGER: ['view.dashboard', 'view.accounts', 'view.reports', 'view.tally', 'view.audit', 'view.lookup', 'approve.expenses', 'submit.expenses', 'run.sync', 'reconcile.bank', 'resolve.alerts'],
    MANAGEMENT: ['view.dashboard', 'view.accounts', 'view.reports', 'view.lookup'],
    DATA_ENTRY: ['view.lookup', 'write.offline_sales', 'write.transactions', 'submit.expenses'],
    AUDITOR: ['view.dashboard', 'view.accounts', 'view.reports', 'view.tally', 'view.audit', 'view.lookup']
  };
  var ROUTE_PERMS = {
    getDashboard: 'view.dashboard', getAlerts: 'view.dashboard', getManagementDashboard: 'view.reports', getFinancialHealth: 'view.reports', getAnalytics: 'view.reports',
    getTrialBalance: 'view.reports', getProfitLoss: 'view.reports', getBalanceSheet: 'view.reports', getCashFlow: 'view.reports', getGSTSummary: 'view.reports',
    saveOfflineSale: 'write.offline_sales', saveReceipt: 'write.transactions', savePayment: 'write.transactions', saveJournal: 'write.transactions', cancelVoucher: 'write.transactions',
    saveExpense: 'submit.expenses', approveExpense: 'approve.expenses', rejectExpense: 'approve.expenses', createLedger: 'write.masters', createCustomer: 'write.masters', createVendor: 'write.masters',
    importBankStatement: 'reconcile.bank', autoReconcile: 'reconcile.bank', setBankMatch: 'reconcile.bank',
    getTallyStatus: 'view.tally', getSyncLog: 'view.tally', getTallyErrors: 'view.tally', getTallyData: 'view.tally', requestTallySync: 'run.sync', resolveTallyError: 'run.sync',
    getAuditLog: 'view.audit', resolveNotification: 'resolve.alerts', getSettings: 'admin.settings', updateSetting: 'admin.settings', updateConfig: 'admin.settings',
    getUsers: 'admin.users', createUser: 'admin.users', updateUser: 'admin.users', getLookups: 'view.lookup'
  };
  ROUTE_PERMS.getExpenses = 'submit.expenses|view.accounts';
  function can(role, perm) { var p = ROLE_PERMISSIONS[role] || []; return !perm || p.indexOf('*') >= 0 || String(perm).split('|').some(function (x) { return p.indexOf(x) >= 0; }); }

  var DEMO_KEY = 'acctdash.demo.v1';
  var db = null, mut = null, ctxCache = null, version = 0;
  function persist() { try { storage('localStorage').setItem(DEMO_KEY, JSON.stringify(mut)); } catch (e) { /* quota / private mode */ } }
  var TABLE_KEY = { VOUCHERS: 'vouchers', VOUCHER_ENTRIES: 'entries', BILL_REFERENCES: 'bills', LEDGERS: 'ledgers', SALES_ITEMS: 'salesItems', OFFLINE_SALES: 'offlineSales', EXPENSES: 'expenses', AUDIT_LOG: 'audit', NOTIFICATIONS: 'notifications', BANK_TRANSACTIONS: 'bankTransactions', BANK_RECONCILIATION: 'bankRecon', TALLY_SYNC_LOG: 'syncLog', TALLY_ERRORS: 'tallyErrors', CUSTOMERS: 'customers', VENDORS: 'vendors', USERS: 'users', CONFIG: 'config' };
  function applyAdd(t, rows) { var k = TABLE_KEY[t]; db[k] = db[k].concat(rows); }
  function applyPatch(t, idField, id, patch) { var k = TABLE_KEY[t]; db[k].forEach(function (r) { if (String(r[idField]) === String(id)) Object.keys(patch).forEach(function (f) { r[f] = patch[f]; }); }); }
  function add(t, rows) { rows = JSON.parse(JSON.stringify(rows)); applyAdd(t, rows); mut.ops.push(['add', t, rows]); touch(); return rows; }
  function patch(t, idField, id, p) { applyPatch(t, idField, id, p); mut.ops.push(['patch', t, idField, id, p]); touch(); }
  function touch() { version++; ctxCache = null; persist(); }
  function init() {
    if (db) return;
    db = DemoData.build(U.D(new Date()));
    try { mut = JSON.parse(storage('localStorage').getItem(DEMO_KEY) || 'null'); } catch (e) { mut = null; }
    if (!mut || !mut.ops) mut = { ops: [], settings: {}, seq: 1000 };
    mut.ops.forEach(function (op) { try { if (op[0] === 'add') applyAdd(op[1], op[2]); else applyPatch(op[1], op[2], op[3], op[4]); } catch (e) { /* stale op */ } });
    db.settings = mut.settings || {};
  }
  function ctx() {
    init();
    if (!ctxCache) ctxCache = Engine.createContext(db, db.settings);
    return ctxCache;
  }
  function nextId(prefix) { mut.seq = (mut.seq || 1000) + 1; return prefix + '-' + ('000000' + mut.seq).slice(-6); }
  function nowStr() { var d = new Date(); return U.D(d) + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
  function fail(code, msg, details) { throw new ApiError(code, msg, details); }
  function audit(session, action, entity, id, oldV, newV) { add('AUDIT_LOG', [{ audit_id: nextId('AUD'), timestamp: nowStr(), user: session.email, role: session.role, action: action, entity: entity, record_id: id, old_value: oldV ? JSON.stringify(oldV) : '', new_value: newV ? JSON.stringify(newV) : '', source: 'WEB' }]); }

  function paging(rows, p) {
    p = p || {};
    if (p.q) { var q = String(p.q).toLowerCase(); rows = rows.filter(function (r) { return Object.keys(r).some(function (k) { var v = r[k]; return v !== null && typeof v !== 'object' && String(v).toLowerCase().indexOf(q) >= 0; }); }); }
    if (p.sort) { var dir = p.dir === 'desc' ? -1 : 1, s = p.sort; rows = rows.slice().sort(function (a, b) { var x = a[s], y = b[s]; return (x < y ? -1 : x > y ? 1 : 0) * dir; }); }
    var size = Math.min(Math.max(Number(p.pageSize) || 50, 1), 5000), page = Math.max(Number(p.page) || 1, 1);
    return { rows: rows.slice((page - 1) * size, page * size), total: rows.length, page: page, pageSize: size, pages: Math.max(1, Math.ceil(rows.length / size)) };
  }
  function period(p) {
    var o = {}; Object.keys(p || {}).forEach(function (k) { o[k] = p[k]; });
    if (o.preset && o.preset !== 'custom') { var r = U.periodRange(o.preset, ctx().today, ctx().fyM); o.from = r.from; o.to = r.to; }
    return o;
  }
  function names(pred) { var c = ctx(); return Object.keys(c.allLedgerNames).map(function (k) { return c.allLedgerNames[k]; }).filter(function (n) { return pred(c.ledgerInfo(n)); }).sort(); }
  function ledgerExists(n) { return db.ledgers.some(function (l) { return l.ledger_name.toLowerCase() === String(n || '').toLowerCase(); }); }

  function postVouchers(built, session) {
    var keys = {}; db.vouchers.forEach(function (v) { keys[v.unique_key] = true; });
    built.forEach(function (b) {
      if (keys[b.header.unique_key]) fail('DUPLICATE_VOUCHER', 'Duplicate voucher detected: ' + b.header.voucher_type + ' ' + b.header.voucher_number + ' already exists.');
      var chk = Engine.validateVoucher(b.header, b.lines); if (!chk.valid) fail('UNBALANCED', chk.errors.join(' '));
    });
    return built.map(function (b) {
      var h = b.header; h.voucher_id = nextId('VCH'); h.company_id = 'CMP-0001'; h.revision = 1; h.created_by = session.email; h.created_at = nowStr();
      add('VOUCHERS', [h]);
      add('VOUCHER_ENTRIES', b.lines.map(function (l) { l.voucher_id = h.voucher_id; l.revision = 1; return l; }));
      add('BILL_REFERENCES', (b.bills || []).map(function (x) { x.voucher_id = h.voucher_id; x.revision = 1; return x; }));
      return h;
    });
  }
  function postLedgers(list, session) {
    var fresh = (list || []).filter(function (l) { return !ledgerExists(l.ledger_name); });
    fresh.forEach(function (l) { l.ledger_id = nextId('LED'); l.company_id = 'CMP-0001'; });
    if (fresh.length) {
      add('LEDGERS', fresh);
      var c = fresh.filter(function (l) { return l.parent_group === 'Sundry Debtors'; }).map(function (l) { return { customer_id: nextId('CUS'), customer_name: l.ledger_name, gstin: l.gstin || '', mobile: l.mobile || '', state: l.state || '', credit_days: l.credit_days || '', status: 'ACTIVE', source: l.source }; });
      var v = fresh.filter(function (l) { return l.parent_group === 'Sundry Creditors'; }).map(function (l) { return { vendor_id: nextId('VEN'), vendor_name: l.ledger_name, gstin: l.gstin || '', state: l.state || '', credit_days: l.credit_days || '', msme_registered: !!l.msme_registered, status: 'ACTIVE', source: l.source }; });
      if (c.length) add('CUSTOMERS', c);
      if (v.length) add('VENDORS', v);
      fresh.forEach(function (l) { audit(session, 'CREATE', 'LEDGERS', l.ledger_id, null, { ledger_name: l.ledger_name, parent_group: l.parent_group, source: l.source }); });
    }
    return fresh;
  }
  function docNo(series) { mut.docs = mut.docs || {}; mut.docs[series] = (mut.docs[series] || 0) + 1; persist(); var fs = U.fyStart(ctx().today, ctx().fyM); return series + '/' + fs.slice(2, 4) + String(+fs.slice(2, 4) + 1).slice(-2) + '/' + ('000' + mut.docs[series]).slice(-4); }

  function partyList(kind, p) {
    p = period(p);
    var acc = Engine.partyAccounts(ctx(), { kind: kind, from: p.from, to: p.to });
    var prof = {}; (kind === 'customer' ? db.customers : db.vendors).forEach(function (r) { prof[String(r.customer_name || r.vendor_name).toLowerCase()] = r; });
    var seen = {};
    var rows = acc.rows.map(function (r) { seen[r.party.toLowerCase()] = 1; return merge(r, prof[r.party.toLowerCase()] || {}); });
    Object.keys(prof).forEach(function (k) { if (!seen[k]) rows.push(merge({ party: prof[k].customer_name || prof[k].vendor_name, opening: 0, invoices: 0, notes: 0, settlements: 0, adjustments: 0, closing: 0, outstanding_bills: 0, overdue_bills: 0, overdue_amount: 0 }, prof[k])); });
    function merge(r, pr) {
      r.gstin = r.gstin || pr.gstin || ''; r.mobile = pr.mobile || ''; r.email = pr.email || ''; r.state = pr.state || ''; r.credit_days = pr.credit_days || ''; r.status = pr.status || 'ACTIVE';
      if (kind === 'customer') { r.credit_limit = pr.credit_limit || ''; r.salesperson = pr.salesperson || ''; r.over_limit = pr.credit_limit ? r.closing > pr.credit_limit : false; } else { r.msme = !!pr.msme_registered; r.category = pr.vendor_category || ''; }
      delete r.ageing; return r;
    }
    var out = paging(rows, p); out.totals = acc.totals; out.labels = acc.labels; out.from = acc.from; out.to = acc.to; return out;
  }
  function outstandingP(kind, p) {
    var o = Engine.outstanding(ctx(), { kind: kind, asOf: p.asOf });
    var b = o.bills;
    if (p.party) b = b.filter(function (x) { return x.party.toLowerCase() === String(p.party).toLowerCase(); });
    if (p.status) b = b.filter(function (x) { return x.status === p.status; });
    if (p.bucket) b = b.filter(function (x) { return x.ageing_bucket === p.bucket; });
    o.bills = paging(b, p); return o;
  }
  function bankSummary(id) {
    var acct = db.bankAccounts.filter(function (a) { return a.bank_account_id === id; })[0]; if (!acct) return null;
    var c = ctx(), txns = db.bankTransactions.filter(function (t) { return t.bank_account_id === id; });
    var matched = {}; txns.forEach(function (t) { if (t.matched_voucher_id) matched[t.matched_voucher_id] = 1; });
    var first = txns.reduce(function (m, t) { return t.txn_date < m ? t.txn_date : m; }, c.today);
    var notInBank = c.lines.filter(function (l) { return l.ledger === acct.ledger_name && l.date >= first && !matched[l.v.id]; });
    var notInBooks = txns.filter(function (t) { return t.reconciliation_status === 'Unmatched' || t.reconciliation_status === 'Pending'; });
    return { account: acct.ledger_name, balanceAsPerBooks: Engine.balanceAt(c, acct.ledger_name, c.today), balanceAsPerStatement: null,
      depositsNotCredited: U.r2(notInBank.filter(function (l) { return l.nd > 0; }).reduce(function (s, l) { return s + l.nd; }, 0)),
      chequesNotPresented: U.r2(notInBank.filter(function (l) { return l.nd < 0; }).reduce(function (s, l) { return s - l.nd; }, 0)),
      creditsNotInBooks: U.r2(notInBooks.reduce(function (s, t) { return s + (+t.credit || 0); }, 0)), debitsNotInBooks: U.r2(notInBooks.reduce(function (s, t) { return s + (+t.debit || 0); }, 0)),
      unmatchedBookEntries: notInBank.length, unmatchedStatementLines: notInBooks.length };
  }

  var H = {
    health: function () { return { status: 'ok', mode: 'demo', engine: Engine.VERSION }; },
    login: function (p) {
      init();
      var role = p.role || 'ADMIN';
      var u = db.users.filter(function (x) { return x.role === role; })[0] || db.users[0];
      return { token: 'demo-' + role, user: { email: u.email, name: u.full_name, role: u.role, permissions: ROLE_PERMISSIONS[u.role] }, expiresIn: 21600 };
    },
    logout: function () { return { loggedOut: true }; },
    getDashboard: function (p) { var d = Engine.dashboard(ctx(), { date: p.date }); d.lastSync = db.syncLog[0]; d.openAlerts = Engine.alerts(ctx(), {}).length; d.company = db.company.company_name; return d; },
    getManagementDashboard: function (p) { return Engine.managementDashboard(ctx(), { date: p.date }); },
    getFinancialHealth: function (p) { return Engine.financialHealth(ctx(), period(p)); },
    getAnalytics: function (p) { return Engine.analytics(ctx(), period(p)); },
    getAlerts: function (p) {
      var st = {}; db.notifications.forEach(function (n) { st[n.dedupe_key] = n.status; });
      var all = Engine.alerts(ctx(), { date: p.date }).map(function (a) { a.status = st[a.dedupe_key] || 'OPEN'; return a; }).filter(function (a) { return a.status !== 'RESOLVED'; });
      db.tallyErrors.filter(function (e) { return !e.resolved; }).forEach(function (e) { all.push({ severity: 'CRITICAL', category: 'SYNC_FAILED', title: 'Tally voucher rejected: ' + e.voucher_number, message: e.message, dedupe_key: 'TER|' + e.error_id, status: 'OPEN' }); });
      var rank = { CRITICAL: 0, WARNING: 1, INFO: 2 }; all.sort(function (a, b) { return rank[a.severity] - rank[b.severity]; });
      return { alerts: all, counts: { critical: all.filter(function (a) { return a.severity === 'CRITICAL'; }).length, warning: all.filter(function (a) { return a.severity === 'WARNING'; }).length } };
    },
    searchTransactions: function (p) { return Engine.search(ctx(), { q: p.q }); },
    getLookups: function () {
      var c = ctx();
      return {
        customers: names(function (i) { return i.isDebtor; }), vendors: names(function (i) { return i.isCreditor; }), cashBank: names(function (i) { return i.isCashEq; }),
        expenseLedgers: names(function (i) { return i.nature === 'Expenses' && i.primary !== 'Purchase Accounts'; }), allLedgers: names(function () { return true; }),
        groups: Object.keys(Engine.RESERVED_GROUPS).concat(db.groups.map(function (g) { return g.group_name; })).sort(),
        products: db.products.map(function (x) { return { name: x.product_name, hsn: x.hsn_sac, uom: x.uom, rate: x.sale_rate, gst: x.gst_rate }; }),
        salespersons: Object.keys(c.vouchers.reduce(function (o, v) { if (v.salesperson) o[v.salesperson] = 1; return o; }, {})).sort(),
        costCentres: ['Delhi Showroom', 'Factory', 'Head Office'], bankAccounts: db.bankAccounts,
        paymentModeLedgers: { 'Cash': 'Cash', 'UPI': 'UPI Collections', 'Bank Transfer': 'HDFC Bank CA 4521', 'Cheque': 'HDFC Bank CA 4521', 'Other': 'Cash' },
        companyState: c.S.COMPANY_STATE, fyStartMonth: c.fyM,
        expenseCategories: ['Salary', 'Rent', 'Electricity', 'Internet', 'Transportation', 'Office Expenses', 'Repairs', 'Maintenance', 'Marketing', 'Travel', 'Professional Fees', 'Miscellaneous']
      };
    },
    getSales: function (p) { p = period(p); var r = Engine.register(ctx(), { kind: 'sales', from: p.from, to: p.to, party: p.customer, status: p.status, source: p.source, salesperson: p.salesperson }); var o = paging(r.rows, p); o.totals = r.totals; o.from = r.from; o.to = r.to; return o; },
    getSalesReport: function (p) { p = period(p); return Engine.salesReport(ctx(), { kind: 'sales', groupBy: p.groupBy, from: p.from, to: p.to }); },
    getPurchases: function (p) { p = period(p); var r = Engine.register(ctx(), { kind: 'purchase', from: p.from, to: p.to, party: p.vendor, status: p.status, source: p.source }); var o = paging(r.rows, p); o.totals = r.totals; o.from = r.from; o.to = r.to; return o; },
    getPurchaseReport: function (p) { p = period(p); return Engine.salesReport(ctx(), { kind: 'purchase', groupBy: p.groupBy === 'customer' ? 'vendor' : p.groupBy, from: p.from, to: p.to }); },
    getCustomers: function (p) { return partyList('customer', p); },
    getVendors: function (p) { return partyList('vendor', p); },
    getReceivables: function (p) { return outstandingP('receivable', p); },
    getPayables: function (p) { return outstandingP('payable', p); },
    getAgeing: function (p) { return outstandingP(p.kind === 'payable' ? 'payable' : 'receivable', p); },
    getPartyAccounts: function (p) { p = period(p); return Engine.partyAccounts(ctx(), p); },
    getReceipts: function (p) { p = period(p); var r = Engine.cashRegister(ctx(), { kind: 'receipt', from: p.from, to: p.to, party: p.party }); var o = paging(r.rows, p); o.total_amount = r.total; return o; },
    getPayments: function (p) { p = period(p); var r = Engine.cashRegister(ctx(), { kind: 'payment', from: p.from, to: p.to, party: p.party }); var o = paging(r.rows, p); o.total_amount = r.total; return o; },
    getExpenses: function (p) {
      p = period(p); init();
      var rows = db.expenses.filter(function (e) { return (!p.from || e.expense_date >= p.from) && (!p.to || e.expense_date <= p.to) && (!p.status || e.approval_status === p.status) && (!p.category || e.category === p.category); })
        .sort(function (a, b) { return a.expense_date < b.expense_date ? 1 : -1; });
      // Posted expense ledgers from the books give the monthly analysis
      var c = ctx(), byCat = {}, byMonth = {};
      c.lines.forEach(function (l) {
        if (l.info.nature !== 'Expenses' || l.info.primary === 'Purchase Accounts' || (p.from && l.date < p.from) || (p.to && l.date > p.to)) return;
        byCat[l.info.name] = U.r2((byCat[l.info.name] || 0) + l.nd);
        byMonth[l.date.slice(0, 7)] = U.r2((byMonth[l.date.slice(0, 7)] || 0) + l.nd);
      });
      var o = paging(rows, p);
      o.byCategory = Object.keys(byCat).map(function (k) { return { category: k, amount: byCat[k] }; }).sort(function (a, b) { return b.amount - a.amount; });
      o.byMonth = Object.keys(byMonth).sort().map(function (k) { return { month: k, amount: byMonth[k] }; });
      o.pending = db.expenses.filter(function (e) { return e.approval_status === 'Pending'; }).length;
      return o;
    },
    getLedgers: function (p) {
      p = period(p);
      var tb = Engine.trialBalance(ctx(), { from: p.from, to: p.to, includeZero: true });
      var m = {}; db.ledgers.forEach(function (l) { m[l.ledger_name.toLowerCase()] = l; });
      var rows = tb.rows.map(function (r) { var x = m[r.ledger.toLowerCase()] || {}; return { ledger: r.ledger, group: r.group, primary: r.primary, nature: r.nature, ledger_type: x.ledger_type || '', gstin: x.gstin || '', source: x.source || '', opening: U.r2(r.openingDr - r.openingCr), debit: r.periodDr, credit: r.periodCr, closing: U.r2(r.closingDr - r.closingCr) }; });
      if (p.group) rows = rows.filter(function (r) { return r.group === p.group || r.primary === p.group; });
      return paging(rows, p);
    },
    getLedgerStatement: function (p) { return Engine.ledgerStatement(ctx(), period(p)); },
    getCashBook: function (p) { p = period(p); var cb = Engine.cashBook(ctx(), p); cb.rows = paging(cb.rows.slice().reverse(), p); return cb; },
    getBankTransactions: function (p) {
      init();
      var rows = db.bankTransactions.filter(function (t) { return (!p.bank_account_id || t.bank_account_id === p.bank_account_id) && (!p.status || t.reconciliation_status === p.status); }).sort(function (a, b) { return a.txn_date < b.txn_date ? 1 : -1; });
      var o = paging(rows, p); o.accounts = db.bankAccounts; o.summary = bankSummary(p.bank_account_id || 'BNK-0001'); return o;
    },
    getTrialBalance: function (p) { return Engine.trialBalance(ctx(), period(p)); },
    getProfitLoss: function (p) { p = period(p); var pl = Engine.profitLoss(ctx(), p); if (p.comparative) pl.comparative = Engine.profitLossComparative(ctx(), { asOf: p.to }); else pl.trend = Engine.monthlyTrend(ctx(), { from: pl.from, to: pl.to }); return pl; },
    getBalanceSheet: function (p) { return Engine.balanceSheet(ctx(), { asOf: p.asOf || period(p).to }); },
    getCashFlow: function (p) { return Engine.cashFlow(ctx(), period(p)); },
    getGSTSummary: function (p) { var g = Engine.gstSummary(ctx(), period(p)); g.transactions = paging(g.transactions, p); return g; },
    getVoucher: function (p) {
      init();
      var h = db.vouchers.filter(function (v) { return v.voucher_id === p.voucher_id; })[0];
      if (!h) fail('NOT_FOUND', 'Voucher not found.');
      var rev = +h.revision || 1, mine = function (r) { return r.voucher_id === h.voucher_id && (+r.revision || 1) === rev; };
      var lines = db.entries.filter(mine).sort(function (a, b) { return a.line_no - b.line_no; });
      var dr = U.r2(lines.reduce(function (s, l) { return s + (+l.debit || 0); }, 0)), cr = U.r2(lines.reduce(function (s, l) { return s + (+l.credit || 0); }, 0));
      return { header: h, lines: lines, bills: db.bills.filter(mine), items: db.salesItems.filter(mine).concat(db.purchaseItems.filter(mine)), totalDebit: dr, totalCredit: cr, balanced: Math.abs(dr - cr) < 0.01 };
    },
    getInventory: function (p) {
      var c = ctx(), asOf = p.asOf || c.today;
      var sales = Engine.salesReport(c, { groupBy: 'product', from: U.fyStart(asOf, c.fyM), to: asOf }).rows;
      var sold = {}; sales.forEach(function (r) { sold[r.key] = r; });
      var vals = db.inventory.filter(function (r) { return r.as_of_date <= asOf; }).sort(function (a, b) { return a.as_of_date < b.as_of_date ? 1 : -1; });
      return { asOf: asOf, stockValue: Engine.stockAt(c, asOf), valuations: vals, source: c.S.STOCK_VALUATION_SOURCE,
        products: db.products.map(function (x) { var s = sold[x.product_name] || {}; return { product: x.product_name, hsn_sac: x.hsn_sac, uom: x.uom, gst_rate: x.gst_rate, sale_rate: x.sale_rate, purchase_rate: x.purchase_rate, qty_sold: s.quantity || 0, revenue: s.taxable || 0, avg_price: s.avg_price || 0 }; }) };
    },

    saveOfflineSale: function (p, s) {
      init();
      p.invoice_date = U.D(p.invoice_date || ctx().today);
      if (!p.invoice_no) p.invoice_no = docNo('OFF');
      if (db.offlineSales.some(function (r) { return String(r.invoice_no).toLowerCase() === String(p.invoice_no).toLowerCase(); })) fail('DUPLICATE_VOUCHER', 'Offline invoice ' + p.invoice_no + ' already exists.');
      var modes = H.getLookups().paymentModeLedgers;
      var settings = {}; Object.keys(db.settings).forEach(function (k) { settings[k] = db.settings[k]; }); settings.PAYMENT_MODE_LEDGERS = JSON.stringify(modes);
      var built = Engine.buildOfflineSale(p, settings, db.ledgers.map(function (l) { return l.ledger_name; }));
      if (!built.valid) fail('INVALID_INVOICE', 'Invalid invoice data.', built.errors);
      built.newLedgers.forEach(function (l) { if (l.parent_group === 'Sundry Debtors') l.mobile = p.mobile || ''; });
      postLedgers(built.newLedgers, s);
      var heads = postVouchers(built.vouchers, s);
      add('SALES_ITEMS', built.items.map(function (it) { it.voucher_id = heads[0].voucher_id; it.revision = 1; return it; }));
      var row = built.offlineRow; row.offline_sale_id = nextId('OFS'); row.voucher_id = heads[0].voucher_id; row.receipt_voucher_id = heads[1] ? heads[1].voucher_id : ''; row.created_by = s.email; row.created_at = nowStr();
      add('OFFLINE_SALES', [row]);
      audit(s, 'CREATE', 'OFFLINE_SALES', row.offline_sale_id, null, { invoice_no: p.invoice_no, total: built.totals.total, paid: built.totals.paid });
      return { offline_sale_id: row.offline_sale_id, invoice_no: p.invoice_no, voucher_ids: heads.map(function (h) { return h.voucher_id; }), totals: built.totals, ledgersCreated: built.newLedgers.map(function (l) { return l.ledger_name; }) };
    },
    saveReceipt: function (p, s) { return H.cash_('receipt', p, s); },
    savePayment: function (p, s) { return H.cash_('payment', p, s); },
    cash_: function (kind, p, s) {
      init();
      p.date = U.D(p.date || ctx().today);
      if (!p.number) p.number = docNo(kind === 'receipt' ? 'RCPT' : 'PYMT');
      [p.party_ledger, p.bank_ledger].forEach(function (n) { if (n && !ledgerExists(n)) fail('VALIDATION', 'Ledger "' + n + '" does not exist.'); });
      var b = Engine.buildCashVoucher(kind, p, db.settings, db.ledgers.map(function (l) { return l.ledger_name; }));
      if (!b.valid) fail('VALIDATION', b.errors.join(' '), b.errors);
      postLedgers(b.newLedgers, s);
      var h = postVouchers(b.vouchers, s)[0];
      audit(s, 'CREATE', kind === 'receipt' ? 'RECEIPTS' : 'PAYMENTS', h.voucher_id, null, { number: p.number, party: p.party_ledger, amount: p.amount });
      return { voucher_id: h.voucher_id, number: p.number };
    },
    saveJournal: function (p, s) {
      init();
      var date = U.D(p.date || ctx().today), number = p.number || docNo('JV');
      var lines = (p.lines || []).map(function (l, i) { if (!ledgerExists(l.ledger_name)) fail('VALIDATION', 'Line ' + (i + 1) + ': ledger "' + l.ledger_name + '" does not exist.'); return { line_no: i + 1, ledger_name: l.ledger_name, debit: +l.debit || 0, credit: +l.credit || 0 }; });
      var header = { voucher_date: date, voucher_type: 'Journal', base_voucher_type: 'Journal', voucher_number: number, narration: p.narration || '', source: 'MANUAL', status: 'ACTIVE', unique_key: 'MANUAL:JOURNAL:' + number.toLowerCase() };
      var chk = Engine.validateVoucher(header, lines); if (!chk.valid) fail('UNBALANCED', chk.errors.join(' '), chk.errors);
      header.amount = chk.totalDebit;
      var h = postVouchers([{ header: header, lines: lines, bills: [] }], s)[0];
      audit(s, 'CREATE', 'JOURNALS', h.voucher_id, null, { number: number, lines: lines });
      return { voucher_id: h.voucher_id, number: number };
    },
    cancelVoucher: function (p, s) {
      init();
      var v = db.vouchers.filter(function (x) { return x.voucher_id === p.voucher_id; })[0];
      if (!v) fail('NOT_FOUND', 'Voucher not found.');
      if (v.source === 'TALLY') fail('FORBIDDEN', 'Tally vouchers must be cancelled in Tally; the next sync will reflect it.');
      if (!p.reason) fail('VALIDATION', 'A reason is required.');
      patch('VOUCHERS', 'voucher_id', p.voucher_id, { status: 'CANCELLED' });
      audit(s, 'DELETE', 'VOUCHERS', p.voucher_id, { status: v.status }, { status: 'CANCELLED', reason: p.reason });
      return { voucher_id: p.voucher_id, status: 'CANCELLED' };
    },
    saveExpense: function (p, s) {
      init();
      ['expense_date', 'category', 'amount', 'expense_ledger', 'payment_mode'].forEach(function (f) { if (!p[f]) fail('VALIDATION', 'Missing required field: ' + f + '.'); });
      if (!(+p.amount > 0)) fail('VALIDATION', 'Amount must be a positive number.');
      var gst = p.gst_amount !== undefined && p.gst_amount !== '' ? +p.gst_amount : U.r2(+p.amount * (+p.gst_rate || 0) / 100);
      var row = { expense_id: nextId('EXP'), expense_date: U.D(p.expense_date), category: p.category, vendor_ledger: p.vendor_ledger || '', description: p.description || '', amount: +p.amount, gst_rate: +p.gst_rate || 0, gst_amount: gst, total_amount: U.r2(+p.amount + gst), payment_mode: p.payment_mode, paid_from_ledger: p.paid_from_ledger || '', expense_ledger: p.expense_ledger, cost_centre: p.cost_centre || '', approval_status: 'Pending', created_by: s.email, created_at: nowStr() };
      add('EXPENSES', [row]); audit(s, 'CREATE', 'EXPENSES', row.expense_id, null, row);
      return { expense_id: row.expense_id, approval_status: 'Pending' };
    },
    approveExpense: function (p, s) {
      init();
      var e = db.expenses.filter(function (x) { return x.expense_id === p.expense_id; })[0];
      if (!e) fail('NOT_FOUND', 'Expense not found.');
      if (e.approval_status !== 'Pending') fail('VALIDATION', 'Expense is already ' + e.approval_status + '.');
      if (e.created_by === s.email && s.role !== 'ADMIN') fail('FORBIDDEN', 'Maker-checker: you cannot approve an expense you entered.');
      var b = Engine.buildExpenseVoucher(e, db.settings); if (!b.valid) fail('VALIDATION', b.errors.join(' '));
      var S = ctx().S;
      postLedgers(b.vouchers[0].lines.map(function (l) { return l.ledger_name; }).filter(function (n) { return !ledgerExists(n); }).map(function (n) {
        var tax = [S.INPUT_CGST_LEDGER, S.INPUT_SGST_LEDGER, S.INPUT_IGST_LEDGER].indexOf(n) >= 0;
        return tax ? { ledger_name: n, parent_group: 'Duties & Taxes', ledger_type: 'Tax', tax_type: n.indexOf('IGST') >= 0 ? 'IGST' : n.indexOf('CGST') >= 0 ? 'CGST' : 'SGST', source: 'AUTO', opening_balance: 0, opening_dr_cr: 'Dr' } : { ledger_name: n, parent_group: 'Indirect Expenses', ledger_type: 'Expense', source: 'AUTO', needs_review: true, opening_balance: 0, opening_dr_cr: 'Dr' };
      }), s);
      var h = postVouchers(b.vouchers, s)[0];
      patch('EXPENSES', 'expense_id', p.expense_id, { approval_status: 'Approved', approved_by: s.email, approved_at: nowStr(), voucher_id: h.voucher_id });
      audit(s, 'APPROVE', 'EXPENSES', p.expense_id, { approval_status: 'Pending' }, { approval_status: 'Approved', voucher_id: h.voucher_id });
      return { expense_id: p.expense_id, voucher_id: h.voucher_id };
    },
    rejectExpense: function (p, s) {
      init();
      var e = db.expenses.filter(function (x) { return x.expense_id === p.expense_id; })[0];
      if (!e || e.approval_status !== 'Pending') fail('VALIDATION', 'Only pending expenses can be rejected.');
      if (!p.reason) fail('VALIDATION', 'A reason is required.');
      patch('EXPENSES', 'expense_id', p.expense_id, { approval_status: 'Rejected', approved_by: s.email, approved_at: nowStr() });
      audit(s, 'REJECT', 'EXPENSES', p.expense_id, { approval_status: 'Pending' }, { approval_status: 'Rejected', reason: p.reason });
      return { expense_id: p.expense_id, approval_status: 'Rejected' };
    },
    createLedger: function (p, s) {
      init();
      if (!p.ledger_name || !p.parent_group) fail('VALIDATION', 'Ledger name and group are required.');
      if (ledgerExists(p.ledger_name)) fail('DUPLICATE', 'Ledger "' + p.ledger_name + '" already exists.');
      if (p.gstin && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(String(p.gstin).toUpperCase())) fail('VALIDATION', 'GSTIN format is invalid.');
      var l = { ledger_name: String(p.ledger_name).trim(), parent_group: p.parent_group, ledger_type: p.ledger_type || 'Other', opening_balance: +p.opening_balance || 0, opening_dr_cr: p.opening_dr_cr === 'Cr' ? 'Cr' : 'Dr', gstin: String(p.gstin || '').toUpperCase(), state: p.state || '', credit_days: p.credit_days || '', mobile: p.mobile || '', msme_registered: p.msme_registered === true || p.msme_registered === 'true', is_active: true, source: 'MANUAL' };
      var c = postLedgers([l], s)[0];
      return { ledger_id: c.ledger_id, ledger_name: c.ledger_name };
    },
    createCustomer: function (p, s) { p.parent_group = 'Sundry Debtors'; p.ledger_type = 'Customer'; p.ledger_name = p.ledger_name || p.customer_name; return H.createLedger(p, s); },
    createVendor: function (p, s) { p.parent_group = 'Sundry Creditors'; p.ledger_type = 'Vendor'; p.ledger_name = p.ledger_name || p.vendor_name; return H.createLedger(p, s); },
    importBankStatement: function (p, s) {
      init();
      var batch = 'STMT-' + Date.now(), have = {}, fresh = [], dup = 0;
      db.bankTransactions.forEach(function (t) { have[[t.bank_account_id, t.txn_date, +t.debit || 0, +t.credit || 0, t.reference].join('|')] = 1; });
      (p.rows || []).forEach(function (r, i) {
        var d = U.D(r.txn_date || r.date); if (!d) fail('VALIDATION', 'Row ' + (i + 1) + ': invalid date.');
        var dr = +r.debit || 0, cr = +r.credit || 0; if ((dr && cr) || (!dr && !cr)) fail('VALIDATION', 'Row ' + (i + 1) + ': exactly one of debit/credit is required.');
        var k = [p.bank_account_id, d, dr, cr, r.reference || ''].join('|'); if (have[k]) { dup++; return; } have[k] = 1;
        fresh.push({ bank_txn_id: nextId('BTX'), bank_account_id: p.bank_account_id, txn_date: d, description: r.description || '', reference: r.reference || '', debit: dr, credit: cr, balance: r.balance || '', import_batch: batch, reconciliation_status: 'Pending', matched_voucher_id: '' });
      });
      if (fresh.length) add('BANK_TRANSACTIONS', fresh);
      audit(s, 'IMPORT', 'BANK_TRANSACTIONS', batch, null, { imported: fresh.length, duplicates: dup });
      return { batch: batch, imported: fresh.length, duplicatesSkipped: dup };
    },
    autoReconcile: function (p, s) {
      init();
      var acct = db.bankAccounts.filter(function (a) { return a.bank_account_id === p.bank_account_id; })[0]; if (!acct) fail('NOT_FOUND', 'Bank account not found.');
      var c = ctx(), used = {};
      db.bankTransactions.forEach(function (t) { if (t.matched_voucher_id) used[t.matched_voucher_id] = 1; });
      var book = c.lines.filter(function (l) { return l.ledger === acct.ledger_name && !used[l.v.id]; });
      var res = { matched: 0, partiallyMatched: 0, unmatched: 0 };
      db.bankTransactions.filter(function (t) { return t.bank_account_id === p.bank_account_id && (t.reconciliation_status === 'Pending' || t.reconciliation_status === 'Unmatched'); }).forEach(function (t) {
        var amt = +t.credit || -(+t.debit);
        var cands = book.filter(function (l) { return Math.abs(l.nd - amt) < 0.005 && Math.abs(U.daysBetween(l.date, t.txn_date)) <= 5; });
        var tokens = String(t.reference + ' ' + t.description).toUpperCase().split(/[^A-Z0-9]+/).filter(function (x) { return x.length >= 6; });
        var byRef = cands.filter(function (l) { var hay = (l.v.ref + ' ' + l.v.narration + ' ' + l.v.number + ' ' + l.v.party).toUpperCase(); return tokens.some(function (tk) { return hay.indexOf(tk) >= 0; }); });
        var same = cands.filter(function (l) { return l.date === t.txn_date; });
        var pick = byRef.length === 1 ? byRef[0] : same.length === 1 ? same[0] : cands.length === 1 ? cands[0] : null;
        var status = pick ? (byRef.length === 1 || same.length === 1 ? 'Matched' : 'Partially Matched') : 'Unmatched';
        if (pick) book.splice(book.indexOf(pick), 1);
        res[status === 'Matched' ? 'matched' : status === 'Unmatched' ? 'unmatched' : 'partiallyMatched']++;
        patch('BANK_TRANSACTIONS', 'bank_txn_id', t.bank_txn_id, { reconciliation_status: status, matched_voucher_id: pick ? pick.v.id : '' });
      });
      audit(s, 'RECONCILE', 'BANK_RECONCILIATION', p.bank_account_id, null, res);
      res.summary = bankSummary(p.bank_account_id);
      return res;
    },
    setBankMatch: function (p, s) {
      patch('BANK_TRANSACTIONS', 'bank_txn_id', p.bank_txn_id, { reconciliation_status: p.voucher_id ? 'Matched' : 'Unmatched', matched_voucher_id: p.voucher_id || '' });
      audit(s, 'RECONCILE', 'BANK_TRANSACTIONS', p.bank_txn_id, null, { voucher_id: p.voucher_id || '' });
      return { bank_txn_id: p.bank_txn_id };
    },
    getTallyStatus: function () {
      init();
      var counts = {}; db.vouchers.forEach(function (v) { var k = v.source + '|' + v.status; counts[k] = (counts[k] || 0) + 1; });
      return { lastSuccess: db.syncLog.filter(function (l) { return l.status === 'SUCCESS' || l.status === 'PARTIAL'; })[0], connectorLastSeen: db.syncLog[0].start_time, pending: db.syncLog.filter(function (l) { return l.status === 'REQUESTED'; }).length, running: 0, unresolvedErrors: db.tallyErrors.filter(function (e) { return !e.resolved; }).length, voucherCounts: counts, config: db.config.reduce(function (o, c) { o[c.config_key] = c.config_value; return o; }, {}), recent: db.syncLog.slice(0, 25) };
    },
    getSyncLog: function (p) { init(); return paging(db.syncLog, p); },
    getTallyErrors: function (p) { init(); return paging(db.tallyErrors.filter(function (e) { return p.all || !e.resolved; }), p); },
    getTallyData: function (p) {
      init();
      var v = db.vouchers.filter(function (x) { return x.voucher_id === p.voucher_id || x.unique_key === p.unique_key; })[0];
      if (!v) return paging([], p);
      var lines = db.entries.filter(function (e) { return e.voucher_id === v.voucher_id; });
      var xml = '<VOUCHER VCHTYPE="' + v.voucher_type + '" ACTION="Create">\n  <DATE>' + v.voucher_date.replace(/-/g, '') + '</DATE>\n  <VOUCHERTYPENAME>' + v.voucher_type + '</VOUCHERTYPENAME>\n  <VOUCHERNUMBER>' + v.voucher_number + '</VOUCHERNUMBER>\n  <PARTYLEDGERNAME>' + (v.party_ledger || '') + '</PARTYLEDGERNAME>\n' +
        lines.map(function (l) { return '  <ALLLEDGERENTRIES.LIST>\n    <LEDGERNAME>' + l.ledger_name + '</LEDGERNAME>\n    <ISDEEMEDPOSITIVE>' + (l.debit ? 'Yes' : 'No') + '</ISDEEMEDPOSITIVE>\n    <AMOUNT>' + (l.debit ? '-' + l.debit.toFixed(2) : l.credit.toFixed(2)) + '</AMOUNT>\n  </ALLLEDGERENTRIES.LIST>'; }).join('\n') + '\n</VOUCHER>';
      return { unique_key: v.unique_key, alter_id: 5000 + (+v.voucher_id.slice(4) || 0), xml: xml, revisions: 1, note: 'Demo mode: XML reconstructed from the posted voucher.' };
    },
    requestTallySync: function (p, s) {
      init();
      var mode = p.mode || 'INCREMENTAL';
      if (['DATE_RANGE', 'LEDGER', 'VOUCHER'].indexOf(mode) >= 0 && !(p.from_date && p.to_date)) fail('VALIDATION', 'From and to dates are required for this sync mode.');
      var row = { sync_id: nextId('SYN'), company: 'Demo Company', mode: mode, requested_by: s.email, requested_at: nowStr(), from_date: p.from_date || '', to_date: p.to_date || '', status: 'REQUESTED', records_fetched: 0, records_added: 0, records_updated: 0, records_skipped: 0, records_failed: 0 };
      db.syncLog.unshift(row); mut.ops.push(['add', 'TALLY_SYNC_LOG', []]);
      audit(s, 'SYNC', 'TALLY_SYNC_LOG', row.sync_id, null, { requested: mode });
      return { sync_id: row.sync_id, status: 'REQUESTED', message: 'Sync queued. In production the Tally connector picks it up on its next poll (demo mode has no connector).' };
    },
    resolveTallyError: function (p, s) { patch('TALLY_ERRORS', 'error_id', p.error_id, { resolved: true }); audit(s, 'UPDATE', 'TALLY_ERRORS', p.error_id, null, { resolved: true }); return { resolved: true }; },
    getAuditLog: function (p) {
      p = period(p); init();
      var rows = db.audit.filter(function (a) { var d = String(a.timestamp).slice(0, 10); return (!p.from || d >= p.from) && (!p.to || d <= p.to) && (!p.entity || a.entity === p.entity) && (!p.action_type || a.action === p.action_type); }).slice().reverse();
      return paging(rows, p);
    },
    resolveNotification: function (p, s) { add('NOTIFICATIONS', [{ dedupe_key: p.dedupe_key, status: 'RESOLVED', resolved_by: s.email }]); audit(s, 'UPDATE', 'NOTIFICATIONS', p.dedupe_key, null, { status: 'RESOLVED' }); return { resolved: true }; },
    getSettings: function () { var eff = ctx().S; return { settings: Object.keys(Engine.DEFAULT_SETTINGS).map(function (k) { return { key: k, value: eff[k], default: Engine.DEFAULT_SETTINGS[k], overridden: db.settings[k] !== undefined }; }), config: db.config, connectorKeyConfigured: false }; },
    updateSetting: function (p, s) {
      if (!(p.key in Engine.DEFAULT_SETTINGS)) fail('VALIDATION', 'Unknown setting.');
      var old = ctx().S[p.key]; mut.settings[p.key] = p.value; db.settings = mut.settings; touch();
      audit(s, 'CONFIG', 'SETTINGS', p.key, old, p.value); return { key: p.key, value: p.value };
    },
    updateConfig: function (p, s) {
      if (/KEY|SECRET|PASSWORD|TOKEN/i.test(p.key)) fail('VALIDATION', 'Secrets cannot be stored in CONFIG.');
      if (db.config.some(function (c) { return c.config_key === p.key; })) patch('CONFIG', 'config_key', p.key, { config_value: p.value }); else add('CONFIG', [{ config_key: p.key, config_value: p.value, category: p.category || 'APP' }]);
      audit(s, 'CONFIG', 'CONFIG', p.key, null, p.value); return { key: p.key, value: p.value };
    },
    getUsers: function () { init(); return db.users; },
    createUser: function (p, s) {
      if (!p.email || !p.role || !p.full_name) fail('VALIDATION', 'Email, name and role are required.');
      if (!p.password || p.password.length < 10) fail('VALIDATION', 'Password must be at least 10 characters and contain letters and digits.');
      var u = { user_id: nextId('USR'), email: String(p.email).toLowerCase(), full_name: p.full_name, role: p.role, status: 'ACTIVE' };
      add('USERS', [u]); audit(s, 'CREATE', 'USERS', u.user_id, null, { email: u.email, role: u.role }); return u;
    },
    updateUser: function (p, s) { var pt = {}; if (p.role) pt.role = p.role; if (p.status) pt.status = p.status; patch('USERS', 'user_id', p.user_id, pt); audit(s, 'UPDATE', 'USERS', p.user_id, null, pt); return pt; }
  };

  var DemoAdapter = {
    mode: 'demo',
    call: function (action, params, token) {
      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          try {
            var h = H[action];
            if (!h || action.slice(-1) === '_') throw new ApiError('UNKNOWN_ACTION', 'Unknown action "' + action + '".');
            var session = null;
            if (action !== 'login' && action !== 'health') {
              var role = String(token || '').replace('demo-', '');
              if (!ROLE_PERMISSIONS[role]) throw new ApiError('UNAUTHENTICATED', 'Please sign in again.');
              var u = (init(), db.users.filter(function (x) { return x.role === role; })[0]);
              session = { email: u.email, role: role, name: u.full_name };
              if (!can(role, ROUTE_PERMS[action] || 'view.accounts')) throw new ApiError('FORBIDDEN', 'You do not have permission for this action.');
            }
            resolve(JSON.parse(JSON.stringify(h(JSON.parse(JSON.stringify(params || {})), session))));
          } catch (e) {
            if (!(e instanceof ApiError)) { console.error(e); e = new ApiError('INTERNAL', 'Something went wrong: ' + (e.message || e)); }
            reject(e);
          }
        }, 60);
      });
    },
    reset: function () { try { storage('localStorage').removeItem(DEMO_KEY); } catch (e) { /* ignore */ } db = null; ctxCache = null; }
  };

  var adapter = (APP_CONFIG.API_URL && APP_CONFIG.MODE !== 'demo') ? RemoteAdapter : DemoAdapter;
  var session = loadSession();
  var listeners = [];

  return {
    ApiError: ApiError,
    mode: function () { return adapter.mode; },
    session: function () { return session; },
    can: function (perm) { if (!session) return false; var p = session.user.permissions || []; return !perm || p.indexOf('*') >= 0 || p.indexOf(perm) >= 0; },
    onUnauthorized: function (fn) { listeners.push(fn); },
    login: function (params) {
      return adapter.call('login', params).then(function (d) { session = d; saveSession(d); return d; });
    },
    logout: function () {
      var t = session && session.token;
      session = null; saveSession(null);
      if (t) adapter.call('logout', {}, t).catch(function () { /* already expired */ });
    },
    call: function (action, params) {
      return adapter.call(action, params || {}, session && session.token).catch(function (e) {
        if (e.code === 'UNAUTHENTICATED' && action !== 'login') { session = null; saveSession(null); listeners.forEach(function (fn) { fn(e); }); }
        throw e;
      });
    },
    resetDemo: function () { if (DemoAdapter.reset) DemoAdapter.reset(); }
  };
})();
