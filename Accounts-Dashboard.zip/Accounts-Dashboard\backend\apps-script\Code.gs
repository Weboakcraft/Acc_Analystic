/**
 * Accounts Dashboard - Apps Script API entry point.
 *
 * Transport
 *   Apps Script web apps only receive GET and POST. Every request is routed by `action`.
 *   PUT/PATCH/DELETE semantics are expressed through the action name (updateX / deleteX) or
 *   an optional `_method` field, which is recorded in the audit log.
 *
 *   POST body (Content-Type: text/plain, which avoids a CORS pre-flight):
 *     { "action": "getSales", "token": "<session token>", "params": { ... } }
 *   Connector calls use "api_key" instead of "token".
 *   GET ?action=health (public) or ?action=getDashboard&token=...&params={json} for quick reads.
 *
 * Response envelope
 *   { ok: true,  data: {...}, meta: { action, ms, version } }
 *   { ok: false, error: { code, message }, meta: {...} }
 *   Technical details stay in the Apps Script execution log; users see a friendly message.
 */

var APP_VERSION = '1.0.0';

function doGet(e) {
  var p = (e && e.parameter) || {};
  var params = {};
  if (p.params) { try { params = JSON.parse(p.params); } catch (err) { params = {}; } }
  Object.keys(p).forEach(function (k) { if (['action', 'token', 'params', 'api_key'].indexOf(k) < 0) params[k] = p[k]; });
  return handle_({ action: p.action || 'health', token: p.token, api_key: p.api_key, params: params, _method: 'GET' });
}

function doPost(e) {
  var body = {};
  try {
    body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (err) {
    return json_({ ok: false, error: { code: 'BAD_REQUEST', message: 'Request body must be valid JSON.' } });
  }
  return handle_(body);
}

function handle_(req) {
  var started = Date.now();
  var action = String(req.action || '');
  var meta = { action: action, version: APP_VERSION };
  try {
    var route = Object.prototype.hasOwnProperty.call(getRoutes_(), action) ? getRoutes_()[action] : null;
    if (!route) throw new AppError('UNKNOWN_ACTION', 'Unknown action "' + action + '".');
    var session = Auth.authorize(req, route);        // throws on failure
    var params = Validate.params(req.params || {});   // shape + size checks
    var data;
    if (route.write) {
      data = Db.withLock(function () { return route.fn(params, session); });
    } else if (route.cache && session) {
      data = ApiCache.getOrCompute(action, params, route.cache, function () { return route.fn(params, session); });
    } else {
      data = route.fn(params, session);
    }
    meta.ms = Date.now() - started;
    return json_({ ok: true, data: data, meta: meta });
  } catch (err) {
    meta.ms = Date.now() - started;
    return json_({ ok: false, error: Errors.toClient(err, action), meta: meta });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Adds the admin menu to the spreadsheet. */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Accounts Dashboard')
    .addItem('Initialize / repair database', 'initializeDatabase')
    .addItem('Set a user password', 'setPasswordFromMenu')
    .addItem('Generate connector API key', 'setConnectorApiKey')
    .addItem('Rebuild report snapshots', 'rebuildReportSnapshots')
    .addItem('Run alert scan now', 'runAlertScan')
    .addSeparator()
    .addItem('Install scheduled automations', 'installTriggers')
    .addItem('Remove sample rows', 'purgeSampleData')
    .addToUi();
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------
function AppError(code, message, status) {
  this.name = 'AppError';
  this.code = code;
  this.message = message;
  this.status = status || 400;
}
AppError.prototype = Object.create(Error.prototype);

var Errors = {
  FRIENDLY: {
    UNAUTHENTICATED: 'Please sign in again.',
    FORBIDDEN: 'You do not have permission for this action.',
    TALLY_UNAVAILABLE: 'Tally connection unavailable.',
    SYNC_FAILED: 'Unable to synchronize vouchers.',
    DUPLICATE_VOUCHER: 'Duplicate voucher detected.',
    INVALID_INVOICE: 'Invalid invoice data.',
    SHEETS_ERROR: 'Google Sheets API error. Please retry in a minute.',
    LOCK_TIMEOUT: 'The system is busy saving another entry. Please retry.',
    INTERNAL: 'Something went wrong. The error has been logged.'
  },
  toClient: function (err, action) {
    if (err instanceof AppError) {
      return { code: err.code, message: err.message || Errors.FRIENDLY[err.code] || Errors.FRIENDLY.INTERNAL, details: err.details };
    }
    var msg = String(err && err.message || err);
    console.error('[' + action + '] ' + msg + '\n' + (err && err.stack || ''));
    if (/Service Spreadsheets|Exceeded maximum|timed out|Service invoked too many times/i.test(msg)) {
      return { code: 'SHEETS_ERROR', message: Errors.FRIENDLY.SHEETS_ERROR };
    }
    return { code: 'INTERNAL', message: Errors.FRIENDLY.INTERNAL };
  }
};

// ---------------------------------------------------------------------------
// Input validation
// ---------------------------------------------------------------------------
var Validate = {
  MAX_STRING: 20000,
  params: function (p) {
    if (typeof p !== 'object' || Array.isArray(p)) throw new AppError('BAD_REQUEST', 'params must be an object.');
    return p;
  },
  required: function (obj, fields) {
    var missing = fields.filter(function (f) { return obj[f] === undefined || obj[f] === null || String(obj[f]).trim() === ''; });
    if (missing.length) throw new AppError('VALIDATION', 'Missing required field(s): ' + missing.join(', ') + '.');
  },
  date: function (v, field) {
    var d = Engine.util.D(v);
    if (!d) throw new AppError('VALIDATION', (field || 'Date') + ' is invalid.');
    return d;
  },
  amount: function (v, field, allowZero) {
    var n = Number(v);
    if (!isFinite(n) || n < 0 || (!allowZero && n === 0)) throw new AppError('VALIDATION', (field || 'Amount') + ' must be a positive number.');
    return Math.round(n * 100) / 100;
  },
  text: function (v, max) {
    var s = v === null || v === undefined ? '' : String(v).trim();
    if (s.length > (max || 500)) throw new AppError('VALIDATION', 'Text is too long (max ' + (max || 500) + ' characters).');
    return s;
  },
  oneOf: function (v, list, field) {
    if (list.indexOf(v) < 0) throw new AppError('VALIDATION', (field || 'Value') + ' must be one of: ' + list.join(', ') + '.');
    return v;
  },
  gstin: function (v) {
    var s = String(v || '').trim().toUpperCase();
    if (s && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(s)) throw new AppError('VALIDATION', 'GSTIN format is invalid.');
    return s;
  },
  email: function (v) {
    var s = String(v || '').trim().toLowerCase();
    if (s && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) throw new AppError('VALIDATION', 'Email address is invalid.');
    return s;
  },
  mobile: function (v) {
    var s = String(v || '').replace(/[\s-]/g, '');
    if (s && !/^(\+91)?[6-9][0-9]{9}$/.test(s)) throw new AppError('VALIDATION', 'Mobile number must be a valid 10-digit Indian number.');
    return s;
  }
};

// ---------------------------------------------------------------------------
// Response cache (keyed by data version so any write invalidates everything)
// ---------------------------------------------------------------------------
var ApiCache = {
  getOrCompute: function (action, params, ttl, fn) {
    var cache = CacheService.getScriptCache();
    var key = 'api:' + Db.dataVersion() + ':' + action + ':' + Utilities.base64EncodeWebSafe(
      Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, JSON.stringify(params)));
    var hit = cache.get(key);
    if (hit) return JSON.parse(hit);
    var data = fn();
    var s = JSON.stringify(data);
    if (s.length < 95000) { try { cache.put(key, s, ttl); } catch (e) { /* value too large - skip */ } }
    return data;
  }
};
