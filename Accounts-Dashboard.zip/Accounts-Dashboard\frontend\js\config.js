/**
 * Frontend configuration - the ONLY file to edit when deploying.
 * API_URL: the Apps Script web-app URL (Deploy > Manage deployments > Web app URL, ending in /exec).
 * Leave API_URL empty to run the built-in demo (no backend needed).
 * Never put API keys, Tally credentials or passwords here - this file is public on GitHub Pages.
 */
window.APP_CONFIG = {
  API_URL: '',
  MODE: 'auto',              // 'auto' (remote if API_URL is set) | 'demo'
  APP_NAME: 'Accounts Dashboard',
  COMPANY_NAME: 'Demo Company',
  TIMEOUT_SECONDS: 60
};
