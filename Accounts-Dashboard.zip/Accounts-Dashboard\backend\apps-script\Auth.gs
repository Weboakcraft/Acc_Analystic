/**
 * Authentication & role-based authorization.
 *
 * - Users sign in with email + password (USERS sheet, salted + iterated SHA-256).
 * - A session token is kept in the script cache for 6 hours (Apps Script cache maximum).
 * - The on-premise Tally connector authenticates with CONNECTOR_API_KEY held in Script Properties.
 * - Secrets never live in the spreadsheet or the frontend.
 */

var ROLE_PERMISSIONS = {
  ADMIN: ['*'],
  ACCOUNTANT: ['view.dashboard', 'view.accounts', 'view.reports', 'view.tally', 'view.lookup',
    'write.transactions', 'write.masters', 'write.offline_sales', 'submit.expenses', 'run.sync', 'reconcile.bank'],
  FINANCE_MANAGER: ['view.dashboard', 'view.accounts', 'view.reports', 'view.tally', 'view.audit', 'view.lookup',
    'approve.expenses', 'submit.expenses', 'run.sync', 'reconcile.bank', 'resolve.alerts'],
  MANAGEMENT: ['view.dashboard', 'view.accounts', 'view.reports', 'view.lookup'],
  DATA_ENTRY: ['view.lookup', 'write.offline_sales', 'write.transactions', 'submit.expenses'],
  AUDITOR: ['view.dashboard', 'view.accounts', 'view.reports', 'view.tally', 'view.audit', 'view.lookup']
};

var SESSION_TTL_SECONDS = 6 * 60 * 60;
var MAX_FAILED_LOGINS = 5;
var HASH_ITERATIONS = 1000;

var Auth = {
  permissionsFor: function (role) {
    return ROLE_PERMISSIONS[role] || [];
  },

  can: function (session, perm) {
    if (!perm) return true;
    var perms = Auth.permissionsFor(session.role);
    if (perms.indexOf('*') >= 0) return true;
    return String(perm).split('|').some(function (p) { return perms.indexOf(p) >= 0; }); // 'a|b' = either
  },

  /** Returns the session for this request or throws. Route shape: { perm, public, connector }. */
  authorize: function (req, route) {
    if (route.public) return null;
    if (route.connector) {
      var expected = PropertiesService.getScriptProperties().getProperty('CONNECTOR_API_KEY');
      if (!expected) throw new AppError('CONFIG', 'Connector API key is not configured. Run setConnectorApiKey() in the Apps Script editor.');
      if (!req.api_key || !Auth.safeEquals_(String(req.api_key), expected)) throw new AppError('UNAUTHENTICATED', 'Invalid connector API key.', 401);
      return { email: 'tally-connector', role: 'CONNECTOR', name: 'Tally Connector' };
    }
    var token = String(req.token || '');
    if (!token) throw new AppError('UNAUTHENTICATED', Errors.FRIENDLY.UNAUTHENTICATED, 401);
    var raw = CacheService.getScriptCache().get('sess:' + token);
    if (!raw) throw new AppError('UNAUTHENTICATED', 'Your session has expired. Please sign in again.', 401);
    var session = JSON.parse(raw);
    session.token = token;
    if (route.perm && !Auth.can(session, route.perm)) throw new AppError('FORBIDDEN', Errors.FRIENDLY.FORBIDDEN, 403);
    return session;
  },

  login: function (p) {
    Validate.required(p, ['email', 'password']);
    var email = Validate.email(p.email);
    var users = Db.read('USERS');
    var user = users.filter(function (u) { return String(u.email).toLowerCase() === email; })[0];
    var generic = new AppError('UNAUTHENTICATED', 'Email or password is incorrect.', 401);
    if (!user) { Audit.log({ action: 'LOGIN_FAILED', entity: 'USERS', record_id: email, user: email }); throw generic; }
    if (user.status === 'LOCKED') throw new AppError('LOCKED', 'This account is locked after repeated failed sign-ins. Ask an administrator to unlock it.', 403);
    if (user.status !== 'ACTIVE') throw new AppError('INACTIVE', 'This account is not active. Ask an administrator to set a password.', 403);
    var ok = user.password_hash && Auth.safeEquals_(Auth.hash_(String(p.password), String(user.password_salt)), String(user.password_hash));
    if (!ok) {
      var fails = (Number(user.failed_attempts) || 0) + 1;
      Db.update('USERS', 'user_id', user.user_id, { failed_attempts: fails, status: fails >= MAX_FAILED_LOGINS ? 'LOCKED' : user.status });
      Audit.log({ action: 'LOGIN_FAILED', entity: 'USERS', record_id: user.user_id, user: email });
      throw generic;
    }
    Db.update('USERS', 'user_id', user.user_id, { failed_attempts: 0, last_login: new Date() });
    var token = Utilities.getUuid() + Utilities.getUuid().replace(/-/g, '');
    var session = { email: email, role: user.role, name: user.full_name, user_id: user.user_id, issued: Date.now() };
    CacheService.getScriptCache().put('sess:' + token, JSON.stringify(session), SESSION_TTL_SECONDS);
    Audit.log({ action: 'LOGIN', entity: 'USERS', record_id: user.user_id, user: email, role: user.role });
    return { token: token, user: Auth.publicUser_(session), expiresIn: SESSION_TTL_SECONDS };
  },

  logout: function (p, session) {
    CacheService.getScriptCache().remove('sess:' + session.token);
    return { loggedOut: true };
  },

  me: function (p, session) {
    return Auth.publicUser_(session);
  },

  publicUser_: function (s) {
    return { email: s.email, name: s.name, role: s.role, permissions: Auth.permissionsFor(s.role) };
  },

  newSalt_: function () {
    return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, Utilities.getUuid() + Date.now()));
  },

  hash_: function (password, salt) {
    var h = salt + '|' + password;
    for (var i = 0; i < HASH_ITERATIONS; i++) {
      h = Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h + '|' + salt, Utilities.Charset.UTF_8));
    }
    return h;
  },

  safeEquals_: function (a, b) {
    if (a.length !== b.length) return false;
    var r = 0;
    for (var i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return r === 0;
  },

  validatePassword_: function (pwd) {
    if (!pwd || pwd.length < 10 || !/[A-Za-z]/.test(pwd) || !/[0-9]/.test(pwd)) {
      throw new AppError('VALIDATION', 'Password must be at least 10 characters and contain letters and digits.');
    }
  },

  // ---- Admin user management (API) ----
  createUser: function (p, session) {
    Validate.required(p, ['email', 'full_name', 'role', 'password']);
    var email = Validate.email(p.email);
    Validate.oneOf(p.role, Object.keys(ROLE_PERMISSIONS), 'Role');
    Auth.validatePassword_(String(p.password));
    if (Db.read('USERS').some(function (u) { return String(u.email).toLowerCase() === email; })) throw new AppError('DUPLICATE', 'A user with this email already exists.');
    var salt = Auth.newSalt_();
    var row = Db.insert('USERS', [{
      email: email, full_name: Validate.text(p.full_name, 100), role: p.role,
      password_hash: Auth.hash_(String(p.password), salt), password_salt: salt,
      status: 'ACTIVE', failed_attempts: 0, created_by: session.email
    }], session)[0];
    Audit.log({ action: 'CREATE', entity: 'USERS', record_id: row.user_id, new_value: { email: email, role: p.role } }, session);
    return { user_id: row.user_id, email: email, role: p.role };
  },

  updateUser: function (p, session) {
    Validate.required(p, ['user_id']);
    var patch = {};
    if (p.role) patch.role = Validate.oneOf(p.role, Object.keys(ROLE_PERMISSIONS), 'Role');
    if (p.status) patch.status = Validate.oneOf(p.status, ['ACTIVE', 'INACTIVE', 'LOCKED'], 'Status');
    if (p.status === 'ACTIVE') patch.failed_attempts = 0;
    if (p.password) {
      Auth.validatePassword_(String(p.password));
      patch.password_salt = Auth.newSalt_();
      patch.password_hash = Auth.hash_(String(p.password), patch.password_salt);
    }
    var res = Db.update('USERS', 'user_id', p.user_id, patch);
    var safeOld = { role: res.old.role, status: res.old.status }, safeNew = { role: res.row.role, status: res.row.status, password_changed: !!p.password };
    Audit.log({ action: 'UPDATE', entity: 'USERS', record_id: p.user_id, old_value: safeOld, new_value: safeNew }, session);
    return { user_id: p.user_id, role: res.row.role, status: res.row.status };
  },

  listUsers: function () {
    return Db.read('USERS').map(function (u) {
      return { user_id: u.user_id, email: u.email, full_name: u.full_name, role: u.role, status: u.status, last_login: u.last_login };
    });
  }
};

// ---------------------------------------------------------------------------
// Editor-only helpers (run from the Apps Script editor; never exposed via the API)
// ---------------------------------------------------------------------------

/** Set/replace a user's password. Edit the two values, run once, then clear them. */
function setUserPassword(email, password) {
  email = email || 'admin@company.example';
  if (!password) throw new Error('Call setUserPassword("user@company.com", "a strong password") from a scratch function; do not save the password in code.');
  Auth.validatePassword_(password);
  var user = Db.read('USERS').filter(function (u) { return String(u.email).toLowerCase() === email.toLowerCase(); })[0];
  if (!user) throw new Error('No user with email ' + email + ' in USERS.');
  var salt = Auth.newSalt_();
  Db.update('USERS', 'user_id', user.user_id, { password_salt: salt, password_hash: Auth.hash_(password, salt), status: 'ACTIVE', failed_attempts: 0 });
  Audit.log({ action: 'CONFIG', entity: 'USERS', record_id: user.user_id, new_value: { password_set: true }, user: 'editor' });
  Logger.log('Password set for ' + email);
}

/** Generates a new connector API key, stores it in Script Properties and logs it ONCE. */
function setConnectorApiKey() {
  var key = Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, Utilities.getUuid() + Utilities.getUuid() + Date.now())).replace(/=+$/, '');
  PropertiesService.getScriptProperties().setProperty('CONNECTOR_API_KEY', key);
  Audit.log({ action: 'CONFIG', entity: 'SCRIPT_PROPERTIES', record_id: 'CONNECTOR_API_KEY', new_value: { rotated: true }, user: 'editor' });
  var msg = 'New connector API key (set it as the ACCOUNTS_CONNECTOR_API_KEY environment variable on the Tally PC; it is not shown again):\n\n' + key;
  Logger.log(msg);
  try { SpreadsheetApp.getUi().alert(msg); } catch (e) { /* run from the editor: see the execution log */ }
}
