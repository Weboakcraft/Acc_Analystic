/**
 * API route table. One line per endpoint:
 *   perm      permission required (see ROLE_PERMISSIONS in Auth.gs)
 *   write     wrap in the script lock (all mutations)
 *   cache     seconds to cache the response (invalidated by any write)
 *   public    no authentication
 *   connector authenticated with the connector API key
 * documentation/API.md is the human-readable version of this table.
 *
 * Built lazily: Apps Script evaluates .gs files in project order, so the service objects may not
 * exist yet when this file is loaded.
 */
var ROUTES_ = null;
function getRoutes_() { return ROUTES_ || (ROUTES_ = buildRoutes_()); }

function buildRoutes_() { return {
  // System & auth
  health:                  { public: true, fn: Svc.health },
  login:                   { public: true, write: true, fn: Auth.login },
  logout:                  { fn: Auth.logout },
  me:                      { fn: Auth.me },

  // Dashboards & analytics
  getDashboard:            { perm: 'view.dashboard', cache: 120, fn: Svc.getDashboard },
  getManagementDashboard:  { perm: 'view.reports', cache: 300, fn: Svc.getManagementDashboard },
  getFinancialHealth:      { perm: 'view.reports', cache: 300, fn: Svc.getFinancialHealth },
  getAnalytics:            { perm: 'view.reports', cache: 300, fn: Svc.getAnalytics },
  getAlerts:               { perm: 'view.dashboard', cache: 120, fn: Svc.getAlerts },
  searchTransactions:      { perm: 'view.accounts', cache: 60, fn: Svc.searchTransactions },
  getLookups:              { perm: 'view.lookup', cache: 300, fn: Svc.getLookups },

  // Sales / purchases / parties
  getSales:                { perm: 'view.accounts', cache: 120, fn: Svc.getSales },
  getSalesReport:          { perm: 'view.accounts', cache: 300, fn: Svc.getSalesReport },
  getPurchases:            { perm: 'view.accounts', cache: 120, fn: Svc.getPurchases },
  getPurchaseReport:       { perm: 'view.accounts', cache: 300, fn: Svc.getPurchaseReport },
  getCustomers:            { perm: 'view.accounts', cache: 120, fn: Svc.getCustomers },
  getVendors:              { perm: 'view.accounts', cache: 120, fn: Svc.getVendors },
  getReceivables:          { perm: 'view.accounts', cache: 120, fn: Svc.getReceivables },
  getPayables:             { perm: 'view.accounts', cache: 120, fn: Svc.getPayables },
  getAgeing:               { perm: 'view.accounts', cache: 120, fn: Svc.getAgeing },
  getPartyAccounts:        { perm: 'view.accounts', cache: 120, fn: Svc.getPartyAccounts },
  getReceipts:             { perm: 'view.accounts', cache: 120, fn: Svc.getReceipts },
  getPayments:             { perm: 'view.accounts', cache: 120, fn: Svc.getPayments },
  getExpenses:             { perm: 'submit.expenses|view.accounts', fn: Svc.getExpenses },
  getVoucher:              { perm: 'view.accounts', fn: Svc.getVoucher },
  getInventory:            { perm: 'view.accounts', cache: 300, fn: Svc.getInventory },

  // Ledgers, cash & bank
  getLedgers:              { perm: 'view.accounts', cache: 120, fn: Svc.getLedgers },
  getLedgerStatement:      { perm: 'view.accounts', cache: 120, fn: Svc.getLedgerStatement },
  getCashBook:             { perm: 'view.accounts', cache: 120, fn: Svc.getCashBook },
  getBankTransactions:     { perm: 'view.accounts', fn: Svc.getBankTransactions },

  // Statements & tax
  getTrialBalance:         { perm: 'view.reports', cache: 300, fn: Svc.getTrialBalance },
  getProfitLoss:           { perm: 'view.reports', cache: 300, fn: Svc.getProfitLoss },
  getBalanceSheet:         { perm: 'view.reports', cache: 300, fn: Svc.getBalanceSheet },
  getCashFlow:             { perm: 'view.reports', cache: 300, fn: Svc.getCashFlow },
  getGSTSummary:           { perm: 'view.reports', cache: 300, fn: Svc.getGSTSummary },

  // Transactions (write)
  saveOfflineSale:         { perm: 'write.offline_sales', write: true, fn: Svc.saveOfflineSale },
  saveReceipt:             { perm: 'write.transactions', write: true, fn: Svc.saveReceipt },
  savePayment:             { perm: 'write.transactions', write: true, fn: Svc.savePayment },
  saveJournal:             { perm: 'write.transactions', write: true, fn: Svc.saveJournal },
  cancelVoucher:           { perm: 'write.transactions', write: true, fn: Svc.cancelVoucher },
  saveExpense:             { perm: 'submit.expenses', write: true, fn: Svc.saveExpense },
  approveExpense:          { perm: 'approve.expenses', write: true, fn: Svc.approveExpense },
  rejectExpense:           { perm: 'approve.expenses', write: true, fn: Svc.rejectExpense },

  // Masters (write)
  createLedger:            { perm: 'write.masters', write: true, fn: Svc.createLedger },
  createCustomer:          { perm: 'write.masters', write: true, fn: Svc.createCustomer },
  createVendor:            { perm: 'write.masters', write: true, fn: Svc.createVendor },

  // Bank reconciliation
  importBankStatement:     { perm: 'reconcile.bank', write: true, fn: Bank.importStatement },
  autoReconcile:           { perm: 'reconcile.bank', write: true, fn: Bank.autoReconcile },
  setBankMatch:            { perm: 'reconcile.bank', write: true, fn: Bank.setMatch },

  // Tally (web UI)
  getTallyStatus:          { perm: 'view.tally', fn: Tally.status },
  getSyncLog:              { perm: 'view.tally', fn: Tally.syncLog },
  getTallyErrors:          { perm: 'view.tally', fn: Tally.errors },
  getTallyData:            { perm: 'view.tally', fn: Tally.rawData },
  requestTallySync:        { perm: 'run.sync', write: true, fn: Tally.requestSync },
  resolveTallyError:       { perm: 'run.sync', write: true, fn: Tally.resolveError },

  // Tally connector (API key)
  tallyConfig:             { connector: true, fn: Tally.config },
  tallySyncStart:          { connector: true, write: true, fn: Tally.syncStart },
  tallyIngestMasters:      { connector: true, write: true, fn: Tally.ingestMasters },
  syncTallyData:           { connector: true, write: true, fn: Tally.ingestVouchers },
  tallySyncFinish:         { connector: true, write: true, fn: Tally.syncFinish },

  // Audit, alerts, admin
  getAuditLog:             { perm: 'view.audit', fn: Svc.getAuditLog },
  resolveNotification:     { perm: 'resolve.alerts', write: true, fn: Svc.resolveNotification },
  getSettings:             { perm: 'admin.settings', fn: Svc.getSettings },
  updateSetting:           { perm: 'admin.settings', write: true, fn: Svc.updateSetting },
  updateConfig:            { perm: 'admin.settings', write: true, fn: Svc.updateConfig },
  getUsers:                { perm: 'admin.users', fn: Auth.listUsers },
  createUser:              { perm: 'admin.users', write: true, fn: Auth.createUser },
  updateUser:              { perm: 'admin.users', write: true, fn: Auth.updateUser },
  rebuildReportSnapshots:  { perm: 'admin.settings', fn: function () { return { status: rebuildReportSnapshots() }; } },
  runAlertScan:            { perm: 'admin.settings', fn: function () { return { status: runAlertScan() }; } }
}; }
