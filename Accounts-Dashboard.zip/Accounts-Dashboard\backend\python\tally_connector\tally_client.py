"""HTTP client and request builders for the Tally XML server.

Tally Prime / ERP 9 listens on ``http://<host>:9000`` and accepts XML
"envelopes". Vouchers and masters are exported with inline TDL collections;
the classic Day Book report is supported as a fallback (``export_mode =
daybook``) for Tally builds where collection exports return incomplete
vouchers.
"""

from __future__ import annotations

import http.client
import logging
import time
import urllib.error
import urllib.request
from datetime import date, timedelta
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple
from xml.sax.saxutils import escape as _xml_escape
import xml.etree.ElementTree as ET

from .xml_parser import (
    TallyParseError,
    extract_masters,
    extract_tally_errors,
    extract_vouchers,
    format_tally_date,
    master_name,
    parse_int,
    parse_tally_date,
    parse_xml,
    text_of,
    to_date,
)

log = logging.getLogger("tally_connector.tally")


class TallyError(Exception):
    """Tally is unreachable, the company is not open, or Tally reported an error."""


# ---------------------------------------------------------------------------
# Request builders
# ---------------------------------------------------------------------------

VOUCHER_FETCH: Tuple[str, ...] = (
    "GUID", "MasterID", "AlterID", "Date", "VoucherTypeName", "VoucherNumber",
    "Reference", "ReferenceDate", "PartyLedgerName", "PartyGSTIN", "PlaceOfSupply",
    "StateName", "Narration", "IsCancelled", "IsOptional", "IsInvoice", "PersistedView",
    "AllLedgerEntries.*", "LedgerEntries.*", "AllInventoryEntries.*", "InventoryEntries.*",
)

MASTER_COLLECTIONS: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    # key: (TDL object type, extra FETCH list; NATIVEMETHOD * is always added)
    "groups": ("Group", ("Name", "Parent", "IsRevenue", "AffectsGrossProfit", "IsDeemedPositive",
                         "GUID", "AlterID", "MasterID")),
    "ledgers": ("Ledger", ("Name", "Parent", "OpeningBalance", "PartyGSTIN", "LedStateName",
                           "BillCreditPeriod", "Email", "LedgerMobile", "LedgerPhone", "Address",
                           "TaxType", "GSTDutyHead", "RateOfTaxCalculation", "GUID", "AlterID")),
    "voucher_types": ("VoucherType", ("Name", "Parent", "GUID", "AlterID")),
    "stock_items": ("StockItem", ("Name", "Parent", "BaseUnits", "OpeningBalance", "OpeningValue",
                                  "GUID", "AlterID")),
    "cost_centres": ("CostCentre", ("Name", "Category", "Parent", "GUID", "AlterID")),
}


def xml_text(value: str) -> str:
    """Escape a value for use as XML element text."""
    return _xml_escape(str(value))


def xml_attr(value: str) -> str:
    """Escape a value for use inside a double-quoted XML attribute."""
    return _xml_escape(str(value), {'"': "&quot;"})


def tdl_string(value: str) -> str:
    """Quote a value as a TDL string literal (TDL has no escape for '"')."""
    return '"' + str(value).replace('"', "") + '"'


def _static_variables(company: Optional[str], from_date=None, to_date_=None,
                      extra: Optional[Dict[str, str]] = None) -> str:
    parts = ["<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>"]
    if company:
        parts.append("<SVCURRENTCOMPANY>%s</SVCURRENTCOMPANY>" % xml_text(company))
    if from_date:
        parts.append("<SVFROMDATE>%s</SVFROMDATE>" % format_tally_date(from_date))
    if to_date_:
        parts.append("<SVTODATE>%s</SVTODATE>" % format_tally_date(to_date_))
    for key, value in (extra or {}).items():
        parts.append("<%s>%s</%s>" % (key, xml_text(value), key))
    return "<STATICVARIABLES>%s</STATICVARIABLES>" % "".join(parts)


def build_collection_request(
    collection: str,
    obj_type: str,
    company: Optional[str] = None,
    fetch: Sequence[str] = (),
    filters: Sequence[Tuple[str, str]] = (),
    from_date=None,
    to_date_=None,
    native_all: bool = True,
) -> str:
    """Build an Export/Collection envelope with an inline TDL collection.

    ``filters`` is a list of ``(formula_name, tdl_formula)`` pairs; each
    becomes a ``<SYSTEM TYPE="Formulae">`` definition referenced from the
    collection's ``<FILTER>``.
    """
    coll = ['<COLLECTION NAME="%s" ISMODIFY="No">' % xml_attr(collection),
            "<TYPE>%s</TYPE>" % xml_text(obj_type)]
    if native_all:
        coll.append("<NATIVEMETHOD>*</NATIVEMETHOD>")
    if fetch:
        coll.append("<FETCH>%s</FETCH>" % xml_text(", ".join(fetch)))
    if filters:
        coll.append("<FILTER>%s</FILTER>" % xml_text(", ".join(name for name, _ in filters)))
    coll.append("</COLLECTION>")
    systems = "".join(
        '<SYSTEM TYPE="Formulae" NAME="%s">%s</SYSTEM>' % (xml_attr(name), xml_text(formula))
        for name, formula in filters
    )
    return (
        "<ENVELOPE>"
        "<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST>"
        "<TYPE>Collection</TYPE><ID>%s</ID></HEADER>"
        "<BODY><DESC>%s<TDL><TDLMESSAGE>%s%s</TDLMESSAGE></TDL></DESC></BODY>"
        "</ENVELOPE>"
    ) % (xml_text(collection), _static_variables(company, from_date, to_date_), "".join(coll), systems)


def build_voucher_collection_request(
    company: str,
    from_date,
    to_date_,
    min_alter_id: Optional[int] = None,
    voucher_type: Optional[str] = None,
    voucher_number: Optional[str] = None,
) -> str:
    """Inline-TDL voucher collection for a date range with optional filters."""
    filters: List[Tuple[str, str]] = [
        ("Accounts DashboardDateFilter", "$Date >= ##SVFromDate AND $Date <= ##SVToDate"),
    ]
    if min_alter_id is not None:
        filters.append(("Accounts DashboardAlterFilter", "$AlterID > %d" % int(min_alter_id)))
    if voucher_type:
        filters.append(("Accounts DashboardVchTypeFilter", "$VoucherTypeName = %s" % tdl_string(voucher_type)))
    if voucher_number:
        filters.append(("Accounts DashboardVchNoFilter", "$VoucherNumber = %s" % tdl_string(voucher_number)))
    return build_collection_request(
        "Accounts DashboardVouchers", "Voucher", company=company, fetch=VOUCHER_FETCH,
        filters=filters, from_date=from_date, to_date_=to_date_,
    )


def build_daybook_request(company: str, from_date, to_date_) -> str:
    """Classic Day Book data export (full voucher detail with EXPLODEFLAG)."""
    return (
        "<ENVELOPE>"
        "<HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST>"
        "<TYPE>Data</TYPE><ID>Day Book</ID></HEADER>"
        "<BODY><DESC>%s</DESC></BODY>"
        "</ENVELOPE>"
    ) % _static_variables(company, from_date, to_date_, {"EXPLODEFLAG": "Yes"})


def build_master_request(company: str, key: str) -> str:
    obj_type, fetch = MASTER_COLLECTIONS[key]
    return build_collection_request("Accounts Dashboard%ss" % obj_type, obj_type, company=company, fetch=fetch)


def build_company_list_request() -> str:
    return build_collection_request("Accounts DashboardCompanies", "Company", company=None,
                                    fetch=("Name", "GUID", "StartingFrom", "BooksFrom"))


# ---------------------------------------------------------------------------
# Client-side filtering (defence in depth: TDL filters differ across builds)
# ---------------------------------------------------------------------------

def _norm(value: str) -> str:
    return " ".join((value or "").split()).lower()


def filter_voucher_elements(
    vouchers: Iterable[ET.Element],
    from_date: Optional[date] = None,
    to_date_: Optional[date] = None,
    min_alter_id: Optional[int] = None,
    voucher_type: Optional[str] = None,
    voucher_number: Optional[str] = None,
) -> List[ET.Element]:
    out = []
    for v in vouchers:
        vdate = to_date(text_of(v, "DATE"))
        # Vouchers with an unreadable date are kept so validation reports them.
        if vdate is not None:
            if from_date and vdate < from_date:
                continue
            if to_date_ and vdate > to_date_:
                continue
        if min_alter_id is not None and parse_int(text_of(v, "ALTERID"), 0) <= int(min_alter_id):
            continue
        if voucher_type:
            vtype = text_of(v, "VOUCHERTYPENAME") or (v.get("VCHTYPE") or "")
            if _norm(vtype) != _norm(voucher_type):
                continue
        if voucher_number and _norm(text_of(v, "VOUCHERNUMBER")) != _norm(voucher_number):
            continue
        out.append(v)
    return out


def split_date_range(start: date, end: date, chunk_days: int) -> List[Tuple[date, date]]:
    """Split [start, end] into consecutive chunks of at most ``chunk_days`` days."""
    chunk_days = max(1, int(chunk_days))
    chunks = []
    cur = start
    while cur <= end:
        stop = min(end, cur + timedelta(days=chunk_days - 1))
        chunks.append((cur, stop))
        cur = stop + timedelta(days=1)
    return chunks


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class TallyClient:
    """Talks to one Tally company over the XML HTTP server."""

    def __init__(
        self,
        url: str,
        company: str,
        timeout: float = 120.0,
        retries: int = 2,
        retry_backoff: float = 2.0,
        export_mode: str = "collection",
        request_encoding: str = "utf-8",
        chunk_days: int = 31,
        opener=None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.url = url.strip()
        self.company = company
        self.timeout = float(timeout)
        self.retries = max(0, int(retries))
        self.retry_backoff = float(retry_backoff)
        self.export_mode = (export_mode or "collection").lower()
        self.request_encoding = (request_encoding or "utf-8").lower()
        self.chunk_days = int(chunk_days)
        # Tally is on the LAN: never route it through a system/corporate proxy.
        self._opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self._sleep = sleep

    # -- transport ----------------------------------------------------------
    def _post(self, body: str) -> bytes:
        data = body.encode(self.request_encoding)
        headers = {"Content-Type": "text/xml;charset=%s" % self.request_encoding}
        last_error: Optional[BaseException] = None
        for attempt in range(self.retries + 1):
            request = urllib.request.Request(self.url, data=data, headers=headers, method="POST")
            try:
                with self._opener.open(request, timeout=self.timeout) as response:
                    return response.read()
            except urllib.error.HTTPError as exc:
                raise TallyError("Tally returned HTTP %s from %s." % (exc.code, self.url)) from exc
            except (OSError, http.client.HTTPException) as exc:
                last_error = exc
                if attempt < self.retries:
                    delay = self.retry_backoff * (2 ** attempt)
                    log.warning("Tally request failed (%s); retrying in %.0fs", exc, delay)
                    self._sleep(delay)
        reason = getattr(last_error, "reason", None) or last_error
        raise TallyError(
            "Tally connection unavailable at %s (%s). Check that Tally is running, the company "
            "is open and the XML server is enabled (F1 > Settings > Connectivity > "
            "'TallyPrime acts as' Server/Both, port 9000)." % (self.url, reason)
        ) from last_error

    def _explain(self, messages: List[str]) -> str:
        joined = "; ".join(messages)
        low = joined.lower()
        if "svcurrentcompany" in low or "company" in low:
            return "Company '%s' is not open in Tally (%s). Open/select the company in Tally and retry." % (
                self.company, joined)
        return "Tally reported an error: %s" % joined

    def export(self, envelope: str) -> ET.Element:
        """POST an export envelope and return the parsed response root."""
        raw = self._post(envelope)
        try:
            root = parse_xml(raw)
        except TallyParseError as exc:
            raise TallyError(str(exc)) from exc
        errors = extract_tally_errors(root)
        if errors:
            raise TallyError(self._explain(errors))
        return root

    # -- high level ---------------------------------------------------------
    def list_companies(self) -> List[str]:
        """Names of companies currently open (loaded) in Tally."""
        root = self.export(build_company_list_request())
        names = []
        for el in root.iter("COMPANY"):
            name = master_name(el)
            if name and name not in names:
                names.append(name)
        return names

    def ping(self) -> Dict[str, object]:
        """Check the XML server and whether the configured company is open."""
        companies = self.list_companies()
        is_open = any(_norm(c) == _norm(self.company) for c in companies)
        return {"ok": True, "url": self.url, "company": self.company,
                "companies": companies, "company_open": is_open}

    def fetch_masters(self) -> Dict[str, List[ET.Element]]:
        """Groups, ledgers, voucher types, stock items and cost centres."""
        out: Dict[str, List[ET.Element]] = {}
        for key in MASTER_COLLECTIONS:
            root = self.export(build_master_request(self.company, key))
            out[key] = extract_masters(root)[key]
            log.debug("Fetched %d %s", len(out[key]), key)
        return out

    def fetch_vouchers(
        self,
        from_date,
        to_date_,
        min_alter_id: Optional[int] = None,
        voucher_type: Optional[str] = None,
        voucher_number: Optional[str] = None,
    ) -> List[ET.Element]:
        """Vouchers dated within [from_date, to_date_] (inclusive).

        ``min_alter_id`` restricts to vouchers altered after that AlterID
        (incremental sync). Long ranges are fetched in ``chunk_days`` slices so
        Tally is never asked for a multi-year export in one request.
        """
        start, end = to_date(from_date), to_date(to_date_)
        if start is None or end is None:
            raise ValueError("fetch_vouchers needs valid from/to dates (got %r, %r)" % (from_date, to_date_))
        if start > end:
            raise ValueError("from_date %s is after to_date %s" % (start, end))
        elements: List[ET.Element] = []
        if self.export_mode == "daybook":
            for lo, hi in split_date_range(start, end, self.chunk_days):
                root = self.export(build_daybook_request(self.company, lo, hi))
                elements.extend(extract_vouchers(root))
        else:
            ranges = [(start, end)] if min_alter_id is not None else split_date_range(start, end, self.chunk_days)
            for lo, hi in ranges:
                root = self.export(build_voucher_collection_request(
                    self.company, lo, hi, min_alter_id, voucher_type, voucher_number))
                elements.extend(extract_vouchers(root))
        result = filter_voucher_elements(elements, start, end, min_alter_id, voucher_type, voucher_number)
        log.info("Fetched %d voucher(s) from Tally for %s..%s", len(result), start, end)
        return result


__all__ = [
    "TallyClient", "TallyError", "build_collection_request", "build_voucher_collection_request",
    "build_daybook_request", "build_master_request", "build_company_list_request",
    "filter_voucher_elements", "split_date_range", "parse_tally_date",
]
