"""Sync orchestration: Tally -> normalize/validate -> Apps Script.

One :meth:`SyncEngine.run` performs a complete sync for one mode:

1. ``tallyConfig`` (server state: last AlterID, config, pending requests)
2. ``tallySyncStart``
3. fetch + normalize masters; ``tallyIngestMasters`` when they changed
4. fetch vouchers, normalize, de-duplicate by unique_key, validate
5. ``syncTallyData`` in batches (``reconcile`` only on the last batch of a
   FULL / DATE_RANGE sync, listing every unique_key Tally returned)
6. ``tallySyncFinish`` with SUCCESS / PARTIAL / FAILED - also on failure
7. a JSON run report in ``<log_dir>/runs``

:meth:`SyncEngine.watch` polls the server, executes "Sync now" requests made
in the web UI and otherwise runs an incremental sync every interval.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import socket
import time
from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

from . import __version__
from .api_client import ApiError
from .config import AppConfig
from .normalizer import NormalizerContext, make_unique_key, normalize_masters, normalize_tally_voucher, strip_private
from .tally_client import TallyError
from .validators import clean_masters, is_non_accounting, validate_voucher
from .xml_parser import parse_int, parse_tally_date, text_of

log = logging.getLogger("tally_connector.sync")

MODES = ("FULL", "INCREMENTAL", "DATE_RANGE", "VOUCHER", "LEDGER", "MASTERS")
MODE_ALIASES = {
    "FULL": "FULL",
    "INCREMENTAL": "INCREMENTAL", "INC": "INCREMENTAL",
    "DATE_RANGE": "DATE_RANGE", "DATE": "DATE_RANGE", "DATERANGE": "DATE_RANGE",
    "VOUCHER": "VOUCHER",
    "LEDGER": "LEDGER",
    "MASTERS": "MASTERS", "MASTER": "MASTERS",
}
RECONCILE_MODES = frozenset({"FULL", "DATE_RANGE"})
ALTER_ADVANCING_MODES = frozenset({"FULL", "INCREMENTAL"})
MASTER_KINDS = ("groups", "ledgers", "voucher_types", "stock_items", "cost_centres")
MAX_REPORT_FILES = 500


class SyncError(Exception):
    """A sync could not be started or completed for a connector-side reason."""


def _key(value: Any) -> str:
    return " ".join(str(value or "").split()).lower()


def fy_start(d: date) -> date:
    """Start of the Indian financial year (1 April) containing ``d``."""
    return date(d.year if d.month >= 4 else d.year - 1, 4, 1)


def fy_end(d: date) -> date:
    return date(fy_start(d).year + 1, 3, 31)


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------

@dataclass
class SyncRequest:
    mode: str = "INCREMENTAL"
    from_date: str = ""
    to_date: str = ""
    voucher_type: str = ""
    voucher_number: str = ""
    ledger: str = ""
    request_sync_id: str = ""

    @classmethod
    def from_pending(cls, item: Dict[str, Any]) -> "SyncRequest":
        """Build from a ``pending_requests`` entry returned by ``tallyConfig``."""
        def s(name: str) -> str:
            value = item.get(name)
            return "" if value is None else str(value).strip()
        return cls(mode=s("mode"), from_date=s("from_date"), to_date=s("to_date"),
                   voucher_type=s("voucher_type"), voucher_number=s("voucher_number"),
                   ledger=s("ledger"), request_sync_id=s("sync_id"))

    def normalized(self) -> "SyncRequest":
        """Validated copy with canonical mode and ISO dates; raises ValueError."""
        mode = MODE_ALIASES.get(re.sub(r"[\s-]+", "_", str(self.mode or "").strip().upper()))
        if not mode:
            raise ValueError("unknown sync mode %r (expected one of %s)" % (self.mode, ", ".join(MODES)))
        from_iso = parse_tally_date(self.from_date) if self.from_date else ""
        to_iso = parse_tally_date(self.to_date) if self.to_date else ""
        if self.from_date and not from_iso:
            raise ValueError("invalid from date %r" % self.from_date)
        if self.to_date and not to_iso:
            raise ValueError("invalid to date %r" % self.to_date)
        if from_iso and to_iso and from_iso > to_iso:
            raise ValueError("from date %s is after to date %s" % (from_iso, to_iso))
        voucher_type = (self.voucher_type or "").strip()
        voucher_number = (self.voucher_number or "").strip()
        ledger = (self.ledger or "").strip()
        if mode == "DATE_RANGE" and not (from_iso and to_iso):
            raise ValueError("DATE_RANGE sync needs both a from and a to date")
        if mode == "VOUCHER" and not (voucher_type or voucher_number):
            raise ValueError("VOUCHER sync needs a voucher type and/or a voucher number")
        if mode == "LEDGER" and not ledger:
            raise ValueError("LEDGER sync needs a ledger name")
        return SyncRequest(mode, from_iso, to_iso, voucher_type, voucher_number, ledger,
                           (self.request_sync_id or "").strip())


# ---------------------------------------------------------------------------
# Voucher processing (shared by sync and the export command)
# ---------------------------------------------------------------------------

@dataclass
class ProcessedVouchers:
    fetched: int = 0
    unique: int = 0
    duplicates: int = 0
    filtered_out: int = 0
    valid: List[Dict[str, Any]] = field(default_factory=list)
    invalid: List[Dict[str, Any]] = field(default_factory=list)
    non_accounting: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[Dict[str, Any]] = field(default_factory=list)
    all_keys: List[str] = field(default_factory=list)
    max_alter_id: int = 0


def _voucher_summary(voucher: Dict[str, Any], problems: List[Dict[str, str]]) -> Dict[str, Any]:
    header = voucher.get("header") or {}
    return {
        "unique_key": header.get("unique_key", ""),
        "voucher_number": header.get("voucher_number", ""),
        "voucher_type": header.get("voucher_type", ""),
        "voucher_date": header.get("voucher_date", ""),
        "party_ledger": header.get("party_ledger", ""),
        "amount": header.get("amount", 0),
        "tally_alter_id": header.get("tally_alter_id", 0),
        "errors": problems,
    }


def _fallback_key(el, company: str) -> str:
    guid = text_of(el, "GUID") or (el.get("REMOTEID") or "").strip()
    vtype = text_of(el, "VOUCHERTYPENAME") or (el.get("VCHTYPE") or "").strip()
    raw_date = text_of(el, "DATE")
    return make_unique_key(company, vtype, text_of(el, "VOUCHERNUMBER"), parse_tally_date(raw_date) or raw_date, guid)


def _touches_ledger(voucher: Dict[str, Any], ledger_key: str) -> bool:
    if _key((voucher.get("header") or {}).get("party_ledger")) == ledger_key:
        return True
    return any(_key(line.get("ledger_name")) == ledger_key for line in voucher.get("lines") or [])


def process_voucher_elements(elements: List[Any], company: str, context: Any,
                             ledger: Optional[str] = None) -> ProcessedVouchers:
    """Normalize, de-duplicate (by unique_key, highest AlterID wins), filter and validate."""
    result = ProcessedVouchers(fetched=len(elements))
    by_key: Dict[str, Dict[str, Any]] = {}
    failures: Dict[str, Dict[str, Any]] = {}
    for el in elements:
        result.max_alter_id = max(result.max_alter_id, parse_int(text_of(el, "ALTERID"), 0))
        try:
            voucher = normalize_tally_voucher(el, company, context)
        except Exception as exc:  # noqa: BLE001 - one bad voucher must not stop the run
            key = _fallback_key(el, company)
            if key in by_key or key in failures:
                result.duplicates += 1
                continue
            log.warning("Could not normalize voucher %s: %s", key, exc)
            failures[key] = {
                "unique_key": key,
                "voucher_number": text_of(el, "VOUCHERNUMBER"),
                "voucher_type": text_of(el, "VOUCHERTYPENAME") or (el.get("VCHTYPE") or ""),
                "voucher_date": parse_tally_date(text_of(el, "DATE")),
                "party_ledger": text_of(el, "PARTYLEDGERNAME"),
                "amount": 0,
                "tally_alter_id": parse_int(text_of(el, "ALTERID"), 0),
                "errors": [{"code": "NORMALIZE_ERROR", "message": str(exc)}],
            }
            continue
        key = voucher["header"]["unique_key"]
        existing = by_key.get(key)
        if existing is not None:
            result.duplicates += 1
            if voucher["header"]["tally_alter_id"] >= existing["header"]["tally_alter_id"]:
                by_key[key] = voucher
            continue
        by_key[key] = voucher

    result.all_keys = list(by_key.keys()) + [k for k in failures if k not in by_key]
    result.unique = len(result.all_keys)
    result.invalid.extend(failures.values())
    ledger_key = _key(ledger) if ledger else ""
    for key, voucher in by_key.items():
        if ledger_key and not _touches_ledger(voucher, ledger_key):
            result.filtered_out += 1
            continue
        header = voucher["header"]
        for warning in voucher.get("_warnings") or []:
            entry = {"unique_key": key, "voucher_number": header.get("voucher_number", "")}
            entry.update(warning)
            result.warnings.append(entry)
        if is_non_accounting(voucher):
            result.non_accounting.append(_voucher_summary(voucher, []))
            continue
        problems = validate_voucher(voucher)
        if problems:
            result.invalid.append(_voucher_summary(voucher, problems))
            continue
        result.valid.append(voucher)
    result.valid.sort(key=lambda v: (v["header"]["voucher_date"], v["header"]["tally_alter_id"]))
    return result


# ---------------------------------------------------------------------------
# Local state and locking
# ---------------------------------------------------------------------------

def _slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value or "").strip("_") or "company"


class StateStore:
    """Small JSON file with connector-side state (fallback when offline)."""

    def __init__(self, state_dir: str, company: str) -> None:
        self.path = os.path.join(state_dir, "state_%s.json" % _slug(company))

    def load(self) -> Dict[str, Any]:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as exc:
            log.warning("Ignoring unreadable state file %s: %s", self.path, exc)
            return {}

    def update(self, **values: Any) -> None:
        data = self.load()
        data.update(values)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False, default=str)
        os.replace(tmp, self.path)


class RunLock:
    """OS-level exclusive lock so two connector processes never sync the same company.

    The lock is released automatically by the OS if the process dies.
    """

    def __init__(self, path: str) -> None:
        self.path = path
        self._fh = None

    def acquire(self) -> None:
        fh = open(self.path, "a+", encoding="utf-8")
        try:
            fh.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fh.close()
            raise SyncError("Another sync is already running for this company (lock %s). "
                            "Wait for it to finish or stop the other connector process." % self.path) from None
        self._fh = fh

    def release(self) -> None:
        fh, self._fh = self._fh, None
        if fh is None:
            return
        try:
            fh.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        finally:
            fh.close()


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class SyncEngine:
    """Runs syncs for one Tally company.

    ``tally`` needs ``fetch_masters()``, ``fetch_vouchers(...)`` and
    (optionally) ``ping()``; ``api`` needs ``call(action, params)``. With
    ``api=None`` every run is a dry run.
    """

    def __init__(self, config: AppConfig, tally: Any, api: Any = None,
                 now: Callable[[], datetime] = datetime.now, hostname: Optional[str] = None,
                 sleep: Callable[[float], None] = time.sleep) -> None:
        self.config = config
        self.tally = tally
        self.api = api
        self._now = now
        self.hostname = hostname or socket.gethostname()
        self._sleep = sleep
        self._stop = False
        os.makedirs(config.sync.state_dir, exist_ok=True)
        os.makedirs(config.sync.log_dir, exist_ok=True)
        self.state = StateStore(config.sync.state_dir, config.tally.company)
        self.lock_path = os.path.join(config.sync.state_dir, "sync_%s.lock" % _slug(config.tally.company))

    @property
    def company(self) -> str:
        return self.config.tally.company

    def stop(self) -> None:
        """Ask :meth:`watch` to stop after the current step."""
        self._stop = True

    # -- server state -------------------------------------------------------
    def fetch_server_state(self) -> Dict[str, Any]:
        if self.api is None:
            local = self.state.load()
            return {"company": self.company, "last_alter_id": parse_int(local.get("last_alter_id"), 0),
                    "last_success_at": local.get("last_success_at", ""), "config": {}, "pending_requests": []}
        data = self.api.call("tallyConfig", {"company": self.company})
        if not isinstance(data, dict):
            raise SyncError("tallyConfig returned unexpected data: %r" % (data,))
        return data

    def _effective_settings(self, server_config: Dict[str, Any]) -> Dict[str, Any]:
        """Server-side config (set from the web UI) overrides the local ini when valid."""
        batch_size = self.config.sync.batch_size
        raw_batch = server_config.get("SYNC_BATCH_SIZE")
        if raw_batch not in (None, ""):
            value = parse_int(raw_batch, 0)
            if 1 <= value <= 500:
                batch_size = value
            else:
                log.warning("Ignoring invalid server SYNC_BATCH_SIZE %r", raw_batch)
        from_date = self.config.sync.from_date
        raw_from = server_config.get("SYNC_FROM_DATE")
        if raw_from not in (None, ""):
            iso = parse_tally_date(raw_from)
            if iso:
                from_date = iso
            else:
                log.warning("Ignoring invalid server SYNC_FROM_DATE %r", raw_from)
        if not from_date:
            from_date = fy_start(self._now().date()).isoformat()
        return {"batch_size": batch_size, "from_date": from_date}

    def _resolve_range(self, req: SyncRequest, default_from: str) -> Tuple[str, str]:
        if req.mode == "MASTERS":
            return "", ""
        if req.mode == "DATE_RANGE":
            return req.from_date, req.to_date
        start = req.from_date or default_from
        end = req.to_date or fy_end(self._now().date()).isoformat()
        if start > end:
            raise SyncError("from date %s is after to date %s" % (start, end))
        return start, end

    # -- public API -----------------------------------------------------------
    def run(self, request: SyncRequest, dry_run: bool = False,
            server_state: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute one sync; never raises for sync failures (see report['status']).

        KeyboardInterrupt is re-raised after the server has been told the
        sync FAILED.
        """
        dry_run = bool(dry_run) or self.api is None
        t0 = time.monotonic()
        report = self._new_report(request, dry_run)
        lock = RunLock(self.lock_path)
        try:
            lock.acquire()
        except SyncError as exc:
            report["error"] = str(exc)
            log.error("%s", exc)
            self._finalize(report, t0)
            return report
        try:
            self._run_locked(request, dry_run, server_state, report)
        except KeyboardInterrupt:
            report["status"] = "FAILED"
            report["error"] = "Interrupted by user (Ctrl+C)."
            self._safe_finish(report, dry_run)
            raise
        finally:
            lock.release()
            self._finalize(report, t0)
        return report

    def watch(self, max_cycles: Optional[int] = None) -> None:
        """Poll for UI sync requests; run incremental syncs every interval."""
        interval = self.config.sync.interval_seconds
        poll = max(1, min(self.config.sync.poll_seconds, interval))
        next_incremental = 0.0
        cycles = 0
        log.info("Watching company '%s': checking for requests every %ss, incremental sync every %ss. "
                 "Press Ctrl+C to stop.", self.company, poll, interval)
        try:
            while not self._stop:
                cycles += 1
                state = None
                try:
                    state = self.fetch_server_state()
                except Exception as exc:  # noqa: BLE001 - keep watching
                    log.warning("Could not poll the server (%s); retrying in %ss", exc, poll)
                if state is not None:
                    pending = [p for p in (state.get("pending_requests") or []) if isinstance(p, dict)]
                    if pending:
                        for item in pending:
                            if self._stop:
                                break
                            request = SyncRequest.from_pending(item)
                            log.info("Executing sync request %s (%s)", request.request_sync_id or "?", request.mode)
                            self._run_safely(request)
                    elif time.monotonic() >= next_incremental:
                        self._run_safely(SyncRequest(mode="INCREMENTAL"), server_state=state)
                        next_incremental = time.monotonic() + interval
                if max_cycles is not None and cycles >= max_cycles:
                    break
                self._sleep_interruptible(poll)
        except KeyboardInterrupt:
            log.info("Stopped by user.")

    # -- internals ------------------------------------------------------------
    def _run_safely(self, request: SyncRequest, server_state: Optional[Dict[str, Any]] = None) -> None:
        try:
            self.run(request, server_state=server_state)
        except KeyboardInterrupt:
            raise
        except Exception as exc:  # noqa: BLE001 - run() already reports; never kill the watcher
            log.exception("Unexpected error during sync: %s", exc)

    def _sleep_interruptible(self, seconds: float) -> None:
        end = time.monotonic() + seconds
        while not self._stop:
            remaining = end - time.monotonic()
            if remaining <= 0:
                break
            self._sleep(min(1.0, remaining))

    def _new_report(self, request: SyncRequest, dry_run: bool) -> Dict[str, Any]:
        return {
            "connector_version": __version__,
            "host": self.hostname,
            "company": self.company,
            "mode": str(request.mode or "").upper(),
            "request": asdict(request),
            "dry_run": dry_run,
            "sync_id": "",
            "status": "FAILED",
            "error": "",
            "started_at": self._now().replace(microsecond=0).isoformat(),
            "finished_at": "",
            "duration_seconds": 0,
            "from_date": "",
            "to_date": "",
            "from_alter_id": 0,
            "to_alter_id": 0,
            "batch_size": 0,
            "counts": {
                "records_fetched": 0, "fetched": 0, "unique": 0, "duplicates": 0, "filtered_out": 0,
                "non_accounting_skipped": 0, "invalid": 0, "valid": 0, "sent": 0, "batches": 0,
                "added": 0, "updated": 0, "skipped": 0, "failed": 0, "failed_total": 0,
            },
            "masters": {},
            "master_problems": [],
            "invalid_vouchers": [],
            "non_accounting_vouchers": [],
            "warnings": [],
            "server_errors": [],
        }

    def _run_locked(self, request: SyncRequest, dry_run: bool, server_state: Optional[Dict[str, Any]],
                    report: Dict[str, Any]) -> None:
        try:
            req = request.normalized()
        except ValueError as exc:
            report["error"] = "Invalid sync request: %s" % exc
            log.error(report["error"])
            if request.request_sync_id and not dry_run:
                self._reject_request(request, report["error"])
            return
        report["mode"] = req.mode
        report["request"] = asdict(req)
        previous_alter = 0
        try:
            if server_state is None:
                server_state = self.fetch_server_state()
            previous_alter = parse_int(server_state.get("last_alter_id"), 0)
            settings = self._effective_settings(server_state.get("config") or {})
            from_d, to_d = self._resolve_range(req, settings["from_date"])
            incremental = req.mode == "INCREMENTAL"
            report.update(from_date=from_d, to_date=to_d, batch_size=settings["batch_size"],
                          from_alter_id=previous_alter if incremental else 0, to_alter_id=previous_alter)
            report["sync_id"] = self._start(req, from_d, to_d, report["from_alter_id"], dry_run)
            log.info("Sync %s started: %s %s..%s%s", report["sync_id"], req.mode, from_d or "-", to_d or "-",
                     " (AlterID > %d)" % previous_alter if incremental and previous_alter else "")

            self._ensure_company_open()
            masters = self._load_masters(report, req, previous_alter, dry_run)
            context = NormalizerContext.from_masters(masters)

            if req.mode == "MASTERS":
                report["counts"]["records_fetched"] = sum(len(rows) for rows in masters.values())
            else:
                min_alter = previous_alter if incremental and previous_alter > 0 else None
                elements = self.tally.fetch_vouchers(
                    from_d, to_d, min_alter_id=min_alter,
                    voucher_type=req.voucher_type or None, voucher_number=req.voucher_number or None)
                processed = process_voucher_elements(elements, self.company, context, ledger=req.ledger or None)
                self._record_processed(report, processed)
                self._send_vouchers(report, req, processed, from_d, to_d, settings["batch_size"], dry_run)
                if req.mode in ALTER_ADVANCING_MODES:
                    report["to_alter_id"] = max(previous_alter, processed.max_alter_id)

            counts = report["counts"]
            counts["failed_total"] = counts["invalid"] + counts["failed"]
            report["status"] = "SUCCESS" if counts["failed_total"] == 0 else "PARTIAL"
            report["error"] = self._failure_summary(report) if report["status"] == "PARTIAL" else ""
            self._finish(report, dry_run)
            self._save_state(report, dry_run)
        except Exception as exc:  # noqa: BLE001 - reported to the server and the run report
            if isinstance(exc, (TallyError, SyncError, ApiError)):
                log.error("Sync failed: %s", exc)
            else:
                log.exception("Sync failed: %s", exc)
            report["status"] = "FAILED"
            report["error"] = str(exc) or exc.__class__.__name__
            report["to_alter_id"] = previous_alter
            self._safe_finish(report, dry_run)

    def _start(self, req: SyncRequest, from_d: str, to_d: str, from_alter: int, dry_run: bool) -> str:
        if dry_run:
            return "DRYRUN-" + self._now().strftime("%Y%m%d%H%M%S")
        params: Dict[str, Any] = {
            "company": self.company,
            "mode": req.mode,
            "from_date": from_d,
            "to_date": to_d,
            "from_alter_id": int(from_alter),
            "connector_host": self.hostname,
            "connector_version": __version__,
        }
        if req.request_sync_id:
            params["request_sync_id"] = req.request_sync_id
        data = self.api.call("tallySyncStart", params) or {}
        sync_id = str(data.get("sync_id") or "").strip() if isinstance(data, dict) else ""
        if not sync_id:
            raise SyncError("tallySyncStart did not return a sync_id")
        return sync_id

    def _finish(self, report: Dict[str, Any], dry_run: bool) -> None:
        if dry_run or not report.get("sync_id"):
            return
        self.api.call("tallySyncFinish", {
            "sync_id": report["sync_id"],
            "status": report["status"],
            "records_fetched": int(report["counts"]["records_fetched"]),
            "to_alter_id": int(report["to_alter_id"]),
            "error": report["error"] or "",
        })

    def _safe_finish(self, report: Dict[str, Any], dry_run: bool) -> None:
        try:
            self._finish(report, dry_run)
        except Exception as exc:  # noqa: BLE001
            report["finish_error"] = str(exc)
            log.error("Could not report the sync status to the server: %s", exc)

    def _reject_request(self, request: SyncRequest, message: str) -> None:
        """Tell the server an invalid UI request failed so it does not stay pending."""
        try:
            data = self.api.call("tallySyncStart", {
                "company": self.company, "mode": str(request.mode or "").upper(),
                "from_date": request.from_date, "to_date": request.to_date, "from_alter_id": 0,
                "request_sync_id": request.request_sync_id,
                "connector_host": self.hostname, "connector_version": __version__,
            }) or {}
            sync_id = str(data.get("sync_id") or "") if isinstance(data, dict) else ""
            if sync_id:
                self.api.call("tallySyncFinish", {"sync_id": sync_id, "status": "FAILED",
                                                  "records_fetched": 0, "to_alter_id": 0, "error": message})
        except Exception as exc:  # noqa: BLE001
            log.error("Could not report the invalid request %s: %s", request.request_sync_id, exc)

    def _ensure_company_open(self) -> None:
        ping = getattr(self.tally, "ping", None)
        if ping is None:
            return
        info = ping() or {}
        if info.get("company_open") is False:
            opened = ", ".join(info.get("companies") or []) or "none"
            raise TallyError("Company '%s' is not open in Tally (open companies: %s)." % (self.company, opened))

    def _load_masters(self, report: Dict[str, Any], req: SyncRequest, previous_alter: int,
                      dry_run: bool) -> Dict[str, List[Dict[str, Any]]]:
        masters, problems = clean_masters(normalize_masters(self.tally.fetch_masters()))
        report["master_problems"] = problems[:200]
        fingerprint = hashlib.sha256(
            json.dumps(masters, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()
        report["masters"] = {"fetched": {k: len(masters.get(k) or []) for k in MASTER_KINDS},
                             "ingested": False, "added": 0, "updated": 0, "skipped": 0}
        changed = self.state.load().get("masters_fingerprint") != fingerprint
        if req.mode in ("FULL", "MASTERS") or previous_alter == 0 or changed:
            if not dry_run:
                totals = self._ingest_masters(report["sync_id"], masters)
                report["masters"].update(totals)
                report["masters"]["ingested"] = True
                self.state.update(masters_fingerprint=fingerprint)
        return masters

    def _ingest_masters(self, sync_id: str, masters: Dict[str, List[Dict[str, Any]]]) -> Dict[str, int]:
        size = self.config.sync.masters_batch_size
        total_rows = sum(len(masters.get(k) or []) for k in MASTER_KINDS)
        calls: List[Dict[str, List[Dict[str, Any]]]] = []
        if total_rows == 0:
            return {"added": 0, "updated": 0, "skipped": 0}
        if total_rows <= size:
            calls.append({k: list(masters.get(k) or []) for k in MASTER_KINDS})
        else:
            for kind in MASTER_KINDS:  # groups first so parents exist before children
                rows = masters.get(kind) or []
                for i in range(0, len(rows), size):
                    chunk = {k: [] for k in MASTER_KINDS}
                    chunk[kind] = rows[i:i + size]
                    calls.append(chunk)
        totals = {"added": 0, "updated": 0, "skipped": 0}
        for chunk in calls:
            params: Dict[str, Any] = {"sync_id": sync_id, "company": self.company}
            params.update(chunk)
            data = self.api.call("tallyIngestMasters", params) or {}
            for key in totals:
                totals[key] += parse_int(data.get(key), 0) if isinstance(data, dict) else 0
        log.info("Masters ingested: %s", totals)
        return totals

    def _record_processed(self, report: Dict[str, Any], processed: ProcessedVouchers) -> None:
        counts = report["counts"]
        counts.update(
            fetched=processed.fetched, unique=processed.unique, duplicates=processed.duplicates,
            filtered_out=processed.filtered_out, non_accounting_skipped=len(processed.non_accounting),
            invalid=len(processed.invalid), valid=len(processed.valid), records_fetched=processed.unique,
        )
        report["invalid_vouchers"] = processed.invalid
        report["non_accounting_vouchers"] = processed.non_accounting[:500]
        report["warnings"] = processed.warnings[:1000]
        for item in processed.invalid:
            log.warning("Invalid voucher %s (%s): %s", item.get("voucher_number") or "?", item.get("unique_key"),
                        "; ".join(e.get("message", "") for e in item.get("errors") or []))
        log.info("Vouchers: %d fetched, %d unique, %d duplicate, %d valid, %d invalid, %d non-accounting",
                 processed.fetched, processed.unique, processed.duplicates, len(processed.valid),
                 len(processed.invalid), len(processed.non_accounting))

    def _send_vouchers(self, report: Dict[str, Any], req: SyncRequest, processed: ProcessedVouchers,
                       from_d: str, to_d: str, batch_size: int, dry_run: bool) -> None:
        counts = report["counts"]
        valid = processed.valid
        batches = [valid[i:i + batch_size] for i in range(0, len(valid), batch_size)]
        reconcile = req.mode in RECONCILE_MODES
        if reconcile and not batches:
            batches = [[]]  # the server still needs the reconcile key list
        for index, batch in enumerate(batches):
            params: Dict[str, Any] = {
                "sync_id": report["sync_id"],
                "company": self.company,
                "vouchers": [strip_private(v) for v in batch],
                "reconcile": None,
            }
            if reconcile and index == len(batches) - 1:
                params["reconcile"] = {"from_date": from_d, "to_date": to_d,
                                       "unique_keys": list(processed.all_keys)}
            if dry_run:
                counts["sent"] += len(batch)
                continue
            data = self.api.call("syncTallyData", params) or {}
            if not isinstance(data, dict):
                data = {}
            counts["sent"] += len(batch)
            counts["batches"] += 1
            for key in ("added", "updated", "skipped", "failed"):
                counts[key] += parse_int(data.get(key), 0)
            for err in data.get("errors") or []:
                if len(report["server_errors"]) < 1000:
                    report["server_errors"].append(err)
            log.info("Batch %d/%d: %d voucher(s) -> added %s, updated %s, skipped %s, failed %s",
                     index + 1, len(batches), len(batch), data.get("added", 0), data.get("updated", 0),
                     data.get("skipped", 0), data.get("failed", 0))

    @staticmethod
    def _failure_summary(report: Dict[str, Any]) -> str:
        parts = []
        invalid = report.get("invalid_vouchers") or []
        if invalid:
            sample = ", ".join(
                "%s (%s)" % (item.get("voucher_number") or item.get("unique_key"),
                             "/".join(e.get("code", "") for e in (item.get("errors") or [])[:2]))
                for item in invalid[:10])
            parts.append("%d voucher(s) failed local validation: %s%s"
                         % (len(invalid), sample, " ..." if len(invalid) > 10 else ""))
        failed = report["counts"].get("failed", 0)
        if failed:
            parts.append("%d voucher(s) rejected by the server" % failed)
        return "; ".join(parts)[:1500]

    def _save_state(self, report: Dict[str, Any], dry_run: bool) -> None:
        if dry_run:
            return
        updates: Dict[str, Any] = {"last_run_at": report["started_at"], "last_status": report["status"],
                                   "last_sync_id": report["sync_id"]}
        if report["mode"] in ALTER_ADVANCING_MODES:
            updates["last_alter_id"] = report["to_alter_id"]
        updates["last_success_at"] = self._now().replace(microsecond=0).isoformat()
        try:
            self.state.update(**updates)
        except OSError as exc:
            log.warning("Could not save local state: %s", exc)

    def _finalize(self, report: Dict[str, Any], t0: float) -> None:
        report["finished_at"] = self._now().replace(microsecond=0).isoformat()
        report["duration_seconds"] = round(time.monotonic() - t0, 2)
        report["report_path"] = self._write_report(report)
        c = report["counts"]
        log.info("Sync %s %s [%s] in %.1fs: sent %d, added %d, updated %d, skipped %d, failed %d%s",
                 report.get("sync_id") or "-", report["status"], report["mode"], report["duration_seconds"],
                 c["sent"], c["added"], c["updated"], c["skipped"], c["failed_total"] or c["failed"],
                 (" - " + report["error"]) if report["error"] else "")

    def _write_report(self, report: Dict[str, Any]) -> str:
        runs_dir = os.path.join(self.config.sync.log_dir, "runs")
        try:
            os.makedirs(runs_dir, exist_ok=True)
            stamp = re.sub(r"[^0-9T]", "", report["started_at"])
            base = "run_%s_%s_%s" % (stamp, _slug(report["mode"] or "UNKNOWN"), _slug(report["sync_id"] or "nosync"))
            path = os.path.join(runs_dir, base + ".json")
            n = 1
            while os.path.exists(path):
                n += 1
                path = os.path.join(runs_dir, "%s_%d.json" % (base, n))
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(report, fh, indent=2, ensure_ascii=False, default=str)
            self._prune_reports(runs_dir)
            return path
        except OSError as exc:
            log.error("Could not write run report: %s", exc)
            return ""

    @staticmethod
    def _prune_reports(runs_dir: str) -> None:
        try:
            files = sorted(
                (os.path.join(runs_dir, f) for f in os.listdir(runs_dir) if f.startswith("run_") and f.endswith(".json")),
                key=os.path.getmtime)
            for old in files[:-MAX_REPORT_FILES]:
                os.remove(old)
        except OSError:
            pass


__all__ = ["SyncEngine", "SyncRequest", "SyncError", "ProcessedVouchers", "process_voucher_elements",
           "MODES", "fy_start", "fy_end", "StateStore", "RunLock"]
