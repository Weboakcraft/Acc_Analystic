/* Entry point (kept separate so the CSP needs no inline script). */
App.start();
