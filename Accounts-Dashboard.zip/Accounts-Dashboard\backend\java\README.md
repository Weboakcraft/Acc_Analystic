# Java - where it belongs (not built yet, on purpose)

The prompt asked for Java only where it adds real value. For phases 1-7, Python handles Tally I/O and data processing, and Apps Script is the API. Java here would duplicate the connector without adding anything.

Java becomes worth it at **scale-out**, when Google Sheets stops being enough (roughly 200k voucher lines, several companies, or many users writing at once):

1. **`ledger-api` (Spring Boot 3, Java 21, PostgreSQL)**
   - Implements the action contract in `documentation/API.md` unchanged. The frontend only changes `API_URL`.
   - Tables mirror `database/schema.json`, with real foreign keys, a unique index on `vouchers.unique_key`, and a CHECK that entries balance per voucher (deferred constraint trigger).
   - The accounting engine runs as-is on GraalJS, or is ported to Java with `tests/engine.spec.js` as the acceptance suite (every test must pass on both).
   - Materialised monthly ledger balances make the trial balance and statements run in O(ledgers) instead of O(entries).
2. **`tally-gateway` (optional Windows service)**
   - Useful for groups with many Tally companies or sites: pooled connections, per-company schedules, a durable outbound queue (so pushes survive network outages).
   - It speaks the same `tallyConfig / tallySyncStart / syncTallyData / tallySyncFinish` contract as the Python connector, so the two are interchangeable.

Migration path: export each Sheet tab as CSV (the headers match `database/csv/*.csv`), then bulk-load into PostgreSQL, run the engine test suite against the new API, and switch `API_URL`.
