"""Tests for voucher/master normalization and validation."""

import os
import unittest

from tally_connector.normalizer import (
    NormalizerContext,
    guess_base_type,
    guess_tax_head,
    normalize_masters,
    normalize_tally_voucher,
    strip_private,
    to_flat_transactions,
)
from tally_connector.validators import clean_masters, is_non_accounting, validate_voucher
from tally_connector.xml_parser import element_to_value, extract_masters, extract_vouchers, parse_xml

FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")
COMPANY = "Demo Company"


def load(name):
    with open(os.path.join(FIXTURES, name), "rb") as fh:
        return parse_xml(fh.read())


class NormalizerTestBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.masters = normalize_masters(extract_masters(load("masters_sample.xml")))
        cls.ctx = NormalizerContext.from_masters(cls.masters)
        cls.elements = {
            el.find("VOUCHERNUMBER").text: el for el in extract_vouchers(load("daybook_sample.xml"))
        }

    def voucher(self, number, context="default"):
        ctx = self.ctx if context == "default" else context
        return normalize_tally_voucher(self.elements[number], COMPANY, ctx)

    @staticmethod
    def line(voucher, ledger):
        matches = [ln for ln in voucher["lines"] if ln["ledger_name"] == ledger]
        assert len(matches) == 1, "expected one line for %s, got %r" % (ledger, voucher["lines"])
        return matches[0]


class SalesVoucherTests(NormalizerTestBase):
    def test_header(self):
        h = self.voucher("AC/S/0001")["header"]
        self.assertEqual(h["unique_key"], "GUID:a1b2c3d4-0000-0000-0000-000000001001")
        self.assertEqual(h["company"], COMPANY)
        self.assertEqual(h["voucher_date"], "2026-09-01")
        self.assertEqual(h["voucher_type"], "Sales GST")
        self.assertEqual(h["base_voucher_type"], "Sales")
        self.assertEqual(h["voucher_number"], "AC/S/0001")
        self.assertEqual(h["reference_no"], "PO-ABC-7781")
        self.assertEqual(h["reference_date"], "2026-08-28")
        self.assertEqual(h["party_ledger"], "ABC Interiors")
        self.assertEqual(h["party_gstin"], "07AABCA1234B1Z9")
        self.assertEqual(h["place_of_supply"], "Delhi")
        self.assertEqual(h["amount"], 118000.0)
        self.assertEqual(h["salesperson"], "Ravi Kumar")
        self.assertEqual(h["cost_centre"], "Delhi Showroom")
        self.assertEqual(h["status"], "ACTIVE")
        self.assertEqual(h["tally_guid"], "a1b2c3d4-0000-0000-0000-000000001001")
        self.assertEqual(h["tally_master_id"], 1001)
        self.assertEqual(h["tally_alter_id"], 5001)

    def test_invoice_mode_lines_prefer_all_variant_and_signs(self):
        v = self.voucher("AC/S/0001")
        self.assertEqual(len(v["lines"]), 4)  # LEDGERENTRIES duplicates ignored
        party = self.line(v, "ABC Interiors")
        self.assertEqual((party["debit"], party["credit"], party["is_party_line"]), (118000.0, 0.0, True))
        self.assertEqual(self.line(v, "Output CGST")["credit"], 9000.0)
        self.assertEqual(self.line(v, "Output SGST")["credit"], 9000.0)
        sales = self.line(v, "Sales - Furniture (GST 18%)")
        self.assertEqual((sales["debit"], sales["credit"]), (0.0, 100000.0))
        self.assertFalse(sales["is_party_line"])
        self.assertEqual(sales["cost_centre"], "Delhi Showroom")
        self.assertEqual([ln["line_no"] for ln in v["lines"]], [1, 2, 3, 4])
        self.assertEqual(sum(ln["debit"] for ln in v["lines"]), sum(ln["credit"] for ln in v["lines"]))
        self.assertEqual(validate_voucher(v), [])
        self.assertEqual(v["_warnings"], [])

    def test_bill_and_due_date(self):
        bills = self.voucher("AC/S/0001")["bills"]
        self.assertEqual(bills, [{
            "party_ledger": "ABC Interiors", "bill_name": "AC/S/0001", "bill_type": "New Ref",
            "bill_date": "2026-09-01", "due_date": "2026-10-01", "credit_days": 30,
            "amount": 118000.0, "dr_cr": "Dr",
        }])

    def test_items(self):
        items = self.voucher("AC/S/0001")["items"]
        self.assertEqual(len(items), 1)
        item = items[0]
        self.assertEqual(item["line_no"], 1)
        self.assertEqual(item["product_name"], "Executive Office Desk")
        self.assertEqual(item["hsn_sac"], "9403")  # from the stock item master (latest GST details)
        self.assertEqual(item["qty"], 2.0)
        self.assertEqual(item["uom"], "Nos")
        self.assertEqual(item["rate"], 50000.0)
        self.assertEqual(item["discount_pct"], 0.0)
        self.assertEqual(item["discount_amount"], 0.0)
        self.assertEqual(item["taxable_amount"], 100000.0)
        self.assertEqual(item["gst_rate"], 18.0)
        self.assertEqual((item["cgst"], item["sgst"], item["igst"], item["cess"]), (9000.0, 9000.0, 0.0, 0.0))
        self.assertEqual(item["line_total"], 118000.0)
        self.assertEqual(item["godown"], "Main Warehouse")
        self.assertEqual(item["ledger"], "Sales - Furniture (GST 18%)")

    def test_gst_rate_derived_without_masters(self):
        v = self.voucher("AC/S/0001", context=None)
        self.assertEqual(v["items"][0]["gst_rate"], 18.0)
        self.assertEqual(v["header"]["base_voucher_type"], "Sales")  # name-based fallback
        self.assertEqual(v["gst"], {"taxable": 100000.0, "cgst": 9000.0, "sgst": 9000.0, "igst": 0.0, "cess": 0.0})

    def test_gst_summary(self):
        self.assertEqual(self.voucher("AC/S/0001")["gst"],
                         {"taxable": 100000.0, "cgst": 9000.0, "sgst": 9000.0, "igst": 0.0, "cess": 0.0})

    def test_raw_xml_and_private_keys(self):
        v = self.voucher("AC/S/0001")
        self.assertTrue(v["raw_xml"].startswith("<VOUCHER"))
        self.assertTrue(v["raw_xml"].endswith("</VOUCHER>"))
        public = strip_private(v)
        self.assertEqual(sorted(public), ["bills", "gst", "header", "items", "lines", "raw_xml"])

    def test_dict_input_matches_element_input(self):
        from_dict = normalize_tally_voucher({"VOUCHER": element_to_value(self.elements["AC/S/0001"])}, COMPANY, self.ctx)
        from_element = self.voucher("AC/S/0001")
        self.assertEqual(from_dict["header"], from_element["header"])
        self.assertEqual(from_dict["lines"], from_element["lines"])
        self.assertEqual(from_dict["items"], from_element["items"])

    def test_dict_context(self):
        ctx = {"vtype_base": {"Sales GST": "Sales"}, "ledger_tax_head": {"Output CGST": "CGST", "Output SGST": "SGST"}}
        v = normalize_tally_voucher(self.elements["AC/S/0001"], COMPANY, ctx)
        self.assertEqual(v["header"]["base_voucher_type"], "Sales")
        self.assertEqual(v["gst"]["cgst"], 9000.0)

    def test_flat_transactions(self):
        rows = to_flat_transactions(self.voucher("AC/S/0001"), sync_timestamp="2026-09-26T10:00:00")
        self.assertEqual(len(rows), 4)
        self.assertEqual(round(sum(r["debit"] for r in rows), 2), round(sum(r["credit"] for r in rows), 2))
        by_ledger = {r["ledger"]: r for r in rows}
        party = by_ledger["ABC Interiors"]
        self.assertEqual(party["due_date"], "2026-10-01")
        self.assertEqual(party["amount"], 118000.0)
        self.assertEqual(party["transaction_id"], "GUID:a1b2c3d4-0000-0000-0000-000000001001#1")
        self.assertEqual(party["voucher_id"], "GUID:a1b2c3d4-0000-0000-0000-000000001001")
        self.assertEqual(by_ledger["Output CGST"]["gst"], 9000.0)
        self.assertEqual(by_ledger["Sales - Furniture (GST 18%)"]["taxable_amount"], 100000.0)
        self.assertEqual(party["gst"], 0.0)
        for row in rows:
            self.assertEqual(row["source"], "TALLY")
            self.assertEqual(row["sync_timestamp"], "2026-09-26T10:00:00")
            self.assertEqual(row["party"], "ABC Interiors")
            self.assertEqual(row["voucher_type"], "Sales GST")


class OtherVoucherTests(NormalizerTestBase):
    def test_receipt_signs_and_agst_ref(self):
        v = self.voucher("AC/R/0031")
        self.assertEqual(v["header"]["base_voucher_type"], "Receipt")
        self.assertEqual(v["header"]["amount"], 50000.0)
        party = self.line(v, "ABC Interiors")
        bank = self.line(v, "HDFC Bank CA 4521")
        self.assertEqual((party["debit"], party["credit"], party["is_party_line"]), (0.0, 50000.0, True))
        self.assertEqual((bank["debit"], bank["credit"], bank["is_party_line"]), (50000.0, 0.0, False))
        self.assertEqual(v["bills"], [{
            "party_ledger": "ABC Interiors", "bill_name": "AC/S/0001", "bill_type": "Agst Ref",
            "bill_date": "", "due_date": "", "credit_days": 0, "amount": 50000.0, "dr_cr": "Cr",
        }])
        self.assertEqual(v["gst"]["taxable"], 0.0)
        self.assertEqual(validate_voucher(v), [])

    def test_invalid_char_is_sanitized(self):
        narration = self.voucher("AC/R/0031")["header"]["narration"]
        self.assertNotIn("\x04", narration)
        self.assertTrue(narration.startswith("NEFT HDFCN26258123456"))
        self.assertIn("against AC/S/0001", narration)

    def test_purchase_non_all_ledger_entries_and_bill(self):
        v = self.voucher("AC/P/0012")
        h = v["header"]
        self.assertEqual(h["base_voucher_type"], "Purchase")
        self.assertEqual(h["party_ledger"], "Delhi Foam & Fabric")
        self.assertEqual(h["amount"], 59000.0)
        self.assertEqual(h["cost_centre"], "Factory - Kirti Nagar")
        self.assertEqual(len(v["lines"]), 4)
        self.assertEqual(self.line(v, "Delhi Foam & Fabric")["credit"], 59000.0)
        self.assertEqual(self.line(v, "Purchase - Raw Materials")["debit"], 50000.0)
        self.assertEqual(self.line(v, "Input CGST")["debit"], 4500.0)
        bill = v["bills"][0]
        self.assertEqual((bill["bill_type"], bill["bill_name"], bill["bill_date"], bill["credit_days"], bill["due_date"]),
                         ("New Ref", "DFF/2026/0457", "2026-09-10", 45, "2026-10-25"))
        self.assertEqual((bill["amount"], bill["dr_cr"]), (59000.0, "Cr"))
        self.assertEqual(v["gst"], {"taxable": 50000.0, "cgst": 4500.0, "sgst": 4500.0, "igst": 0.0, "cess": 0.0})
        self.assertEqual(v["items"], [])
        self.assertEqual(validate_voucher(v), [])

    def test_cancelled_journal(self):
        v = self.voucher("AC/J/0007")
        self.assertEqual(v["header"]["status"], "CANCELLED")
        self.assertEqual(v["header"]["base_voucher_type"], "Journal")
        self.assertEqual(v["lines"], [])
        self.assertEqual(validate_voucher(v), [])
        self.assertFalse(is_non_accounting(v))

    def test_unbalanced_journal_detected(self):
        v = self.voucher("AC/J/0008")
        codes = [p["code"] for p in validate_voucher(v)]
        self.assertEqual(codes, ["UNBALANCED"])
        self.assertIn("12500.00", validate_voucher(v)[0]["message"])

    def test_unique_key_fallback_without_guid(self):
        xml = ("<VOUCHER VCHTYPE=\"Journal\"><DATE>20260920</DATE><VOUCHERTYPENAME>Journal</VOUCHERTYPENAME>"
               "<VOUCHERNUMBER>AC/J/0100</VOUCHERNUMBER>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Rent</LEDGERNAME><AMOUNT>-100.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Cash</LEDGERNAME><AMOUNT>100.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "</VOUCHER>")
        v = normalize_tally_voucher(xml, COMPANY)
        self.assertEqual(v["header"]["unique_key"], "KEY:acctdash furniture|journal|oc/j/0100|2026-09-20")
        self.assertEqual(v["header"]["tally_guid"], "")

    def test_sign_mismatch_warning_amount_wins(self):
        xml = ("<VOUCHER><DATE>20260920</DATE><GUID>g-1</GUID><VOUCHERTYPENAME>Journal</VOUCHERTYPENAME>"
               "<VOUCHERNUMBER>J/1</VOUCHERNUMBER>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Rent</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>"
               "<AMOUNT>-1,000.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Cash</LEDGERNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>"
               "<AMOUNT>1000.00</AMOUNT></ALLLEDGERENTRIES.LIST></VOUCHER>")
        v = normalize_tally_voucher(xml, COMPANY)
        self.assertEqual([w["code"] for w in v["_warnings"]], ["SIGN_MISMATCH"])
        self.assertEqual(self.line(v, "Rent")["debit"], 1000.0)
        self.assertEqual(validate_voucher(v), [])

    def test_bad_amount_and_date_are_invalid(self):
        xml = ("<VOUCHER><DATE>20261340</DATE><GUID>g-2</GUID><VOUCHERTYPENAME>Journal</VOUCHERTYPENAME>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Rent</LEDGERNAME><AMOUNT>abc</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Cash</LEDGERNAME><AMOUNT>100.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "</VOUCHER>")
        codes = {p["code"] for p in validate_voucher(normalize_tally_voucher(xml, COMPANY))}
        self.assertTrue({"INVALID_AMOUNT", "INVALID_DATE", "TOO_FEW_LINES", "UNBALANCED"} <= codes)

    def test_igst_accounting_voucher(self):
        xml = ("<VOUCHER><DATE>20260911</DATE><GUID>g-3</GUID><VOUCHERTYPENAME>Sales</VOUCHERTYPENAME>"
               "<VOUCHERNUMBER>AC/S/0002</VOUCHERNUMBER><PARTYLEDGERNAME>Jaipur Decor</PARTYLEDGERNAME>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Jaipur Decor</LEDGERNAME><AMOUNT>-11800.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Sales Interstate</LEDGERNAME><AMOUNT>10000.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "<ALLLEDGERENTRIES.LIST><LEDGERNAME>Output IGST @18%</LEDGERNAME><AMOUNT>1800.00</AMOUNT></ALLLEDGERENTRIES.LIST>"
               "</VOUCHER>")
        v = normalize_tally_voucher(xml, COMPANY)
        self.assertEqual(v["gst"], {"taxable": 10000.0, "cgst": 0.0, "sgst": 0.0, "igst": 1800.0, "cess": 0.0})
        self.assertTrue(self.line(v, "Jaipur Decor")["is_party_line"])
        self.assertEqual(v["header"]["amount"], 11800.0)


class MastersTests(NormalizerTestBase):
    def by(self, kind, field, value):
        return next(r for r in self.masters[kind] if r[field] == value)

    def test_groups(self):
        furniture = self.by("groups", "group_name", "Furniture Sales")
        self.assertEqual(furniture["parent_group"], "Sales Accounts")
        self.assertEqual(furniture["nature"], "Income")
        self.assertTrue(furniture["affects_gross_profit"])
        self.assertEqual(furniture["alter_id"], 101)
        self.assertEqual(furniture["tally_guid"], "a1b2c3d4-0000-0000-0000-000000000101")
        self.assertEqual(self.by("groups", "group_name", "Sales Accounts")["parent_group"], "")
        raw = self.by("groups", "group_name", "Raw Material Purchases")
        self.assertEqual((raw["nature"], raw["affects_gross_profit"]), ("Expenses", True))
        self.assertEqual(self.by("groups", "group_name", "Sundry Debtors")["nature"], "Assets")
        duties = self.by("groups", "group_name", "Duties & Taxes")
        self.assertEqual((duties["nature"], duties["affects_gross_profit"]), ("Liabilities", False))

    def test_ledgers(self):
        abc = self.by("ledgers", "ledger_name", "ABC Interiors")
        self.assertEqual((abc["opening_balance"], abc["opening_dr_cr"]), (25000.0, "Dr"))
        self.assertEqual(abc["parent_group"], "Sundry Debtors")
        self.assertEqual((abc["gstin"], abc["state"], abc["credit_days"]), ("07AABCA1234B1Z9", "Delhi", 30))
        self.assertEqual((abc["email"], abc["mobile"]), ("accounts@abcinteriors.example", "9810000001"))
        self.assertEqual(abc["address"], "12, Rajouri Garden Main Market, New Delhi 110027")
        self.assertEqual(abc["tax_type"], "")
        dff = self.by("ledgers", "ledger_name", "Delhi Foam & Fabric")
        self.assertEqual((dff["opening_balance"], dff["opening_dr_cr"], dff["credit_days"]), (15000.0, "Cr", 45))
        xyz = self.by("ledgers", "ledger_name", "XYZ Hardware Suppliers")
        self.assertEqual((xyz["gstin"], xyz["state"]), ("06AAXFX4321K1Z2", "Haryana"))
        self.assertEqual(xyz["address"], "Plot 7, Sector 37, Gurugram 122001")
        self.assertEqual(self.by("ledgers", "ledger_name", "HDFC Bank CA 4521")["opening_dr_cr"], "Dr")
        cgst = self.by("ledgers", "ledger_name", "Output CGST")
        self.assertEqual((cgst["tax_type"], cgst["gst_rate"]), ("CGST", 9.0))
        self.assertEqual(self.by("ledgers", "ledger_name", "Output SGST")["tax_type"], "SGST")
        self.assertEqual(self.by("ledgers", "ledger_name", "Input CGST")["tax_type"], "CGST")
        self.assertEqual(self.by("ledgers", "ledger_name", "Input SGST")["tax_type"], "SGST")
        sales = self.by("ledgers", "ledger_name", "Sales - Furniture (GST 18%)")
        self.assertEqual((sales["parent_group"], sales["gst_rate"], sales["tax_type"]), ("Furniture Sales", 18.0, ""))

    def test_voucher_types(self):
        types = {r["voucher_type"]: r["base_voucher_type"] for r in self.masters["voucher_types"]}
        self.assertEqual(types["Sales GST"], "Sales")
        self.assertEqual(types["Sales"], "Sales")
        self.assertEqual(types["Showroom Returns"], "Credit Note")
        self.assertEqual(types["Stock Journal"], "Other")
        self.assertEqual(self.by("voucher_types", "voucher_type", "Sales GST")["tally_guid"],
                         "a1b2c3d4-0000-0000-0000-000000000502")

    def test_stock_items_and_cost_centres(self):
        desk = self.masters["stock_items"][0]
        self.assertEqual(desk, {
            "product_name": "Executive Office Desk", "stock_group": "Office Furniture", "uom": "Nos",
            "hsn_sac": "9403", "gst_rate": 18.0, "opening_qty": 12.0, "opening_value": 408000.0,
            "tally_guid": "a1b2c3d4-0000-0000-0000-000000000301",
        })
        showroom = self.by("cost_centres", "cost_centre_name", "Delhi Showroom")
        self.assertEqual(showroom, {"cost_centre_name": "Delhi Showroom", "category": "Primary Cost Category",
                                    "parent": "", "tally_guid": "a1b2c3d4-0000-0000-0000-000000000401"})

    def test_clean_masters_dedupes(self):
        cleaned, problems = clean_masters({"ledgers": [{"ledger_name": "Cash"}, {"ledger_name": " cash "},
                                                       {"ledger_name": ""}]})
        self.assertEqual(len(cleaned["ledgers"]), 1)
        self.assertEqual(len(problems), 2)


class GuessingTests(unittest.TestCase):
    def test_base_type_guessing(self):
        self.assertEqual(guess_base_type("Sales GST"), "Sales")
        self.assertEqual(guess_base_type("Tax Invoice"), "Sales")
        self.assertEqual(guess_base_type("Credit Note GST"), "Credit Note")
        self.assertEqual(guess_base_type("Purchase Return"), "Debit Note")
        self.assertEqual(guess_base_type("Sales Order"), "Other")
        self.assertEqual(guess_base_type("Stock Journal"), "Other")
        self.assertEqual(guess_base_type("Bank Receipt"), "Receipt")
        self.assertEqual(guess_base_type("Cash Payment"), "Payment")
        self.assertEqual(guess_base_type("Contra Entry"), "Contra")

    def test_tax_head_guessing(self):
        self.assertEqual(guess_tax_head("Output CGST @9%"), "CGST")
        self.assertEqual(guess_tax_head("UTGST Payable"), "SGST")
        self.assertEqual(guess_tax_head("IGST Input"), "IGST")
        self.assertEqual(guess_tax_head("Compensation Cess"), "CESS")
        self.assertEqual(guess_tax_head("Success Traders"), "")
        self.assertEqual(guess_tax_head("Sales - Furniture (GST 18%)"), "")


if __name__ == "__main__":
    unittest.main()
