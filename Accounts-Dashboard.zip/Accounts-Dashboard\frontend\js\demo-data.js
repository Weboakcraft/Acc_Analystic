/**
 * Demo dataset - used ONLY by the demo adapter (no API_URL configured).
 * The production Google Sheet starts with one sample row per table; this generator exists so the
 * frontend can be evaluated on GitHub Pages without a backend. Dates are relative to today, so
 * "today's" figures are never empty. Generation is deterministic (seeded).
 */
var DemoData = (function () {
  'use strict';
  var U = Engine.util;

  function rng(seed) { return function () { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }; }

  function build(todayStr) {
    var today = todayStr || U.D(new Date());
    var rand = rng(20260926);
    var pick = function (a) { return a[Math.floor(rand() * a.length)]; };
    var booksBegin = U.addDays(today, -150);
    var company = { company_id: 'CMP-0001', company_name: 'Demo Company', tally_company_name: 'Demo Company', gstin: '07AAACO1234F1Z5', state: 'Delhi', state_code: '07', fy_start_month: 4, books_begin_date: booksBegin, base_currency: 'INR', is_active: true };

    var ledgers = [], groups = [{ group_name: 'Furniture Sales', parent_group: 'Sales Accounts', nature: 'Income', affects_gross_profit: true }];
    function L(name, group, type, ob, drcr, extra) {
      var l = { ledger_id: 'LED-' + ('000' + (ledgers.length + 1)).slice(-4), company_id: 'CMP-0001', ledger_name: name, parent_group: group, ledger_type: type, opening_balance: ob || 0, opening_dr_cr: drcr || 'Dr', is_active: true, source: 'TALLY' };
      Object.keys(extra || {}).forEach(function (k) { l[k] = extra[k]; });
      ledgers.push(l); return name;
    }
    var CAP = L("Owner's Capital", 'Capital Account', 'Capital', 2500000, 'Cr');
    L('General Reserve', 'Reserves & Surplus', 'Capital', 240000, 'Cr');
    var LOAN = L('Term Loan - SBI', 'Secured Loans', 'Liability', 900000, 'Cr');
    var BANK = L('HDFC Bank CA 4521', 'Bank Accounts', 'Bank', 1850000, 'Dr');
    var UPI = L('UPI Collections', 'Bank Accounts', 'Bank', 0, 'Dr');
    var CASH = L('Cash', 'Cash-in-Hand', 'Cash', 60000, 'Dr');
    var PM = L('Plant & Machinery', 'Fixed Assets', 'Asset', 1200000, 'Dr');
    L('Closing Stock', 'Stock-in-Hand', 'Stock', 650000, 'Dr');
    var SALES = L('Sales - Furniture (GST 18%)', 'Furniture Sales', 'Sales');
    L('Sales - Offline', 'Sales Accounts', 'Sales');
    var PUR_RM = L('Purchase - Raw Material', 'Purchase Accounts', 'Purchase');
    var PUR_HW = L('Purchase - Hardware (GST 18%)', 'Purchase Accounts', 'Purchase');
    var WAGES = L('Factory Wages', 'Direct Expenses', 'Expense', 0, 'Dr', { mis_category: 'SALARY' });
    var SAL = L('Salaries', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'SALARY' });
    var RENT = L('Showroom Rent', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'RENT' });
    var ELEC = L('Electricity Charges', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'UTILITIES' });
    var MKT = L('Marketing & Advertising', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'MARKETING' });
    var FRT = L('Freight Outward', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'FREIGHT' });
    var DEP = L('Depreciation', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'DEPRECIATION' });
    var INT = L('Interest on Term Loan', 'Indirect Expenses', 'Expense', 0, 'Dr', { mis_category: 'INTEREST' });
    L('Round Off', 'Indirect Expenses', 'Expense');
    var OCG = L('Output CGST', 'Duties & Taxes', 'Tax', 0, 'Cr', { tax_type: 'CGST' });
    var OSG = L('Output SGST', 'Duties & Taxes', 'Tax', 0, 'Cr', { tax_type: 'SGST' });
    var OIG = L('Output IGST', 'Duties & Taxes', 'Tax', 0, 'Cr', { tax_type: 'IGST' });
    var ICG = L('Input CGST', 'Duties & Taxes', 'Tax', 0, 'Dr', { tax_type: 'CGST' });
    var ISG = L('Input SGST', 'Duties & Taxes', 'Tax', 0, 'Dr', { tax_type: 'SGST' });
    var IIG = L('Input IGST', 'Duties & Taxes', 'Tax', 0, 'Dr', { tax_type: 'IGST' });

    var customers = [
      { name: 'ABC Interiors', state: 'Delhi', gstin: '07AABCA1234B1Z2', days: 30, mobile: '9810012345', sp: 'Rahul Mehta', w: 5 },
      { name: 'Modern Office Solutions', state: 'Uttar Pradesh', gstin: '09AAECM4321K1Z3', days: 45, mobile: '9711122233', sp: 'Neha Kapoor', w: 4 },
      { name: 'Greenleaf Hospitality', state: 'Haryana', gstin: '06AAGCG7788M1Z1', days: 30, mobile: '9899000111', sp: 'Rahul Mehta', w: 3 },
      { name: 'Urban Nest Realty', state: 'Delhi', gstin: '07AAHFU5566N1Z8', days: 15, mobile: '9958123123', sp: 'Arjun Sethi', w: 2 },
      { name: 'Skyline Coworking', state: 'Delhi', gstin: '07AAJCS9090P1Z4', days: 30, mobile: '9312345678', sp: 'Neha Kapoor', w: 2 },
      { name: 'Sunrise Public School', state: 'Uttar Pradesh', gstin: '', days: 60, mobile: '9412233445', sp: 'Arjun Sethi', w: 1 }
    ];
    var vendors = [
      { name: 'XYZ Hardware Suppliers', state: 'Delhi', gstin: '07AAAFX5678C1Z9', days: 45, msme: true, ledger: PUR_HW, ob: 0 },
      { name: 'Delhi Foam & Fabric', state: 'Delhi', gstin: '07AADFD3344E1Z6', days: 30, msme: false, ledger: PUR_RM, ob: 120000 },
      { name: 'Shree Timber Traders', state: 'Rajasthan', gstin: '08AAKFS1122Q1Z5', days: 30, msme: true, ledger: PUR_RM, ob: 0 }
    ];
    customers.forEach(function (c) { L(c.name, 'Sundry Debtors', 'Customer', 0, 'Dr', { gstin: c.gstin, state: c.state, credit_days: c.days }); });
    L('Walk-in Customers', 'Sundry Debtors', 'Customer', 0, 'Dr', { state: 'Delhi', credit_days: 0, source: 'OFFLINE' });
    vendors.forEach(function (v) { L(v.name, 'Sundry Creditors', 'Vendor', v.ob, 'Cr', { gstin: v.gstin, state: v.state, credit_days: v.days }); });
    var BSES = L('BSES Rajdhani Power Ltd', 'Sundry Creditors', 'Vendor', 0, 'Cr', { state: 'Delhi', credit_days: 15 });

    var products = [
      { name: 'Executive Office Desk', hsn: '9403', rate: 50000, cost: 33500 },
      { name: 'Ergonomic Mesh Chair', hsn: '9401', rate: 12000, cost: 7400 },
      { name: 'Conference Table 8-Seater', hsn: '9403', rate: 95000, cost: 61000 },
      { name: 'Modular Workstation 4-Seater', hsn: '9403', rate: 140000, cost: 92000 },
      { name: 'Storage Cabinet', hsn: '9403', rate: 22000, cost: 14100 }
    ];

    var vouchers = [], entries = [], bills = [], salesItems = [], purchaseItems = [];
    var vseq = 0, eseq = 0;
    function V(date, type, number, party, lines, vbills, items, source, extra) {
      var id = 'VCH-' + ('00000' + (++vseq)).slice(-6);
      var dr = 0; lines.forEach(function (l) { dr += l[1]; });
      var v = { voucher_id: id, company_id: 'CMP-0001', unique_key: 'DEMO:' + id, voucher_date: date, voucher_type: type, base_voucher_type: type, voucher_number: number, party_ledger: party || '', amount: U.r2(dr), source: source || 'TALLY', status: 'ACTIVE', revision: 1, narration: '' };
      Object.keys(extra || {}).forEach(function (k) { v[k] = extra[k]; });
      vouchers.push(v);
      lines.forEach(function (l, i) { entries.push({ entry_id: 'ENT-' + (++eseq), voucher_id: id, revision: 1, line_no: i + 1, ledger_name: l[0], debit: U.r2(l[1]), credit: U.r2(l[2]), is_party_line: l[0] === party }); });
      (vbills || []).forEach(function (b) { b.voucher_id = id; b.revision = 1; bills.push(b); });
      (items || []).forEach(function (it, i) { it.voucher_id = id; it.revision = 1; it.line_no = i + 1; });
      return v;
    }
    var openInvoices = [], openBills = [];
    var sNo = 0, pNo = 0, rNo = 0, pyNo = 0, jNo = 0;

    function sale(date, c, source) {
      var n = 1 + Math.floor(rand() * 2), items = [], taxable = 0;
      for (var i = 0; i < n; i++) {
        var p = pick(products), qty = p.rate > 60000 ? 1 : 1 + Math.floor(rand() * 4), disc = pick([0, 0, 5, 10]);
        var tv = U.r2(qty * p.rate * (1 - disc / 100));
        items.push({ product_name: p.name, hsn_sac: p.hsn, qty: qty, uom: 'Nos', rate: p.rate, discount_pct: disc, discount_amount: U.r2(qty * p.rate - tv), taxable_amount: tv, gst_rate: 18, godown: 'Main Warehouse', sales_ledger: SALES });
        taxable += tv;
      }
      var intra = c.state === 'Delhi';
      items.forEach(function (it) { it.cgst = intra ? U.r2(it.taxable_amount * .09) : 0; it.sgst = it.cgst; it.igst = intra ? 0 : U.r2(it.taxable_amount * .18); it.cess = 0; it.line_total = U.r2(it.taxable_amount + it.cgst + it.sgst + it.igst); });
      taxable = U.r2(taxable);
      var cg = intra ? U.r2(taxable * .09) : 0, ig = intra ? 0 : U.r2(taxable * .18);
      var gross = U.r2(taxable + 2 * cg + ig), total = Math.round(gross), ro = U.r2(total - gross);
      var no = (source === 'OFFLINE' ? 'AC/OFF/' : 'AC/S/') + ('000' + (++sNo)).slice(-4);
      var lines = [[c.name, total, 0], [source === 'OFFLINE' ? 'Sales - Offline' : SALES, 0, taxable]];
      if (intra) { lines.push([OCG, 0, cg]); lines.push([OSG, 0, cg]); } else lines.push([OIG, 0, ig]);
      if (ro) lines.push(ro > 0 ? ['Round Off', 0, ro] : ['Round Off', -ro, 0]);
      var due = U.addDays(date, c.days);
      var v = V(date, 'Sales', no, c.name, lines, [{ party_ledger: c.name, bill_name: no, bill_type: 'New Ref', bill_date: date, due_date: due, credit_days: c.days, amount: total, dr_cr: 'Dr' }], items, source, { salesperson: c.sp, place_of_supply: c.state, party_gstin: c.gstin, reference_no: 'PO-' + Math.floor(1000 + rand() * 8999) });
      items.forEach(function (it) { salesItems.push(it); });
      openInvoices.push({ c: c, no: no, date: date, due: due, total: total, v: v });
    }
    function receipt(date, c, billNo, amt, acct) {
      V(date, 'Receipt', 'AC/R/' + ('000' + (++rNo)).slice(-4), c.name, [[acct || BANK, amt, 0], [c.name, 0, amt]], [{ party_ledger: c.name, bill_name: billNo, bill_type: 'Agst Ref', bill_date: date, amount: amt, dr_cr: 'Cr' }], null, 'TALLY', { reference_no: 'NEFT' + Math.floor(rand() * 1e9), narration: 'Received against ' + billNo });
    }
    function purchase(date, vd) {
      var taxable = U.r2((vd.ledger === PUR_HW ? 90000 : 240000) * (0.6 + rand() * 0.9));
      taxable = Math.round(taxable / 100) * 100;
      var intra = vd.state === 'Delhi', cg = intra ? U.r2(taxable * .09) : 0, ig = intra ? 0 : U.r2(taxable * .18);
      var total = U.r2(taxable + 2 * cg + ig);
      var inv = vd.name.split(' ')[0].toUpperCase().slice(0, 4) + '/' + (1100 + (++pNo));
      var no = 'AC/P/' + ('000' + pNo).slice(-4);
      var lines = [[vd.ledger, taxable, 0]];
      if (intra) { lines.push([ICG, cg, 0]); lines.push([ISG, cg, 0]); } else lines.push([IIG, ig, 0]);
      lines.push([vd.name, 0, total]);
      var due = U.addDays(date, vd.days);
      var pi = vd.ledger === PUR_HW ? { name: 'Soft-close Drawer Channel 18in', hsn: '8302', uom: 'Pairs', rate: 200 } : pick([{ name: 'Sheesham Wood Planks', hsn: '4407', uom: 'CFT', rate: 2400 }, { name: 'HD Foam Sheet 50mm', hsn: '3921', uom: 'Nos', rate: 1800 }, { name: 'Upholstery Fabric', hsn: '5407', uom: 'Mtr', rate: 450 }]);
      var qty = Math.round(taxable / pi.rate);
      var v = V(date, 'Purchase', no, vd.name, lines, [{ party_ledger: vd.name, bill_name: inv, bill_type: 'New Ref', bill_date: date, due_date: due, credit_days: vd.days, amount: total, dr_cr: 'Cr' }], null, 'TALLY', { reference_no: inv, party_gstin: vd.gstin, place_of_supply: 'Delhi' });
      purchaseItems.push({ voucher_id: v.voucher_id, revision: 1, line_no: 1, product_name: pi.name, hsn_sac: pi.hsn, qty: qty, uom: pi.uom, rate: U.r2(taxable / qty), discount_amount: 0, taxable_amount: taxable, gst_rate: 18, cgst: cg, sgst: cg, igst: ig, cess: 0, line_total: total, godown: 'Main Warehouse', purchase_ledger: vd.ledger });
      openBills.push({ vd: vd, inv: inv, date: date, due: due, total: total });
    }
    function payment(date, party, amt, billNo, narr) {
      V(date, 'Payment', 'AC/PY/' + ('000' + (++pyNo)).slice(-4), party, [[party, amt, 0], [BANK, 0, amt]], billNo ? [{ party_ledger: party, bill_name: billNo, bill_type: 'Agst Ref', bill_date: date, amount: amt, dr_cr: 'Dr' }] : [], null, 'TALLY', { narration: narr || '' });
    }
    function expense(date, ledger, amt, narr, acct) {
      V(date, 'Payment', 'AC/PY/' + ('000' + (++pyNo)).slice(-4), '', [[ledger, amt, 0], [acct || BANK, 0, amt]], [], null, 'TALLY', { narration: narr });
    }
    function journal(date, lines, narr) { V(date, 'Journal', 'AC/J/' + ('000' + (++jNo)).slice(-4), '', lines, [], null, 'TALLY', { narration: narr }); }

    // Opening bill for the vendor opening balance
    openBills.push({ vd: vendors[1], inv: 'DFF/0998', date: U.addDays(booksBegin, -20), due: U.addDays(booksBegin, 10), total: 120000, opening: true });

    var weights = []; customers.forEach(function (c) { for (var i = 0; i < c.w; i++) weights.push(c); });
    for (var d = 140; d >= 0; d--) {
      var date = U.addDays(today, -d);
      var dow = new Date(date + 'T00:00:00Z').getUTCDay();
      if (dow === 0 && d !== 0) continue;
      // sales
      var ns = d === 0 ? 3 : (rand() < 0.62 ? 1 + (rand() < 0.3 ? 1 : 0) : 0);
      for (var s = 0; s < ns; s++) sale(date, pick(weights), rand() < 0.2 ? 'OFFLINE' : 'TALLY');
      if (rand() < 0.15) { sale(date, { name: 'Walk-in Customers', state: 'Delhi', gstin: '', days: 0, sp: 'Showroom' }, 'OFFLINE'); }
      // collections
      openInvoices.slice().forEach(function (inv) {
        var age = U.daysBetween(inv.date, date);
        if (inv.c.name === 'Walk-in Customers' && age === 0) { receipt(date, inv.c, inv.no, inv.total, rand() < 0.5 ? CASH : UPI); openInvoices.splice(openInvoices.indexOf(inv), 1); return; }
        var slow = inv.c.name === 'Modern Office Solutions' || inv.c.name === 'Sunrise Public School';
        if (age >= inv.c.days - 5 && rand() < (slow ? 0.03 : 0.16)) {
          var partial = rand() < 0.2 ? U.r2(Math.round(inv.total * 0.5)) : inv.total;
          receipt(date, inv.c, inv.no, partial);
          if (partial === inv.total) openInvoices.splice(openInvoices.indexOf(inv), 1); else inv.total = U.r2(inv.total - partial);
        }
      });
      // purchases
      if (rand() < 0.33) purchase(date, pick(vendors));
      openBills.slice().forEach(function (b) {
        var age = U.daysBetween(b.date, date);
        var lateVendor = b.vd.name === 'Delhi Foam & Fabric';
        if (age >= b.vd.days - 3 && rand() < (lateVendor ? 0.05 : 0.2)) {
          payment(date, b.vd.name, b.total, b.inv, 'Paid against ' + b.inv);
          openBills.splice(openBills.indexOf(b), 1);
        }
      });
      var dom = +date.slice(8, 10);
      if (dom === 1) { expense(date, RENT, 85000, 'Showroom rent'); payment(date, LOAN, 25000, null, 'EMI principal - SBI term loan'); expense(date, INT, 9000, 'Interest on SBI term loan'); }
      if (dom === 5) { V(date, 'Purchase', 'AC/P/E' + date.slice(5, 7), 'BSES Rajdhani Power Ltd', [[ELEC, 18000 + Math.round(rand() * 6000), 0], ['BSES Rajdhani Power Ltd', 0, 0]], [], null, 'TALLY'); var last = vouchers[vouchers.length - 1]; var e0 = entries[entries.length - 2]; entries[entries.length - 1].credit = e0.debit; last.amount = e0.debit; bills.push({ voucher_id: last.voucher_id, revision: 1, party_ledger: 'BSES Rajdhani Power Ltd', bill_name: 'BSES/' + date.slice(0, 7), bill_type: 'New Ref', bill_date: date, due_date: U.addDays(date, 15), credit_days: 15, amount: e0.debit, dr_cr: 'Cr' }); }
      if (dom === 18) { var el = bills.filter(function (b) { return b.bill_name === 'BSES/' + date.slice(0, 7); })[0]; if (el) payment(date, 'BSES Rajdhani Power Ltd', el.amount, el.bill_name, 'Electricity bill'); }
      if (dom === 7) { expense(date, SAL, 420000, 'Staff salaries'); expense(date, WAGES, 260000, 'Factory wages'); }
      if (dom === 12) expense(date, MKT, 30000 + Math.round(rand() * 40000), 'Digital campaigns');
      if (dom % 9 === 0) expense(date, FRT, 4000 + Math.round(rand() * 8000), 'Delivery charges', CASH);
      if (dom === 25) V(date, 'Contra', 'AC/C/' + date.slice(5, 7), '', [[BANK, 150000, 0], [UPI, 0, 150000]], [], null, 'TALLY', { narration: 'UPI settlement to bank' });
      var eom = +U.addDays(date, 1).slice(8, 10) === 1;
      if (eom && d > 0) journal(date, [[DEP, 12500, 0], [PM, 0, 12500]], 'Monthly depreciation - plant & machinery');
    }

    var inventory = [{ inventory_id: 'INV-0001', product_name: 'All items', godown: 'Main Warehouse', as_of_date: U.addDays(booksBegin, -1), closing_qty: '', uom: '', closing_value: 650000, valuation_method: 'Avg Cost', source: 'TALLY' }];
    var m = booksBegin.slice(0, 8) + '01', k = 0;
    while (true) {
      var eomD = U.addDays(U.addDays(m, 32).slice(0, 8) + '01', -1);
      if (eomD >= today) break;
      if (eomD >= booksBegin) inventory.push({ inventory_id: 'INV-' + ('000' + (inventory.length + 1)).slice(-4), product_name: 'All items', godown: 'Main Warehouse', as_of_date: eomD, closing_value: 650000 + [45000, 92000, 60000, 118000, 81000, 104000][k++ % 6], valuation_method: 'Avg Cost', source: 'TALLY' });
      m = U.addDays(eomD, 1);
    }

    var custRows = customers.map(function (c, i) { return { customer_id: 'CUS-' + ('000' + (i + 1)).slice(-4), customer_name: c.name, gstin: c.gstin, mobile: c.mobile, state: c.state, credit_days: c.days, credit_limit: 800000, salesperson: c.sp, status: 'ACTIVE', source: 'TALLY', email: 'accounts@' + c.name.toLowerCase().replace(/[^a-z]/g, '') + '.example' }; });
    custRows.push({ customer_id: 'CUS-0007', customer_name: 'Walk-in Customers', status: 'ACTIVE', source: 'OFFLINE' });
    var vendRows = vendors.map(function (v, i) { return { vendor_id: 'VEN-' + ('000' + (i + 1)).slice(-4), vendor_name: v.name, gstin: v.gstin, state: v.state, credit_days: v.days, msme_registered: v.msme, vendor_category: v.ledger === PUR_HW ? 'Hardware & Fittings' : 'Raw Material', status: 'ACTIVE', source: 'TALLY' }; });
    vendRows.push({ vendor_id: 'VEN-0004', vendor_name: 'BSES Rajdhani Power Ltd', state: 'Delhi', credit_days: 15, msme_registered: false, vendor_category: 'Utilities', status: 'ACTIVE', source: 'TALLY' });

    var expenses = [
      { expense_id: 'EXP-000101', expense_date: U.addDays(today, -2), category: 'Travel', vendor_ledger: '', description: 'Client visit - Noida (cab + meals)', amount: 3850, gst_rate: 0, gst_amount: 0, total_amount: 3850, payment_mode: 'Cash', paid_from_ledger: CASH, expense_ledger: 'Travel & Conveyance', approval_status: 'Pending', created_by: 'accounts@company.example', created_at: U.addDays(today, -2) },
      { expense_id: 'EXP-000102', expense_date: U.addDays(today, -1), category: 'Repairs', vendor_ledger: '', description: 'CNC router spindle repair', amount: 24000, gst_rate: 18, gst_amount: 4320, total_amount: 28320, payment_mode: 'Bank Transfer', paid_from_ledger: BANK, expense_ledger: 'Repairs & Maintenance', approval_status: 'Pending', created_by: 'accounts@company.example', created_at: U.addDays(today, -1) },
      { expense_id: 'EXP-000103', expense_date: U.addDays(today, -9), category: 'Internet', vendor_ledger: '', description: 'Airtel leased line - monthly', amount: 5900, gst_rate: 18, gst_amount: 1062, total_amount: 6962, payment_mode: 'Bank Transfer', paid_from_ledger: BANK, expense_ledger: 'Internet Charges', approval_status: 'Approved', approved_by: 'finance@company.example', created_by: 'accounts@company.example', created_at: U.addDays(today, -9) }
    ];

    // Bank statement lines for the reconciliation demo: last few bank entries, one unmatched line
    var bankLines = entries.filter(function (e) { return e.ledger_name === BANK; }).slice(-8);
    var vById = {}; vouchers.forEach(function (v) { vById[v.voucher_id] = v; });
    var bankTxns = bankLines.map(function (e, i) {
      var v = vById[e.voucher_id];
      return { bank_txn_id: 'BTX-' + ('000000' + (i + 1)).slice(-7), bank_account_id: 'BNK-0001', txn_date: U.addDays(v.voucher_date, i % 3 === 0 ? 1 : 0), description: (e.debit ? 'NEFT CR-' : 'NEFT DR-') + (v.party_ledger || v.narration || '').toUpperCase().slice(0, 24), reference: v.reference_no || '', debit: e.credit, credit: e.debit, balance: '', import_batch: 'STMT-DEMO', reconciliation_status: 'Pending', matched_voucher_id: '' };
    });
    bankTxns.push({ bank_txn_id: 'BTX-0000099', bank_account_id: 'BNK-0001', txn_date: U.addDays(today, -1), description: 'BANK CHARGES - SMS ALERTS', reference: '', debit: 59, credit: 0, balance: '', import_batch: 'STMT-DEMO', reconciliation_status: 'Pending', matched_voucher_id: '' });

    ['Travel & Conveyance', 'Repairs & Maintenance', 'Internet Charges'].forEach(function (n) { L(n, 'Indirect Expenses', 'Expense'); });

    var syncLog = [
      { sync_id: 'SYN-0142', company: 'Demo Company', mode: 'INCREMENTAL', requested_by: 'scheduler', requested_at: U.addDays(today, 0) + ' 09:55', start_time: today + ' 09:55', end_time: today + ' 09:56', records_fetched: 6, records_added: 5, records_updated: 1, records_skipped: 0, records_failed: 0, status: 'SUCCESS', error: '', connector_host: 'ACCOUNTS-PC-01 v1.0.0' },
      { sync_id: 'SYN-0141', company: 'Demo Company', mode: 'INCREMENTAL', requested_by: 'scheduler', requested_at: U.addDays(today, -1) + ' 18:40', start_time: U.addDays(today, -1) + ' 18:40', end_time: U.addDays(today, -1) + ' 18:41', records_fetched: 14, records_added: 13, records_updated: 0, records_skipped: 0, records_failed: 1, status: 'PARTIAL', error: '1 voucher rejected', connector_host: 'ACCOUNTS-PC-01 v1.0.0' },
      { sync_id: 'SYN-0140', company: 'Demo Company', mode: 'MASTERS', requested_by: 'accounts@company.example', requested_at: U.addDays(today, -1) + ' 11:02', start_time: U.addDays(today, -1) + ' 11:03', end_time: U.addDays(today, -1) + ' 11:03', records_fetched: 58, records_added: 2, records_updated: 3, records_skipped: 53, records_failed: 0, status: 'SUCCESS', error: '', connector_host: 'ACCOUNTS-PC-01 v1.0.0' }
    ];
    var tallyErrors = [{ error_id: 'TER-0000007', sync_id: 'SYN-0141', entity_type: 'VOUCHER', unique_key: 'GUID:7f3a-demo', voucher_number: 'AC/J/0031', severity: 'ERROR', error_code: 'UNBALANCED', message: 'Total debit 25000.00 does not equal total credit 24999.00.', resolved: false, created_at: U.addDays(today, -1) + ' 18:41' }];

    return {
      company: company, today: today, ledgers: ledgers, groups: groups, voucherTypes: [{ voucher_type: 'Sales GST', base_voucher_type: 'Sales' }],
      vouchers: vouchers, entries: entries, bills: bills, salesItems: salesItems, purchaseItems: purchaseItems, inventory: inventory,
      customers: custRows, vendors: vendRows,
      products: products.map(function (p, i) { return { product_id: 'PRD-' + ('000' + (i + 1)).slice(-4), product_name: p.name, hsn_sac: p.hsn, uom: 'Nos', gst_rate: 18, sale_rate: p.rate, purchase_rate: p.cost, stock_group: 'Office Furniture' }; }),
      expenses: expenses, bankAccounts: [{ bank_account_id: 'BNK-0001', ledger_name: BANK, bank_name: 'HDFC Bank', account_no_masked: 'XXXXXXXX4521', account_type: 'Current' }, { bank_account_id: 'BNK-0002', ledger_name: UPI, bank_name: 'HDFC Bank (UPI)', account_no_masked: 'VPA acctdash@hdfcbank', account_type: 'UPI' }],
      bankTransactions: bankTxns, bankRecon: [], syncLog: syncLog, tallyErrors: tallyErrors, notifications: [], audit: [], settings: {}, offlineSales: [],
      config: [{ config_key: 'TALLY_SERVER_URL', config_value: 'http://localhost:9000', category: 'TALLY' }, { config_key: 'TALLY_COMPANY', config_value: 'Demo Company', category: 'TALLY' }, { config_key: 'SYNC_INTERVAL_SECONDS', config_value: '300', category: 'SYNC' }, { config_key: 'SYNC_BATCH_SIZE', config_value: '100', category: 'SYNC' }],
      users: [
        { user_id: 'USR-0001', email: 'admin@company.example', full_name: 'Accounts Administrator', role: 'ADMIN', status: 'ACTIVE' },
        { user_id: 'USR-0101', email: 'accounts@company.example', full_name: 'Priya Sharma', role: 'ACCOUNTANT', status: 'ACTIVE' },
        { user_id: 'USR-0102', email: 'finance@company.example', full_name: 'Vikram Rao', role: 'FINANCE_MANAGER', status: 'ACTIVE' },
        { user_id: 'USR-0103', email: 'md@company.example', full_name: 'Anil Khanna', role: 'MANAGEMENT', status: 'ACTIVE' },
        { user_id: 'USR-0104', email: 'counter@company.example', full_name: 'Showroom Counter', role: 'DATA_ENTRY', status: 'ACTIVE' },
        { user_id: 'USR-0105', email: 'auditor@company.example', full_name: 'Statutory Auditor', role: 'AUDITOR', status: 'ACTIVE' }
      ]
    };
  }

  return { build: build };
})();
