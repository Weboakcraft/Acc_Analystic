# Accounts Dashboard – Tally connector

Runs on the PC (or LAN) where Tally Prime / Tally ERP 9 is running. It pulls
masters and vouchers over Tally's XML HTTP server, validates and normalizes
them, and pushes them to the Accounts Dashboard Apps Script web app. It also picks
up "Sync now" requests made in the web UI. Tally URLs and credentials never
leave this machine.

```
Tally (localhost:9000)  <--XML-->  tally_connector  --HTTPS/JSON-->  Apps Script web app  -->  Google Sheets
```

## Requirements

* Windows 10/11 (any OS with Python works), Python **3.9+** – standard library only.
* Tally with the XML server enabled: **F1 > Settings > Connectivity >
  Client/Server configuration: TallyPrime acts as `Both` (or `Server`), Port `9000`**.
  Restart Tally after changing it. The company must be **open** in Tally.
* The Apps Script web app deployed with **Execute as: Me** and **Who has access: Anyone**,
  and the connector API key generated in the web app's settings.

## Setup

```bat
cd backend\python
copy config.example.ini config.ini
notepad config.ini          :: set [tally] company and [api] apps_script_url
setx ACCOUNTS_CONNECTOR_API_KEY "paste-the-connector-key-here"
:: open a NEW terminal so setx takes effect
python -m tally_connector test-connection
```

The API key is only ever read from the environment variable named by
`[api] api_key_env`. A config file containing `api_key` is rejected.

### Configuration reference

| Section / key | Default | Env override |
|---|---|---|
| `[tally] url` | `http://localhost:9000` | `ACCOUNTS_TALLY_URL` |
| `[tally] company` | – (required) | `ACCOUNTS_TALLY_COMPANY` or `--company` |
| `[tally] timeout`, `retries` | 120, 2 | `ACCOUNTS_TALLY_TIMEOUT` |
| `[tally] export_mode` | `collection` (`daybook` fallback) | |
| `[tally] request_encoding` | `utf-8` (`utf-16`) | |
| `[tally] chunk_days` | 31 | |
| `[api] apps_script_url` | – (required for real syncs) | `ACCOUNTS_APPS_SCRIPT_URL` |
| `[api] api_key_env` | `ACCOUNTS_CONNECTOR_API_KEY` | |
| `[api] timeout`, `retries` | 300, 4 | |
| `[sync] batch_size` | 100 | `ACCOUNTS_SYNC_BATCH_SIZE` |
| `[sync] masters_batch_size` | 1000 | |
| `[sync] interval_seconds` | 300 | `ACCOUNTS_SYNC_INTERVAL_SECONDS` |
| `[sync] poll_seconds` | 30 | |
| `[sync] from_date` | start of current FY | `ACCOUNTS_SYNC_FROM_DATE` |
| `[sync] state_dir`, `log_dir` | `state`, `logs` (relative to the ini) | `ACCOUNTS_STATE_DIR`, `ACCOUNTS_LOG_DIR` |
| `[sync] log_level` | `INFO` | `ACCOUNTS_LOG_LEVEL` |

The config file is found via `--config`, then `ACCOUNTS_CONNECTOR_CONFIG`, then
`./config.ini`, then `backend/python/config.ini`. `SYNC_BATCH_SIZE` and
`SYNC_FROM_DATE` returned by the server (`tallyConfig.config`) override the ini.

## Commands

Run from `backend\python`:

```bat
python -m tally_connector test-connection
python -m tally_connector sync --mode incremental
python -m tally_connector sync --mode full
python -m tally_connector sync --mode date --from 2026-09-01 --to 2026-09-30
python -m tally_connector sync --mode voucher --voucher-type "Sales GST" [--voucher-number AC/S/0001]
python -m tally_connector sync --mode ledger --ledger "ABC Interiors" [--from ... --to ...]
python -m tally_connector sync --mode masters
python -m tally_connector sync --mode full --dry-run
python -m tally_connector watch            :: Ctrl+C to stop
python -m tally_connector watch --once
python -m tally_connector export --out out\tally.json [--from 2026-09-01 --to 2026-09-30] [--no-raw]
python -m tally_connector export --out out\sample.json --tally-xml tests\fixtures\daybook_sample.xml --masters-xml tests\fixtures\masters_sample.xml
```

Global options (before the command): `--config PATH`, `--company NAME`, `--log-level DEBUG`.

Exit codes: `0` success, `1` failed, `2` configuration/usage error, `3` partial
(some vouchers failed validation or were rejected), `130` interrupted.

### Sync modes

| Mode | What is fetched | Reconcile (server marks missing vouchers `DELETED_IN_TALLY`) | Advances last AlterID |
|---|---|---|---|
| `incremental` | vouchers with AlterID > server `last_alter_id` | no | yes |
| `full` | all vouchers from `from_date` to end of FY | yes (last batch) | yes |
| `date` | vouchers in `--from..--to` | yes (last batch) | no |
| `voucher` | by voucher type and/or number | no | no |
| `ledger` | vouchers touching the ledger (filtered locally) | no | no |
| `masters` | groups, ledgers, voucher types, stock items, cost centres | – | no |

Every run: `tallyConfig` → `tallySyncStart` → masters (ingested on full/masters
runs, the first run, or when they changed) → vouchers in batches of
`batch_size` via `syncTallyData` → `tallySyncFinish` (`SUCCESS`, `PARTIAL` or
`FAILED` – also sent when the run crashes or is interrupted).

Vouchers are validated locally (Σdebit = Σcredit ± 0.01, ≥ 2 lines, valid date,
voucher type). Invalid ones are **not sent**; they are listed in the run report
and counted as failed. Cancelled vouchers are sent with status `CANCELLED`
(Tally strips their entries). Inventory-only vouchers with no ledger lines
(delivery notes, orders, stock journals) are skipped.

### Run reports and logs

* `logs\connector.log` – rotating log (5 MB × 10), API key masked.
* `logs\runs\run_<time>_<mode>_<sync_id>.json` – per-run report: counts,
  invalid vouchers with reasons, sign warnings, server errors (last 500 kept).
* `state\state_<company>.json` – local state (masters fingerprint, last AlterID).
* `state\sync_<company>.lock` – prevents two connector processes syncing the same company.

## Automatic sync with Windows Task Scheduler

Option A – one long-running watcher (recommended; also serves "Sync now"):

1. Task Scheduler → **Create Task…**
2. *General*: name `Accounts Dashboard Tally Connector`; **Run whether user is logged on or not**.
   Use the same Windows user that ran `setx` (the key lives in that user's environment).
3. *Triggers*: **At log on** (or **At startup**).
4. *Actions*: **Start a program**
   * Program: `C:\Path\To\Python39\python.exe` (from `where python`)
   * Arguments: `-m tally_connector watch`
   * Start in: `C:\...\accounting-system\backend\python`
5. *Settings*: **If the task fails, restart every 1 minute** (up to 999 times);
   **uncheck** "Stop the task if it runs longer than…"; *If already running*: **Do not start a new instance**.

Option B – periodic one-shot syncs: same task but trigger **Daily, repeat every
5 minutes for 1 day**, arguments `-m tally_connector sync --mode incremental`.
(UI "Sync now" requests are then only served by a `watch` process.)

Command-line equivalent for option A:

```bat
schtasks /Create /TN "Accounts Dashboard Tally Connector" /SC ONLOGON /RL LIMITED ^
  /TR "cmd /c cd /d C:\...\backend\python && python -m tally_connector watch"
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Tally connection unavailable at http://localhost:9000` | Tally not running, XML server disabled, wrong port, or firewall blocking port 9000 (for a remote Tally PC, allow inbound TCP 9000 there and use its IP). |
| `Company 'X' is not open in Tally` | Open the company in Tally (Alt+F3 / F3) or fix `[tally] company` – spelling must match exactly. `test-connection` lists open companies. |
| `Apps Script returned an HTML page instead of JSON` | Deployment access must be **Anyone**, execute as **Me**; use the `/exec` URL; create a new deployment version after code changes. |
| `HTTP_401/403` or `UNAUTHORIZED` | Wrong/rotated API key – re-run `setx ACCOUNTS_CONNECTOR_API_KEY ...` and open a new terminal / restart the scheduled task. |
| Vouchers arrive without ledger lines or items | Set `[tally] export_mode = daybook` (some Tally builds return partial collection data). |
| Garbled names (non-English) | Try `[tally] request_encoding = utf-16`. |
| `UNBALANCED` / `TOO_FEW_LINES` in the run report | Open the voucher in Tally and fix it; the next incremental run picks it up (its AlterID changes). |
| `SIGN_MISMATCH` warnings | Informational: the amount sign was used (negative = debit). |
| `Another sync is already running` | A second connector process (watch + scheduled sync) is active; keep only one. |
| Timeouts on large companies | Raise `[tally] timeout`, lower `chunk_days`, or lower `batch_size`. |

Inspect exactly what would be sent, without touching the server:

```bat
python -m tally_connector sync --mode full --dry-run
python -m tally_connector export --out out\check.json
```

## Tests

```bat
cd backend\python
python -m unittest discover -s tests -v
```

## Layout

```
tally_connector/
  __main__.py        CLI
  config.py          ini + env loading and validation
  tally_client.py    Tally XML requests (inline TDL collections, Day Book), HTTP, retries
  xml_parser.py      decoding (UTF-8/UTF-16), sanitizing, value parsing helpers
  normalizer.py      voucher/master normalization, flat transactions
  validators.py      voucher/master validation
  api_client.py      Apps Script client (retries/backoff, 302 handling, HTML detection)
  sync_engine.py     sync orchestration, watch loop, run reports, locking
  logging_setup.py   rotating file + console logging
tests/               unittest suites + fixtures
```
