"""Logging: rotating file (UTF-8) + console, with secret masking."""

from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from typing import Iterable, Optional

LOGGER_NAME = "tally_connector"
LOG_FORMAT = "%(asctime)s %(levelname)-7s %(name)s: %(message)s"


class SecretMaskFilter(logging.Filter):
    """Replaces secrets (e.g. the API key) in log messages with ``***``."""

    def __init__(self, secrets: Iterable[str] = ()) -> None:
        super().__init__()
        self.secrets = [s for s in secrets if s and len(s) >= 4]

    def filter(self, record: logging.LogRecord) -> bool:
        if self.secrets:
            try:
                message = record.getMessage()
            except Exception:  # noqa: BLE001 - never break logging
                return True
            masked = message
            for secret in self.secrets:
                masked = masked.replace(secret, "***")
            if masked != message:
                record.msg = masked
                record.args = None
        return True


def _make_console_safe() -> None:
    """Avoid UnicodeEncodeError on legacy Windows consoles (e.g. for '₹')."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(errors="replace")
            except (ValueError, OSError):
                pass


def setup_logging(log_dir: Optional[str] = None, level: str = "INFO", console: bool = True,
                  secrets: Iterable[str] = ()) -> logging.Logger:
    """Configure the ``tally_connector`` logger (idempotent)."""
    logger = logging.getLogger(LOGGER_NAME)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    logger.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    logger.propagate = False
    formatter = logging.Formatter(LOG_FORMAT)
    mask = SecretMaskFilter(secrets)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
        file_handler = RotatingFileHandler(os.path.join(log_dir, "connector.log"),
                                           maxBytes=5 * 1024 * 1024, backupCount=10, encoding="utf-8")
        file_handler.setFormatter(formatter)
        file_handler.addFilter(mask)
        logger.addHandler(file_handler)
    if console:
        _make_console_safe()
        stream_handler = logging.StreamHandler(sys.stderr)
        stream_handler.setFormatter(formatter)
        stream_handler.addFilter(mask)
        logger.addHandler(stream_handler)
    return logger


__all__ = ["setup_logging", "SecretMaskFilter", "LOGGER_NAME"]
