# Architecture

Accounts Dashboard is an accounting intelligence layer on top of Tally. Tally stays the accounting source system. The app adds offline sales, bill-wise receivables and payables, GST, statements, MIS and automation. It is one set of double-entry books, built from Tally vouchers plus vouchers posted from the web app.

## 1. System architecture

```
 ┌──────────────┐  XML/HTTP :9000   ┌────────────────────────────┐   HTTPS (JSON, API key)   ┌──────────────────────────────┐
 │ Tally Prime  │ ◄──────────────── │ Tally connector (Python)   │ ────────────────────────► │ Google Apps Script API       │
 │ (LAN PC)     │                   │ fetch → validate →         │ ◄──── sync requests ───── │ router · auth · services     │
 └──────────────┘                   │ normalize → batch → push   │                           │ accounting engine            │
                                    └────────────────────────────┘                           │ repository (Db.gs)           │
                                                                                             └──────────────┬───────────────┘
 ┌──────────────────────────────┐   HTTPS POST {action, token, params}                                      │ batch reads/writes
 │ Web app (GitHub Pages)       │ ─────────────────────────────────────────────────────────────►            ▼
 │ HTML/CSS/JS · Chart.js       │                                                            ┌──────────────────────────────┐
 │ Api.call() - no Sheets code  │                                                            │ Google Sheets (42 tables)    │
 └──────────────────────────────┘                                                            └──────────────────────────────┘
```

Layers (the frontend never touches the database):

| Layer | Where | Responsibility |
|---|---|---|
| Presentation | `frontend/` | Screens, filters, charts, exports. Calls only `Api.call(action, params)`. |
| API | `Code.gs`, `Routes.gs`, `Auth.gs` | Routing, authentication, role permissions, validation, error mapping, response cache. |
| Business logic | `Services.gs`, `Tally.gs`, `Automation.gs` + **`Engine.gs`** | Posting rules, Tally ingestion, jobs. All accounting maths is in the engine. |
| Repository | `Db.gs` | The **only** code that knows about Sheets. |
| Database | Google Sheets | 42 tables defined in `database/schema.json`. |

### Why Tally sync is a connector, not Apps Script
Apps Script runs on Google's servers and cannot reach a Tally XML server on a LAN. So the Python connector runs on (or next to) the Tally PC and pushes data out. The web app's **Sync now** button queues a request in `TALLY_SYNC_LOG`. The connector's `watch` loop polls for queued requests and runs them. Tally credentials and the connector API key never reach the browser.

### Swapping Google Sheets for PostgreSQL/MySQL
- `shared/accounting-engine.js` is pure: plain objects in, plain objects out.
- The API contract is fixed: `{action, token|api_key, params}` in, `{ok, data|error}` out, documented in `API.md`.
- Migrating means re-implementing `Db.gs` (read / insert / update / updateWhere / replaceWhere / nextIds) against SQL. Alternatively, write a new API service that serves the same actions. The frontend only needs a new `API_URL`.

### Where Java belongs
Java is **not** used in phases 1-7, deliberately. It adds value at the point where Sheets stops being enough (roughly 200k voucher lines, or several users writing at once):
- **Enterprise API service** (Spring Boot + PostgreSQL) implementing the same `API.md` contract. It would run the accounting engine unchanged via GraalJS, or port it with the test suite in `tests/engine.spec.js` as the acceptance gate.
- **Multi-company Tally connector service**, as a long-running Windows service polling many Tally instances with connection pooling.

`backend/java/README.md` has the plan. Writing Java earlier would duplicate the Python connector with no benefit.

## 2. Module list

| Module | Screens | Engine functions |
|---|---|---|
| Dashboard | Dashboard | `dashboard` |
| Management MIS (15 questions) | Management MIS | `managementDashboard` |
| Sales (+ reports) | Sales | `register('sales')`, `salesReport` |
| Offline sales | Offline Sales | `buildOfflineSale` |
| Purchases | Purchases | `register('purchase')` |
| Receipts / Payments | Receipts, Payments | `cashRegister`, `buildCashVoucher` |
| Expenses (maker-checker) | Expenses | `buildExpenseVoucher` |
| Customers / Vendors (auto ledgers) | Customers, Vendors | `partyAccounts` |
| Receivables / Payables / Ageing | Receivables, Payables | `outstanding` |
| Ledgers | Ledgers + statement drawer | `trialBalance`, `ledgerStatement` |
| Cash & Bank, Bank reconciliation | Cash & Bank | `cashBook`, `Bank.*` |
| Trial balance | Trial Balance | `trialBalance` |
| P&L, Balance Sheet, Cash Flow | Statements | `profitLoss(+Comparative)`, `balanceSheet`, `cashFlow` |
| GST | GST | `gstTransactions`, `gstSummary` |
| Inventory | Inventory | `stockAt` |
| Analytics, Financial health | Insights | `analytics`, `financialHealth` |
| Alerts & automation | Alert Center | `alerts`, `Automation.gs` |
| Tally integration | Tally Integration | `Tally.gs` + Python connector |
| Audit trail, Settings, Users | System | `Audit`, `Auth` |

## 3. Data model: book of record vs derived

- **Posting tables** (`VOUCHERS`, `VOUCHER_ENTRIES`, `BILL_REFERENCES`) are the book of record. Every voucher has debit = credit, checked before it is written.
- **Register tables** (`SALES`, `PURCHASES`, `RECEIPTS`, `PAYMENTS`, `JOURNALS`, `OFFLINE_SALES`, `EXPENSES`, item tables) hold document detail and link to `voucher_id`.
- **Snapshot tables** (`RECEIVABLES`, `PAYABLES`, `CASH_BOOK`, `GST_SUMMARY`, `PROFIT_LOSS`, `BALANCE_SHEET`, `CASH_FLOW`, `GST_TRANSACTIONS`) are rebuilt nightly for history and for people who read the Sheet directly. The API always computes live, so the numbers on screen are never stale.
- **Revisions:** when Tally alters a voucher (higher `ALTERID`), the header's `revision` goes up and new lines are written with that revision. Old lines stay for history, and the engine only counts lines whose revision matches the header's.
- **Duplicates:** `unique_key` = `GUID:<tally guid>`, or `KEY:company|type|number|date` when there is no GUID. Offline and manual vouchers use `OFFLINE:` / `MANUAL:` keys.

Full column lists: `DATABASE.md` (generated).

## 4. Accounting rules (every ambiguity is a named setting)

| Ambiguity | Rule | Setting (default) |
|---|---|---|
| Financial year | Indian FY, April-March | `FY_START_MONTH` = 4 |
| Ageing from due date or bill date | Configurable | `AGEING_BASIS` = DUE_DATE |
| Bucket boundaries | 0-30, 31-60, 61-90, 91-180, 181-365, 365+ | `AGEING_BUCKETS` |
| Receipts with no bill reference | Applied FIFO to oldest bills, or left on account | `BILL_ALLOCATION_FALLBACK` = FIFO |
| Bills that don't explain the ledger balance | Shown as "On Account" / "Unallocated", so the total **always** ties to the ledger | - |
| Credit period when the bill has none | Ledger credit days, else default | `DEFAULT_CREDIT_DAYS` = 30 |
| Closing stock | Latest `INVENTORY` valuation ≤ date, falling back to Stock-in-Hand ledger balances | `STOCK_VALUATION_SOURCE` = INVENTORY |
| Prior-year profit | Closed to "Profit & Loss A/c (brought forward)" / retained earnings | - |
| Opening balances that don't agree | Shown as "Difference in opening balances" (as Tally does), never hidden | - |
| Tally optional vouchers | Excluded | `INCLUDE_OPTIONAL_VOUCHERS` = false |
| Depreciation / interest / tax lines for EBITDA | Identified by `LEDGERS.mis_category` | - |
| Other income in EBITDA | Excluded (added before PBT) | `EBITDA_INCLUDES_OTHER_INCOME` = false |
| Interest paid in cash flow | Financing (Ind AS 7 allows operating) | `INTEREST_PAID_ACTIVITY` |
| Bank OD as cash | No | `BANK_OD_AS_CASH_EQUIVALENT` |
| Receivable days denominator | GST-inclusive sales (debtors include GST) | `DSO_USE_GROSS_SALES` = true |
| GST direction | From accounting content (income lines → output; purchase/expense/asset lines → input; neither → settlement), **not** from voucher-type names | - |
| Intra- vs inter-state (offline) | Customer state vs `COMPANY_STATE` | `COMPANY_STATE` |
| Offline invoice rounding | Round to rupee via Round Off ledger | `ROUND_INVOICE_TOTAL`, `ROUND_OFF_LEDGER` |
| One sample row per sheet vs double entry | `VOUCHER_ENTRIES` holds the 4 lines of the one sample voucher (one line cannot balance) | - |

The GST figures are indicative. The ITC set-off order (Sec. 49/49A/49B), blocked credits, RCM and GSTR-2B matching are **not** applied. The app is not a substitute for professional tax advice.

## 5. Security

- Authentication: email and password with salted, iterated SHA-256. Accounts lock after 5 failures. Session tokens live in the Apps Script cache for 6 hours.
- Authorization: `ROLE_PERMISSIONS` (Auth.gs) is enforced on **every** route. The frontend hides navigation the role cannot use, but the server is the gate.
- The connector authenticates with `CONNECTOR_API_KEY` in Script Properties. No secret is stored in the Sheet, CONFIG, or frontend (CONFIG refuses keys named `*KEY*|*SECRET*|*PASSWORD*|*TOKEN*`).
- Input validation happens server-side (dates, amounts, GSTIN, mobile, enums, text length). Text that starts with `= + - @` is stored as literal text, so formula injection doesn't work.
- XSS: every value is escaped on output (`UI.esc`). A strict CSP means no inline scripts and no `javascript:` URLs.
- Writes run under `LockService`, so there is no double posting. The audit log is append-only and sheet-protected.
- Maker-checker: the person who enters an expense cannot approve it.

## 6. Performance

- Each sheet is read at most once per request (single `getValues()`); writes use one `setValues()` per table.
- Responses are cached for 2-5 minutes, keyed by `DATA_VERSION`, so any write invalidates them.
- Server-side paging, sorting and filtering: the browser receives 25-50 rows, and exports fetch up to 5,000.
- Incremental Tally sync uses the `ALTERID` watermark, in batches of 100 vouchers.
- Known ceiling: Sheets holds about 10M cells, and Apps Script requests time out at 6 minutes. Beyond about 200k voucher lines, move to the SQL backend (section 1).

## 7. Implementation roadmap

| Phase | Scope | Status |
|---|---|---|
| 1 | Schema, sample rows, initializer, API, auth, config | Built |
| 2 | Tally connector, normalization, sync engine, dedupe, logs | Built (connector untested against live Tally) |
| 3 | Sales, purchases, parties, receivables, payables, ledgers, receipts/payments, offline sales | Built |
| 4 | Accounting engine, journal, trial balance, P&L, BS, cash flow, GST | Built |
| 5 | Analytics, MIS, management dashboard, financial health, ageing | Built |
| 6 | Automation, alerts, e-mail, reminders, scheduled reports | Built |
| 7 | Security, audit, RBAC, performance | Built |
| 8 | Deployment + production configuration | Guide written (DEPLOYMENT.md); needs your Google account and Tally PC |
| Next | Stock journals / godown transfers, e-invoice/e-way bill fields, GSTR-1/3B export layouts, PDF invoice printing, Java/PostgreSQL service | Not started |
