# Database structure (Google Sheets)

Schema version **1.0.0** - generated from `database/schema.json` by `tools/build.py` / `tools/build.ps1`.

- Single source of truth for every table. tools/build.py generates backend/apps-script/Schema.gs, database/csv/*.csv and documentation/DATABASE.md from this file.
- Column spec is 'name:type'. Types: id, ref, str, date, dt, num, cur, pct, bool, enum, json, email.
- Posting tables (VOUCHERS, VOUCHER_ENTRIES, BILL_REFERENCES) are the book of record. Every financial report is derived from them.
- Register tables (SALES, PURCHASES, RECEIPTS, ...) hold document detail and link to a voucher_id.
- Snapshot tables (RECEIVABLES, PAYABLES, CASH_BOOK, GST_SUMMARY, PROFIT_LOSS, BALANCE_SHEET, CASH_FLOW) are rebuilt by rebuildReportSnapshots(); the API always computes live figures.
- Exception to the one-sample-row rule: VOUCHER_ENTRIES holds the 4 lines of the single sample voucher, because one ledger line on its own cannot balance.

## Tables

| # | Table | Group | Columns | Description |
|---|---|---|---|---|
| 1 | [CONFIG](#config) | System | 6 | Environment and connection settings (key/value). Secrets are never stored here; they live in Apps Script Script Properties. |
| 2 | [USERS](#users) | System | 11 | Application users. Passwords are stored as salted, iterated SHA-256 hashes; set them with setUserPassword() in the Apps Script editor. |
| 3 | [COMPANIES](#companies) | Masters | 13 | Companies (one row per Tally company). |
| 4 | [GROUPS](#groups) | Masters | 10 | Custom account groups. Tally's 28 reserved groups are built into the engine; rows here add or override groups. |
| 5 | [LEDGERS](#ledgers) | Masters | 22 | Chart of accounts. Every party, bank, tax, income and expense account. Parties are created automatically when a voucher or offline sale needs them. |
| 6 | [VOUCHER_TYPES](#voucher_types) | Masters | 6 | Maps custom Tally voucher types (e.g. 'Sales GST') to one of the base types the engine understands. |
| 7 | [CUSTOMERS](#customers) | Masters | 18 | Customer profile. Accounting balance always comes from the linked ledger, never from this sheet. |
| 8 | [VENDORS](#vendors) | Masters | 20 | Vendor profile. MSME flag drives the 45-day payment alert (Sec. 43B(h), Income-tax Act). |
| 9 | [PRODUCTS](#products) | Masters | 14 | Stock items. |
| 10 | [VOUCHERS](#vouchers) | Posting | 27 | Voucher headers - the book of record. unique_key prevents duplicate imports; revision increments when Tally alters a voucher. |
| 11 | [VOUCHER_ENTRIES](#voucher_entries) | Posting | 10 | Ledger lines (double entry). Only lines whose revision equals the voucher's current revision are live. Sum(debit) must equal Sum(credit) per voucher. |
| 12 | [BILL_REFERENCES](#bill_references) | Posting | 12 | Bill-wise allocations (Tally 'Bill-wise details'). Drives receivables, payables and ageing. |
| 13 | [SALES](#sales) | Registers | 22 | Sales invoice register (Tally and offline). Paid amount, outstanding and payment status are derived live from BILL_REFERENCES. |
| 14 | [SALES_ITEMS](#sales_items) | Registers | 20 | Line items of sales invoices. |
| 15 | [OFFLINE_SALES](#offline_sales) | Registers | 28 | Manual/offline sales entered in the web app. Each entry posts a Sales voucher (and a Receipt voucher when paid at the counter) so it flows into every report. |
| 16 | [PURCHASES](#purchases) | Registers | 19 | Purchase invoice register. |
| 17 | [PURCHASE_ITEMS](#purchase_items) | Registers | 19 | Line items of purchase invoices. |
| 18 | [RECEIPTS](#receipts) | Registers | 16 | Money received from customers. |
| 19 | [PAYMENTS](#payments) | Registers | 17 | Money paid to vendors and others. |
| 20 | [JOURNALS](#journals) | Registers | 12 | Journal vouchers (adjustments, depreciation, provisions). |
| 21 | [EXPENSES](#expenses) | Registers | 20 | Expense claims and bills. Approved expenses post a Payment (paid) or Journal (on credit) voucher. |
| 22 | [RECEIVABLES](#receivables) | Snapshots | 14 | Daily snapshot of customer bills outstanding (for history and trend). Live figures come from the API. |
| 23 | [PAYABLES](#payables) | Snapshots | 15 | Daily snapshot of vendor bills outstanding. |
| 24 | [CASH_BOOK](#cash_book) | Snapshots | 11 | Cash/bank book snapshot with running balance. |
| 25 | [BANK_ACCOUNTS](#bank_accounts) | Cash & Bank | 9 | Bank, UPI, gateway and petty-cash accounts, each linked to a ledger. |
| 26 | [BANK_TRANSACTIONS](#bank_transactions) | Cash & Bank | 13 | Imported bank statement lines. |
| 27 | [BANK_RECONCILIATION](#bank_reconciliation) | Cash & Bank | 16 | Match results between book entries and bank statement lines. |
| 28 | [GST_TRANSACTIONS](#gst_transactions) | Tax | 20 | GST lines extracted from posted vouchers. direction is derived from the voucher's accounting content, not from the voucher type name. |
| 29 | [GST_SUMMARY](#gst_summary) | Snapshots | 12 | Monthly GST position snapshot. |
| 30 | [INVENTORY](#inventory) | Inventory | 10 | Stock valuation by item and date. The engine uses the latest valuation on or before a date as closing stock (setting STOCK_VALUATION_SOURCE). |
| 31 | [COST_CENTRES](#cost_centres) | Masters | 7 | Cost centres and categories. |
| 32 | [PROFIT_LOSS](#profit_loss) | Snapshots | 8 | Monthly P&L snapshot (long format: one row per line). |
| 33 | [BALANCE_SHEET](#balance_sheet) | Snapshots | 7 | Balance sheet snapshot. |
| 34 | [CASH_FLOW](#cash_flow) | Snapshots | 9 | Cash flow snapshot (direct method). |
| 35 | [TALLY_SYNC_LOG](#tally_sync_log) | Tally | 19 | One row per synchronisation run, including runs requested from the web app and picked up by the connector. |
| 36 | [TALLY_RAW_DATA](#tally_raw_data) | Tally | 10 | Original Tally XML for every voucher/master received, split into 45,000-character chunks (Sheets cell limit is 50,000). |
| 37 | [TALLY_ERRORS](#tally_errors) | Tally | 10 | Validation and ingestion failures. Failed vouchers are never half-posted. |
| 38 | [AUDIT_LOG](#audit_log) | System | 11 | Append-only audit trail of every create, update, delete, sync, import, reconciliation and approval. |
| 39 | [NOTIFICATIONS](#notifications) | System | 13 | Alert centre. dedupe_key stops the same alert being raised twice. |
| 40 | [AUTOMATIONS](#automations) | System | 9 | Scheduled jobs. installTriggers() creates the time-driven triggers that run them. |
| 41 | [REPORTS](#reports) | System | 9 | Log of generated/exported reports. |
| 42 | [SETTINGS](#settings) | System | 6 | Accounting rules (key/value). Every ambiguity the engine must resolve is a named setting here; code defaults apply to keys not listed. |

## CONFIG

Environment and connection settings (key/value). Secrets are never stored here; they live in Apps Script Script Properties.

ID prefix: `key/value table` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `config_key` | Text |  | TALLY_SERVER_URL |
| `config_value` | Text |  | http://localhost:9000 |
| `category` | Dropdown | TALLY, SYNC, EMAIL, APP, SECURITY | TALLY |
| `description` | Text |  | Tally XML server address as seen by the on-premise connector |
| `updated_by` | Text |  | system |
| `updated_at` | Date-time |  | 2026-09-01T09:00:00 |

## USERS

Application users. Passwords are stored as salted, iterated SHA-256 hashes; set them with setUserPassword() in the Apps Script editor.

ID prefix: `USR` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `user_id` | ID (primary key) |  | USR-0001 |
| `email` | Email |  | admin@company.example |
| `full_name` | Text |  | Accounts Administrator |
| `role` | Dropdown | ADMIN, ACCOUNTANT, FINANCE_MANAGER, MANAGEMENT, DATA_ENTRY, AUDITOR | ADMIN |
| `password_hash` | Text |  |  |
| `password_salt` | Text |  |  |
| `status` | Dropdown | ACTIVE, INACTIVE, PENDING_SETUP, LOCKED | PENDING_SETUP |
| `failed_attempts` | Number |  | 0 |
| `last_login` | Date-time |  |  |
| `created_by` | Text |  | system |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## COMPANIES

Companies (one row per Tally company).

ID prefix: `CMP` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `company_id` | ID (primary key) |  | CMP-0001 |
| `company_name` | Text |  | Demo Company |
| `tally_company_name` | Text |  | Demo Company |
| `gstin` | Text |  | 07AAACO1234F1Z5 |
| `pan` | Text |  | AAACO1234F |
| `state` | Text |  | Delhi |
| `state_code` | Text |  | 07 |
| `address` | Text |  | Plot 14, Kirti Nagar Industrial Area, New Delhi 110015 |
| `fy_start_month` | Number |  | 4 |
| `books_begin_date` | Date |  | 2026-04-01 |
| `base_currency` | Text |  | INR |
| `is_active` | Checkbox |  | True |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## GROUPS

Custom account groups. Tally's 28 reserved groups are built into the engine; rows here add or override groups.

ID prefix: `GRP` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `group_id` | ID (primary key) |  | GRP-0001 |
| `group_name` | Text |  | Furniture Sales |
| `parent_group` | Text |  | Sales Accounts |
| `nature` | Dropdown | Assets, Liabilities, Income, Expenses | Income |
| `affects_gross_profit` | Checkbox |  | True |
| `is_tally_reserved` | Checkbox |  | False |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `tally_guid` | Text |  | a1b2c3d4-0000-0000-0000-000000000101 |
| `alter_id` | Number |  | 101 |
| `updated_at` | Date-time |  | 2026-09-01T09:00:00 |

## LEDGERS

Chart of accounts. Every party, bank, tax, income and expense account. Parties are created automatically when a voucher or offline sale needs them.

ID prefix: `LED` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `ledger_id` | ID (primary key) |  | LED-0001 |
| `company_id` | Reference (foreign key) |  | CMP-0001 |
| `ledger_name` | Text |  | ABC Interiors |
| `parent_group` | Text |  | Sundry Debtors |
| `ledger_type` | Dropdown | Customer, Vendor, Bank, Cash, Tax, Sales, Purchase, Expense, Income, Asset, Liability, Capital, Stock, Other | Customer |
| `opening_balance` | Amount (INR) |  | 0 |
| `opening_dr_cr` | Dropdown | Dr, Cr | Dr |
| `gstin` | Text |  | 07AABCA1234B1Z2 |
| `state` | Text |  | Delhi |
| `tax_type` | Dropdown | CGST, SGST, IGST, CESS, TDS, TCS |  |
| `gst_rate` | Percent |  |  |
| `mis_category` | Dropdown | DEPRECIATION, INTEREST, INCOME_TAX, SALARY, RENT, UTILITIES, MARKETING, TRAVEL, PROFESSIONAL_FEES, REPAIRS, FREIGHT, OTHER |  |
| `credit_days` | Number |  | 30 |
| `bank_account_no` | Text |  |  |
| `ifsc` | Text |  |  |
| `is_active` | Checkbox |  | True |
| `needs_review` | Checkbox |  | False |
| `source` | Dropdown | TALLY, OFFLINE, MANUAL, AUTO, SAMPLE | TALLY |
| `tally_guid` | Text |  | a1b2c3d4-0000-0000-0000-000000000201 |
| `alter_id` | Number |  | 201 |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |
| `updated_at` | Date-time |  | 2026-09-01T09:00:00 |

## VOUCHER_TYPES

Maps custom Tally voucher types (e.g. 'Sales GST') to one of the base types the engine understands.

ID prefix: `VTY` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `voucher_type_id` | ID (primary key) |  | VTY-0001 |
| `voucher_type` | Text |  | Sales GST |
| `base_voucher_type` | Dropdown | Sales, Purchase, Receipt, Payment, Journal, Contra, Credit Note, Debit Note, Stock Journal, Delivery Note, Receipt Note, Sales Order, Purchase Order, Memorandum, Other | Sales |
| `numbering_prefix` | Text |  | AC/S/ |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `updated_at` | Date-time |  | 2026-09-01T09:00:00 |

## CUSTOMERS

Customer profile. Accounting balance always comes from the linked ledger, never from this sheet.

ID prefix: `CUS` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `customer_id` | ID (primary key) |  | CUS-0001 |
| `ledger_id` | Reference (foreign key) |  | LED-0001 |
| `customer_name` | Text |  | ABC Interiors |
| `gstin` | Text |  | 07AABCA1234B1Z2 |
| `pan` | Text |  | AABCA1234B |
| `mobile` | Text |  | 9810012345 |
| `email` | Email |  | accounts@abcinteriors.example |
| `billing_address` | Text |  | 22 Rajouri Garden Main Market |
| `city` | Text |  | New Delhi |
| `state` | Text |  | Delhi |
| `state_code` | Text |  | 07 |
| `credit_limit` | Amount (INR) |  | 500000 |
| `credit_days` | Number |  | 30 |
| `salesperson` | Text |  | Rahul Mehta |
| `customer_since` | Date |  | 2025-06-15 |
| `status` | Dropdown | ACTIVE, INACTIVE, BLOCKED | ACTIVE |
| `source` | Dropdown | TALLY, OFFLINE, MANUAL, SAMPLE | TALLY |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## VENDORS

Vendor profile. MSME flag drives the 45-day payment alert (Sec. 43B(h), Income-tax Act).

ID prefix: `VEN` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `vendor_id` | ID (primary key) |  | VEN-0001 |
| `ledger_id` | Reference (foreign key) |  | LED-0002 |
| `vendor_name` | Text |  | XYZ Hardware Suppliers |
| `gstin` | Text |  | 07AAAFX5678C1Z9 |
| `pan` | Text |  | AAAFX5678C |
| `mobile` | Text |  | 9899054321 |
| `email` | Email |  | billing@xyzhardware.example |
| `address` | Text |  | Shop 7, Chawri Bazar |
| `city` | Text |  | New Delhi |
| `state` | Text |  | Delhi |
| `state_code` | Text |  | 07 |
| `credit_days` | Number |  | 45 |
| `msme_registered` | Checkbox |  | True |
| `msme_number` | Text |  | UDYAM-DL-01-0012345 |
| `vendor_category` | Text |  | Hardware & Fittings |
| `bank_account_no` | Text |  | XXXXXX4521 |
| `ifsc` | Text |  | HDFC0001234 |
| `status` | Dropdown | ACTIVE, INACTIVE, BLOCKED | ACTIVE |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## PRODUCTS

Stock items.

ID prefix: `PRD` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `product_id` | ID (primary key) |  | PRD-0001 |
| `product_name` | Text |  | Executive Office Desk |
| `stock_group` | Text |  | Office Furniture |
| `hsn_sac` | Text |  | 9403 |
| `uom` | Text |  | Nos |
| `gst_rate` | Percent |  | 18 |
| `sale_rate` | Amount (INR) |  | 50000 |
| `purchase_rate` | Amount (INR) |  | 34000 |
| `opening_qty` | Number |  | 12 |
| `opening_value` | Amount (INR) |  | 408000 |
| `is_active` | Checkbox |  | True |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `tally_guid` | Text |  | a1b2c3d4-0000-0000-0000-000000000301 |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## VOUCHERS

Voucher headers - the book of record. unique_key prevents duplicate imports; revision increments when Tally alters a voucher.

ID prefix: `VCH` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `voucher_id` | ID (primary key) |  | VCH-000001 |
| `company_id` | Reference (foreign key) |  | CMP-0001 |
| `unique_key` | Text |  | GUID:a1b2c3d4-0000-0000-0000-000000001001 |
| `voucher_date` | Date |  | 2026-09-01 |
| `voucher_type` | Text |  | Sales GST |
| `base_voucher_type` | Dropdown | Sales, Purchase, Receipt, Payment, Journal, Contra, Credit Note, Debit Note, Other | Sales |
| `voucher_number` | Text |  | AC/S/0001 |
| `reference_no` | Text |  | PO-ABC-889 |
| `reference_date` | Date |  | 2026-08-28 |
| `party_ledger` | Text |  | ABC Interiors |
| `party_gstin` | Text |  | 07AABCA1234B1Z2 |
| `place_of_supply` | Text |  | Delhi |
| `amount` | Amount (INR) |  | 118000 |
| `narration` | Text |  | 2 x Executive Office Desk as per PO-ABC-889 |
| `salesperson` | Text |  | Rahul Mehta |
| `cost_centre` | Text |  | Delhi Showroom |
| `source` | Dropdown | TALLY, OFFLINE, MANUAL, IMPORT, SAMPLE | TALLY |
| `status` | Dropdown | ACTIVE, CANCELLED, OPTIONAL, DELETED_IN_TALLY | ACTIVE |
| `revision` | Number |  | 1 |
| `tally_guid` | Text |  | a1b2c3d4-0000-0000-0000-000000001001 |
| `tally_master_id` | Number |  | 1001 |
| `tally_alter_id` | Number |  | 5001 |
| `sync_id` | Reference (foreign key) |  | SYN-0001 |
| `created_by` | Text |  | tally-connector |
| `created_at` | Date-time |  | 2026-09-01T18:30:00 |
| `updated_by` | Text |  | tally-connector |
| `updated_at` | Date-time |  | 2026-09-01T18:30:00 |

## VOUCHER_ENTRIES

Ledger lines (double entry). Only lines whose revision equals the voucher's current revision are live. Sum(debit) must equal Sum(credit) per voucher.

ID prefix: `ENT` | Sample rows: 4

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `entry_id` | ID (primary key) |  | ENT-0000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000001 |
| `revision` | Number |  | 1 |
| `line_no` | Number |  | 1 |
| `ledger_name` | Text |  | ABC Interiors |
| `debit` | Amount (INR) |  | 118000 |
| `credit` | Amount (INR) |  | 0 |
| `cost_centre` | Text |  |  |
| `is_party_line` | Checkbox |  | True |
| `created_at` | Date-time |  | 2026-09-01T18:30:00 |

## BILL_REFERENCES

Bill-wise allocations (Tally 'Bill-wise details'). Drives receivables, payables and ageing.

ID prefix: `BIL` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `bill_ref_id` | ID (primary key) |  | BIL-0000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000001 |
| `revision` | Number |  | 1 |
| `party_ledger` | Text |  | ABC Interiors |
| `bill_name` | Text |  | AC/S/0001 |
| `bill_type` | Dropdown | New Ref, Agst Ref, Advance, On Account | New Ref |
| `bill_date` | Date |  | 2026-09-01 |
| `due_date` | Date |  | 2026-10-01 |
| `credit_days` | Number |  | 30 |
| `amount` | Amount (INR) |  | 118000 |
| `dr_cr` | Dropdown | Dr, Cr | Dr |
| `created_at` | Date-time |  | 2026-09-01T18:30:00 |

## SALES

Sales invoice register (Tally and offline). Paid amount, outstanding and payment status are derived live from BILL_REFERENCES.

ID prefix: `SAL` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `sale_id` | ID (primary key) |  | SAL-000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000001 |
| `invoice_no` | Text |  | AC/S/0001 |
| `invoice_date` | Date |  | 2026-09-01 |
| `customer_ledger` | Text |  | ABC Interiors |
| `customer_gstin` | Text |  | 07AABCA1234B1Z2 |
| `customer_state` | Text |  | Delhi |
| `place_of_supply` | Text |  | Delhi |
| `salesperson` | Text |  | Rahul Mehta |
| `channel` | Dropdown | Showroom, Dealer, Corporate, Online, Export, Other | Corporate |
| `taxable_amount` | Amount (INR) |  | 100000 |
| `discount_amount` | Amount (INR) |  | 0 |
| `cgst` | Amount (INR) |  | 9000 |
| `sgst` | Amount (INR) |  | 9000 |
| `igst` | Amount (INR) |  | 0 |
| `cess` | Amount (INR) |  | 0 |
| `round_off` | Amount (INR) |  | 0 |
| `invoice_amount` | Amount (INR) |  | 118000 |
| `due_date` | Date |  | 2026-10-01 |
| `source` | Dropdown | TALLY, OFFLINE, SAMPLE | TALLY |
| `status` | Dropdown | ACTIVE, CANCELLED | ACTIVE |
| `created_at` | Date-time |  | 2026-09-01T18:30:00 |

## SALES_ITEMS

Line items of sales invoices.

ID prefix: `SIT` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `item_id` | ID (primary key) |  | SIT-0000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000001 |
| `revision` | Number |  | 1 |
| `line_no` | Number |  | 1 |
| `product_name` | Text |  | Executive Office Desk |
| `hsn_sac` | Text |  | 9403 |
| `qty` | Number |  | 2 |
| `uom` | Text |  | Nos |
| `rate` | Amount (INR) |  | 50000 |
| `discount_pct` | Percent |  | 0 |
| `discount_amount` | Amount (INR) |  | 0 |
| `taxable_amount` | Amount (INR) |  | 100000 |
| `gst_rate` | Percent |  | 18 |
| `cgst` | Amount (INR) |  | 9000 |
| `sgst` | Amount (INR) |  | 9000 |
| `igst` | Amount (INR) |  | 0 |
| `cess` | Amount (INR) |  | 0 |
| `line_total` | Amount (INR) |  | 118000 |
| `godown` | Text |  | Main Warehouse |
| `sales_ledger` | Text |  | Sales - Furniture (GST 18%) |

## OFFLINE_SALES

Manual/offline sales entered in the web app. Each entry posts a Sales voucher (and a Receipt voucher when paid at the counter) so it flows into every report.

ID prefix: `OFS` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `offline_sale_id` | ID (primary key) |  | OFS-000001 |
| `invoice_no` | Text |  | AC/OFF/0001 |
| `invoice_date` | Date |  | 2026-09-02 |
| `customer_name` | Text |  | Modern Office Solutions |
| `customer_gstin` | Text |  | 09AAECM4321K1Z3 |
| `mobile` | Text |  | 9711122233 |
| `address` | Text |  | Sector 62, Noida |
| `state` | Text |  | Uttar Pradesh |
| `product` | Text |  | Ergonomic Mesh Chair |
| `qty` | Number |  | 5 |
| `rate` | Amount (INR) |  | 12000 |
| `discount_pct` | Percent |  | 5 |
| `tax_rate` | Percent |  | 18 |
| `taxable_amount` | Amount (INR) |  | 57000 |
| `cgst` | Amount (INR) |  | 0 |
| `sgst` | Amount (INR) |  | 0 |
| `igst` | Amount (INR) |  | 10260 |
| `total_amount` | Amount (INR) |  | 67260 |
| `payment_mode` | Dropdown | Cash, UPI, Bank Transfer, Cheque, Credit, Other | UPI |
| `paid_amount` | Amount (INR) |  | 30000 |
| `outstanding_at_entry` | Amount (INR) |  | 37260 |
| `salesperson` | Text |  | Neha Kapoor |
| `remarks` | Text |  | Showroom walk-in; balance on delivery |
| `voucher_id` | Reference (foreign key) |  | VCH-000002 |
| `receipt_voucher_id` | Reference (foreign key) |  | VCH-000003 |
| `status` | Dropdown | POSTED, CANCELLED | POSTED |
| `created_by` | Text |  | admin@company.example |
| `created_at` | Date-time |  | 2026-09-02T12:10:00 |

## PURCHASES

Purchase invoice register.

ID prefix: `PUR` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `purchase_id` | ID (primary key) |  | PUR-000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000004 |
| `purchase_invoice_no` | Text |  | XYZ/2627/0457 |
| `invoice_date` | Date |  | 2026-09-03 |
| `vendor_ledger` | Text |  | XYZ Hardware Suppliers |
| `vendor_gstin` | Text |  | 07AAAFX5678C1Z9 |
| `due_date` | Date |  | 2026-10-18 |
| `purchase_type` | Dropdown | Goods, Services, Capital Goods, Expense | Goods |
| `taxable_amount` | Amount (INR) |  | 40000 |
| `cgst` | Amount (INR) |  | 3600 |
| `sgst` | Amount (INR) |  | 3600 |
| `igst` | Amount (INR) |  | 0 |
| `cess` | Amount (INR) |  | 0 |
| `total_amount` | Amount (INR) |  | 47200 |
| `bill_reference` | Text |  | XYZ/2627/0457 |
| `tally_voucher_number` | Text |  | AC/P/0012 |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `status` | Dropdown | ACTIVE, CANCELLED | ACTIVE |
| `created_at` | Date-time |  | 2026-09-03T18:30:00 |

## PURCHASE_ITEMS

Line items of purchase invoices.

ID prefix: `PIT` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `item_id` | ID (primary key) |  | PIT-0000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000004 |
| `revision` | Number |  | 1 |
| `line_no` | Number |  | 1 |
| `product_name` | Text |  | Soft-close Drawer Channel 18in |
| `hsn_sac` | Text |  | 8302 |
| `qty` | Number |  | 200 |
| `uom` | Text |  | Pairs |
| `rate` | Amount (INR) |  | 200 |
| `discount_amount` | Amount (INR) |  | 0 |
| `taxable_amount` | Amount (INR) |  | 40000 |
| `gst_rate` | Percent |  | 18 |
| `cgst` | Amount (INR) |  | 3600 |
| `sgst` | Amount (INR) |  | 3600 |
| `igst` | Amount (INR) |  | 0 |
| `cess` | Amount (INR) |  | 0 |
| `line_total` | Amount (INR) |  | 47200 |
| `godown` | Text |  | Main Warehouse |
| `purchase_ledger` | Text |  | Purchase - Hardware (GST 18%) |

## RECEIPTS

Money received from customers.

ID prefix: `RCT` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `receipt_id` | ID (primary key) |  | RCT-000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000005 |
| `receipt_no` | Text |  | AC/R/0031 |
| `receipt_date` | Date |  | 2026-09-15 |
| `party_ledger` | Text |  | ABC Interiors |
| `amount` | Amount (INR) |  | 50000 |
| `mode` | Dropdown | Cash, UPI, Bank Transfer, Cheque, Other | Bank Transfer |
| `bank_ledger` | Text |  | HDFC Bank CA 4521 |
| `instrument_no` | Text |  | NEFT/HDFCN26258123456 |
| `instrument_date` | Date |  | 2026-09-15 |
| `against_bill` | Text |  | AC/S/0001 |
| `tds_deducted` | Amount (INR) |  | 0 |
| `source` | Dropdown | TALLY, OFFLINE, MANUAL, SAMPLE | TALLY |
| `status` | Dropdown | ACTIVE, CANCELLED, BOUNCED | ACTIVE |
| `created_by` | Text |  | tally-connector |
| `created_at` | Date-time |  | 2026-09-15T18:30:00 |

## PAYMENTS

Money paid to vendors and others.

ID prefix: `PAY` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `payment_id` | ID (primary key) |  | PAY-000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000006 |
| `payment_no` | Text |  | AC/PY/0022 |
| `payment_date` | Date |  | 2026-09-20 |
| `party_ledger` | Text |  | XYZ Hardware Suppliers |
| `amount` | Amount (INR) |  | 47200 |
| `mode` | Dropdown | Cash, UPI, Bank Transfer, Cheque, Other | Bank Transfer |
| `bank_ledger` | Text |  | HDFC Bank CA 4521 |
| `instrument_no` | Text |  | NEFT/HDFCN26263998877 |
| `instrument_date` | Date |  | 2026-09-20 |
| `against_bill` | Text |  | XYZ/2627/0457 |
| `tds_amount` | Amount (INR) |  | 0 |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `status` | Dropdown | ACTIVE, CANCELLED | ACTIVE |
| `approved_by` | Text |  | finance.manager@company.example |
| `created_by` | Text |  | tally-connector |
| `created_at` | Date-time |  | 2026-09-20T18:30:00 |

## JOURNALS

Journal vouchers (adjustments, depreciation, provisions).

ID prefix: `JNL` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `journal_id` | ID (primary key) |  | JNL-000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000007 |
| `journal_no` | Text |  | AC/J/0009 |
| `journal_date` | Date |  | 2026-09-30 |
| `journal_type` | Dropdown | Adjustment, Depreciation, Provision, Rectification, GST Set-off, Other | Depreciation |
| `total_debit` | Amount (INR) |  | 12500 |
| `total_credit` | Amount (INR) |  | 12500 |
| `narration` | Text |  | Monthly depreciation on plant & machinery (SLM) |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `status` | Dropdown | ACTIVE, CANCELLED, PENDING_APPROVAL | ACTIVE |
| `approved_by` | Text |  | finance.manager@company.example |
| `created_at` | Date-time |  | 2026-09-30T18:30:00 |

## EXPENSES

Expense claims and bills. Approved expenses post a Payment (paid) or Journal (on credit) voucher.

ID prefix: `EXP` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `expense_id` | ID (primary key) |  | EXP-000001 |
| `expense_date` | Date |  | 2026-09-05 |
| `category` | Dropdown | Salary, Rent, Electricity, Internet, Transportation, Office Expenses, Repairs, Maintenance, Marketing, Travel, Professional Fees, Miscellaneous | Electricity |
| `vendor_ledger` | Text |  | BSES Rajdhani Power Ltd |
| `description` | Text |  | Factory electricity - August 2026 |
| `amount` | Amount (INR) |  | 18400 |
| `gst_rate` | Percent |  | 0 |
| `gst_amount` | Amount (INR) |  | 0 |
| `total_amount` | Amount (INR) |  | 18400 |
| `payment_mode` | Dropdown | Cash, UPI, Bank Transfer, Cheque, Credit, Other | Bank Transfer |
| `paid_from_ledger` | Text |  | HDFC Bank CA 4521 |
| `expense_ledger` | Text |  | Electricity Charges |
| `cost_centre` | Text |  | Factory |
| `receipt_url` | Text |  |  |
| `approval_status` | Dropdown | Pending, Approved, Rejected | Pending |
| `approved_by` | Text |  |  |
| `approved_at` | Date-time |  |  |
| `voucher_id` | Reference (foreign key) |  |  |
| `created_by` | Text |  | admin@company.example |
| `created_at` | Date-time |  | 2026-09-05T11:00:00 |

## RECEIVABLES

Daily snapshot of customer bills outstanding (for history and trend). Live figures come from the API.

ID prefix: `RSN` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `snapshot_id` | ID (primary key) |  | RSN-0000001 |
| `as_of_date` | Date |  | 2026-09-26 |
| `party_ledger` | Text |  | ABC Interiors |
| `bill_name` | Text |  | AC/S/0001 |
| `bill_date` | Date |  | 2026-09-01 |
| `due_date` | Date |  | 2026-10-01 |
| `bill_amount` | Amount (INR) |  | 118000 |
| `settled_amount` | Amount (INR) |  | 0 |
| `outstanding` | Amount (INR) |  | 118000 |
| `days_outstanding` | Number |  | 25 |
| `days_overdue` | Number |  | 0 |
| `ageing_bucket` | Text |  | 0-30 |
| `status` | Dropdown | Current, Overdue, Advance | Current |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## PAYABLES

Daily snapshot of vendor bills outstanding.

ID prefix: `PSN` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `snapshot_id` | ID (primary key) |  | PSN-0000001 |
| `as_of_date` | Date |  | 2026-09-26 |
| `party_ledger` | Text |  | Delhi Foam & Fabric |
| `bill_name` | Text |  | DFF/1123 |
| `bill_date` | Date |  | 2026-08-10 |
| `due_date` | Date |  | 2026-09-09 |
| `bill_amount` | Amount (INR) |  | 64900 |
| `settled_amount` | Amount (INR) |  | 20000 |
| `outstanding` | Amount (INR) |  | 44900 |
| `days_outstanding` | Number |  | 47 |
| `days_overdue` | Number |  | 17 |
| `ageing_bucket` | Text |  | 31-60 |
| `msme` | Checkbox |  | False |
| `status` | Dropdown | Current, Overdue, Advance | Overdue |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## CASH_BOOK

Cash/bank book snapshot with running balance.

ID prefix: `CBK` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `snapshot_id` | ID (primary key) |  | CBK-0000001 |
| `entry_date` | Date |  | 2026-09-15 |
| `voucher_id` | Reference (foreign key) |  | VCH-000005 |
| `voucher_number` | Text |  | AC/R/0031 |
| `voucher_type` | Text |  | Receipt |
| `cash_bank_ledger` | Text |  | HDFC Bank CA 4521 |
| `particulars` | Text |  | ABC Interiors |
| `receipt` | Amount (INR) |  | 50000 |
| `payment` | Amount (INR) |  | 0 |
| `running_balance` | Amount (INR) |  | 1250000 |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## BANK_ACCOUNTS

Bank, UPI, gateway and petty-cash accounts, each linked to a ledger.

ID prefix: `BNK` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `bank_account_id` | ID (primary key) |  | BNK-0001 |
| `ledger_name` | Text |  | HDFC Bank CA 4521 |
| `bank_name` | Text |  | HDFC Bank |
| `account_no_masked` | Text |  | XXXXXXXX4521 |
| `ifsc` | Text |  | HDFC0000123 |
| `branch` | Text |  | Kirti Nagar, New Delhi |
| `account_type` | Dropdown | Current, Savings, OD, CC, Payment Gateway, UPI, Petty Cash, Cash | Current |
| `is_active` | Checkbox |  | True |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## BANK_TRANSACTIONS

Imported bank statement lines.

ID prefix: `BTX` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `bank_txn_id` | ID (primary key) |  | BTX-0000001 |
| `bank_account_id` | Reference (foreign key) |  | BNK-0001 |
| `txn_date` | Date |  | 2026-09-15 |
| `value_date` | Date |  | 2026-09-15 |
| `description` | Text |  | NEFT CR-ABC INTERIORS-HDFCN26258123456 |
| `reference` | Text |  | HDFCN26258123456 |
| `debit` | Amount (INR) |  | 0 |
| `credit` | Amount (INR) |  | 50000 |
| `balance` | Amount (INR) |  | 1250000 |
| `import_batch` | Text |  | STMT-2026-09-A |
| `reconciliation_status` | Dropdown | Matched, Unmatched, Partially Matched, Pending | Matched |
| `matched_voucher_id` | Reference (foreign key) |  | VCH-000005 |
| `created_at` | Date-time |  | 2026-09-16T10:00:00 |

## BANK_RECONCILIATION

Match results between book entries and bank statement lines.

ID prefix: `BRC` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `recon_id` | ID (primary key) |  | BRC-0000001 |
| `bank_account_id` | Reference (foreign key) |  | BNK-0001 |
| `bank_txn_id` | Reference (foreign key) |  | BTX-0000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000005 |
| `txn_date` | Date |  | 2026-09-15 |
| `description` | Text |  | NEFT CR-ABC INTERIORS |
| `reference` | Text |  | HDFCN26258123456 |
| `amount` | Amount (INR) |  | 50000 |
| `dr_cr` | Dropdown | Dr, Cr | Dr |
| `tally_status` | Dropdown | In Books, Not in Books | In Books |
| `bank_statement_status` | Dropdown | In Statement, Not in Statement | In Statement |
| `reconciliation_status` | Dropdown | Matched, Unmatched, Partially Matched, Pending | Matched |
| `match_rule` | Text |  | AMOUNT+REFERENCE |
| `reconciled_by` | Text |  | auto |
| `reconciled_at` | Date-time |  | 2026-09-16T10:00:00 |
| `remarks` | Text |  |  |

## GST_TRANSACTIONS

GST lines extracted from posted vouchers. direction is derived from the voucher's accounting content, not from the voucher type name.

ID prefix: `GST` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `gst_txn_id` | ID (primary key) |  | GST-0000001 |
| `voucher_id` | Reference (foreign key) |  | VCH-000001 |
| `revision` | Number |  | 1 |
| `voucher_date` | Date |  | 2026-09-01 |
| `voucher_number` | Text |  | AC/S/0001 |
| `base_voucher_type` | Text |  | Sales |
| `direction` | Dropdown | OUTPUT, INPUT, SETTLEMENT | OUTPUT |
| `party_ledger` | Text |  | ABC Interiors |
| `party_gstin` | Text |  | 07AABCA1234B1Z2 |
| `place_of_supply` | Text |  | Delhi |
| `supply_type` | Dropdown | Intra-State, Inter-State | Intra-State |
| `hsn_sac` | Text |  | 9403 |
| `taxable_value` | Amount (INR) |  | 100000 |
| `gst_rate` | Percent |  | 18 |
| `cgst` | Amount (INR) |  | 9000 |
| `sgst` | Amount (INR) |  | 9000 |
| `igst` | Amount (INR) |  | 0 |
| `cess` | Amount (INR) |  | 0 |
| `total_tax` | Amount (INR) |  | 18000 |
| `created_at` | Date-time |  | 2026-09-01T18:30:00 |

## GST_SUMMARY

Monthly GST position snapshot.

ID prefix: `GSS` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `summary_id` | ID (primary key) |  | GSS-0001 |
| `period` | Text |  | 2026-09 |
| `output_cgst` | Amount (INR) |  | 9000 |
| `output_sgst` | Amount (INR) |  | 9000 |
| `output_igst` | Amount (INR) |  | 0 |
| `output_cess` | Amount (INR) |  | 0 |
| `input_cgst` | Amount (INR) |  | 3600 |
| `input_sgst` | Amount (INR) |  | 3600 |
| `input_igst` | Amount (INR) |  | 0 |
| `input_cess` | Amount (INR) |  | 0 |
| `net_liability` | Amount (INR) |  | 10800 |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## INVENTORY

Stock valuation by item and date. The engine uses the latest valuation on or before a date as closing stock (setting STOCK_VALUATION_SOURCE).

ID prefix: `INV` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `inventory_id` | ID (primary key) |  | INV-0000001 |
| `product_name` | Text |  | Executive Office Desk |
| `godown` | Text |  | Main Warehouse |
| `as_of_date` | Date |  | 2026-08-31 |
| `closing_qty` | Number |  | 12 |
| `uom` | Text |  | Nos |
| `closing_value` | Amount (INR) |  | 408000 |
| `valuation_method` | Dropdown | Avg Cost, FIFO, Last Purchase, Standard, Manual | Avg Cost |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## COST_CENTRES

Cost centres and categories.

ID prefix: `CCN` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `cost_centre_id` | ID (primary key) |  | CCN-0001 |
| `cost_centre_name` | Text |  | Delhi Showroom |
| `category` | Text |  | Primary Cost Category |
| `parent` | Text |  |  |
| `is_active` | Checkbox |  | True |
| `source` | Dropdown | TALLY, MANUAL, SAMPLE | TALLY |
| `created_at` | Date-time |  | 2026-09-01T09:00:00 |

## PROFIT_LOSS

Monthly P&L snapshot (long format: one row per line).

ID prefix: `PLS` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `snapshot_id` | ID (primary key) |  | PLS-0000001 |
| `period_from` | Date |  | 2026-09-01 |
| `period_to` | Date |  | 2026-09-30 |
| `line_code` | Text |  | REVENUE |
| `line_label` | Text |  | Revenue from operations |
| `section` | Text |  | Income |
| `amount` | Amount (INR) |  | 100000 |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## BALANCE_SHEET

Balance sheet snapshot.

ID prefix: `BSS` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `snapshot_id` | ID (primary key) |  | BSS-0000001 |
| `as_of_date` | Date |  | 2026-09-26 |
| `side` | Dropdown | Assets, Liabilities, Equity | Assets |
| `section` | Text |  | Current Assets |
| `line_label` | Text |  | Sundry Debtors |
| `amount` | Amount (INR) |  | 118000 |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## CASH_FLOW

Cash flow snapshot (direct method).

ID prefix: `CFS` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `snapshot_id` | ID (primary key) |  | CFS-0000001 |
| `period_from` | Date |  | 2026-09-01 |
| `period_to` | Date |  | 2026-09-30 |
| `activity` | Dropdown | Operating, Investing, Financing | Operating |
| `line_label` | Text |  | Receipts from customers |
| `inflow` | Amount (INR) |  | 50000 |
| `outflow` | Amount (INR) |  | 0 |
| `net` | Amount (INR) |  | 50000 |
| `generated_at` | Date-time |  | 2026-09-26T23:00:00 |

## TALLY_SYNC_LOG

One row per synchronisation run, including runs requested from the web app and picked up by the connector.

ID prefix: `SYN` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `sync_id` | ID (primary key) |  | SYN-0001 |
| `company` | Text |  | Demo Company |
| `mode` | Dropdown | FULL, INCREMENTAL, DATE_RANGE, VOUCHER, LEDGER, MASTERS | INCREMENTAL |
| `requested_by` | Text |  | scheduler |
| `requested_at` | Date-time |  | 2026-09-01T18:29:00 |
| `start_time` | Date-time |  | 2026-09-01T18:29:05 |
| `end_time` | Date-time |  | 2026-09-01T18:30:12 |
| `from_date` | Date |  | 2026-04-01 |
| `to_date` | Date |  | 2026-09-01 |
| `from_alter_id` | Number |  | 5000 |
| `to_alter_id` | Number |  | 5001 |
| `records_fetched` | Number |  | 1 |
| `records_added` | Number |  | 1 |
| `records_updated` | Number |  | 0 |
| `records_skipped` | Number |  | 0 |
| `records_failed` | Number |  | 0 |
| `status` | Dropdown | REQUESTED, RUNNING, SUCCESS, PARTIAL, FAILED | SUCCESS |
| `error` | Text |  |  |
| `connector_host` | Text |  | ACCOUNTS-PC-01 |

## TALLY_RAW_DATA

Original Tally XML for every voucher/master received, split into 45,000-character chunks (Sheets cell limit is 50,000).

ID prefix: `RAW` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `raw_id` | ID (primary key) |  | RAW-0000001 |
| `sync_id` | Reference (foreign key) |  | SYN-0001 |
| `entity_type` | Dropdown | VOUCHER, LEDGER, GROUP, VOUCHERTYPE, STOCKITEM, COSTCENTRE, COMPANY | VOUCHER |
| `unique_key` | Text |  | GUID:a1b2c3d4-0000-0000-0000-000000001001 |
| `tally_guid` | Text |  | a1b2c3d4-0000-0000-0000-000000001001 |
| `alter_id` | Number |  | 5001 |
| `chunk_no` | Number |  | 1 |
| `chunk_count` | Number |  | 1 |
| `payload` | Text |  | <VOUCHER VCHTYPE="Sales GST"><DATE>20260901</DATE><VOUCHE... |
| `received_at` | Date-time |  | 2026-09-01T18:30:00 |

## TALLY_ERRORS

Validation and ingestion failures. Failed vouchers are never half-posted.

ID prefix: `TER` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `error_id` | ID (primary key) |  | TER-0000001 |
| `sync_id` | Reference (foreign key) |  | SYN-0001 |
| `entity_type` | Text |  | VOUCHER |
| `unique_key` | Text |  | GUID:a1b2c3d4-0000-0000-0000-000000009999 |
| `voucher_number` | Text |  | AC/J/0003 |
| `severity` | Dropdown | ERROR, WARNING | ERROR |
| `error_code` | Text |  | UNBALANCED |
| `message` | Text |  | Debit 25000.00 does not equal credit 24999.00 |
| `resolved` | Checkbox |  | False |
| `created_at` | Date-time |  | 2026-09-01T18:30:00 |

## AUDIT_LOG

Append-only audit trail of every create, update, delete, sync, import, reconciliation and approval.

ID prefix: `AUD` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `audit_id` | ID (primary key) |  | AUD-0000001 |
| `timestamp` | Date-time |  | 2026-09-01T18:30:12 |
| `user` | Text |  | tally-connector |
| `role` | Text |  | CONNECTOR |
| `action` | Dropdown | CREATE, UPDATE, DELETE, SYNC, IMPORT, RECONCILE, APPROVE, REJECT, LOGIN, LOGIN_FAILED, CONFIG | SYNC |
| `entity` | Text |  | VOUCHERS |
| `record_id` | Text |  | VCH-000001 |
| `old_value` | JSON text |  |  |
| `new_value` | JSON text |  | {"voucher_number":"AC/S/0001","amount":118000} |
| `source` | Text |  | TALLY |
| `client_info` | Text |  | connector 1.0.0 @ ACCOUNTS-PC-01 |

## NOTIFICATIONS

Alert centre. dedupe_key stops the same alert being raised twice.

ID prefix: `NTF` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `notification_id` | ID (primary key) |  | NTF-0000001 |
| `created_at` | Date-time |  | 2026-09-26T08:00:00 |
| `severity` | Dropdown | CRITICAL, WARNING, INFO | CRITICAL |
| `category` | Dropdown | OVERDUE_RECEIVABLE, OVERDUE_PAYABLE, UPCOMING_PAYMENT, UPCOMING_COLLECTION, CASH_SHORTAGE, HIGH_EXPENSE, SYNC_FAILED, UNRECONCILED_BANK, DUPLICATE_VOUCHER, MSME_DUE, UNBALANCED_VOUCHER | OVERDUE_PAYABLE |
| `title` | Text |  | Overdue payable: Delhi Foam & Fabric |
| `message` | Text |  | Bill DFF/1123 of Rs 44,900 is 17 days overdue |
| `entity` | Text |  | BILL |
| `record_id` | Text |  | DFF/1123 |
| `target_role` | Text |  | FINANCE_MANAGER |
| `status` | Dropdown | OPEN, READ, RESOLVED | OPEN |
| `resolved_by` | Text |  |  |
| `resolved_at` | Date-time |  |  |
| `dedupe_key` | Text |  | OVERDUE_PAYABLE\|Delhi Foam & Fabric\|DFF/1123 |

## AUTOMATIONS

Scheduled jobs. installTriggers() creates the time-driven triggers that run them.

ID prefix: `AUT` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `automation_id` | ID (primary key) |  | AUT-0001 |
| `name` | Text |  | Daily MIS email |
| `job` | Dropdown | DAILY_SUMMARY, WEEKLY_REPORT, MONTHLY_PL, MONTHLY_BS, GST_SUMMARY, ALERT_SCAN, COLLECTION_REMINDERS, VENDOR_PAYMENT_REMINDERS, REPORT_SNAPSHOTS | DAILY_SUMMARY |
| `schedule` | Text |  | DAILY 20:00 |
| `recipients` | Text |  | management@company.example |
| `is_enabled` | Checkbox |  | True |
| `last_run` | Date-time |  |  |
| `last_status` | Text |  |  |
| `config_json` | JSON text |  | {} |

## REPORTS

Log of generated/exported reports.

ID prefix: `RPT` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `report_id` | ID (primary key) |  | RPT-0000001 |
| `report_name` | Text |  | Daily MIS Summary |
| `report_type` | Text |  | DAILY_SUMMARY |
| `parameters_json` | JSON text |  | {"date":"2026-09-25"} |
| `format` | Dropdown | PDF, XLSX, CSV, EMAIL, SCREEN | EMAIL |
| `generated_by` | Text |  | scheduler |
| `generated_at` | Date-time |  | 2026-09-25T20:00:00 |
| `file_url` | Text |  |  |
| `status` | Dropdown | SUCCESS, FAILED | SUCCESS |

## SETTINGS

Accounting rules (key/value). Every ambiguity the engine must resolve is a named setting here; code defaults apply to keys not listed.

ID prefix: `key/value table` | Sample rows: 1

| Column | Type | Allowed values | Sample |
|---|---|---|---|
| `setting_key` | Text |  | AGEING_BASIS |
| `setting_value` | Text |  | DUE_DATE |
| `data_type` | Dropdown | string, number, boolean, json | string |
| `description` | Text |  | DUE_DATE ages bills from their due date; BILL_DATE ages f... |
| `updated_by` | Text |  | system |
| `updated_at` | Date-time |  | 2026-09-01T09:00:00 |
