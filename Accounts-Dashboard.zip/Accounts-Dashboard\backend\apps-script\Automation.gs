/**
 * Automation engine: time-driven jobs, alert scanning, e-mail reports, report snapshots.
 *
 * installTriggers() creates the triggers (idempotent). Each job checks the AUTOMATIONS sheet:
 * a row with job=<JOB> and is_enabled=FALSE disables it; recipients come from that row or from
 * CONFIG key REPORT_RECIPIENTS. Jobs record last_run / last_status back to AUTOMATIONS.
 *
 * Note: automatic Tally sync is driven by the on-premise connector (Apps Script cannot reach a LAN
 * Tally server). checkSyncHealth() raises an alert when the connector has not synced recently.
 */

var JOBS = {
  runAlertScan: { job: 'ALERT_SCAN', every: 'hour' },
  checkSyncHealth: { job: 'ALERT_SCAN', every: 'hour' },
  runDailySummary: { job: 'DAILY_SUMMARY', daily: 20 },
  rebuildReportSnapshots: { job: 'REPORT_SNAPSHOTS', daily: 23 },
  runCollectionReminders: { job: 'COLLECTION_REMINDERS', daily: 9 },
  runVendorPaymentReminders: { job: 'VENDOR_PAYMENT_REMINDERS', daily: 9 },
  runWeeklyReport: { job: 'WEEKLY_REPORT', weekly: ScriptApp.WeekDay.MONDAY, hour: 9 },
  runMonthlyReports: { job: 'MONTHLY_PL', monthDay: 1, hour: 8 }
};

function installTriggers() {
  var existing = ScriptApp.getProjectTriggers().map(function (t) { return t.getHandlerFunction(); });
  var created = [];
  Object.keys(JOBS).forEach(function (fn) {
    if (existing.indexOf(fn) >= 0) return;
    var j = JOBS[fn], b = ScriptApp.newTrigger(fn).timeBased();
    if (j.every === 'hour') b.everyHours(1);
    else if (j.daily !== undefined) b.everyDays(1).atHour(j.daily);
    else if (j.weekly) b.onWeekDay(j.weekly).atHour(j.hour);
    else if (j.monthDay) b.onMonthDay(j.monthDay).atHour(j.hour);
    b.inTimezone('Asia/Kolkata').create();
    created.push(fn);
  });
  Db.withLock(function () { Audit.log({ action: 'CONFIG', entity: 'AUTOMATIONS', record_id: 'installTriggers', new_value: { created: created }, user: Session.getEffectiveUser().getEmail() || 'editor' }); });
  return created;
}

function runJob_(fnName, body) {
  var job = JOBS[fnName].job;
  var row = Db.read('AUTOMATIONS').filter(function (a) { return a.job === job; })[0];
  if (row && row.is_enabled === false) return 'disabled';
  var status = 'SUCCESS';
  try { body(row); } catch (e) { status = 'FAILED: ' + String(e.message || e).slice(0, 200); console.error(fnName, e); }
  if (row) Db.withLock(function () { Db.update('AUTOMATIONS', 'automation_id', row.automation_id, { last_run: new Date(), last_status: status }); });
  return status;
}

function recipients_(row) {
  var r = (row && row.recipients) || Config.get('REPORT_RECIPIENTS', '');
  return String(r).split(/[,;\s]+/).filter(function (x) { return /@/.test(x); }).join(',');
}

// ---------------------------------------------------------------------------
// Jobs
// ---------------------------------------------------------------------------
function runAlertScan() {
  return runJob_('runAlertScan', function () {
    var alerts = Engine.alerts(Ctx.load({}), {});
    Db.withLock(function () {
      var open = {};
      Db.read('NOTIFICATIONS').forEach(function (n) { open[n.dedupe_key] = n; });
      var fresh = alerts.filter(function (a) { return !open[a.dedupe_key]; }).map(function (a) {
        return { created_at: new Date(), severity: a.severity, category: a.category, title: a.title, message: a.message, entity: 'BILL', record_id: a.record_id, target_role: /PAYABLE|PAYMENT|MSME|CASH/.test(a.category) ? 'FINANCE_MANAGER' : 'ACCOUNTANT', status: 'OPEN', dedupe_key: a.dedupe_key };
      });
      // auto-resolve alerts whose condition has cleared
      var live = {}; alerts.forEach(function (a) { live[a.dedupe_key] = true; });
      Db.updateWhere('NOTIFICATIONS', function (n) { return n.status === 'OPEN' && !live[n.dedupe_key] && ['SYNC_FAILED', 'UNRECONCILED_BANK'].indexOf(n.category) < 0; }, function (n) { n.status = 'RESOLVED'; n.resolved_by = 'auto'; n.resolved_at = new Date(); });
      Db.insert('NOTIFICATIONS', fresh);
    });
  });
}

function checkSyncHealth() {
  return runJob_('checkSyncHealth', function () {
    var maxHours = Number(Config.get('SYNC_STALE_HOURS', 6));
    var ok = Db.read('TALLY_SYNC_LOG').filter(function (l) { return l.status === 'SUCCESS' || l.status === 'PARTIAL'; }).sort(function (a, b) { return b.end_time - a.end_time; })[0];
    var hours = ok && ok.end_time ? (Date.now() - new Date(ok.end_time).getTime()) / 3600000 : Infinity;
    var stuck = Db.read('TALLY_SYNC_LOG').filter(function (l) { return l.status === 'RUNNING' && l.start_time && (Date.now() - new Date(l.start_time).getTime()) > 3600000; });
    Db.withLock(function () {
      if (hours > maxHours) Notify.raise('CRITICAL', 'SYNC_FAILED', 'Tally sync is stale', ok ? 'Last successful sync ' + Math.round(hours) + ' hours ago. Check the connector PC and that Tally is open.' : 'No successful Tally sync yet.', '', 'SYNC_STALE|' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd'), 'ACCOUNTANT');
      stuck.forEach(function (l) { Db.update('TALLY_SYNC_LOG', 'sync_id', l.sync_id, { status: 'FAILED', end_time: new Date(), error: 'Marked failed: no completion after 60 minutes (connector stopped?)' }); });
    });
  });
}

function runDailySummary() {
  return runJob_('runDailySummary', function (row) {
    var to = recipients_(row); if (!to) return;
    var ctx = Ctx.load({});
    var d = Engine.dashboard(ctx, {});
    var t = d.today, inr = Engine.util.inr;
    var alerts = Engine.alerts(ctx, {}).filter(function (a) { return a.severity === 'CRITICAL'; }).slice(0, 10);
    var html = Mail.wrap('Daily MIS - ' + d.date, [
      Mail.kpis([['Sales bills', t.salesBills], ['Sales', inr(t.salesAmount)], ['Purchases', inr(t.purchaseAmount)], ['Receipts', inr(t.receipts)], ['Payments', inr(t.payments)], ['Net cash flow', inr(t.netCashFlow)]]),
      Mail.kpis([['Cash', inr(d.cashBalance)], ['Bank', inr(d.bankBalance)], ['Receivables', inr(d.receivables)], ['Overdue receivables', inr(d.overdueReceivables)], ['Payables', inr(d.payables)], ['Overdue payables', inr(d.overduePayables)]]),
      Mail.table('Critical alerts', ['Alert', 'Detail'], alerts.map(function (a) { return [a.title, a.message]; })),
      Mail.table('Top overdue invoices', ['Customer', 'Bill', 'Due', 'Outstanding', 'Days overdue'], d.topOverdue.map(function (b) { return [b.party, b.bill_name, b.due_date, inr(b.outstanding), b.days_overdue]; }))
    ]);
    MailApp.sendEmail({ to: to, subject: 'Accounts Dashboard | Daily MIS ' + d.date, htmlBody: html });
    Mail.logReport('Daily MIS Summary', 'DAILY_SUMMARY', { date: d.date });
  });
}

function runWeeklyReport() {
  return runJob_('runWeeklyReport', function (row) {
    var to = recipients_(row); if (!to) return;
    var ctx = Ctx.load({}), inr = Engine.util.inr;
    var end = Engine.util.addDays(ctx.today, -1), start = Engine.util.addDays(end, -6);
    var pl = Engine.profitLoss(ctx, { from: start, to: end }), cf = Engine.cashFlow(ctx, { from: start, to: end });
    var sales = Engine.salesReport(ctx, { groupBy: 'customer', from: start, to: end });
    var html = Mail.wrap('Weekly financial report ' + start + ' to ' + end, [
      Mail.kpis([['Revenue', inr(pl.revenue)], ['Gross profit', inr(pl.grossProfit)], ['Net profit', inr(pl.netProfit)], ['Cash in', inr(cf.inflow)], ['Cash out', inr(cf.outflow)], ['Net cash', inr(cf.net)]]),
      Mail.table('Sales by customer', ['Customer', 'Invoices', 'Amount', 'Share %'], sales.rows.slice(0, 15).map(function (r) { return [r.key, r.count, inr(r.amount), r.share]; }))
    ]);
    MailApp.sendEmail({ to: to, subject: 'Accounts Dashboard | Weekly report ' + start + ' to ' + end, htmlBody: html });
    Mail.logReport('Weekly Financial Report', 'WEEKLY_REPORT', { from: start, to: end });
  });
}

function runMonthlyReports() {
  return runJob_('runMonthlyReports', function (row) {
    var to = recipients_(row); if (!to) return;
    var ctx = Ctx.load({}), inr = Engine.util.inr;
    var r = Engine.util.periodRange('previous_month', ctx.today, ctx.fyM);
    var pl = Engine.profitLoss(ctx, r), bs = Engine.balanceSheet(ctx, { asOf: r.to }), gst = Engine.gstSummary(ctx, r);
    var html = Mail.wrap('Monthly pack ' + r.from.slice(0, 7), [
      Mail.table('Profit & Loss', ['Line', 'Amount'], pl.lines.map(function (l) { return [l.label, inr(l.amount)]; })),
      Mail.table('Balance Sheet - Liabilities & Equity', ['Section', 'Amount'], bs.liabilities.map(function (s) { return [s.section, inr(s.amount)]; }).concat([['Total', inr(bs.totalLiabilities)]])),
      Mail.table('Balance Sheet - Assets', ['Section', 'Amount'], bs.assets.map(function (s) { return [s.section, inr(s.amount)]; }).concat([['Total', inr(bs.totalAssets)]])),
      Mail.table('GST summary (indicative)', ['Head', 'Output', 'Input', 'Net'], ['cgst', 'sgst', 'igst', 'cess'].map(function (k) { return [k.toUpperCase(), inr(gst.output[k]), inr(gst.input[k]), inr(gst.net[k])]; })),
      '<p style="color:#64748b;font-size:12px">' + gst.disclaimer + '</p>',
      bs.balanced ? '' : '<p style="color:#b91c1c"><b>Balance sheet difference: ' + inr(bs.difference) + '</b> - review opening balances.</p>'
    ]);
    MailApp.sendEmail({ to: to, subject: 'Accounts Dashboard | Monthly P&L, Balance Sheet & GST ' + r.from.slice(0, 7), htmlBody: html });
    Mail.logReport('Monthly P&L / BS / GST', 'MONTHLY_PL', r);
  });
}

/** Internal digest of collections due/overdue. Customer-facing e-mails are off unless SEND_CUSTOMER_REMINDERS=TRUE in CONFIG. */
function runCollectionReminders() {
  return runJob_('runCollectionReminders', function (row) {
    var ctx = Ctx.load({}), inr = Engine.util.inr;
    var os = Engine.outstanding(ctx, { kind: 'receivable' });
    var win = Engine.util.addDays(ctx.today, ctx.S.UPCOMING_WINDOW_DAYS);
    var due = os.bills.filter(function (b) { return b.outstanding > 0 && b.due_date <= win; });
    var to = recipients_(row);
    if (to && due.length) {
      MailApp.sendEmail({ to: to, subject: 'Collections due / overdue - ' + due.length + ' bills', htmlBody: Mail.wrap('Collections', [Mail.table('Bills', ['Customer', 'Bill', 'Due', 'Outstanding', 'Status'], due.map(function (b) { return [b.party, b.bill_name, b.due_date, inr(b.outstanding), b.status]; }))]) });
    }
    if (String(Config.get('SEND_CUSTOMER_REMINDERS', 'FALSE')).toUpperCase() === 'TRUE') {
      var emails = {}; Db.read('CUSTOMERS').forEach(function (c) { if (c.email) emails[String(c.customer_name).toLowerCase()] = c.email; });
      var byParty = {};
      due.filter(function (b) { return b.status === 'Overdue'; }).forEach(function (b) { (byParty[b.party] = byParty[b.party] || []).push(b); });
      Object.keys(byParty).forEach(function (party) {
        var em = emails[party.toLowerCase()]; if (!em) return;
        MailApp.sendEmail({ to: em, subject: 'Payment reminder - ' + (ctx.company.company_name || ''), htmlBody: Mail.wrap('Payment reminder', ['<p>Dear ' + Mail.esc(party) + ',</p><p>The following invoices are overdue. Kindly arrange payment or share remittance details.</p>', Mail.table('', ['Invoice', 'Date', 'Due', 'Outstanding'], byParty[party].map(function (b) { return [b.bill_name, b.bill_date, b.due_date, inr(b.outstanding)]; }))]) });
      });
    }
  });
}

function runVendorPaymentReminders() {
  return runJob_('runVendorPaymentReminders', function (row) {
    var to = recipients_(row); if (!to) return;
    var ctx = Ctx.load({}), inr = Engine.util.inr;
    var os = Engine.outstanding(ctx, { kind: 'payable' });
    var win = Engine.util.addDays(ctx.today, ctx.S.UPCOMING_WINDOW_DAYS);
    var due = os.bills.filter(function (b) { return b.outstanding > 0 && b.due_date <= win; });
    if (!due.length) return;
    MailApp.sendEmail({ to: to, subject: 'Vendor payments due - ' + due.length + ' bills (' + inr(due.reduce(function (s, b) { return s + b.outstanding; }, 0)) + ')', htmlBody: Mail.wrap('Vendor payments due', [Mail.table('Bills', ['Vendor', 'Bill', 'Due', 'Outstanding', 'Status'], due.map(function (b) { return [b.party, b.bill_name, b.due_date, inr(b.outstanding), b.status]; }))]) });
  });
}

/** Writes snapshot tables (history for trends; the API itself always computes live). */
function rebuildReportSnapshots() {
  return runJob_('rebuildReportSnapshots', function () {
    var ctx = Ctx.load({});
    var today = ctx.today, fs = Engine.util.fyStart(today, ctx.fyM), D = Engine.util.D;
    var rec = Engine.outstanding(ctx, { kind: 'receivable' }), pay = Engine.outstanding(ctx, { kind: 'payable' });
    var msme = {}; Db.read('VENDORS').forEach(function (v) { if (v.msme_registered === true) msme[String(v.vendor_name).toLowerCase()] = true; });
    var cb = Engine.cashBook(ctx, { from: fs, to: today });
    var gstTx = Engine.gstTransactions(ctx, { from: fs, to: today });
    var gst = Engine.gstSummary(ctx, { from: fs, to: today });
    var pl = Engine.profitLoss(ctx, { from: today.slice(0, 8) + '01', to: today });
    var plY = Engine.profitLoss(ctx, { from: fs, to: today });
    var bs = Engine.balanceSheet(ctx, { asOf: today });
    var cf = Engine.cashFlow(ctx, { from: today.slice(0, 8) + '01', to: today });
    Db.withLock(function () {
      var sameDay = function (r) { return D(r.as_of_date) === today; };
      Db.replaceWhere('RECEIVABLES', sameDay, rec.bills.map(function (b) { return { as_of_date: today, party_ledger: b.party, bill_name: b.bill_name, bill_date: b.bill_date, due_date: b.due_date, bill_amount: b.bill_amount, settled_amount: b.settled_amount, outstanding: b.outstanding, days_outstanding: b.days_outstanding, days_overdue: b.days_overdue, ageing_bucket: b.ageing_bucket, status: b.status }; }));
      Db.replaceWhere('PAYABLES', sameDay, pay.bills.map(function (b) { return { as_of_date: today, party_ledger: b.party, bill_name: b.bill_name, bill_date: b.bill_date, due_date: b.due_date, bill_amount: b.bill_amount, settled_amount: b.settled_amount, outstanding: b.outstanding, days_outstanding: b.days_outstanding, days_overdue: b.days_overdue, ageing_bucket: b.ageing_bucket, msme: !!msme[b.party.toLowerCase()], status: b.status }; }));
      Db.replaceWhere('CASH_BOOK', function (r) { return D(r.entry_date) >= fs; }, cb.rows.map(function (r) { return { entry_date: r.date, voucher_id: r.voucher_id, voucher_number: r.voucher_number, voucher_type: r.voucher_type, cash_bank_ledger: r.account, particulars: r.particulars, receipt: r.receipt, payment: r.payment, running_balance: r.balance }; }));
      Db.replaceWhere('GST_TRANSACTIONS', function (r) { return D(r.voucher_date) >= fs; }, gstTx.map(function (t) { var v = ctx.vById[t.voucher_id]; t.revision = v ? v.revision : 1; return t; }));
      Db.replaceWhere('GST_SUMMARY', function (r) { return gst.monthly.some(function (m) { return m.period === String(r.period); }); }, gst.monthly.map(function (m) {
        var mt = gstTx.filter(function (t) { return t.voucher_date.slice(0, 7) === m.period; });
        var s = function (dir, k) { return Engine.util.r2(mt.filter(function (t) { return t.direction === dir; }).reduce(function (a, t) { return a + t[k]; }, 0)); };
        return { period: m.period, output_cgst: s('OUTPUT', 'cgst'), output_sgst: s('OUTPUT', 'sgst'), output_igst: s('OUTPUT', 'igst'), output_cess: s('OUTPUT', 'cess'), input_cgst: s('INPUT', 'cgst'), input_sgst: s('INPUT', 'sgst'), input_igst: s('INPUT', 'igst'), input_cess: s('INPUT', 'cess'), net_liability: m.net };
      }));
      var plRows = function (r) { return r.lines.map(function (l) { return { period_from: r.from, period_to: r.to, line_code: l.code, line_label: l.label, section: l.total ? 'Total' : 'Line', amount: l.amount }; }); };
      Db.replaceWhere('PROFIT_LOSS', function (r) { return D(r.period_to) === today || (D(r.period_from) === pl.from && D(r.period_to) >= pl.from); }, plRows(pl).concat(plRows(plY)));
      Db.replaceWhere('BALANCE_SHEET', function (r) { return D(r.as_of_date) === today; }, [].concat(
        bs.assets.reduce(function (a, s) { return a.concat(s.groups.map(function (g) { return { as_of_date: today, side: 'Assets', section: s.section, line_label: g.name, amount: g.amount }; })); }, []),
        bs.liabilities.reduce(function (a, s) { return a.concat(s.groups.map(function (g) { return { as_of_date: today, side: s.section === 'Capital Account' ? 'Equity' : 'Liabilities', section: s.section, line_label: g.name, amount: g.amount }; })); }, [])));
      Db.replaceWhere('CASH_FLOW', function (r) { return D(r.period_from) === cf.from; }, cf.sections.reduce(function (a, s) { return a.concat(s.lines.map(function (l) { return { period_from: cf.from, period_to: cf.to, activity: s.activity, line_label: l.label, inflow: l.inflow, outflow: l.outflow, net: l.net }; })); }, []));
    });
  });
}

// ---------------------------------------------------------------------------
// E-mail helpers (inline styles - mail clients ignore <style>)
// ---------------------------------------------------------------------------
var Mail = {
  esc: function (s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); },
  wrap: function (title, parts) {
    return '<div style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;max-width:760px">' +
      '<div style="border-bottom:2px solid #1f2a44;padding:8px 0;margin-bottom:12px"><b style="font-size:18px">' + Mail.esc(title) + '</b></div>' +
      parts.join('') + '<p style="color:#94a3b8;font-size:11px;margin-top:24px">Generated by Accounts Dashboard. Figures are derived from posted vouchers.</p></div>';
  },
  kpis: function (pairs) {
    return '<table style="border-collapse:collapse;width:100%;margin:8px 0"><tr>' + pairs.map(function (p) {
      return '<td style="border:1px solid #e2e8f0;padding:8px"><div style="font-size:11px;color:#64748b">' + Mail.esc(p[0]) + '</div><div style="font-size:15px;font-weight:600">' + Mail.esc(p[1]) + '</div></td>';
    }).join('') + '</tr></table>';
  },
  table: function (title, head, rows) {
    if (!rows.length) return title ? '<p style="color:#64748b">' + Mail.esc(title) + ': none.</p>' : '';
    return (title ? '<h3 style="font-size:14px;margin:16px 0 6px">' + Mail.esc(title) + '</h3>' : '') +
      '<table style="border-collapse:collapse;width:100%;font-size:12px"><tr>' + head.map(function (h) { return '<th style="text-align:left;background:#f1f5f9;padding:6px;border:1px solid #e2e8f0">' + Mail.esc(h) + '</th>'; }).join('') + '</tr>' +
      rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="padding:6px;border:1px solid #e2e8f0">' + Mail.esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>';
  },
  logReport: function (name, type, params) {
    Db.withLock(function () { Db.insert('REPORTS', [{ report_name: name, report_type: type, parameters_json: JSON.stringify(params), format: 'EMAIL', generated_by: 'scheduler', generated_at: new Date(), status: 'SUCCESS' }]); });
  }
};
