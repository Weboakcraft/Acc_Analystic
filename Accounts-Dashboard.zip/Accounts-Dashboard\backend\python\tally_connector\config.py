"""Configuration loading: INI file + environment overrides + validation.

The connector API key is NEVER read from the INI file: ``[api] api_key_env``
names the environment variable that holds it (default
``ACCOUNTS_CONNECTOR_API_KEY``).
"""

from __future__ import annotations

import configparser
import os
from dataclasses import dataclass, field
from typing import Dict, List, Mapping, Optional, Tuple
from urllib.parse import urlparse

from .xml_parser import parse_tally_date

DEFAULT_API_KEY_ENV = "ACCOUNTS_CONNECTOR_API_KEY"
CONFIG_ENV = "ACCOUNTS_CONNECTOR_CONFIG"

# (section, option) -> environment variable that overrides it
ENV_OVERRIDES: Dict[Tuple[str, str], str] = {
    ("tally", "url"): "ACCOUNTS_TALLY_URL",
    ("tally", "company"): "ACCOUNTS_TALLY_COMPANY",
    ("tally", "timeout"): "ACCOUNTS_TALLY_TIMEOUT",
    ("api", "apps_script_url"): "ACCOUNTS_APPS_SCRIPT_URL",
    ("sync", "batch_size"): "ACCOUNTS_SYNC_BATCH_SIZE",
    ("sync", "interval_seconds"): "ACCOUNTS_SYNC_INTERVAL_SECONDS",
    ("sync", "from_date"): "ACCOUNTS_SYNC_FROM_DATE",
    ("sync", "state_dir"): "ACCOUNTS_STATE_DIR",
    ("sync", "log_dir"): "ACCOUNTS_LOG_DIR",
    ("sync", "log_level"): "ACCOUNTS_LOG_LEVEL",
}


class ConfigError(Exception):
    """Configuration is missing or invalid; the message lists every problem."""


@dataclass
class TallySettings:
    url: str = "http://localhost:9000"
    company: str = ""
    timeout: float = 120.0
    retries: int = 2
    export_mode: str = "collection"      # collection | daybook
    request_encoding: str = "utf-8"      # utf-8 | utf-16
    chunk_days: int = 31


@dataclass
class ApiSettings:
    apps_script_url: str = ""
    api_key_env: str = DEFAULT_API_KEY_ENV
    api_key: str = field(default="", repr=False)
    timeout: float = 300.0
    retries: int = 4

    @property
    def configured(self) -> bool:
        return bool(self.apps_script_url and self.api_key)


@dataclass
class SyncSettings:
    batch_size: int = 100
    masters_batch_size: int = 1000
    interval_seconds: int = 300
    poll_seconds: int = 30
    from_date: str = ""
    state_dir: str = "state"
    log_dir: str = "logs"
    log_level: str = "INFO"


@dataclass
class AppConfig:
    tally: TallySettings = field(default_factory=TallySettings)
    api: ApiSettings = field(default_factory=ApiSettings)
    sync: SyncSettings = field(default_factory=SyncSettings)
    source_path: str = ""


def find_config_file(path: Optional[str] = None, env: Optional[Mapping[str, str]] = None) -> Optional[str]:
    """Explicit path > $ACCOUNTS_CONNECTOR_CONFIG > ./config.ini > <package parent>/config.ini."""
    env = os.environ if env is None else env
    if path:
        return path
    if env.get(CONFIG_ENV):
        return env[CONFIG_ENV]
    candidates = [os.path.join(os.getcwd(), "config.ini"),
                  os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.ini")]
    for candidate in candidates:
        if os.path.isfile(candidate):
            return candidate
    return None


def load_config(path: Optional[str] = None, env: Optional[Mapping[str, str]] = None,
                require_api: bool = True) -> AppConfig:
    """Load, override and validate configuration.

    ``require_api=False`` is used by commands that never talk to the server
    (``test-connection`` without a key, ``export``, ``sync --dry-run``).
    """
    env = os.environ if env is None else env
    errors: List[str] = []
    source = find_config_file(path, env)
    parser = configparser.ConfigParser(interpolation=None)
    base_dir = os.getcwd()
    if source:
        if not os.path.isfile(source):
            raise ConfigError("Config file not found: %s (copy config.example.ini to config.ini)" % source)
        try:
            with open(source, "r", encoding="utf-8-sig") as fh:
                parser.read_file(fh)
        except (configparser.Error, OSError, UnicodeDecodeError) as exc:
            raise ConfigError("Could not read %s: %s" % (source, exc)) from exc
        base_dir = os.path.dirname(os.path.abspath(source))
    for section in ("tally", "api", "sync"):
        if not parser.has_section(section):
            parser.add_section(section)
    if parser.has_option("api", "api_key"):
        errors.append("[api] api_key must not be stored in the ini file. Put the key in the environment "
                      "variable named by [api] api_key_env (default %s) and remove api_key." % DEFAULT_API_KEY_ENV)
    for (section, option), var in ENV_OVERRIDES.items():
        value = env.get(var)
        if value not in (None, ""):
            parser.set(section, option, value)

    def get(section: str, option: str, default: str = "") -> str:
        return parser.get(section, option, fallback=default).strip()

    def get_number(section: str, option: str, default, cast, low=None, high=None):
        raw = get(section, option, str(default))
        try:
            value = cast(raw)
        except ValueError:
            errors.append("[%s] %s must be a number (got %r)" % (section, option, raw))
            return default
        if (low is not None and value < low) or (high is not None and value > high):
            errors.append("[%s] %s must be between %s and %s (got %s)" % (section, option, low, high, value))
            return default
        return value

    tally = TallySettings(
        url=get("tally", "url", TallySettings.url),
        company=get("tally", "company"),
        timeout=get_number("tally", "timeout", TallySettings.timeout, float, 5, 3600),
        retries=get_number("tally", "retries", TallySettings.retries, int, 0, 10),
        export_mode=get("tally", "export_mode", "collection").lower(),
        request_encoding=get("tally", "request_encoding", "utf-8").lower(),
        chunk_days=get_number("tally", "chunk_days", TallySettings.chunk_days, int, 1, 366),
    )
    parsed = urlparse(tally.url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        errors.append("[tally] url must look like http://localhost:9000 (got %r)" % tally.url)
    if not tally.company:
        errors.append("[tally] company is required: the exact company name as shown in Tally "
                      "(e.g. 'Demo Company').")
    if tally.export_mode not in ("collection", "daybook"):
        errors.append("[tally] export_mode must be 'collection' or 'daybook' (got %r)" % tally.export_mode)
    if tally.request_encoding not in ("utf-8", "utf-16"):
        errors.append("[tally] request_encoding must be 'utf-8' or 'utf-16' (got %r)" % tally.request_encoding)

    api_key_env = get("api", "api_key_env", DEFAULT_API_KEY_ENV) or DEFAULT_API_KEY_ENV
    api = ApiSettings(
        apps_script_url=get("api", "apps_script_url"),
        api_key_env=api_key_env,
        api_key=(env.get(api_key_env) or "").strip(),
        timeout=get_number("api", "timeout", ApiSettings.timeout, float, 10, 3600),
        retries=get_number("api", "retries", ApiSettings.retries, int, 0, 10),
    )
    if api.apps_script_url:
        parsed = urlparse(api.apps_script_url)
        if parsed.scheme != "https" or not parsed.netloc:
            errors.append("[api] apps_script_url must be an https URL "
                          "(https://script.google.com/macros/s/<id>/exec), got %r" % api.apps_script_url)
    if require_api:
        if not api.apps_script_url:
            errors.append("[api] apps_script_url is required (the /exec URL of the Apps Script web app).")
        if not api.api_key:
            errors.append("Environment variable %s is not set. Set it once with:  setx %s \"<connector key>\"  "
                          "and open a new terminal." % (api_key_env, api_key_env))

    sync = SyncSettings(
        batch_size=get_number("sync", "batch_size", SyncSettings.batch_size, int, 1, 500),
        masters_batch_size=get_number("sync", "masters_batch_size", SyncSettings.masters_batch_size, int, 50, 5000),
        interval_seconds=get_number("sync", "interval_seconds", SyncSettings.interval_seconds, int, 30, 86400),
        poll_seconds=get_number("sync", "poll_seconds", SyncSettings.poll_seconds, int, 5, 3600),
        from_date=get("sync", "from_date"),
        state_dir=get("sync", "state_dir", "state") or "state",
        log_dir=get("sync", "log_dir", "logs") or "logs",
        log_level=(get("sync", "log_level", "INFO") or "INFO").upper(),
    )
    if sync.from_date:
        iso = parse_tally_date(sync.from_date)
        if not iso:
            errors.append("[sync] from_date must be a date like 2026-04-01 (got %r)" % sync.from_date)
        sync.from_date = iso
    if sync.log_level not in ("DEBUG", "INFO", "WARNING", "ERROR"):
        errors.append("[sync] log_level must be DEBUG, INFO, WARNING or ERROR (got %r)" % sync.log_level)
    sync.state_dir = os.path.normpath(os.path.join(base_dir, os.path.expandvars(sync.state_dir)))
    sync.log_dir = os.path.normpath(os.path.join(base_dir, os.path.expandvars(sync.log_dir)))

    if errors:
        where = source or "(no config file found; using environment variables only)"
        raise ConfigError("Invalid configuration in %s:\n  - %s" % (where, "\n  - ".join(errors)))
    return AppConfig(tally=tally, api=api, sync=sync, source_path=source or "")


__all__ = ["AppConfig", "TallySettings", "ApiSettings", "SyncSettings", "ConfigError",
           "load_config", "find_config_file", "DEFAULT_API_KEY_ENV"]
